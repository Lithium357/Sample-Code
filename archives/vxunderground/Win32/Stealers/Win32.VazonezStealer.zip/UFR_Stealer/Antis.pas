unit Antis;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls, ExtCtrls, Menus, sButton, sEdit, sListBox, sGroupBox,
  sCheckBox;

type
  TForm12 = class(TForm)
    ListBox1: TsListBox;
    Edit1: TsEdit;
    Button3: TsButton;
    CheckBox1: TsCheckBox;
    CheckBox2: TsCheckBox;
    Image1: TImage;
    Image2: TImage;
    GroupBox1: TsGroupBox;
    PopupMenu1: TPopupMenu;
    N1: TMenuItem;
    Image3: TImage;
    CheckBox3: TsCheckBox;
    Image4: TImage;
    CheckBox4: TsCheckBox;
    Image5: TImage;
    CheckBox5: TsCheckBox;
    Image6: TImage;
    CheckBox6: TsCheckBox;
    Image7: TImage;
    CheckBox7: TsCheckBox;
    Image8: TImage;
    CheckBox8: TsCheckBox;
    Image9: TImage;
    Image10: TImage;
    CheckBox9: TsCheckBox;
    CheckBox10: TsCheckBox;
    procedure N1Click(Sender: TObject);
    procedure Button3Click(Sender: TObject);
    procedure FormDestroy(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure FormClose(Sender: TObject; var Action: TCloseAction);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  Form12: TForm12;

implementation

uses Unit3;

{$R *.dfm}

procedure TForm12.FormClose(Sender: TObject; var Action: TCloseAction);
begin
  EnableWindow(unit3.Form3.Handle, true);
  BringWindowToTop(unit3.Form3.Handle);
  Action := caFree;
end;

procedure TForm12.FormCreate(Sender: TObject);
var
  i:integer;
begin
  if bs.anti_dbg=1 then checkbox3.Checked:=true else checkbox3.Checked:=false;
  if bs.anti_vbox=1 then checkbox4.Checked:=true else checkbox4.Checked:=false;
  if bs.anti_ws=1 then checkbox1.Checked:=true else checkbox1.Checked:=false;
  if bs.anti_vm=1 then checkbox2.Checked:=true else checkbox2.Checked:=false;
  if bs.anti_anubis=1 then checkbox5.Checked:=true else checkbox5.Checked:=false;
  if bs.anti_sbie=1 then checkbox6.Checked:=true else checkbox6.Checked:=false;
  if bs.anti_procexp=1 then checkbox7.Checked:=true else checkbox7.Checked:=false;
  if bs.anti_procmon=1 then checkbox8.Checked:=true else checkbox8.Checked:=false;
  if bs.anti_filemon=1 then checkbox9.Checked:=true else checkbox9.Checked:=false;
  if bs.anti_regmon=1 then checkbox10.Checked:=true else checkbox10.Checked:=false;

  if bs.anti_fc>0 then
  for i:=0 to bs.anti_fc-1 do listbox1.Items.Add(bs.anti_exes[i]);
end;

procedure TForm12.FormDestroy(Sender: TObject);
var
  i:integer;
begin
  if checkbox3.Checked then bs.anti_dbg:=1 else bs.anti_dbg:=0;
  if checkbox4.Checked then bs.anti_vbox:=1 else bs.anti_vbox:=0;
  if checkbox1.Checked then bs.anti_ws:=1 else bs.anti_ws:=0;
  if checkbox2.Checked then bs.anti_vm:=1 else bs.anti_vm:=0;
  if checkbox5.Checked then bs.anti_anubis:=1 else bs.anti_anubis:=0;
  if checkbox6.Checked then bs.anti_sbie:=1 else bs.anti_sbie:=0;
  if checkbox7.Checked then bs.anti_procexp:=1 else bs.anti_procexp:=0;
  if checkbox8.Checked then bs.anti_procmon:=1 else bs.anti_procmon:=0;
  if checkbox9.Checked then bs.anti_filemon:=1 else bs.anti_filemon:=0;
  if checkbox10.Checked then bs.anti_regmon:=1 else bs.anti_regmon:=0;

  bs.anti_fc:=listbox1.Items.Count;
  if listbox1.Items.Count>0 then
  for i:=0 to listbox1.Items.Count-1 do bs.anti_exes[i]:=listbox1.Items[i];
end;

procedure TForm12.Button3Click(Sender: TObject);
begin
  if edit1.text<>'' then listbox1.items.add(edit1.text);
end;

procedure TForm12.N1Click(Sender: TObject);
begin
  if listbox1.ItemIndex<>-1 then listbox1.Items.Delete(listbox1.ItemIndex);
end;

end.
