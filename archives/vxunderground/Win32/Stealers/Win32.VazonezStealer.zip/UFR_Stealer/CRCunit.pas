unit CRCunit;

interface

Uses
    windows;

function GetNewCRC(OldCRC: dword; StPtr: dword; StLen: dword): dword;

implementation
var
  CRCtable: array[0..255] of cardinal;

function GetNewCRC(OldCRC: dword; StPtr: dword; StLen: dword): dword;
asm
  test edx,edx;
  jz @ret;
  neg ecx;
  jz @ret;
  sub edx,ecx; // Address after last element

  push ebx;
  mov ebx,0; // Set ebx=0 & align @next
@next:
  mov bl,al;
  xor bl,byte [edx+ecx];
  shr eax,8;
  xor eax,cardinal [CRCtable+ebx*4];
  inc ecx;
  jnz @next;
  pop ebx;
  not eax
@ret:
end;

procedure CRCInit;
var
  c: cardinal;
  i, j: integer;
begin
  for i := 0 to 255 do
  begin
    c := i;
    for j := 1 to 8 do
      if odd(c) then
        c := (c shr 1) xor $EDB88320
      else
        c := (c shr 1);
    CRCtable[i] := c;
  end;
end;

initialization
  CRCinit;
end.
