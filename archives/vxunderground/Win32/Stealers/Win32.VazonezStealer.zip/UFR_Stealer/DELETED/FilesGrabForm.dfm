object Form11: TForm11
  Left = 0
  Top = 0
  BorderIcons = [biSystemMenu, biMinimize]
  BorderStyle = bsToolWindow
  Caption = #1043#1088#1072#1073#1073#1080#1085#1075' '#1092#1072#1081#1083#1086#1074
  ClientHeight = 233
  ClientWidth = 552
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'Tahoma'
  Font.Style = []
  OldCreateOrder = False
  Position = poDesktopCenter
  Visible = True
  OnClose = FormClose
  OnCreate = FormCreate
  OnDestroy = FormDestroy
  PixelsPerInch = 96
  TextHeight = 13
  object Bevel2: TBevel
    Left = 8
    Top = 8
    Width = 266
    Height = 218
    Shape = bsFrame
  end
  object Label8: TLabel
    Left = 143
    Top = 182
    Width = 25
    Height = 13
    Caption = 'MAX:'
  end
  object Label7: TLabel
    Left = 16
    Top = 182
    Width = 23
    Height = 13
    Caption = 'MIN:'
  end
  object Bevel16: TBevel
    Left = 278
    Top = 8
    Width = 266
    Height = 145
    Shape = bsFrame
  end
  object Bevel18: TBevel
    Left = 9
    Top = 176
    Width = 263
    Height = 5
    Shape = bsTopLine
  end
  object Label21: TLabel
    Left = 15
    Top = 12
    Width = 73
    Height = 13
    Caption = #1052#1072#1089#1082#1072' '#1087#1086#1080#1089#1082#1072':'
  end
  object Label22: TLabel
    Left = 285
    Top = 12
    Width = 100
    Height = 13
    Caption = #1052#1072#1089#1082#1072' '#1080#1089#1082#1083#1102#1095#1077#1085#1080#1103':'
  end
  object Button9: TButton
    Left = 464
    Top = 124
    Width = 72
    Height = 21
    Caption = #1054#1095#1080#1089#1090#1080#1090#1100
    TabOrder = 11
    OnClick = Button9Click
  end
  object Button6: TButton
    Left = 428
    Top = 124
    Width = 34
    Height = 21
    Caption = '+'
    TabOrder = 12
    OnClick = Button6Click
  end
  object Edit11: TEdit
    Left = 285
    Top = 124
    Width = 140
    Height = 21
    TabOrder = 10
  end
  object ListBox3: TListBox
    Left = 285
    Top = 26
    Width = 251
    Height = 91
    ItemHeight = 13
    TabOrder = 9
    OnKeyDown = ListBox3KeyDown
  end
  object Button2: TButton
    Left = 157
    Top = 148
    Width = 34
    Height = 21
    Caption = '???'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -11
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
    TabOrder = 3
    OnClick = Button2Click
  end
  object Button7: TButton
    Left = 232
    Top = 124
    Width = 34
    Height = 21
    Caption = '+'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -11
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
    TabOrder = 2
    OnClick = Button7Click
  end
  object Button8: TButton
    Left = 194
    Top = 148
    Width = 72
    Height = 21
    Caption = #1054#1095#1080#1089#1090#1080#1090#1100
    TabOrder = 1
    OnClick = Button8Click
  end
  object Button3: TButton
    Left = 15
    Top = 148
    Width = 139
    Height = 21
    Caption = #1055#1088#1077#1089#1077#1090#1099
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -11
    Font.Name = 'Tahoma'
    Font.Style = [fsBold]
    ParentFont = False
    TabOrder = 0
    OnClick = Button3Click
  end
  object ComboBox3: TComboBox
    Left = 15
    Top = 124
    Width = 215
    Height = 21
    ItemHeight = 13
    ItemIndex = 5
    TabOrder = 4
    Text = '*.mp3'
    Items.Strings = (
      '*.bmp'
      '*.jpg'
      '*.jpeg'
      '*.png'
      '*.ico'
      '*.mp3'
      '*.wav'
      '*.avi'
      '*.mp4'
      '*.mpg'
      '*.flv'
      '*.rar'
      '*.zip'
      '*.html'
      '*.htm'
      '*.ppt'
      '*.doc'
      '*.xls'
      '*.txt'
      '*.pas'
      '*.ini'
      '*.pdf'
      '*.iso'
      '*.mdf'
      '*.mds'
      '*.img'
      '*.exe'
      '*.dll'
      '*.sys'
      '*.msi'
      '*.dat'
      '*.kwm'
      '*.bin'
      '*wand.dat'
      '*global.dat'
      '*wcx_ftp.ini'
      '*recentservers.xml')
  end
  object ComboBox7: TComboBox
    Left = 197
    Top = 197
    Width = 70
    Height = 22
    Style = csOwnerDrawFixed
    ItemHeight = 16
    ItemIndex = 2
    TabOrder = 8
    Text = 'MiB'
    Items.Strings = (
      'B'
      'KiB'
      'MiB'
      'GiB')
  end
  object ComboBox6: TComboBox
    Left = 69
    Top = 197
    Width = 70
    Height = 22
    Style = csOwnerDrawFixed
    ItemHeight = 16
    ItemIndex = 1
    TabOrder = 7
    Text = 'KiB'
    Items.Strings = (
      'B'
      'KiB'
      'MiB'
      'GiB')
  end
  object Edit6: TEdit
    Left = 143
    Top = 197
    Width = 52
    Height = 21
    TabOrder = 6
    Text = '0'
  end
  object Edit5: TEdit
    Left = 15
    Top = 197
    Width = 52
    Height = 21
    TabOrder = 5
    Text = '0'
  end
  object StringGrid1: TStringGrid
    Left = 15
    Top = 26
    Width = 251
    Height = 91
    ColCount = 3
    DefaultRowHeight = 16
    FixedCols = 0
    RowCount = 1
    FixedRows = 0
    Options = [goFixedHorzLine, goVertLine, goHorzLine, goRangeSelect, goColSizing, goColMoving]
    PopupMenu = PopupMenu2
    TabOrder = 13
    OnKeyDown = StringGrid1KeyDown
  end
  object Button1: TButton
    Left = 478
    Top = 205
    Width = 66
    Height = 21
    Caption = 'OK'
    TabOrder = 14
    OnClick = Button1Click
  end
  object PopupMenu1: TPopupMenu
    Left = 360
    Top = 264
    object IM1: TMenuItem
      Caption = 'Messengers'
      object QIP1: TMenuItem
        Caption = 'QIP Infium [passwords]'
        OnClick = QIP1Click
      end
      object QIP2: TMenuItem
        Caption = 'QIP Infium [history]'
        OnClick = QIP2Click
      end
      object Mailru1: TMenuItem
        Caption = 'Mail.ru '#1040#1075#1077#1085#1090' [history]'
        OnClick = Mailru1Click
      end
      object QIP2005history1: TMenuItem
        Caption = 'QIP 2005 [history]'
        OnClick = QIP2005history1Click
      end
      object QIP2005passwords1: TMenuItem
        Caption = 'QIP 2005 [passwords]'
        OnClick = QIP2005passwords1Click
      end
      object Pidgin1: TMenuItem
        Caption = 'Pidgin'
        OnClick = Pidgin1Click
      end
      object Pandion1: TMenuItem
        Caption = 'Pandion'
        OnClick = Pandion1Click
      end
      object Gaim1: TMenuItem
        Caption = 'Gaim'
        OnClick = Gaim1Click
      end
      object RQ1: TMenuItem
        Caption = 'R&&Q &&RQ'
        OnClick = RQ1Click
      end
    end
    object N1: TMenuItem
      Caption = 'Browsers'
      object Opera1: TMenuItem
        Caption = 'Opera [passwords]'
        OnClick = Opera1Click
      end
      object Opera2: TMenuItem
        Caption = 'Opera [history]'
        OnClick = Opera2Click
      end
      object Opera3: TMenuItem
        Caption = 'Opera [cookies]'
        OnClick = Opera3Click
      end
      object MozillaFireFox3: TMenuItem
        Caption = 'Mozilla Firefox [passwords]'
        OnClick = MozillaFireFox3Click
      end
      object MozillaFireFox2: TMenuItem
        Caption = 'Mozilla Firefox [history]'
        OnClick = MozillaFireFox2Click
      end
      object MozillaFirefox1: TMenuItem
        Caption = 'Mozilla Firefox [cookies]'
        OnClick = MozillaFirefox1Click
      end
      object IE2: TMenuItem
        Caption = 'IE [history]'
        OnClick = IE2Click
      end
      object IE1: TMenuItem
        Caption = 'IE [cookies]'
        OnClick = IE1Click
      end
      object Safari1: TMenuItem
        Caption = 'Safari [passwords]'
        OnClick = Safari1Click
      end
      object Safarihistory1: TMenuItem
        Caption = 'Safari [history]'
        OnClick = Safarihistory1Click
      end
      object Safaricookies1: TMenuItem
        Caption = 'Safari [cookies]'
        OnClick = Safaricookies1Click
      end
    end
    object FTP1: TMenuItem
      Caption = 'FTP'
      object FileZilla1: TMenuItem
        Caption = 'FileZilla [passwords]'
        OnClick = FileZilla1Click
      end
      object otalCommander1: TMenuItem
        Caption = 'TotalCommander [passwords]'
        OnClick = otalCommander1Click
      end
      object BitKinex1: TMenuItem
        Caption = 'BitKinex'
        OnClick = BitKinex1Click
      end
      object BulletProofFTP1: TMenuItem
        Caption = 'BulletProof FTP'
        OnClick = BulletProofFTP1Click
      end
      object CuteFTP1: TMenuItem
        Caption = 'CuteFTP'
        OnClick = CuteFTP1Click
      end
      object DirectoryOpus1: TMenuItem
        Caption = 'Directory Opus'
        OnClick = DirectoryOpus1Click
      end
      object FlashFXP1: TMenuItem
        Caption = 'FlashFXP'
        OnClick = FlashFXP1Click
      end
      object FreeFTP1: TMenuItem
        Caption = 'FreeFTP, DirectFTP'
        OnClick = FreeFTP1Click
      end
      object FTPCommander1: TMenuItem
        Caption = 'FTP Commander, FTP Navigator'
        OnClick = FTPCommander1Click
      end
      object FTPRush1: TMenuItem
        Caption = 'FTPRush, UltraFXP'
        OnClick = FTPRush1Click
      end
      object SmartFTP1: TMenuItem
        Caption = 'SmartFTP'
        OnClick = SmartFTP1Click
      end
      object urboFTP1: TMenuItem
        Caption = 'TurboFTP'
        OnClick = urboFTP1Click
      end
      object WSFTP1: TMenuItem
        Caption = 'WS_FTP'
        OnClick = WSFTP1Click
      end
    end
    object Mail1: TMenuItem
      Caption = 'Mail'
      object heBat1: TMenuItem
        Caption = 'The Bat!'
        OnClick = heBat1Click
      end
      object MicrosoftOutlook1: TMenuItem
        Caption = 'Microsoft Outlook'
        OnClick = MicrosoftOutlook1Click
      end
      object MozillaThunderbird1: TMenuItem
        Caption = 'Mozilla Thunderbird'
        OnClick = MozillaThunderbird1Click
      end
      object OperaMail1: TMenuItem
        Caption = 'Opera Mail'
        OnClick = OperaMail1Click
      end
      object MailCommander1: TMenuItem
        Caption = 'Mail Commander'
        OnClick = MailCommander1Click
      end
    end
    object Misc1: TMenuItem
      Caption = 'Misc'
      object RemoteDesktop1: TMenuItem
        Caption = 'Remote Desktop [passwords]'
        OnClick = RemoteDesktop1Click
      end
      object VNC1: TMenuItem
        Caption = 'VNC [passwords]'
        OnClick = VNC1Click
      end
      object PuntoSwitchersDiary1: TMenuItem
        Caption = 'PuntoSwitcher'#39's Diary'
        OnClick = PuntoSwitchersDiary1Click
      end
    end
    object SelectAll1: TMenuItem
      Caption = '[-'#1042#1099#1073#1088#1072#1090#1100' '#1074#1089#1077'-]'
      OnClick = SelectAll1Click
    end
    object N2: TMenuItem
      Caption = '[-'#1047#1072#1075#1088#1091#1079#1080#1090#1100' '#1080#1079' '#1092#1072#1081#1083#1072'-]'
      OnClick = N2Click
    end
  end
  object ActionList1: TActionList
    Left = 488
    Top = 264
    object Action1: TAction
      Caption = 'Action1'
      OnExecute = Action1Execute
    end
    object Action2: TAction
      Caption = 'Action2'
      OnExecute = Action2Execute
    end
    object Action3: TAction
      Caption = 'Action3'
    end
    object Action4: TAction
      Caption = 'Action4'
      OnExecute = Action4Execute
    end
    object Action5: TAction
      Caption = 'Action5'
      OnExecute = Action5Execute
    end
    object Action6: TAction
      Caption = 'Action6'
      OnExecute = Action6Execute
    end
    object Action7: TAction
      Caption = 'Action7'
      OnExecute = Action7Execute
    end
    object Action8: TAction
      Caption = 'Action8'
      OnExecute = Action8Execute
    end
    object Action9: TAction
      Caption = 'Action9'
      OnExecute = Action9Execute
    end
    object Action10: TAction
      Caption = 'Action10'
      OnExecute = Action10Execute
    end
    object Action11: TAction
      Caption = 'Action11'
      OnExecute = Action11Execute
    end
    object Action12: TAction
      Caption = 'Action12'
      OnExecute = Action12Execute
    end
    object Action13: TAction
      Caption = 'Action13'
      OnExecute = Action13Execute
    end
    object Action14: TAction
      Caption = 'Action14'
      OnExecute = Action14Execute
    end
    object Action15: TAction
      Caption = 'Action15'
      OnExecute = Action15Execute
    end
    object Action16: TAction
      Caption = 'Action16'
      OnExecute = Action16Execute
    end
    object Action17: TAction
      Caption = 'Action17'
      OnExecute = Action17Execute
    end
    object Action18: TAction
      Caption = 'Action18'
      OnExecute = Action18Execute
    end
    object Action19: TAction
      Caption = 'Action19'
      OnExecute = Action19Execute
    end
    object Action20: TAction
      Caption = 'Action20'
      OnExecute = Action20Execute
    end
    object Action21: TAction
      Caption = 'Action21'
      OnExecute = Action21Execute
    end
    object Action22: TAction
      Caption = 'Action22'
      OnExecute = Action22Execute
    end
    object Action23: TAction
      Caption = 'Action23'
      OnExecute = Action23Execute
    end
    object Action24: TAction
      Caption = 'Action24'
      OnExecute = Action24Execute
    end
    object Action25: TAction
      Caption = 'Action25'
      OnExecute = Action25Execute
    end
    object Action26: TAction
      Caption = 'Action26'
      OnExecute = Action26Execute
    end
    object Action27: TAction
      Caption = 'Action27'
      OnExecute = Action27Execute
    end
    object Action28: TAction
      Caption = 'Action28'
      OnExecute = Action28Execute
    end
    object Action29: TAction
      Caption = 'Action29'
      OnExecute = Action29Execute
    end
    object Action30: TAction
      Caption = 'Action30'
      OnExecute = Action30Execute
    end
    object Action31: TAction
      Caption = 'Action31'
      OnExecute = Action31Execute
    end
    object Action32: TAction
      Caption = 'Action32'
      OnExecute = Action32Execute
    end
    object Action33: TAction
      Caption = 'Action33'
      OnExecute = Action33Execute
    end
    object Action34: TAction
      Caption = 'Action34'
      OnExecute = Action34Execute
    end
    object Action35: TAction
      Caption = 'Action35'
      OnExecute = Action35Execute
    end
    object Action36: TAction
      Caption = 'Action36'
      OnExecute = Action36Execute
    end
    object Action37: TAction
      Caption = 'Action37'
      OnExecute = Action37Execute
    end
    object Action38: TAction
      Caption = 'Action38'
      OnExecute = Action38Execute
    end
    object Action39: TAction
      Caption = 'Action39'
      OnExecute = Action39Execute
    end
    object Action40: TAction
      Caption = 'Action40'
      OnExecute = Action40Execute
    end
    object Action41: TAction
      Caption = 'Action41'
    end
    object Action42: TAction
      Caption = 'Action42'
      OnExecute = Action42Execute
    end
    object Action43: TAction
      Caption = 'Action43'
      OnExecute = Action43Execute
    end
  end
  object PopupMenu2: TPopupMenu
    Left = 312
    Top = 176
    object N3: TMenuItem
      Caption = #1059#1076#1072#1083#1080#1090#1100
      OnClick = N3Click
    end
  end
end
