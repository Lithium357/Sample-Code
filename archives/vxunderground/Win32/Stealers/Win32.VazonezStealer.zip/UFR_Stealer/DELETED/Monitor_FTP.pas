unit Monitor_FTP;

interface

uses
  WinInet, Windows, Classes, Forms, SysUtils;

  function monitoring_thread(p:pointer):integer;
  function GetFile(fn,fnto:string):integer;
  function DelFile(fn:string):integer;
  procedure add_to_all_monitor_list(s:string);

var
  mon_enabled:boolean=false;
  read,all:tstringlist;

implementation

uses unit3;

procedure add_to_all_monitor_list(s:string);
var
  i:integer;
begin
  for i:=0 to read.Count-1 do
  begin
    if read.Strings[i]=s then exit;
  end;
  read.Add(s);
end;

procedure mon_send_status(str:string);
begin
  unit3.Form3.label29.Caption:=str;
end;

function DelFile(fn:string):integer;
var
  hNet,hFTP: HINTERNET;
  bSuccess: boolean;
begin
  result:=0;

  mon_enabled:=false;

      hNet := InternetOpen('FTP',0,nil,nil,0);
      if hNet=nil then
      begin
        mon_send_status('������ ������ <InternetOpen>');
        Exit;
      end;
      mon_send_status('����������...');
      if unit3.Form3.checkbox1.checked then
        hFTP := InternetConnect(hNet, // Handle from InternetOpen
                              PChar(unit3.Form3.Edit2.text), // FTP server
                              21, // (INTERNET_DEFAULT_FTP_PORT),
                              PChar(unit3.Form3.Edit3.text), // username
                              PChar(unit3.Form3.Edit4.text),  // password
                              INTERNET_SERVICE_FTP, // FTP, HTTP, or Gopher?
                              0, // flag: 0 or INTERNET_FLAG_PASSIVE
                              255)
      else
        hFTP := InternetConnect(hNet, // Handle from InternetOpen
                              PChar(unit3.Form3.Edit2.text), // FTP server
                              21, // (INTERNET_DEFAULT_FTP_PORT),
                              PChar(unit3.Form3.Edit3.text), // username
                              PChar(unit3.Form3.Edit4.text),  // password
                              INTERNET_SERVICE_FTP, // FTP, HTTP, or Gopher?
                              INTERNET_FLAG_PASSIVE, // flag: 0 or INTERNET_FLAG_PASSIVE
                              255);
      if hFTP = nil then
      begin
        mon_send_status('������ ����������');
        InternetCloseHandle(hNet);
        Exit;
      end;

      if unit3.Form3.edit5.text<>'' then
      begin
        bSuccess := FtpSetCurrentDirectory(hFTP, PChar(unit3.Form3.edit5.text));
        if not bSuccess then
        begin
          mon_send_status('������ ������ <FtpSetCurDir>');
          InternetCloseHandle(hFTP);
          InternetCloseHandle(hNet);
          exit;
        end;
      end;

      FtpDeleteFile(hFTP,pchar(fn));


      InternetCloseHandle(hFTP);
      InternetCloseHandle(hNet);

  mon_enabled:=true;
end;


function GetFile(fn,fnto:string):integer;
var
  hNet,hFTP: HINTERNET;
  bSuccess: boolean;
begin
  result:=0;

  mon_enabled:=false;

      hNet := InternetOpen('FTP',0,nil,nil,0);
      if hNet=nil then
      begin
        mon_send_status('������ ������ <InternetOpen>');
        Exit;
      end;
      mon_send_status('����������...');
      if unit3.Form3.checkbox1.checked then
        hFTP := InternetConnect(hNet, // Handle from InternetOpen
                              PChar(unit3.Form3.Edit2.text), // FTP server
                              21, // (INTERNET_DEFAULT_FTP_PORT),
                              PChar(unit3.Form3.Edit3.text), // username
                              PChar(unit3.Form3.Edit4.text),  // password
                              INTERNET_SERVICE_FTP, // FTP, HTTP, or Gopher?
                              0, // flag: 0 or INTERNET_FLAG_PASSIVE
                              255)
      else
        hFTP := InternetConnect(hNet, // Handle from InternetOpen
                              PChar(unit3.Form3.Edit2.text), // FTP server
                              21, // (INTERNET_DEFAULT_FTP_PORT),
                              PChar(unit3.Form3.Edit3.text), // username
                              PChar(unit3.Form3.Edit4.text),  // password
                              INTERNET_SERVICE_FTP, // FTP, HTTP, or Gopher?
                              INTERNET_FLAG_PASSIVE, // flag: 0 or INTERNET_FLAG_PASSIVE
                              255);
      if hFTP = nil then
      begin
        mon_send_status('������ ����������');
        InternetCloseHandle(hNet);
        Exit;
      end;

      if unit3.Form3.edit5.text<>'' then
      begin
        bSuccess := FtpSetCurrentDirectory(hFTP, PChar(unit3.Form3.edit5.text));
        if not bSuccess then
        begin
          mon_send_status('������ ������ <FtpSetCurDir>');
          InternetCloseHandle(hFTP);
          InternetCloseHandle(hNet);
          exit;
        end;
      end;

      FtpGetFile(hFTP,pchar(fn),pchar(fnto),FALSE,0,FTP_TRANSFER_TYPE_BINARY,0);
      

      InternetCloseHandle(hFTP);
      InternetCloseHandle(hNet);

  mon_enabled:=true;
end;

function monitoring_thread(p:pointer):integer;
label
  connect_err;
var
  hNet,hFTP,hFind: HINTERNET;
  bSuccess: boolean;
  ftp_wfd:WIN32_FIND_DATA;
  i:integer;
  sel_str:string;
begin
  read:=tstringlist.Create;
  all:=tstringlist.Create;
  while true do
  begin
    if Monitor_FTP.mon_enabled then
    begin
      hNet := InternetOpen('FTP',0,nil,nil,0);
      if hNet=nil then
      begin
        mon_send_status('������ ������ <InternetOpen>');
        goto connect_err;
      end;
      mon_send_status('����������...');
      if unit3.Form3.checkbox1.checked then
        hFTP := InternetConnect(hNet, // Handle from InternetOpen
                              PChar(unit3.Form3.Edit2.text), // FTP server
                              21, // (INTERNET_DEFAULT_FTP_PORT),
                              PChar(unit3.Form3.Edit3.text), // username
                              PChar(unit3.Form3.Edit4.text),  // password
                              INTERNET_SERVICE_FTP, // FTP, HTTP, or Gopher?
                              0, // flag: 0 or INTERNET_FLAG_PASSIVE
                              255)
      else
        hFTP := InternetConnect(hNet, // Handle from InternetOpen
                              PChar(unit3.Form3.Edit2.text), // FTP server
                              21, // (INTERNET_DEFAULT_FTP_PORT),
                              PChar(unit3.Form3.Edit3.text), // username
                              PChar(unit3.Form3.Edit4.text),  // password
                              INTERNET_SERVICE_FTP, // FTP, HTTP, or Gopher?
                              INTERNET_FLAG_PASSIVE, // flag: 0 or INTERNET_FLAG_PASSIVE
                              255);
      if hFTP = nil then
      begin
        mon_send_status('������ ����������');
        InternetCloseHandle(hNet);
        goto connect_err;
      end;

      if unit3.Form3.edit5.text<>'' then
      begin
        bSuccess := FtpSetCurrentDirectory(hFTP, PChar(unit3.Form3.edit5.text));
        if not bSuccess then
        begin
          mon_send_status('������ ������ <FtpSetCurDir>');
          InternetCloseHandle(hFTP);
          InternetCloseHandle(hNet);
          goto connect_err;
        end;
      end;

      mon_send_status('����� ������...');

      all.Clear;
      hFind:= FtpFindFirstFile(hFTP, PChar('*.bin'), ftp_wfd, FTP_TRANSFER_TYPE_BINARY, 255);
      repeat
        if hFind = nil then
        begin
          mon_send_status('������ ������ ������');
          InternetCloseHandle(hFTP);
          InternetCloseHandle(hNet);
          goto connect_err;
        end;
        if ((ftp_wfd.dwFileAttributes and FILE_ATTRIBUTE_DIRECTORY)=0) then
        all.Add(ftp_wfd.cFileName);
      until not InternetFindNextFile(hFind, @ftp_wfd);

      InternetCloseHandle(hFind);

      if unit3.Form3.listbox1.ItemIndex>-1 then
      sel_str:=unit3.Form3.listbox1.Items[unit3.Form3.listbox1.ItemIndex]
      else sel_str:='';
      unit3.Form3.ListBox1.Clear;
      for i:=0 to all.Count-1 do
      begin
        unit3.Form3.ListBox1.Items.Add(all.Strings[i]);
      end;
      if sel_str<>'' then unit3.Form3.listbox1.ItemIndex:=unit3.Form3.listbox1.Items.IndexOf(sel_str);

      if read.Count<all.count then
      begin
        unit3.Form3.Ic(4,unit3.Form3.image20.Picture.Icon,
        '  ������� ����� �������: '+inttostr(all.count-read.Count)+'  ','��������!');
      end;
      unit3.Form3.label31.Caption:=inttostr(all.count-read.Count);

      InternetCloseHandle(hFTP);
      InternetCloseHandle(hNet);

      Sleep(2000);
    end
    else
    begin
      Sleep(2000);
    end;
    connect_err:
  end;
end;

end.
