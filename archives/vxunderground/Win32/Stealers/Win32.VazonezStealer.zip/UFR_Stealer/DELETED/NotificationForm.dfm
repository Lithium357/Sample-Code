object Form4: TForm4
  Left = 0
  Top = 0
  BorderIcons = [biSystemMenu, biMinimize]
  BorderStyle = bsToolWindow
  Caption = #1054#1087#1094#1080#1080' '#1085#1086#1090#1080#1092#1080#1082#1072#1094#1080#1080
  ClientHeight = 226
  ClientWidth = 279
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'Tahoma'
  Font.Style = []
  OldCreateOrder = False
  Position = poDesktopCenter
  Visible = True
  OnClose = FormClose
  OnCreate = FormCreate
  OnDestroy = FormDestroy
  PixelsPerInch = 96
  TextHeight = 13
  object Memo1: TMemo
    Left = 24
    Top = 110
    Width = 250
    Height = 85
    TabOrder = 0
  end
  object RadioButton3: TRadioButton
    Left = 5
    Top = 20
    Width = 106
    Height = 17
    Caption = #1057#1086#1079#1076#1072#1090#1100' '#1092#1072#1081#1083
    TabOrder = 1
    OnClick = RadioButton3Click
  end
  object RadioButton2: TRadioButton
    Left = 5
    Top = 64
    Width = 106
    Height = 17
    Caption = #1057#1086#1086#1073#1097#1077#1085#1080#1077':'
    TabOrder = 2
    OnClick = RadioButton2Click
  end
  object RadioButton1: TRadioButton
    Left = 5
    Top = 4
    Width = 106
    Height = 17
    Caption = #1058#1080#1093#1080#1081' '#1088#1077#1078#1080#1084
    Checked = True
    TabOrder = 3
    TabStop = True
    OnClick = RadioButton1Click
  end
  object Edit8: TEdit
    Left = 24
    Top = 84
    Width = 124
    Height = 21
    MaxLength = 255
    TabOrder = 4
  end
  object ComboBox1: TComboBox
    Left = 154
    Top = 84
    Width = 121
    Height = 22
    Style = csOwnerDrawFixed
    ItemHeight = 16
    ItemIndex = 1
    TabOrder = 5
    Text = #1048#1085#1092#1086#1088#1084#1072#1094#1080#1103
    Items.Strings = (
      #1054#1096#1080#1073#1082#1072
      #1048#1085#1092#1086#1088#1084#1072#1094#1080#1103
      #1055#1088#1077#1076#1091#1087#1088#1077#1078#1076#1077#1085#1080#1077)
  end
  object Edit1: TEdit
    Left = 24
    Top = 40
    Width = 250
    Height = 21
    Enabled = False
    TabOrder = 6
  end
  object Button1: TButton
    Left = 5
    Top = 200
    Width = 269
    Height = 21
    Caption = #1054#1050
    TabOrder = 7
    OnClick = Button1Click
  end
end
