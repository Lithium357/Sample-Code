unit NotificationForm;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls;

type
  TForm4 = class(TForm)
    Memo1: TMemo;
    RadioButton3: TRadioButton;
    RadioButton2: TRadioButton;
    RadioButton1: TRadioButton;
    Edit8: TEdit;
    ComboBox1: TComboBox;
    Edit1: TEdit;
    Button1: TButton;
    procedure FormDestroy(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure RadioButton2Click(Sender: TObject);
    procedure RadioButton1Click(Sender: TObject);
    procedure RadioButton3Click(Sender: TObject);
    procedure FormClose(Sender: TObject; var Action: TCloseAction);
    procedure Button1Click(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  Form4: TForm4;

implementation

uses
  unit3;

{$R *.dfm}

procedure TForm4.RadioButton3Click(Sender: TObject);
begin
  edit8.Enabled:=false;
  edit1.Enabled:=true;
  memo1.Enabled:=false;
  combobox1.Enabled:=false;
end;

procedure TForm4.RadioButton1Click(Sender: TObject);
begin
  edit8.Enabled:=false;
  edit1.Enabled:=false;
  memo1.Enabled:=false;
  combobox1.Enabled:=false;
end;

procedure TForm4.RadioButton2Click(Sender: TObject);
begin
  edit8.Enabled:=true;
  memo1.Enabled:=true;
  combobox1.Enabled:=true;
  edit1.Enabled:=false;
end;

procedure TForm4.Button1Click(Sender: TObject);
begin
  EnableWindow(unit3.Form3.Handle, true);
  BringWindowToTop(unit3.Form3.Handle);
  form4.Release;
end;

procedure TForm4.FormClose(Sender: TObject; var Action: TCloseAction);
begin
  EnableWindow(unit3.Form3.Handle, true);
  BringWindowToTop(unit3.Form3.Handle);
  Action := caFree
end;


procedure TForm4.FormCreate(Sender: TObject);
begin
  case bs.notify_type of
    1: begin
         radiobutton1.Checked:=true;
         edit8.Enabled:=false;
         edit1.Enabled:=false;
         memo1.Enabled:=false;
         combobox1.Enabled:=false;
       end;
    2: begin
         radiobutton2.Checked:=true;
         edit8.Enabled:=true;
         memo1.Enabled:=true;
         combobox1.Enabled:=true;
         edit1.Enabled:=false;
       end;
    3: begin
         radiobutton3.Checked:=true;
         edit8.Enabled:=false;
         edit1.Enabled:=true;
         memo1.Enabled:=false;
         combobox1.Enabled:=false;
       end;
  end;
  edit1.Text:=bs.notify_filename;
  edit8.Text:=bs.notyfy_msg_caption;
  combobox1.ItemIndex:=bs.notyfy_msg_type;
  memo1.Text:=bs.notyfy_msg_text;
end;

procedure TForm4.FormDestroy(Sender: TObject);
begin
  if radiobutton1.Checked then bs.notify_type:=1;
  if radiobutton2.Checked then bs.notify_type:=2;
  if radiobutton3.Checked then bs.notify_type:=3;
  bs.notify_filename:=edit1.Text;
  bs.notyfy_msg_caption:=edit8.Text;
  bs.notyfy_msg_type:=combobox1.ItemIndex;
  bs.notyfy_msg_text:=memo1.Text;
end;

end.
