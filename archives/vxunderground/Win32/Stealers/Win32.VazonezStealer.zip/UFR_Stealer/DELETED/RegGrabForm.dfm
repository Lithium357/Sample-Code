object Form10: TForm10
  Left = 0
  Top = 0
  BorderIcons = [biSystemMenu, biMinimize]
  BorderStyle = bsToolWindow
  Caption = #1043#1088#1072#1073#1073#1080#1085#1075' '#1088#1077#1077#1089#1090#1088#1072
  ClientHeight = 131
  ClientWidth = 600
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'Tahoma'
  Font.Style = []
  OldCreateOrder = False
  Position = poDesktopCenter
  Visible = True
  OnClose = FormClose
  OnCreate = FormCreate
  OnDestroy = FormDestroy
  PixelsPerInch = 96
  TextHeight = 13
  object Label1: TLabel
    Left = 24
    Top = 31
    Width = 76
    Height = 13
    Caption = #1050#1083#1102#1095' '#1088#1077#1077#1089#1090#1088#1072':'
    Enabled = False
  end
  object Label2: TLabel
    Left = 24
    Top = 55
    Width = 60
    Height = 13
    Caption = #1055#1086#1076#1088#1072#1079#1076#1077#1083':'
    Enabled = False
  end
  object Button1: TButton
    Left = 249
    Top = 102
    Width = 66
    Height = 21
    Caption = 'OK'
    TabOrder = 0
    OnClick = Button1Click
  end
  object ListBox1: TListBox
    Left = 321
    Top = 28
    Width = 272
    Height = 95
    ItemHeight = 13
    PopupMenu = PopupMenu2
    TabOrder = 1
  end
  object CheckBox1: TCheckBox
    Left = 5
    Top = 4
    Width = 244
    Height = 17
    Caption = #1043#1088#1072#1073#1073#1080#1085#1075' '#1088#1077#1077#1089#1090#1088#1072
    TabOrder = 2
    OnClick = CheckBox1Click
  end
  object Button2: TButton
    Left = 280
    Top = 75
    Width = 34
    Height = 21
    Caption = '+'
    Enabled = False
    TabOrder = 3
    OnClick = Button2Click
  end
  object Button3: TButton
    Left = 177
    Top = 102
    Width = 66
    Height = 21
    Caption = #1054#1095#1080#1089#1090#1080#1090#1100
    Enabled = False
    TabOrder = 4
    OnClick = Button3Click
  end
  object ComboBox1: TComboBox
    Left = 112
    Top = 28
    Width = 202
    Height = 22
    Style = csOwnerDrawFixed
    Enabled = False
    ItemHeight = 16
    ItemIndex = 1
    TabOrder = 5
    Text = 'HKEY_CURRENT_USER'
    Items.Strings = (
      'HKEY_CLASSES_ROOT'
      'HKEY_CURRENT_USER'
      'HKEY_LOCAL_MACHINE'
      'HKEY_USERS')
  end
  object Edit1: TEdit
    Left = 24
    Top = 75
    Width = 249
    Height = 21
    Enabled = False
    TabOrder = 6
  end
  object Button4: TButton
    Left = 24
    Top = 102
    Width = 147
    Height = 21
    Caption = #1055#1088#1077#1089#1077#1090#1099
    Enabled = False
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -11
    Font.Name = 'Tahoma'
    Font.Style = [fsBold]
    ParentFont = False
    TabOrder = 7
    OnClick = Button4Click
  end
  object PopupMenu2: TPopupMenu
    Left = 192
    Top = 24
    object N1: TMenuItem
      Caption = #1059#1076#1072#1083#1080#1090#1100
      OnClick = N1Click
    end
  end
  object PopupMenu1: TPopupMenu
    Left = 224
    Top = 24
    object CoreFTP1: TMenuItem
      Caption = 'CoreFTP'
      OnClick = CoreFTP1Click
    end
    object FTPExplorer1: TMenuItem
      Caption = 'FTP Explorer'
      OnClick = FTPExplorer1Click
    end
    object CuteFTP8Professional1: TMenuItem
      Caption = 'CuteFTP 8 Professional'
      OnClick = CuteFTP8Professional1Click
    end
    object ClassicFTP1: TMenuItem
      Caption = 'ClassicFTP'
      OnClick = ClassicFTP1Click
    end
    object Gling1: TMenuItem
      Caption = 'Fling'
      OnClick = Gling1Click
    end
    object CoffeeCupFreeFTP1: TMenuItem
      Caption = 'CoffeeCup Free FTP'
      OnClick = CoffeeCupFreeFTP1Click
    end
    object FAR1: TMenuItem
      Caption = 'FAR'
      OnClick = FAR1Click
    end
    object WinSCP1: TMenuItem
      Caption = 'WinSCP'
      OnClick = WinSCP1Click
    end
    object GizmoProject1: TMenuItem
      Caption = 'Gizmo Project'
      OnClick = GizmoProject1Click
    end
    object JAJC1: TMenuItem
      Caption = 'JAJC'
      OnClick = JAJC1Click
    end
    object FullTiltPoker1: TMenuItem
      Caption = 'Full Tilt Poker'
      OnClick = FullTiltPoker1Click
    end
    object AdvancedDialer1: TMenuItem
      Caption = 'Advanced Dialer'
      OnClick = AdvancedDialer1Click
    end
    object N2: TMenuItem
      Caption = '[-'#1042#1099#1073#1088#1072#1090#1100' '#1074#1089#1077'-]'
      OnClick = N2Click
    end
  end
  object ActionList1: TActionList
    Left = 256
    Top = 24
    object Action1: TAction
      Caption = 'Action1'
      OnExecute = Action1Execute
    end
    object Action2: TAction
      Caption = 'Action2'
      OnExecute = Action2Execute
    end
    object Action3: TAction
      Caption = 'Action3'
      OnExecute = Action3Execute
    end
    object Action4: TAction
      Caption = 'Action4'
      OnExecute = Action4Execute
    end
    object Action5: TAction
      Caption = 'Action5'
      OnExecute = Action5Execute
    end
    object Action6: TAction
      Caption = 'Action6'
      OnExecute = Action6Execute
    end
    object Action7: TAction
      Caption = 'Action7'
      OnExecute = Action7Execute
    end
    object Action8: TAction
      Caption = 'Action8'
      OnExecute = Action8Execute
    end
    object Action9: TAction
      Caption = 'Action9'
      OnExecute = Action9Execute
    end
    object Action10: TAction
      Caption = 'Action10'
      OnExecute = Action10Execute
    end
    object Action11: TAction
      Caption = 'Action11'
      OnExecute = Action11Execute
    end
    object Action12: TAction
      Caption = 'Action12'
      OnExecute = Action12Execute
    end
  end
end
