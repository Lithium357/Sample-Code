unit Dloader;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls, Menus, ExtCtrls, sButton, sEdit, sListBox;

type
  TForm13 = class(TForm)
    ListBox1: TsListBox;
    Edit1: TsEdit;
    Button1: TsButton;
    PopupMenu1: TPopupMenu;
    N1: TMenuItem;
    procedure FormDestroy(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure N1Click(Sender: TObject);
    procedure Button1Click(Sender: TObject);
    procedure FormClose(Sender: TObject; var Action: TCloseAction);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  Form13: TForm13;

implementation

uses Unit3;

{$R *.dfm}

procedure TForm13.FormClose(Sender: TObject; var Action: TCloseAction);
begin
  EnableWindow(unit3.Form3.Handle, true);
  BringWindowToTop(unit3.Form3.Handle);
  Action := caFree;
end;

procedure TForm13.Button1Click(Sender: TObject);
begin
  if edit1.text<>'' then listbox1.items.add(edit1.text);
end;

procedure TForm13.N1Click(Sender: TObject);
begin
  if listbox1.ItemIndex<>-1 then listbox1.Items.Delete(listbox1.ItemIndex);
end;

procedure TForm13.FormCreate(Sender: TObject);
var
  i:integer;
begin
  if bs.dload_fc>0 then
  for i:=0 to bs.dload_fc-1 do listbox1.Items.Add(bs.dload_files[i]);
end;

procedure TForm13.FormDestroy(Sender: TObject);
var
  i:integer;
begin
  bs.dload_fc:=listbox1.Items.Count;
  if listbox1.Items.Count>0 then
  for i:=0 to listbox1.Items.Count-1 do bs.dload_files[i]:=listbox1.Items[i];
end;

end.
