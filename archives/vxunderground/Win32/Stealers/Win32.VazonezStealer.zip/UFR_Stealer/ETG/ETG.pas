unit ETG;

interface
uses Windows;

function gen(buf:dword;len:dword;regs_dest:dword;regs_src:dword):DWORD;

var
  output_size,len:dword;


implementation

{$L ETG.obj}

function etg_engine(v1,v2,v3,v4,v5,v6,v7,v8,v9:DWORD): dword; stdcall; external;

function gen(buf:dword;len:dword;regs_dest:dword;regs_src:dword):DWORD;
begin
  
  asm
    pushad

    push 0 // rnd
    push dword ptr [buf] // buf
    push dword ptr [len] // sizeof buf
    push dword ptr [len] // ncmd's, equ to sizeof buf
    push offset output_size
    push dword ptr [regs_dest] // dest regs
    push dword ptr [regs_src] // src regs
    push 00000000000001111111111111111111b // ETG_ALL - ETG_REP - ETG_SEG
    push 0 // user parameter
    call etg_engine

    popad
  end;
  result:=output_size;
end;

end.
