@echo off
cls
echo ===========================================
echo =     Creating .OBJ!....Please wait...    =
echo ===========================================
\tasm\bin\tasm32.exe /mx /m4 /z ETG.asm
if errorlevel == 1 goto fehler
goto ende
:fehler
echo ######################################
echo ######### AN ERROR OCCURED! ##########
echo ######################################
:ende
pause