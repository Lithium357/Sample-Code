unit SQLite3Lib;
{ *******************************************************

  SQLite 3 Dynamic Library wrapper for Delphi

  2012 �ngel Fern�ndez Pineda. Madrid. Spain.

  This work is licensed under the Creative Commons
  Attribution-ShareAlike 3.0 Unported License. To
  view a copy of this license,
  visit http://creativecommons.org/licenses/by-sa/3.0/
  or send a letter to Creative Commons,
  444 Castro Street, Suite 900,
  Mountain View, California, 94041, USA.

  *******************************************************

  Files: SQLite3Constants, SQLite3Lib

  *******************************************************

  This wrapper should include sqlite3.dll as a Windows
  Resource. If sqlite3.dll is not found, it will
  be extracted to a temporary folder, then loaded.
  So there is no need to distribute that DLL along
  with an aplication.  As a result, it may be used
  as a statically linked library.

  *******************************************************

  CHANGE LOG:

  - 2012-03-22: First implementation

  TO DO:

  - Some procedures are linked but not exported
  - 64bit implementation not tested

  ******************************************************* }

interface

function isAvailable: boolean;

type
  PSQLite3 = type Pointer;
  PSQLite3_backup = type Pointer;
  Psqlite3_blob = type Pointer;
  Psqlite3_context = type Pointer;
  Psqlite3_file = type Pointer;
  psqlite3_io_methods = type Pointer;
  Psqlite3_index_info = type Pointer;
  Psqlite3_int64 = type Pointer;
  Psqlite3_uint64 = type Pointer;
  Psqlite_int64 = type Pointer;
  Psqlite_uint64 = type Pointer;
  Psqlite3_mem_methods = type Pointer;
  Psqlite3_module = type Pointer;
  Psqlite3_mutex = type Pointer;
  Psqlite3_mutex_methods = type Pointer;
  Psqlite3_pcache = type Pointer;
  Psqlite3_pcache_methods2 = type Pointer;
  Psqlite3_pcache_page = type Pointer;
  Psqlite3_stmt = type Pointer;
  Psqlite3_temp_directory = type Pointer;
  Psqlite3_value = type Pointer;
  Psqlite3_vfs = type Pointer;
  Psqlite3_vtab = type Pointer;
  Psqlite3_vtab_cursor = type Pointer;

  PUTF8Char = PAnsiChar;
  PUTF8CharArray = array of PUTF8Char;
  TSQLite3Destructor = procedure(Data: Pointer); cdecl;
  TSQLiteExecCallback = function(UserData: Pointer; NumCols: integer;
    ColValues: PUTF8CharArray; ColNames: PUTF8CharArray): integer; cdecl;

  // some inits-deinits
function DoInitialize:boolean;
procedure DoFinalize;

  // Open and close
function sqlite3_open(const filename: UTF8String; out db: PSQLite3): integer;
function sqlite3_open16(const filename: UnicodeString;
  out db: PSQLite3): integer;
function sqlite3_open_v2(const filename: UTF8String; out db: PSQLite3;
  flags: integer; zVfs: PAnsiString): integer;
function sqlite3_close(db: PSQLite3): integer;

// Statements
function sqlite3_prepare(db: PSQLite3; const zSql: UTF8String; nByte: integer;
  out ppStmt: Psqlite3_stmt; out pzTail: PUTF8Char): integer;
function sqlite3_prepare_v2(db: PSQLite3; const zSql: UTF8String;
  nByte: integer; out ppStmt: Psqlite3_stmt; out pzTail: PUTF8Char): integer;
function sqlite3_prepare16(db: PSQLite3; const zSql: UnicodeString;
  nByte: integer; out ppStmt: Psqlite3_stmt;
  out pzTail: PUnicodeString): integer;
function sqlite3_prepare16_v2(db: PSQLite3; const zSql: UnicodeString;
  nByte: integer; out ppStmt: Psqlite3_stmt;
  out pzTail: PUnicodeString): integer;
function sqlite3_finalize(pStmt: Psqlite3_stmt): integer;
function sqlite3_step(pStmt: Psqlite3_stmt): integer;
function sqlite3_reset(pStmt: Psqlite3_stmt): integer;
function sqlite3_stmt_readonly(pStmt: Psqlite3_stmt): integer;

// Bindings
function sqlite3_bind_blob(pStmt: Psqlite3_stmt; index: integer; value: Pointer;
  nBytes: integer; pDestructor: TSQLite3Destructor): integer;
function sqlite3_bind_double(pStmt: Psqlite3_stmt; index: integer;
  value: double): integer;
function sqlite3_bind_int(pStmt: Psqlite3_stmt; index: integer;
  value: integer): integer;
function sqlite3_bind_int64(pStmt: Psqlite3_stmt; index: integer;
  value: int64): integer;
function sqlite3_bind_null(pStmt: Psqlite3_stmt; index: integer): integer;
function sqlite3_bind_text(pStmt: Psqlite3_stmt; index: integer;
  const value: AnsiString; nBytes: integer;
  pDestructor: TSQLite3Destructor): integer;
function sqlite3_bind_text16(pStmt: Psqlite3_stmt; index: integer;
  const value: UnicodeString; nBytes: integer;
  pDestructor: TSQLite3Destructor): integer;
function sqlite3_bind_value(pStmt: Psqlite3_stmt; index: integer;
  value: Psqlite3_value): integer;
function sqlite3_bind_zeroblob(pStmt: Psqlite3_stmt; index: integer;
  nBytes: integer): integer;
function sqlite3_clear_bindings(pStmt: Psqlite3_stmt): integer;

// Bindings metadata
function sqlite3_bind_parameter_count(pStmt: Psqlite3_stmt): integer;
function sqlite3_bind_parameter_index(pStmt: Psqlite3_stmt;
  const zName: UTF8String): integer;
function sqlite3_bind_parameter_name(pStmt: Psqlite3_stmt; index: integer)
  : PUTF8Char;

// Result sets
function sqlite3_column_blob(pStmt: Psqlite3_stmt; iCol: integer): Pointer;
function sqlite3_column_bytes(pStmt: Psqlite3_stmt; iCol: integer): integer;
function sqlite3_column_bytes16(pStmt: Psqlite3_stmt; iCol: integer): integer;
function sqlite3_column_double(pStmt: Psqlite3_stmt; iCol: integer): double;
function sqlite3_column_int(pStmt: Psqlite3_stmt; iCol: integer): integer;
function sqlite3_column_int64(pStmt: Psqlite3_stmt; iCol: integer): int64;
function sqlite3_column_text(pStmt: Psqlite3_stmt; iCol: integer): PUTF8Char;
function sqlite3_column_text16(pStmt: Psqlite3_stmt; iCol: integer): PWideChar;
function sqlite3_column_type(pStmt: Psqlite3_stmt; iCol: integer): integer;
function sqlite3_column_value(pStmt: Psqlite3_stmt; iCol: integer)
  : Psqlite3_value;
function sqlite3_column_count(pStmt: Psqlite3_stmt): integer;
function sqlite3_data_count(pStmt: Psqlite3_stmt): integer;

// Result sets metadata
function sqlite3_column_database_name(pStmt: Psqlite3_stmt; index: integer)
  : PUTF8Char;
function sqlite3_column_database_name16(pStmt: Psqlite3_stmt; index: integer)
  : PWideChar;
function sqlite3_column_table_name(pStmt: Psqlite3_stmt; index: integer)
  : PUTF8Char;
function sqlite3_column_table_name16(pStmt: Psqlite3_stmt; index: integer)
  : PWideChar;
function sqlite3_column_origin_name(pStmt: Psqlite3_stmt; index: integer)
  : PUTF8Char;
function sqlite3_column_origin_name16(pStmt: Psqlite3_stmt; index: integer)
  : PWideChar;
function sqlite3_column_decltype(pStmt: Psqlite3_stmt; index: integer)
  : PUTF8Char;
function sqlite3_column_decltype16(pStmt: Psqlite3_stmt; index: integer)
  : PUTF8Char;
function sqlite3_column_name(pStmt: Psqlite3_stmt; index: integer): PUTF8Char;
function sqlite3_column_name16(pStmt: Psqlite3_stmt; index: integer): PWideChar;

// Blobs
function sqlite3_blob_bytes(pBlob: Psqlite3_blob): integer;
function sqlite3_blob_close(pBlob: Psqlite3_blob): integer;
function sqlite3_blob_open(db: PSQLite3; const zDb: UTF8String;
  const zTable: UTF8String; const zColumn: UTF8String; iRow: int64;
  flags: integer; out ppBlob: Psqlite3_blob): integer;
function sqlite3_blob_read(pBlob: Psqlite3_blob; buffer: Pointer;
  nBytes: integer; iOffset: integer): integer;
function sqlite3_blob_reopen(pBlob: Psqlite3_blob; iRow: int64): integer;
function sqlite3_blob_write(pBlob: Psqlite3_blob; buffer: Pointer;
  nBytes: integer; iOffset: integer): integer;

// Run-Time Library Version Numbers
function sqlite3_libversion: PAnsiChar;
function sqlite3_sourceid: PAnsiChar;
function sqlite3_libversion_number: integer;

// Test To See If The Library Is Threadsafe
function sqlite3_threadsafe: integer;

// Test For Auto-Commit Mode
function sqlite3_get_autocommit(db: PSQLite3): integer;

// Error Codes And Messages
function sqlite3_errcode(db: PSQLite3): integer;
function sqlite3_extended_errcode(db: PSQLite3): integer;
function sqlite3_errmsg(db: PSQLite3): PUTF8Char;
function sqlite3_errmsg16(db: PSQLite3): PWideChar;

// Enable Or Disable Extended Result Codes
function sqlite3_extended_result_codes(db: PSQLite3; onoff: integer): integer;

// Affected rows
function sqlite3_changes(db: PSQLite3): integer;
function sqlite3_total_changes(db: PSQLite3): integer;

// One-Step Query Execution Interface
function sqlite3_exec(db: PSQLite3; const sql: UTF8String;
  callback: TSQLiteExecCallback; UserData: Pointer;
  errmsg: PUTF8Char): integer;

// Memory Allocation Subsystem
function sqlite3_malloc(nBytes: integer): Pointer;
function sqlite3_realloc(buffer: Pointer; nBytes: integer): Pointer;
procedure sqlite3_free(buffer: Pointer);

// Run-time Limits
function sqlite3_limit(db: PSQLite3; id: integer; newVal: integer): integer;

// Extract Metadata About A Column Of A Table
function sqlite3_table_column_metadata(db: PSQLite3; const zDbName: UTF8String;
  const zTableName: UTF8String; const zColumnName: UTF8String;
  out pzDataType: PUTF8Char; out pzCollSeq: PUTF8Char; out pNotNull: integer;
  out pPrimaryKey: integer; out pAutoinc: integer): integer;

// Last Insert Rowid
function sqlite3_last_insert_rowid(db: PSQLite3): int64;

implementation

{$IFDEF WIN64}
{$R SQLite3Dll64.RES}
{$ELSE}
{$R SQLite3Dll32.RES}
{$ENDIF}

uses Windows, Classes, SysUtils, BTMemoryModule;

const
  SQLITERESID = 'SQLITE3DLL';
  EXCPT_MSG = 'SQLite3 function not implemented';

var
  // Global library variables
  TempDLLFile: string = '';
  dllHandler: THandle = 0;
  btMM: PBTMemoryModule;

type
  // Dynamically linked prototypes
  Tsqlite3_open = function(const filename: UTF8String; sqlite3: PSQLite3)
    : integer; cdecl;
  Tsqlite3_open16 = function(const filename: UnicodeString;
    out sqlite3: PSQLite3): integer; cdecl;
  Tsqlite3_open_v2 = function(const filename: UTF8String; out sqlite3: PSQLite3;
    flags: integer; zVfs: PAnsiString): integer; cdecl;
  Tsqlite3_close = function(sqlite3: PSQLite3): integer; cdecl;

  Tsqlite3_prepare = function(db: PSQLite3; const zSql: UTF8String;
    nByte: integer; out ppStmt: Psqlite3_stmt; out pzTail: PUTF8Char)
    : integer; cdecl;
  Tsqlite3_prepare_v2 = function(db: PSQLite3; const zSql: UTF8String;
    nByte: integer; out ppStmt: Psqlite3_stmt; out pzTail: PUTF8Char)
    : integer; cdecl;
  Tsqlite3_prepare16 = function(db: PSQLite3; const zSql: UnicodeString;
    nByte: integer; out ppStmt: Psqlite3_stmt; out pzTail: PUnicodeString)
    : integer; cdecl;
  Tsqlite3_prepare16_v2 = function(db: PSQLite3; const zSql: UnicodeString;
    nByte: integer; out ppStmt: Psqlite3_stmt; out pzTail: PUnicodeString)
    : integer; cdecl;
  Tsqlite3_finalize = function(pStmt: Psqlite3_stmt): integer; cdecl;
  Tsqlite3_step = function(pStmt: Psqlite3_stmt): integer; cdecl;
  Tsqlite3_reset = function(pStmt: Psqlite3_stmt): integer; cdecl;
  Tsqlite3_stmt_readonly = function(pStmt: Psqlite3_stmt): integer; cdecl;

  Tsqlite3_bind_blob = function(pStmt: Psqlite3_stmt; index: integer;
    value: Pointer; nBytes: integer; pDestructor: TSQLite3Destructor)
    : integer; cdecl;
  Tsqlite3_bind_double = function(pStmt: Psqlite3_stmt; index: integer;
    value: double): integer; cdecl;
  Tsqlite3_bind_int = function(pStmt: Psqlite3_stmt; index: integer;
    value: integer): integer; cdecl;
  Tsqlite3_bind_int64 = function(pStmt: Psqlite3_stmt; index: integer;
    value: int64): integer; cdecl;
  Tsqlite3_bind_null = function(pStmt: Psqlite3_stmt; index: integer)
    : integer; cdecl;
  Tsqlite3_bind_text = function(pStmt: Psqlite3_stmt; index: integer;
    const value: AnsiString; nBytes: integer; pDestructor: TSQLite3Destructor)
    : integer; cdecl;
  Tsqlite3_bind_text16 = function(pStmt: Psqlite3_stmt; index: integer;
    const value: UnicodeString; nBytes: integer;
    pDestructor: TSQLite3Destructor): integer; cdecl;
  Tsqlite3_bind_value = function(pStmt: Psqlite3_stmt; index: integer;
    value: Psqlite3_value): integer; cdecl;
  Tsqlite3_bind_zeroblob = function(pStmt: Psqlite3_stmt; index: integer;
    nBytes: integer): integer; cdecl;
  Tsqlite3_clear_bindings = function(pStmt: Psqlite3_stmt): integer; cdecl;

  Tsqlite3_bind_parameter_count = function(pStmt: Psqlite3_stmt)
    : integer; cdecl;
  Tsqlite3_bind_parameter_index = function(pStmt: Psqlite3_stmt;
    const zName: UTF8String): integer; cdecl;
  Tsqlite3_bind_parameter_name = function(pStmt: Psqlite3_stmt; index: integer)
    : PUTF8Char; cdecl;

  Tsqlite3_column_blob = function(pStmt: Psqlite3_stmt; iCol: integer)
    : Pointer; cdecl;
  Tsqlite3_column_bytes = function(pStmt: Psqlite3_stmt; iCol: integer)
    : integer; cdecl;
  Tsqlite3_column_bytes16 = function(pStmt: Psqlite3_stmt; iCol: integer)
    : integer; cdecl;
  Tsqlite3_column_double = function(pStmt: Psqlite3_stmt;
    iCol: integer): double;
  Tsqlite3_column_int = function(pStmt: Psqlite3_stmt; iCol: integer)
    : integer; cdecl;
  Tsqlite3_column_int64 = function(pStmt: Psqlite3_stmt; iCol: integer)
    : int64; cdecl;
  Tsqlite3_column_text = function(pStmt: Psqlite3_stmt; iCol: integer)
    : PUTF8Char; cdecl;
  Tsqlite3_column_text16 = function(pStmt: Psqlite3_stmt; iCol: integer)
    : PWideChar; cdecl;
  Tsqlite3_column_type = function(pStmt: Psqlite3_stmt; iCol: integer)
    : integer; cdecl;
  Tsqlite3_column_value = function(pStmt: Psqlite3_stmt; iCol: integer)
    : Psqlite3_value; cdecl;
  Tsqlite3_column_count = function(pStmt: Psqlite3_stmt): integer; cdecl;
  Tsqlite3_data_count = function(pStmt: Psqlite3_stmt): integer; cdecl;
  Tsqlite3_column_database_name = function(pStmt: Psqlite3_stmt; index: integer)
    : PUTF8Char; cdecl;
  Tsqlite3_column_database_name16 = function(pStmt: Psqlite3_stmt;
    index: integer): PWideChar; cdecl;
  Tsqlite3_column_table_name = function(pStmt: Psqlite3_stmt; index: integer)
    : PUTF8Char; cdecl;
  Tsqlite3_column_table_name16 = function(pStmt: Psqlite3_stmt; index: integer)
    : PWideChar; cdecl;
  Tsqlite3_column_origin_name = function(pStmt: Psqlite3_stmt; index: integer)
    : PUTF8Char; cdecl;
  Tsqlite3_column_origin_name16 = function(pStmt: Psqlite3_stmt; index: integer)
    : PWideChar;
  Tsqlite3_column_decltype = function(pStmt: Psqlite3_stmt; index: integer)
    : PUTF8Char; cdecl;
  Tsqlite3_column_decltype16 = function(pStmt: Psqlite3_stmt; index: integer)
    : PUTF8Char; cdecl;
  Tsqlite3_column_name = function(pStmt: Psqlite3_stmt; index: integer)
    : PUTF8Char; cdecl;
  Tsqlite3_column_name16 = function(pStmt: Psqlite3_stmt; index: integer)
    : PWideChar; cdecl;

  Tsqlite3_blob_bytes = function(pBlob: Psqlite3_blob): integer; cdecl;
  Tsqlite3_blob_close = function(pBlob: Psqlite3_blob): integer; cdecl;
  Tsqlite3_blob_open = function(db: PSQLite3; const zDb: UTF8String;
    const zTable: UTF8String; const zColumn: UTF8String; iRow: int64;
    flags: integer; out ppBlob: Psqlite3_blob): integer; cdecl;
  Tsqlite3_blob_read = function(pBlob: Psqlite3_blob; buffer: Pointer;
    nBytes: integer; iOffset: integer): integer; cdecl;
  Tsqlite3_blob_reopen = function(pBlob: Psqlite3_blob; iRow: int64)
    : integer; cdecl;
  Tsqlite3_blob_write = function(pBlob: Psqlite3_blob; buffer: Pointer;
    nBytes: integer; iOffset: integer): integer; cdecl;

  Tsqlite3_libversion = function: PAnsiChar; cdecl;
  Tsqlite3_sourceid = function: PAnsiChar; cdecl;
  Tsqlite3_libversion_number = function: integer; cdecl;

  Tsqlite3_threadsafe = function: integer; cdecl;

  Tsqlite3_get_autocommit = function(db: PSQLite3): integer; cdecl;

  Tsqlite3_errcode = function(db: PSQLite3): integer; cdecl;
  Tsqlite3_extended_errcode = function(db: PSQLite3): integer; cdecl;
  Tsqlite3_errmsg = function(db: PSQLite3): PUTF8Char; cdecl;
  Tsqlite3_errmsg16 = function(db: PSQLite3): PWideChar; cdecl;

  Tsqlite3_extended_result_codes = function(db: PSQLite3; onoff: integer)
    : integer; cdecl;

  Tsqlite3_changes = function(db: PSQLite3): integer; cdecl;
  Tsqlite3_total_changes = function(db: PSQLite3): integer; cdecl;

  Tsqlite3_exec = function(db: PSQLite3; const sql: UTF8String;
    callback: TSQLiteExecCallback; UserData: Pointer; var errmsg: PUTF8Char)
    : integer; cdecl;

  Tsqlite3_malloc = function(nBytes: integer): Pointer; cdecl;
  Tsqlite3_realloc = function(buffer: Pointer; nBytes: integer): Pointer; cdecl;
  Tsqlite3_free = procedure(buffer: Pointer); cdecl;

  Tsqlite3_limit = function(db: PSQLite3; id: integer; newVal: integer)
    : integer; cdecl;

  Tsqlite3_table_column_metadata = function(db: PSQLite3;
    const zDbName: UTF8String; const zTableName: UTF8String;
    const zColumnName: UTF8String; out pzDataType: PUTF8Char;
    out pzCollSeq: PUTF8Char; out pNotNull: integer; out pPrimaryKey: integer;
    out pAutoinc: integer): integer; cdecl;

  Tsqlite3_last_insert_rowid = function(db: PSQLite3): int64;

var
  // Dinamically linked procedures
  psqlite3_aggregate_context: FARPROC = nil;
  psqlite3_auto_extension: FARPROC = nil;
  psqlite3_backup_finish: FARPROC = nil;
  psqlite3_backup_init: FARPROC = nil;
  psqlite3_backup_pagecount: FARPROC = nil;
  psqlite3_backup_remaining: FARPROC = nil;
  psqlite3_backup_step: FARPROC = nil;
  psqlite3_bind_blob: FARPROC = nil;
  psqlite3_bind_double: FARPROC = nil;
  psqlite3_bind_int: FARPROC = nil;
  psqlite3_bind_int64: FARPROC = nil;
  psqlite3_bind_null: FARPROC = nil;
  psqlite3_bind_parameter_count: FARPROC = nil;
  psqlite3_bind_parameter_index: FARPROC = nil;
  psqlite3_bind_parameter_name: FARPROC = nil;
  psqlite3_bind_text: FARPROC = nil;
  psqlite3_bind_text16: FARPROC = nil;
  psqlite3_bind_value: FARPROC = nil;
  psqlite3_bind_zeroblob: FARPROC = nil;
  psqlite3_blob_bytes: FARPROC = nil;
  psqlite3_blob_close: FARPROC = nil;
  psqlite3_blob_open: FARPROC = nil;
  psqlite3_blob_read: FARPROC = nil;
  psqlite3_blob_reopen: FARPROC = nil;
  psqlite3_blob_write: FARPROC = nil;
  psqlite3_busy_handler: FARPROC = nil;
  psqlite3_busy_timeout: FARPROC = nil;
  psqlite3_changes: FARPROC = nil;
  psqlite3_clear_bindings: FARPROC = nil;
  psqlite3_close: FARPROC = nil;
  psqlite3_collation_needed: FARPROC = nil;
  psqlite3_collation_needed16: FARPROC = nil;
  psqlite3_column_blob: FARPROC = nil;
  psqlite3_column_bytes: FARPROC = nil;
  psqlite3_column_bytes16: FARPROC = nil;
  psqlite3_column_count: FARPROC = nil;
  psqlite3_column_database_name: FARPROC = nil;
  psqlite3_column_database_name16: FARPROC = nil;
  psqlite3_column_decltype: FARPROC = nil;
  psqlite3_column_decltype16: FARPROC = nil;
  psqlite3_column_double: FARPROC = nil;
  psqlite3_column_int: FARPROC = nil;
  psqlite3_column_int64: FARPROC = nil;
  psqlite3_column_name: FARPROC = nil;
  psqlite3_column_name16: FARPROC = nil;
  psqlite3_column_origin_name: FARPROC = nil;
  psqlite3_column_origin_name16: FARPROC = nil;
  psqlite3_column_table_name: FARPROC = nil;
  psqlite3_column_table_name16: FARPROC = nil;
  psqlite3_column_text: FARPROC = nil;
  psqlite3_column_text16: FARPROC = nil;
  psqlite3_column_type: FARPROC = nil;
  psqlite3_column_value: FARPROC = nil;
  psqlite3_commit_hook: FARPROC = nil;
  psqlite3_compileoption_get: FARPROC = nil;
  psqlite3_compileoption_used: FARPROC = nil;
  psqlite3_complete: FARPROC = nil;
  psqlite3_complete16: FARPROC = nil;
  psqlite3_config: FARPROC = nil;
  psqlite3_context_db_handle: FARPROC = nil;
  psqlite3_create_collation: FARPROC = nil;
  psqlite3_create_collation16: FARPROC = nil;
  psqlite3_create_collation_v2: FARPROC = nil;
  psqlite3_create_function: FARPROC = nil;
  psqlite3_create_function16: FARPROC = nil;
  psqlite3_create_function_v2: FARPROC = nil;
  psqlite3_create_module: FARPROC = nil;
  psqlite3_create_module_v2: FARPROC = nil;
  psqlite3_data_count: FARPROC = nil;
  psqlite3_db_config: FARPROC = nil;
  psqlite3_db_filename: FARPROC = nil;
  psqlite3_db_handle: FARPROC = nil;
  psqlite3_db_mutex: FARPROC = nil;
  psqlite3_db_readonly: FARPROC = nil;
  psqlite3_db_release_memory: FARPROC = nil;
  psqlite3_db_status: FARPROC = nil;
  psqlite3_declare_vtab: FARPROC = nil;
  psqlite3_enable_load_extension: FARPROC = nil;
  psqlite3_enable_shared_cache: FARPROC = nil;
  psqlite3_errcode: FARPROC = nil;
  psqlite3_errmsg: FARPROC = nil;
  psqlite3_errmsg16: FARPROC = nil;
  psqlite3_exec: FARPROC = nil;
  psqlite3_extended_errcode: FARPROC = nil;
  psqlite3_extended_result_codes: FARPROC = nil;
  psqlite3_file_control: FARPROC = nil;
  psqlite3_finalize: FARPROC = nil;
  psqlite3_free: FARPROC = nil;
  psqlite3_free_table: FARPROC = nil;
  psqlite3_get_autocommit: FARPROC = nil;
  psqlite3_get_auxdata: FARPROC = nil;
  psqlite3_get_table: FARPROC = nil;
  psqlite3_initialize: FARPROC = nil;
  psqlite3_interrupt: FARPROC = nil;
  psqlite3_last_insert_rowid: FARPROC = nil;
  psqlite3_libversion: FARPROC = nil;
  psqlite3_libversion_number: FARPROC = nil;
  psqlite3_limit: FARPROC = nil;
  psqlite3_load_extension: FARPROC = nil;
  psqlite3_log: FARPROC = nil;
  psqlite3_malloc: FARPROC = nil;
  psqlite3_memory_highwater: FARPROC = nil;
  psqlite3_memory_used: FARPROC = nil;
  psqlite3_mprintf: FARPROC = nil;
  psqlite3_mutex_alloc: FARPROC = nil;
  psqlite3_mutex_enter: FARPROC = nil;
  psqlite3_mutex_free: FARPROC = nil;
  psqlite3_mutex_held: FARPROC = nil;
  psqlite3_mutex_leave: FARPROC = nil;
  psqlite3_mutex_notheld: FARPROC = nil;
  psqlite3_mutex_try: FARPROC = nil;
  psqlite3_next_stmt: FARPROC = nil;
  psqlite3_open: FARPROC = nil;
  psqlite3_open16: FARPROC = nil;
  psqlite3_open_v2: FARPROC = nil;
  psqlite3_os_end: FARPROC = nil;
  psqlite3_os_init: FARPROC = nil;
  psqlite3_overload_function: FARPROC = nil;
  psqlite3_prepare: FARPROC = nil;
  psqlite3_prepare16: FARPROC = nil;
  psqlite3_prepare16_v2: FARPROC = nil;
  psqlite3_prepare_v2: FARPROC = nil;
  psqlite3_profile: FARPROC = nil;
  psqlite3_progress_handler: FARPROC = nil;
  psqlite3_randomness: FARPROC = nil;
  psqlite3_realloc: FARPROC = nil;
  psqlite3_release_memory: FARPROC = nil;
  psqlite3_reset: FARPROC = nil;
  psqlite3_reset_auto_extension: FARPROC = nil;
  psqlite3_result_blob: FARPROC = nil;
  psqlite3_result_double: FARPROC = nil;
  psqlite3_result_error: FARPROC = nil;
  psqlite3_result_error16: FARPROC = nil;
  psqlite3_result_error_code: FARPROC = nil;
  psqlite3_result_error_nomem: FARPROC = nil;
  psqlite3_result_error_toobig: FARPROC = nil;
  psqlite3_result_int: FARPROC = nil;
  psqlite3_result_int64: FARPROC = nil;
  psqlite3_result_null: FARPROC = nil;
  psqlite3_result_text: FARPROC = nil;
  psqlite3_result_text16: FARPROC = nil;
  psqlite3_result_text16be: FARPROC = nil;
  psqlite3_result_text16le: FARPROC = nil;
  psqlite3_result_value: FARPROC = nil;
  psqlite3_result_zeroblob: FARPROC = nil;
  psqlite3_rollback_hook: FARPROC = nil;
  psqlite3_set_authorizer: FARPROC = nil;
  psqlite3_set_auxdata: FARPROC = nil;
  psqlite3_shutdown: FARPROC = nil;
  psqlite3_sleep: FARPROC = nil;
  psqlite3_snprintf: FARPROC = nil;
  psqlite3_soft_heap_limit64: FARPROC = nil;
  psqlite3_sourceid: FARPROC = nil;
  psqlite3_sql: FARPROC = nil;
  psqlite3_status: FARPROC = nil;
  psqlite3_step: FARPROC = nil;
  psqlite3_stmt_busy: FARPROC = nil;
  psqlite3_stmt_readonly: FARPROC = nil;
  psqlite3_stmt_status: FARPROC = nil;
  psqlite3_stricmp: FARPROC = nil;
  psqlite3_strnicmp: FARPROC = nil;
  psqlite3_table_column_metadata: FARPROC = nil;
  psqlite3_test_control: FARPROC = nil;
  psqlite3_threadsafe: FARPROC = nil;
  psqlite3_total_changes: FARPROC = nil;
  psqlite3_trace: FARPROC = nil;
  psqlite3_unlock_notify: FARPROC = nil;
  psqlite3_update_hook: FARPROC = nil;
  psqlite3_uri_boolean: FARPROC = nil;
  psqlite3_uri_int64: FARPROC = nil;
  psqlite3_uri_parameter: FARPROC = nil;
  psqlite3_user_data: FARPROC = nil;
  psqlite3_value_blob: FARPROC = nil;
  psqlite3_value_bytes: FARPROC = nil;
  psqlite3_value_bytes16: FARPROC = nil;
  psqlite3_value_double: FARPROC = nil;
  psqlite3_value_int: FARPROC = nil;
  psqlite3_value_int64: FARPROC = nil;
  psqlite3_value_numeric_type: FARPROC = nil;
  psqlite3_value_text: FARPROC = nil;
  psqlite3_value_text16: FARPROC = nil;
  psqlite3_value_text16be: FARPROC = nil;
  psqlite3_value_text16le: FARPROC = nil;
  psqlite3_value_type: FARPROC = nil;
  psqlite3_version: FARPROC = nil;
  psqlite3_vfs_find: FARPROC = nil;
  psqlite3_vfs_register: FARPROC = nil;
  psqlite3_vfs_unregister: FARPROC = nil;
  psqlite3_vmprintf: FARPROC = nil;
  psqlite3_vsnprintf: FARPROC = nil;
  psqlite3_vtab_config: FARPROC = nil;
  psqlite3_vtab_on_conflict: FARPROC = nil;
  psqlite3_wal_autocheckpoint: FARPROC = nil;
  psqlite3_wal_checkpoint: FARPROC = nil;
  psqlite3_wal_checkpoint_v2: FARPROC = nil;
  psqlite3_wal_hook: FARPROC = nil;

  // ------------------------------------
  // Delphi Implementation
  // ------------------------------------

function isAvailable: boolean;
begin
  Result:= Assigned(btMM);
end;

// Open/close

function sqlite3_open(const filename: UTF8String; out db: PSQLite3): integer;
begin
  if assigned(psqlite3_open) then
    Result := Tsqlite3_open(psqlite3_open)(filename, db)
  else
    raise Exception.Create(EXCPT_MSG);
end;

function sqlite3_open16(const filename: UnicodeString;
  out db: PSQLite3): integer;
begin
  if assigned(psqlite3_open16) then
    Result := Tsqlite3_open16(psqlite3_open16)(filename, db)
  else
    raise Exception.Create(EXCPT_MSG);
end;

function sqlite3_open_v2(const filename: UTF8String; out db: PSQLite3;
  flags: integer; zVfs: PAnsiString): integer;
begin
  if assigned(psqlite3_open_v2) then
    Result := Tsqlite3_open_v2(psqlite3_open_v2)(filename, db, flags, zVfs)
  else
    raise Exception.Create(EXCPT_MSG);
end;

function sqlite3_close(db: PSQLite3): integer;
begin
  if assigned(psqlite3_close) then
    Result := Tsqlite3_close(psqlite3_close)(db)
  else
    raise Exception.Create(EXCPT_MSG);
end;

// Statements

function sqlite3_prepare(db: PSQLite3; const zSql: UTF8String; nByte: integer;
  out ppStmt: Psqlite3_stmt; out pzTail: PUTF8Char): integer;
begin
  if assigned(psqlite3_prepare) then
    Result := Tsqlite3_prepare(psqlite3_prepare)
      (db, zSql, nByte, ppStmt, pzTail)
  else
    raise Exception.Create(EXCPT_MSG);
end;

function sqlite3_prepare_v2(db: PSQLite3; const zSql: UTF8String;
  nByte: integer; out ppStmt: Psqlite3_stmt; out pzTail: PUTF8Char): integer;
begin
  if assigned(psqlite3_prepare_v2) then
    Result := Tsqlite3_prepare_v2(psqlite3_prepare_v2)
      (db, zSql, nByte, ppStmt, pzTail)
  else
    raise Exception.Create(EXCPT_MSG);
end;

function sqlite3_prepare16(db: PSQLite3; const zSql: UnicodeString;
  nByte: integer; out ppStmt: Psqlite3_stmt;
  out pzTail: PUnicodeString): integer;
begin
  if assigned(psqlite3_prepare16) then
    Result := Tsqlite3_prepare16(psqlite3_prepare16)
      (db, zSql, nByte, ppStmt, pzTail)
  else
    raise Exception.Create(EXCPT_MSG);
end;

function sqlite3_prepare16_v2(db: PSQLite3; const zSql: UnicodeString;
  nByte: integer; out ppStmt: Psqlite3_stmt;
  out pzTail: PUnicodeString): integer;
begin
  if assigned(psqlite3_prepare16_v2) then
    Result := Tsqlite3_prepare16_v2(psqlite3_prepare16_v2)
      (db, zSql, nByte, ppStmt, pzTail)
  else
    raise Exception.Create(EXCPT_MSG);
end;

function sqlite3_finalize(pStmt: Psqlite3_stmt): integer;
begin
  if assigned(psqlite3_finalize) then
    Result := Tsqlite3_finalize(psqlite3_finalize)(pStmt)
  else
    raise Exception.Create(EXCPT_MSG);
end;

function sqlite3_step(pStmt: Psqlite3_stmt): integer;
begin
  if assigned(psqlite3_step) then
    Result := Tsqlite3_step(psqlite3_step)(pStmt)
  else
    raise Exception.Create(EXCPT_MSG);
end;

function sqlite3_reset(pStmt: Psqlite3_stmt): integer;
begin
  if assigned(psqlite3_reset) then
    Result := Tsqlite3_reset(psqlite3_reset)(pStmt)
  else
    raise Exception.Create(EXCPT_MSG);
end;

function sqlite3_stmt_readonly(pStmt: Psqlite3_stmt): integer;
begin
  if assigned(psqlite3_stmt_readonly) then
    Result := Tsqlite3_stmt_readonly(psqlite3_stmt_readonly)(pStmt)
  else
    raise Exception.Create(EXCPT_MSG);
end;

// Bindings

function sqlite3_bind_blob(pStmt: Psqlite3_stmt; index: integer; value: Pointer;
  nBytes: integer; pDestructor: TSQLite3Destructor): integer;
begin
  if assigned(psqlite3_bind_blob) then
    Result := Tsqlite3_bind_blob(psqlite3_bind_blob)(pStmt, index, value,
      nBytes, pDestructor)
  else
    raise Exception.Create(EXCPT_MSG);
end;

function sqlite3_bind_double(pStmt: Psqlite3_stmt; index: integer;
  value: double): integer;
begin
  if assigned(psqlite3_bind_double) then
    Result := Tsqlite3_bind_double(psqlite3_bind_double)(pStmt, index, value)
  else
    raise Exception.Create(EXCPT_MSG);
end;

function sqlite3_bind_int(pStmt: Psqlite3_stmt; index: integer;
  value: integer): integer;
begin
  if assigned(psqlite3_bind_int) then
    Result := Tsqlite3_bind_int(psqlite3_bind_int)(pStmt, index, value)
  else
    raise Exception.Create(EXCPT_MSG);
end;

function sqlite3_bind_int64(pStmt: Psqlite3_stmt; index: integer;
  value: int64): integer;
begin
  if assigned(psqlite3_bind_int64) then
    Result := Tsqlite3_bind_int64(psqlite3_bind_int64)(pStmt, index, value)
  else
    raise Exception.Create(EXCPT_MSG);
end;

function sqlite3_bind_null(pStmt: Psqlite3_stmt; index: integer): integer;
begin
  if assigned(psqlite3_bind_null) then
    Result := Tsqlite3_bind_null(psqlite3_bind_null)(pStmt, index)
  else
    raise Exception.Create(EXCPT_MSG);
end;

function sqlite3_bind_text(pStmt: Psqlite3_stmt; index: integer;
  const value: AnsiString; nBytes: integer;
  pDestructor: TSQLite3Destructor): integer;
begin
  if assigned(psqlite3_bind_text) then
    Result := Tsqlite3_bind_text(psqlite3_bind_text)(pStmt, index, value,
      nBytes, pDestructor)
  else
    raise Exception.Create(EXCPT_MSG);
end;

function sqlite3_bind_text16(pStmt: Psqlite3_stmt; index: integer;
  const value: UnicodeString; nBytes: integer;
  pDestructor: TSQLite3Destructor): integer;
begin
  if assigned(psqlite3_bind_text16) then
    Result := Tsqlite3_bind_text16(psqlite3_bind_text16)
      (pStmt, index, value, nBytes, pDestructor)
  else
    raise Exception.Create(EXCPT_MSG);
end;

function sqlite3_bind_value(pStmt: Psqlite3_stmt; index: integer;
  value: Psqlite3_value): integer;
begin
  if assigned(psqlite3_bind_value) then
    Result := Tsqlite3_bind_value(psqlite3_bind_value)(pStmt, index, value)
  else
    raise Exception.Create(EXCPT_MSG);
end;

function sqlite3_bind_zeroblob(pStmt: Psqlite3_stmt; index: integer;
  nBytes: integer): integer;
begin
  if assigned(psqlite3_bind_zeroblob) then
    Result := Tsqlite3_bind_zeroblob(psqlite3_bind_zeroblob)
      (pStmt, index, nBytes)
  else
    raise Exception.Create(EXCPT_MSG);
end;

function sqlite3_clear_bindings(pStmt: Psqlite3_stmt): integer;
begin
  if assigned(psqlite3_clear_bindings) then
    Result := Tsqlite3_clear_bindings(psqlite3_clear_bindings)(pStmt)
  else
    raise Exception.Create(EXCPT_MSG);
end;

// Bindings metadata

function sqlite3_bind_parameter_count(pStmt: Psqlite3_stmt): integer;
begin
  if assigned(psqlite3_bind_parameter_count) then
    Result := Tsqlite3_bind_parameter_count
      (psqlite3_bind_parameter_count)(pStmt)
  else
    raise Exception.Create(EXCPT_MSG);
end;

function sqlite3_bind_parameter_index(pStmt: Psqlite3_stmt;
  const zName: UTF8String): integer;
begin
  if assigned(psqlite3_bind_parameter_index) then
    Result := Tsqlite3_bind_parameter_index(psqlite3_bind_parameter_index)
      (pStmt, zName)
  else
    raise Exception.Create(EXCPT_MSG);
end;

function sqlite3_bind_parameter_name(pStmt: Psqlite3_stmt; index: integer)
  : PUTF8Char;
begin
  if assigned(psqlite3_bind_parameter_name) then
    Result := Tsqlite3_bind_parameter_name(psqlite3_bind_parameter_name)
      (pStmt, index)
  else
    raise Exception.Create(EXCPT_MSG);
end;


// Result sets

function sqlite3_column_blob(pStmt: Psqlite3_stmt; iCol: integer): Pointer;
begin
  if assigned(psqlite3_column_blob) then
    Result := Tsqlite3_column_blob(psqlite3_column_blob)(pStmt, iCol)
  else
    raise Exception.Create(EXCPT_MSG);
end;

function sqlite3_column_bytes(pStmt: Psqlite3_stmt; iCol: integer): integer;
begin
  if assigned(psqlite3_column_bytes) then
    Result := Tsqlite3_column_bytes(psqlite3_column_bytes)(pStmt, iCol)
  else
    raise Exception.Create(EXCPT_MSG);
end;

function sqlite3_column_bytes16(pStmt: Psqlite3_stmt; iCol: integer): integer;
begin
  if assigned(psqlite3_column_bytes16) then
    Result := Tsqlite3_column_bytes16(psqlite3_column_bytes16)(pStmt, iCol)
  else
    raise Exception.Create(EXCPT_MSG);
end;

function sqlite3_column_double(pStmt: Psqlite3_stmt; iCol: integer): double;
begin
  if assigned(psqlite3_column_double) then
    Result := Tsqlite3_column_double(psqlite3_column_double)(pStmt, iCol)
  else
    raise Exception.Create(EXCPT_MSG);
end;

function sqlite3_column_int(pStmt: Psqlite3_stmt; iCol: integer): integer;
begin
  if assigned(psqlite3_column_int) then
    Result := Tsqlite3_column_int(psqlite3_column_int)(pStmt, iCol)
  else
    raise Exception.Create(EXCPT_MSG);
end;

function sqlite3_column_int64(pStmt: Psqlite3_stmt; iCol: integer): int64;
begin
  if assigned(psqlite3_column_int64) then
    Result := Tsqlite3_column_int64(psqlite3_column_int64)(pStmt, iCol)
  else
    raise Exception.Create(EXCPT_MSG);
end;

function sqlite3_column_text(pStmt: Psqlite3_stmt; iCol: integer): PUTF8Char;
begin
  if assigned(psqlite3_column_text) then
    Result := Tsqlite3_column_text(psqlite3_column_text)(pStmt, iCol)
  else
    raise Exception.Create(EXCPT_MSG);
end;

function sqlite3_column_text16(pStmt: Psqlite3_stmt; iCol: integer): PWideChar;
begin
  if assigned(psqlite3_column_text16) then
    Result := Tsqlite3_column_text16(psqlite3_column_text16)(pStmt, iCol)
  else
    raise Exception.Create(EXCPT_MSG);
end;

function sqlite3_column_type(pStmt: Psqlite3_stmt; iCol: integer): integer;
begin
  if assigned(psqlite3_column_type) then
    Result := Tsqlite3_column_type(psqlite3_column_type)(pStmt, iCol)
  else
    raise Exception.Create(EXCPT_MSG);
end;

function sqlite3_column_value(pStmt: Psqlite3_stmt; iCol: integer)
  : Psqlite3_value;
begin
  if assigned(psqlite3_column_value) then
    Result := Tsqlite3_column_value(psqlite3_column_value)(pStmt, iCol)
  else
    raise Exception.Create(EXCPT_MSG);
end;

function sqlite3_column_count(pStmt: Psqlite3_stmt): integer;
begin
  if assigned(psqlite3_column_count) then
    Result := Tsqlite3_column_count(psqlite3_column_count)(pStmt)
  else
    raise Exception.Create(EXCPT_MSG);
end;

function sqlite3_data_count(pStmt: Psqlite3_stmt): integer;
begin
  if assigned(psqlite3_data_count) then
    Result := Tsqlite3_data_count(psqlite3_data_count)(pStmt)
  else
    raise Exception.Create(EXCPT_MSG);
end;

// Result sets metadata

function sqlite3_column_database_name(pStmt: Psqlite3_stmt; index: integer)
  : PUTF8Char;
begin
  if assigned(psqlite3_column_database_name) then
    Result := Tsqlite3_column_database_name(psqlite3_column_database_name)
      (pStmt, index)
  else
    raise Exception.Create(EXCPT_MSG);
end;

function sqlite3_column_database_name16(pStmt: Psqlite3_stmt; index: integer)
  : PWideChar;
begin
  if assigned(psqlite3_column_database_name16) then
    Result := Tsqlite3_column_database_name16(psqlite3_column_database_name16)
      (pStmt, index)
  else
    raise Exception.Create(EXCPT_MSG);
end;

function sqlite3_column_table_name(pStmt: Psqlite3_stmt; index: integer)
  : PUTF8Char;
begin
  if assigned(psqlite3_column_table_name) then
    Result := Tsqlite3_column_table_name(psqlite3_column_table_name)
      (pStmt, index)
  else
    raise Exception.Create(EXCPT_MSG);
end;

function sqlite3_column_table_name16(pStmt: Psqlite3_stmt; index: integer)
  : PWideChar;
begin
  if assigned(psqlite3_column_table_name16) then
    Result := Tsqlite3_column_table_name16(psqlite3_column_table_name16)
      (pStmt, index)
  else
    raise Exception.Create(EXCPT_MSG);
end;

function sqlite3_column_origin_name(pStmt: Psqlite3_stmt; index: integer)
  : PUTF8Char;
begin
  if assigned(psqlite3_column_origin_name) then
    Result := Tsqlite3_column_origin_name(psqlite3_column_origin_name)
      (pStmt, index)
  else
    raise Exception.Create(EXCPT_MSG);
end;

function sqlite3_column_origin_name16(pStmt: Psqlite3_stmt; index: integer)
  : PWideChar;
begin
  if assigned(psqlite3_column_origin_name16) then
    Result := Tsqlite3_column_origin_name16(psqlite3_column_origin_name16)
      (pStmt, index)
  else
    raise Exception.Create(EXCPT_MSG);
end;

function sqlite3_column_decltype(pStmt: Psqlite3_stmt; index: integer)
  : PUTF8Char;
begin
  if assigned(psqlite3_column_decltype) then
    Result := Tsqlite3_column_decltype(psqlite3_column_decltype)(pStmt, index)
  else
    raise Exception.Create(EXCPT_MSG);
end;

function sqlite3_column_decltype16(pStmt: Psqlite3_stmt; index: integer)
  : PUTF8Char;
begin
  if assigned(psqlite3_column_decltype16) then
    Result := Tsqlite3_column_decltype16(psqlite3_column_decltype16)
      (pStmt, index)
  else
    raise Exception.Create(EXCPT_MSG);
end;

function sqlite3_column_name(pStmt: Psqlite3_stmt; index: integer): PUTF8Char;
begin
  if assigned(psqlite3_column_name) then
    Result := Tsqlite3_column_name(psqlite3_column_name)(pStmt, index)
  else
    raise Exception.Create(EXCPT_MSG);
end;

function sqlite3_column_name16(pStmt: Psqlite3_stmt; index: integer): PWideChar;
begin
  if assigned(psqlite3_column_name16) then
    Result := Tsqlite3_column_name16(psqlite3_column_name16)(pStmt, index)
  else
    raise Exception.Create(EXCPT_MSG);
end;

// Blobs

function sqlite3_blob_bytes(pBlob: Psqlite3_blob): integer;
begin
  if assigned(psqlite3_blob_bytes) then
    Result := Tsqlite3_blob_bytes(psqlite3_blob_bytes)(pBlob)
  else
    raise Exception.Create(EXCPT_MSG);
end;

function sqlite3_blob_close(pBlob: Psqlite3_blob): integer;
begin
  if assigned(psqlite3_blob_close) then
    Result := Tsqlite3_blob_close(psqlite3_blob_close)(pBlob)
  else
    raise Exception.Create(EXCPT_MSG);
end;

function sqlite3_blob_open(db: PSQLite3; const zDb: UTF8String;
  const zTable: UTF8String; const zColumn: UTF8String; iRow: int64;
  flags: integer; out ppBlob: Psqlite3_blob): integer;
begin
  if assigned(psqlite3_blob_open) then
    Result := Tsqlite3_blob_open(psqlite3_blob_open)(db, zDb, zTable, zColumn,
      iRow, flags, ppBlob)
  else
    raise Exception.Create(EXCPT_MSG);
end;

function sqlite3_blob_read(pBlob: Psqlite3_blob; buffer: Pointer;
  nBytes: integer; iOffset: integer): integer;
begin
  if assigned(psqlite3_blob_read) then
    Result := Tsqlite3_blob_read(psqlite3_blob_read)
      (pBlob, buffer, nBytes, iOffset)
  else
    raise Exception.Create(EXCPT_MSG);
end;

function sqlite3_blob_reopen(pBlob: Psqlite3_blob; iRow: int64): integer;
begin
  if assigned(psqlite3_blob_reopen) then
    Result := Tsqlite3_blob_reopen(psqlite3_blob_reopen)(pBlob, iRow)
  else
    raise Exception.Create(EXCPT_MSG);
end;

function sqlite3_blob_write(pBlob: Psqlite3_blob; buffer: Pointer;
  nBytes: integer; iOffset: integer): integer;
begin
  if assigned(psqlite3_blob_write) then
    Result := Tsqlite3_blob_write(psqlite3_blob_write)
      (pBlob, buffer, nBytes, iOffset)
  else
    raise Exception.Create(EXCPT_MSG);
end;

// Run-Time Library Version Numbers

function sqlite3_libversion: PAnsiChar;
begin
  if assigned(psqlite3_libversion) then
    Result := Tsqlite3_libversion(psqlite3_libversion)()
  else
    raise Exception.Create(EXCPT_MSG);
end;

function sqlite3_sourceid: PAnsiChar;
begin
  if assigned(psqlite3_sourceid) then
    Result := Tsqlite3_sourceid(psqlite3_sourceid)()
  else
    raise Exception.Create(EXCPT_MSG);
end;

function sqlite3_libversion_number: integer;
begin
  if assigned(psqlite3_libversion_number) then
    Result := Tsqlite3_libversion_number(psqlite3_libversion_number)()
  else
    raise Exception.Create(EXCPT_MSG);
end;

// Test To See If The Library Is Threadsafe

function sqlite3_threadsafe: integer;
begin
  if assigned(psqlite3_threadsafe) then
    Result := Tsqlite3_threadsafe(psqlite3_threadsafe)()
  else
    raise Exception.Create(EXCPT_MSG);
end;

// Test For Auto-Commit Mode

function sqlite3_get_autocommit(db: PSQLite3): integer;
begin
  if assigned(psqlite3_get_autocommit) then
    Result := Tsqlite3_get_autocommit(psqlite3_get_autocommit)(db)
  else
    raise Exception.Create(EXCPT_MSG);
end;

// Error Codes And Messages

function sqlite3_errcode(db: PSQLite3): integer;
begin
  if assigned(psqlite3_errcode) then
    Result := Tsqlite3_errcode(psqlite3_errcode)(db)
  else
    raise Exception.Create(EXCPT_MSG);
end;

function sqlite3_extended_errcode(db: PSQLite3): integer;
begin
  if assigned(psqlite3_extended_errcode) then
    Result := Tsqlite3_extended_errcode(psqlite3_extended_errcode)(db)
  else
    raise Exception.Create(EXCPT_MSG);
end;

function sqlite3_errmsg(db: PSQLite3): PUTF8Char;
begin
  if assigned(psqlite3_errmsg) then
    Result := Tsqlite3_errmsg(psqlite3_errmsg)(db)
  else
    raise Exception.Create(EXCPT_MSG);
end;

function sqlite3_errmsg16(db: PSQLite3): PWideChar;
begin
  if assigned(psqlite3_errmsg16) then
    Result := Tsqlite3_errmsg16(psqlite3_errmsg16)(db)
  else
    raise Exception.Create(EXCPT_MSG);
end;

// Enable Or Disable Extended Result Codes

function sqlite3_extended_result_codes(db: PSQLite3; onoff: integer): integer;
begin
  if assigned(psqlite3_extended_result_codes) then
    Result := Tsqlite3_extended_result_codes(psqlite3_extended_result_codes)
      (db, onoff)
  else
    raise Exception.Create(EXCPT_MSG);
end;

// Affected rows

function sqlite3_changes(db: PSQLite3): integer;
begin
  if assigned(psqlite3_changes) then
    Result := Tsqlite3_changes(psqlite3_changes)(db)
  else
    raise Exception.Create(EXCPT_MSG);
end;

function sqlite3_total_changes(db: PSQLite3): integer;
begin
  if assigned(psqlite3_total_changes) then
    Result := Tsqlite3_total_changes(psqlite3_total_changes)(db)
  else
    raise Exception.Create(EXCPT_MSG);
end;

// One-Step Query Execution Interface

function sqlite3_exec(db: PSQLite3; const sql: UTF8String;
  callback: TSQLiteExecCallback; UserData: Pointer;
  errmsg: PUTF8Char): integer;
begin
  if assigned(psqlite3_exec) then
    Result := Tsqlite3_exec(psqlite3_exec)(db, sql, callback, UserData, errmsg)
  else
    raise Exception.Create(EXCPT_MSG);
end;

// Memory Allocation Subsystem

function sqlite3_malloc(nBytes: integer): Pointer;
begin
  if assigned(psqlite3_malloc) then
    Result := Tsqlite3_malloc(psqlite3_malloc)(nBytes)
  else
    raise Exception.Create(EXCPT_MSG);
end;

function sqlite3_realloc(buffer: Pointer; nBytes: integer): Pointer;
begin
  if assigned(psqlite3_realloc) then
    Result := Tsqlite3_realloc(psqlite3_realloc)(buffer, nBytes)
  else
    raise Exception.Create(EXCPT_MSG);
end;

procedure sqlite3_free(buffer: Pointer);
begin
  if assigned(psqlite3_free) then
    Tsqlite3_free(psqlite3_free)(buffer)
  else
    raise Exception.Create(EXCPT_MSG);
end;


// Run-time Limits

function sqlite3_limit(db: PSQLite3; id: integer; newVal: integer): integer;
begin
  if assigned(psqlite3_limit) then
    Result := Tsqlite3_limit(psqlite3_limit)(db, id, newVal)
  else
    raise Exception.Create(EXCPT_MSG);
end;


// Extract Metadata About A Column Of A Table

function sqlite3_table_column_metadata(db: PSQLite3; const zDbName: UTF8String;
  const zTableName: UTF8String; const zColumnName: UTF8String;
  out pzDataType: PUTF8Char; out pzCollSeq: PUTF8Char; out pNotNull: integer;
  out pPrimaryKey: integer; out pAutoinc: integer): integer;
begin
  if assigned(psqlite3_table_column_metadata) then
    Result := Tsqlite3_table_column_metadata(psqlite3_table_column_metadata)
      (db, zDbName, zTableName, zColumnName, pzDataType, pzCollSeq, pNotNull,
      pPrimaryKey, pAutoinc)
  else
    raise Exception.Create(EXCPT_MSG);
end;

// Last Insert Rowid

function sqlite3_last_insert_rowid(db: PSQLite3): int64;
begin
  if assigned(psqlite3_last_insert_rowid) then
    Result := Tsqlite3_last_insert_rowid(psqlite3_last_insert_rowid)(db)
  else
    raise Exception.Create(EXCPT_MSG);
end;




// ------------------------------------
// Unit initalization and finalization
// ------------------------------------

procedure DoLink;
begin
//  @m_TestCallstd := BTMemoryGetProcAddress(btMM, 'TestCallstd');
  psqlite3_aggregate_context := BTMemoryGetProcAddress(btMM,
    'sqlite3_aggregate_context');
  psqlite3_auto_extension :=BTMemoryGetProcAddress(btMM,
    'sqlite3_auto_extension');
  psqlite3_backup_finish :=BTMemoryGetProcAddress(btMM, 'sqlite3_backup_finish');
  psqlite3_backup_init :=BTMemoryGetProcAddress(btMM, 'sqlite3_backup_init');
  psqlite3_backup_pagecount :=BTMemoryGetProcAddress(btMM,
    'sqlite3_backup_pagecount');
  psqlite3_backup_remaining :=BTMemoryGetProcAddress(btMM,
    'sqlite3_backup_remaining');
  psqlite3_backup_step :=BTMemoryGetProcAddress(btMM, 'sqlite3_backup_step');
  psqlite3_bind_blob :=BTMemoryGetProcAddress(btMM, 'sqlite3_bind_blob');
  psqlite3_bind_double :=BTMemoryGetProcAddress(btMM, 'sqlite3_bind_double');
  psqlite3_bind_int :=BTMemoryGetProcAddress(btMM, 'sqlite3_bind_int');
  psqlite3_bind_int64 :=BTMemoryGetProcAddress(btMM, 'sqlite3_bind_int64');
  psqlite3_bind_null :=BTMemoryGetProcAddress(btMM, 'sqlite3_bind_null');
  psqlite3_bind_parameter_count :=BTMemoryGetProcAddress(btMM,
    'sqlite3_bind_parameter_count');
  psqlite3_bind_parameter_index :=BTMemoryGetProcAddress(btMM,
    'sqlite3_bind_parameter_index');
  psqlite3_bind_parameter_name :=BTMemoryGetProcAddress(btMM,
    'sqlite3_bind_parameter_name');
  psqlite3_bind_text :=BTMemoryGetProcAddress(btMM, 'sqlite3_bind_text');
  psqlite3_bind_text16 :=BTMemoryGetProcAddress(btMM, 'sqlite3_bind_text16');
  psqlite3_bind_value :=BTMemoryGetProcAddress(btMM, 'sqlite3_bind_value');
  psqlite3_bind_zeroblob :=BTMemoryGetProcAddress(btMM, 'sqlite3_bind_zeroblob');
  psqlite3_blob_bytes :=BTMemoryGetProcAddress(btMM, 'sqlite3_blob_bytes');
  psqlite3_blob_close :=BTMemoryGetProcAddress(btMM, 'sqlite3_blob_close');
  psqlite3_blob_open :=BTMemoryGetProcAddress(btMM, 'sqlite3_blob_open');
  psqlite3_blob_read :=BTMemoryGetProcAddress(btMM, 'sqlite3_blob_read');
  psqlite3_blob_reopen :=BTMemoryGetProcAddress(btMM, 'sqlite3_blob_reopen');
  psqlite3_blob_write :=BTMemoryGetProcAddress(btMM, 'sqlite3_blob_write');
  psqlite3_busy_handler :=BTMemoryGetProcAddress(btMM, 'sqlite3_busy_handler');
  psqlite3_busy_timeout :=BTMemoryGetProcAddress(btMM, 'sqlite3_busy_timeout');
  psqlite3_changes :=BTMemoryGetProcAddress(btMM, 'sqlite3_changes');
  psqlite3_clear_bindings :=BTMemoryGetProcAddress(btMM,
    'sqlite3_clear_bindings');
  psqlite3_close :=BTMemoryGetProcAddress(btMM, 'sqlite3_close');
  psqlite3_collation_needed :=BTMemoryGetProcAddress(btMM,
    'sqlite3_collation_needed');
  psqlite3_collation_needed16 :=BTMemoryGetProcAddress(btMM,
    'sqlite3_collation_needed16');
  psqlite3_column_blob :=BTMemoryGetProcAddress(btMM, 'sqlite3_column_blob');
  psqlite3_column_bytes :=BTMemoryGetProcAddress(btMM, 'sqlite3_column_bytes');
  psqlite3_column_bytes16 :=BTMemoryGetProcAddress(btMM,
    'sqlite3_column_bytes16');
  psqlite3_column_count :=BTMemoryGetProcAddress(btMM, 'sqlite3_column_count');
  psqlite3_column_database_name :=BTMemoryGetProcAddress(btMM,
    'sqlite3_column_database_name');
  psqlite3_column_database_name16 :=BTMemoryGetProcAddress(btMM,
    'sqlite3_column_database_name16');
  psqlite3_column_decltype :=BTMemoryGetProcAddress(btMM,
    'sqlite3_column_decltype');
  psqlite3_column_decltype16 :=BTMemoryGetProcAddress(btMM,
    'sqlite3_column_decltype16');
  psqlite3_column_double :=BTMemoryGetProcAddress(btMM, 'sqlite3_column_double');
  psqlite3_column_int :=BTMemoryGetProcAddress(btMM, 'sqlite3_column_int');
  psqlite3_column_int64 :=BTMemoryGetProcAddress(btMM, 'sqlite3_column_int64');
  psqlite3_column_name :=BTMemoryGetProcAddress(btMM, 'sqlite3_column_name');
  psqlite3_column_name16 :=BTMemoryGetProcAddress(btMM, 'sqlite3_column_name16');
  psqlite3_column_origin_name :=BTMemoryGetProcAddress(btMM,
    'sqlite3_column_origin_name');
  psqlite3_column_origin_name16 :=BTMemoryGetProcAddress(btMM,
    'sqlite3_column_origin_name16');
  psqlite3_column_table_name :=BTMemoryGetProcAddress(btMM,
    'sqlite3_column_table_name');
  psqlite3_column_table_name16 :=BTMemoryGetProcAddress(btMM,
    'sqlite3_column_table_name16');
  psqlite3_column_text :=BTMemoryGetProcAddress(btMM, 'sqlite3_column_text');
  psqlite3_column_text16 :=BTMemoryGetProcAddress(btMM, 'sqlite3_column_text16');
  psqlite3_column_type :=BTMemoryGetProcAddress(btMM, 'sqlite3_column_type');
  psqlite3_column_value :=BTMemoryGetProcAddress(btMM, 'sqlite3_column_value');
  psqlite3_commit_hook :=BTMemoryGetProcAddress(btMM, 'sqlite3_commit_hook');
  psqlite3_compileoption_get :=BTMemoryGetProcAddress(btMM,
    'sqlite3_compileoption_get');
  psqlite3_compileoption_used :=BTMemoryGetProcAddress(btMM,
    'sqlite3_compileoption_used');
  psqlite3_complete :=BTMemoryGetProcAddress(btMM, 'sqlite3_complete');
  psqlite3_complete16 :=BTMemoryGetProcAddress(btMM, 'sqlite3_complete16');
  psqlite3_config :=BTMemoryGetProcAddress(btMM, 'sqlite3_config');
  psqlite3_context_db_handle :=BTMemoryGetProcAddress(btMM,
    'sqlite3_context_db_handle');
  psqlite3_create_collation :=BTMemoryGetProcAddress(btMM,
    'sqlite3_create_collation');
  psqlite3_create_collation16 :=BTMemoryGetProcAddress(btMM,
    'sqlite3_create_collation16');
  psqlite3_create_collation_v2 :=BTMemoryGetProcAddress(btMM,
    'sqlite3_create_collation_v2');
  psqlite3_create_function :=BTMemoryGetProcAddress(btMM,
    'sqlite3_create_function');
  psqlite3_create_function16 :=BTMemoryGetProcAddress(btMM,
    'sqlite3_create_function16');
  psqlite3_create_function_v2 :=BTMemoryGetProcAddress(btMM,
    'sqlite3_create_function_v2');
  psqlite3_create_module :=BTMemoryGetProcAddress(btMM, 'sqlite3_create_module');
  psqlite3_create_module_v2 :=BTMemoryGetProcAddress(btMM,
    'sqlite3_create_module_v2');
  psqlite3_data_count :=BTMemoryGetProcAddress(btMM, 'sqlite3_data_count');
  psqlite3_db_config :=BTMemoryGetProcAddress(btMM, 'sqlite3_db_config');
  psqlite3_db_filename :=BTMemoryGetProcAddress(btMM, 'sqlite3_db_filename');
  psqlite3_db_handle :=BTMemoryGetProcAddress(btMM, 'sqlite3_db_handle');
  psqlite3_db_mutex :=BTMemoryGetProcAddress(btMM, 'sqlite3_db_mutex');
  psqlite3_db_readonly :=BTMemoryGetProcAddress(btMM, 'sqlite3_db_readonly');
  psqlite3_db_release_memory :=BTMemoryGetProcAddress(btMM,
    'sqlite3_db_release_memory');
  psqlite3_db_status :=BTMemoryGetProcAddress(btMM, 'sqlite3_db_status');
  psqlite3_declare_vtab :=BTMemoryGetProcAddress(btMM, 'sqlite3_declare_vtab');
  psqlite3_enable_load_extension :=BTMemoryGetProcAddress(btMM,
    'sqlite3_enable_load_extension');
  psqlite3_enable_shared_cache :=BTMemoryGetProcAddress(btMM,
    'sqlite3_enable_shared_cache');
  psqlite3_errcode :=BTMemoryGetProcAddress(btMM, 'sqlite3_errcode');
  psqlite3_errmsg :=BTMemoryGetProcAddress(btMM, 'sqlite3_errmsg');
  psqlite3_errmsg16 :=BTMemoryGetProcAddress(btMM, 'sqlite3_errmsg16');
  psqlite3_exec :=BTMemoryGetProcAddress(btMM, 'sqlite3_exec');
  psqlite3_extended_errcode :=BTMemoryGetProcAddress(btMM,
    'sqlite3_extended_errcode');
  psqlite3_extended_result_codes :=BTMemoryGetProcAddress(btMM,
    'sqlite3_extended_result_codes');
  psqlite3_file_control :=BTMemoryGetProcAddress(btMM, 'sqlite3_file_control');
  psqlite3_finalize :=BTMemoryGetProcAddress(btMM, 'sqlite3_finalize');
  psqlite3_free :=BTMemoryGetProcAddress(btMM, 'sqlite3_free');
  psqlite3_free_table :=BTMemoryGetProcAddress(btMM, 'sqlite3_free_table');
  psqlite3_get_autocommit :=BTMemoryGetProcAddress(btMM,
    'sqlite3_get_autocommit');
  psqlite3_get_auxdata :=BTMemoryGetProcAddress(btMM, 'sqlite3_get_auxdata');
  psqlite3_get_table :=BTMemoryGetProcAddress(btMM, 'sqlite3_get_table');
  psqlite3_initialize :=BTMemoryGetProcAddress(btMM, 'sqlite3_initialize');
  psqlite3_interrupt :=BTMemoryGetProcAddress(btMM, 'sqlite3_interrupt');
  psqlite3_last_insert_rowid :=BTMemoryGetProcAddress(btMM,
    'sqlite3_last_insert_rowid');
  psqlite3_libversion :=BTMemoryGetProcAddress(btMM, 'sqlite3_libversion');
  psqlite3_libversion_number :=BTMemoryGetProcAddress(btMM,
    'sqlite3_libversion_number');
  psqlite3_limit :=BTMemoryGetProcAddress(btMM, 'sqlite3_limit');
  psqlite3_load_extension :=BTMemoryGetProcAddress(btMM,
    'sqlite3_load_extension');
  psqlite3_log :=BTMemoryGetProcAddress(btMM, 'sqlite3_log');
  psqlite3_malloc :=BTMemoryGetProcAddress(btMM, 'sqlite3_malloc');
  psqlite3_memory_highwater :=BTMemoryGetProcAddress(btMM,
    'sqlite3_memory_highwater');
  psqlite3_memory_used :=BTMemoryGetProcAddress(btMM, 'sqlite3_memory_used');
  psqlite3_mprintf :=BTMemoryGetProcAddress(btMM, 'sqlite3_mprintf');
  psqlite3_mutex_alloc :=BTMemoryGetProcAddress(btMM, 'sqlite3_mutex_alloc');
  psqlite3_mutex_enter :=BTMemoryGetProcAddress(btMM, 'sqlite3_mutex_enter');
  psqlite3_mutex_free :=BTMemoryGetProcAddress(btMM, 'sqlite3_mutex_free');
  psqlite3_mutex_held :=BTMemoryGetProcAddress(btMM, 'sqlite3_mutex_held');
  psqlite3_mutex_leave :=BTMemoryGetProcAddress(btMM, 'sqlite3_mutex_leave');
  psqlite3_mutex_notheld :=BTMemoryGetProcAddress(btMM, 'sqlite3_mutex_notheld');
  psqlite3_mutex_try :=BTMemoryGetProcAddress(btMM, 'sqlite3_mutex_try');
  psqlite3_next_stmt :=BTMemoryGetProcAddress(btMM, 'sqlite3_next_stmt');
  psqlite3_open :=BTMemoryGetProcAddress(btMM, 'sqlite3_open');
  psqlite3_open16 :=BTMemoryGetProcAddress(btMM, 'sqlite3_open16');
  psqlite3_open_v2 :=BTMemoryGetProcAddress(btMM, 'sqlite3_open_v2');
  psqlite3_os_end :=BTMemoryGetProcAddress(btMM, 'sqlite3_os_end');
  psqlite3_os_init :=BTMemoryGetProcAddress(btMM, 'sqlite3_os_init');
  psqlite3_overload_function :=BTMemoryGetProcAddress(btMM,
    'sqlite3_overload_function');
  psqlite3_prepare :=BTMemoryGetProcAddress(btMM, 'sqlite3_prepare');
  psqlite3_prepare16 :=BTMemoryGetProcAddress(btMM, 'sqlite3_prepare16');
  psqlite3_prepare16_v2 :=BTMemoryGetProcAddress(btMM, 'sqlite3_prepare16_v2');
  psqlite3_prepare_v2 :=BTMemoryGetProcAddress(btMM, 'sqlite3_prepare_v2');
  psqlite3_profile :=BTMemoryGetProcAddress(btMM, 'sqlite3_profile');
  psqlite3_progress_handler :=BTMemoryGetProcAddress(btMM,
    'sqlite3_progress_handler');
  psqlite3_randomness :=BTMemoryGetProcAddress(btMM, 'sqlite3_randomness');
  psqlite3_realloc :=BTMemoryGetProcAddress(btMM, 'sqlite3_realloc');
  psqlite3_release_memory :=BTMemoryGetProcAddress(btMM,
    'sqlite3_release_memory');
  psqlite3_reset :=BTMemoryGetProcAddress(btMM, 'sqlite3_reset');
  psqlite3_reset_auto_extension :=BTMemoryGetProcAddress(btMM,
    'sqlite3_reset_auto_extension');
  psqlite3_result_blob :=BTMemoryGetProcAddress(btMM, 'sqlite3_result_blob');
  psqlite3_result_double :=BTMemoryGetProcAddress(btMM, 'sqlite3_result_double');
  psqlite3_result_error :=BTMemoryGetProcAddress(btMM, 'sqlite3_result_error');
  psqlite3_result_error16 :=BTMemoryGetProcAddress(btMM,
    'sqlite3_result_error16');
  psqlite3_result_error_code :=BTMemoryGetProcAddress(btMM,
    'sqlite3_result_error_code');
  psqlite3_result_error_nomem :=BTMemoryGetProcAddress(btMM,
    'sqlite3_result_error_nomem');
  psqlite3_result_error_toobig :=BTMemoryGetProcAddress(btMM,
    'sqlite3_result_error_toobig');
  psqlite3_result_int :=BTMemoryGetProcAddress(btMM, 'sqlite3_result_int');
  psqlite3_result_int64 :=BTMemoryGetProcAddress(btMM, 'sqlite3_result_int64');
  psqlite3_result_null :=BTMemoryGetProcAddress(btMM, 'sqlite3_result_null');
  psqlite3_result_text :=BTMemoryGetProcAddress(btMM, 'sqlite3_result_text');
  psqlite3_result_text16 :=BTMemoryGetProcAddress(btMM, 'sqlite3_result_text16');
  psqlite3_result_text16be :=BTMemoryGetProcAddress(btMM,
    'sqlite3_result_text16be');
  psqlite3_result_text16le :=BTMemoryGetProcAddress(btMM,
    'sqlite3_result_text16le');
  psqlite3_result_value :=BTMemoryGetProcAddress(btMM, 'sqlite3_result_value');
  psqlite3_result_zeroblob :=BTMemoryGetProcAddress(btMM,
    'sqlite3_result_zeroblob');
  psqlite3_rollback_hook :=BTMemoryGetProcAddress(btMM, 'sqlite3_rollback_hook');
  psqlite3_set_authorizer :=BTMemoryGetProcAddress(btMM,
    'sqlite3_set_authorizer');
  psqlite3_set_auxdata :=BTMemoryGetProcAddress(btMM, 'sqlite3_set_auxdata');
  psqlite3_shutdown :=BTMemoryGetProcAddress(btMM, 'sqlite3_shutdown');
  psqlite3_sleep :=BTMemoryGetProcAddress(btMM, 'sqlite3_sleep');
  psqlite3_snprintf :=BTMemoryGetProcAddress(btMM, 'sqlite3_snprintf');
  psqlite3_soft_heap_limit64 :=BTMemoryGetProcAddress(btMM,
    'sqlite3_soft_heap_limit64');
  psqlite3_sourceid :=BTMemoryGetProcAddress(btMM, 'sqlite3_sourceid');
  psqlite3_sql :=BTMemoryGetProcAddress(btMM, 'sqlite3_sql');
  psqlite3_status :=BTMemoryGetProcAddress(btMM, 'sqlite3_status');
  psqlite3_step :=BTMemoryGetProcAddress(btMM, 'sqlite3_step');
  psqlite3_stmt_busy :=BTMemoryGetProcAddress(btMM, 'sqlite3_stmt_busy');
  psqlite3_stmt_readonly :=BTMemoryGetProcAddress(btMM, 'sqlite3_stmt_readonly');
  psqlite3_stmt_status :=BTMemoryGetProcAddress(btMM, 'sqlite3_stmt_status');
  psqlite3_stricmp :=BTMemoryGetProcAddress(btMM, 'sqlite3_stricmp');
  psqlite3_strnicmp :=BTMemoryGetProcAddress(btMM, 'sqlite3_strnicmp');
  psqlite3_table_column_metadata :=BTMemoryGetProcAddress(btMM,
    'sqlite3_table_column_metadata');
  psqlite3_test_control :=BTMemoryGetProcAddress(btMM, 'sqlite3_test_control');
  psqlite3_threadsafe :=BTMemoryGetProcAddress(btMM, 'sqlite3_threadsafe');
  psqlite3_total_changes :=BTMemoryGetProcAddress(btMM, 'sqlite3_total_changes');
  psqlite3_trace :=BTMemoryGetProcAddress(btMM, 'sqlite3_trace');
  psqlite3_unlock_notify :=BTMemoryGetProcAddress(btMM, 'sqlite3_unlock_notify');
  psqlite3_update_hook :=BTMemoryGetProcAddress(btMM, 'sqlite3_update_hook');
  psqlite3_uri_boolean :=BTMemoryGetProcAddress(btMM, 'sqlite3_uri_boolean');
  psqlite3_uri_int64 :=BTMemoryGetProcAddress(btMM, 'sqlite3_uri_int64');
  psqlite3_uri_parameter :=BTMemoryGetProcAddress(btMM, 'sqlite3_uri_parameter');
  psqlite3_user_data :=BTMemoryGetProcAddress(btMM, 'sqlite3_user_data');
  psqlite3_value_blob :=BTMemoryGetProcAddress(btMM, 'sqlite3_value_blob');
  psqlite3_value_bytes :=BTMemoryGetProcAddress(btMM, 'sqlite3_value_bytes');
  psqlite3_value_bytes16 :=BTMemoryGetProcAddress(btMM, 'sqlite3_value_bytes16');
  psqlite3_value_double :=BTMemoryGetProcAddress(btMM, 'sqlite3_value_double');
  psqlite3_value_int :=BTMemoryGetProcAddress(btMM, 'sqlite3_value_int');
  psqlite3_value_int64 :=BTMemoryGetProcAddress(btMM, 'sqlite3_value_int64');
  psqlite3_value_numeric_type :=BTMemoryGetProcAddress(btMM,
    'sqlite3_value_numeric_type');
  psqlite3_value_text :=BTMemoryGetProcAddress(btMM, 'sqlite3_value_text');
  psqlite3_value_text16 :=BTMemoryGetProcAddress(btMM, 'sqlite3_value_text16');
  psqlite3_value_text16be :=BTMemoryGetProcAddress(btMM,
    'sqlite3_value_text16be');
  psqlite3_value_text16le :=BTMemoryGetProcAddress(btMM,
    'sqlite3_value_text16le');
  psqlite3_value_type :=BTMemoryGetProcAddress(btMM, 'sqlite3_value_type');
  psqlite3_version :=BTMemoryGetProcAddress(btMM, 'sqlite3_version');
  psqlite3_vfs_find :=BTMemoryGetProcAddress(btMM, 'sqlite3_vfs_find');
  psqlite3_vfs_register :=BTMemoryGetProcAddress(btMM, 'sqlite3_vfs_register');
  psqlite3_vfs_unregister :=BTMemoryGetProcAddress(btMM,
    'sqlite3_vfs_unregister');
  psqlite3_vmprintf :=BTMemoryGetProcAddress(btMM, 'sqlite3_vmprintf');
  psqlite3_vsnprintf :=BTMemoryGetProcAddress(btMM, 'sqlite3_vsnprintf');
  psqlite3_vtab_config :=BTMemoryGetProcAddress(btMM, 'sqlite3_vtab_config');
  psqlite3_vtab_on_conflict :=BTMemoryGetProcAddress(btMM,
    'sqlite3_vtab_on_conflict');
  psqlite3_wal_autocheckpoint :=BTMemoryGetProcAddress(btMM,
    'sqlite3_wal_autocheckpoint');
  psqlite3_wal_checkpoint :=BTMemoryGetProcAddress(btMM,
    'sqlite3_wal_checkpoint');
  psqlite3_wal_checkpoint_v2 :=BTMemoryGetProcAddress(btMM,
    'sqlite3_wal_checkpoint_v2');
  psqlite3_wal_hook :=BTMemoryGetProcAddress(btMM, 'sqlite3_wal_hook');
end;

function DoInitialize:boolean;
var
  rs: TResourceStream;
  ms : TMemoryStream;
  errmode: dword;
  m_DllDataSize:dword;
  mp_DllData:pointer;
begin
  result:=false;
  if 0 <> FindResource(GetModuleHandle(nil), SQLITERESID, RT_RCDATA) then
  begin
    rs := TResourceStream.Create(hInstance, SQLITERESID, RT_RCDATA);
    ms := TMemoryStream.Create;
    try
      ms.LoadFromStream(rs);
      ms.Position := 0;
      m_DllDataSize := ms.Size;
      mp_DllData := GetMemory(m_DllDataSize);
      ms.Read(mp_DllData^, m_DllDataSize);
      errmode := SetErrorMode(SEM_FAILCRITICALERRORS or SEM_NOOPENFILEERRORBOX);
      // load dll
      btMM := BTMemoryLoadLibary(mp_DllData, m_DllDataSize);
      if btMM = nil then Abort;
      DoLink;
      SetErrorMode(errmode);
      result:=true;
    finally
      ms.Free;
      rs.Free;
    end;
  end;
end;

procedure DoFinalize;
begin
  // Unload sqlite3 DLL
  if Assigned(btMM) then BTMemoryFreeLibrary(btMM);
end;

end.
