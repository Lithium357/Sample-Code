object Form7: TForm7
  Left = 0
  Top = 0
  BorderIcons = [biSystemMenu, biMinimize]
  BorderStyle = bsToolWindow
  Caption = #1051#1086#1082#1072#1083#1100#1085#1086#1077' '#1080#1089#1087#1086#1083#1100#1079#1086#1074#1072#1085#1080#1077
  ClientHeight = 112
  ClientWidth = 265
  Color = clWhite
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'Tahoma'
  Font.Style = []
  OldCreateOrder = False
  Position = poDesktopCenter
  Visible = True
  OnClose = FormClose
  OnCreate = FormCreate
  OnDestroy = FormDestroy
  PixelsPerInch = 96
  TextHeight = 13
  object Label5: TsLabel
    Left = 24
    Top = 31
    Width = 56
    Height = 13
    Caption = #1048#1084#1103' '#1087#1072#1087#1082#1080':'
    ParentFont = False
    Font.Charset = DEFAULT_CHARSET
    Font.Color = 10329501
    Font.Height = -11
    Font.Name = 'Tahoma'
    Font.Style = []
  end
  object CheckBox6: TsCheckBox
    Left = 5
    Top = 4
    Width = 172
    Height = 20
    Caption = #1050#1086#1087#1080#1088#1086#1074#1072#1090#1100' '#1086#1090#1095#1077#1090#1099' '#1074' '#1087#1072#1087#1082#1091
    Checked = True
    State = cbChecked
    TabOrder = 0
    OnClick = CheckBox6Click
    SkinData.SkinSection = 'CHECKBOX'
    ImgChecked = 0
    ImgUnchecked = 0
    ShowFocus = False
  end
  object Edit1: TsEdit
    Left = 88
    Top = 28
    Width = 160
    Height = 21
    Color = 1710618
    Font.Charset = DEFAULT_CHARSET
    Font.Color = 10329501
    Font.Height = -11
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
    TabOrder = 1
    SkinData.SkinSection = 'EDIT'
    BoundLabel.Indent = 0
    BoundLabel.Font.Charset = DEFAULT_CHARSET
    BoundLabel.Font.Color = clWindowText
    BoundLabel.Font.Height = -11
    BoundLabel.Font.Name = 'Tahoma'
    BoundLabel.Font.Style = []
    BoundLabel.Layout = sclLeft
    BoundLabel.MaxWidth = 0
    BoundLabel.UseSkinColor = True
  end
  object Button1: TsButton
    Left = 5
    Top = 83
    Width = 255
    Height = 24
    Caption = 'OK'
    TabOrder = 2
    OnClick = Button1Click
    SkinData.SkinSection = 'BUTTON'
  end
  object CheckBox3: TsCheckBox
    Left = 24
    Top = 60
    Width = 163
    Height = 20
    Caption = #1055#1088#1103#1090#1072#1090#1100' '#1087#1072#1087#1082#1091' '#1089' '#1086#1090#1095#1077#1090#1072#1084#1080
    Checked = True
    Color = clWhite
    ParentColor = False
    State = cbChecked
    TabOrder = 3
    SkinData.SkinSection = 'CHECKBOX'
    ImgChecked = 0
    ImgUnchecked = 0
    ShowFocus = False
    WordWrap = True
  end
end
