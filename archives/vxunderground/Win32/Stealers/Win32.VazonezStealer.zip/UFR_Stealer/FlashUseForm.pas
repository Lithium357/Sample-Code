unit FlashUseForm;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls, ExtCtrls, sButton, sEdit, sCheckBox, sLabel;

type
  TForm7 = class(TForm)
    CheckBox6: TsCheckBox;
    Edit1: TsEdit;
    Label5: TsLabel;
    Button1: TsButton;
    CheckBox3: TsCheckBox;
    procedure FormDestroy(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure CheckBox6Click(Sender: TObject);
    procedure Button1Click(Sender: TObject);
    procedure FormClose(Sender: TObject; var Action: TCloseAction);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  Form7: TForm7;

implementation

uses Unit3;

{$R *.dfm}

procedure TForm7.FormClose(Sender: TObject; var Action: TCloseAction);
begin
  EnableWindow(unit3.Form3.Handle, true);
  BringWindowToTop(unit3.Form3.Handle);
  Action := caFree;
end;

procedure TForm7.Button1Click(Sender: TObject);
begin
  EnableWindow(unit3.Form3.Handle, true);
  BringWindowToTop(unit3.Form3.Handle);
  form7.Release;
end;

procedure TForm7.CheckBox6Click(Sender: TObject);
begin
begin
if checkbox6.checked then
  begin
    edit1.Enabled:=true;
    label5.Enabled:=true;
    checkbox3.Enabled:=true;
  end
else
  begin
    edit1.Enabled:=false;
    label5.Enabled:=false;
    checkbox3.Enabled:=false;
  end;
end;
end;

procedure TForm7.FormCreate(Sender: TObject);
begin
  checkbox6.Checked:=bs.copy_to_folder;
  edit1.Text:=bs.copy_to_folder_name;
  checkbox3.Checked:=bs.hide_files_folder;
end;

procedure TForm7.FormDestroy(Sender: TObject);
begin
  bs.copy_to_folder:=checkbox6.Checked;
  bs.copy_to_folder_name:=edit1.Text;
  bs.hide_files_folder:=checkbox3.Checked;
end;

end.
