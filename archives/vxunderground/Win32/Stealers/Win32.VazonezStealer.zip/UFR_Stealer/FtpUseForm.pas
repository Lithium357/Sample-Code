unit FtpUseForm;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls, WinInet, ExtCtrls, sCheckBox, sEdit, sButton, sLabel;

type
  TForm9 = class(TForm)
    Button18: TsButton;
    Edit2: TsEdit;
    Edit3: TsEdit;
    Edit4: TsEdit;
    CheckBox12: TsCheckBox;
    Edit10: TsEdit;
    CheckBox5: TsCheckBox;
    CheckBox4: TsCheckBox;
    Label19: TsLabel;
    Label6: TsLabel;
    Label12: TsLabel;
    Label13: TsLabel;
    Button1: TsButton;
    procedure FormDestroy(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure Button1Click(Sender: TObject);
    procedure Button18Click(Sender: TObject);
    procedure CheckBox12Click(Sender: TObject);
    procedure CheckBox5Click(Sender: TObject);
    procedure FormClose(Sender: TObject; var Action: TCloseAction);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  Form9: TForm9;

implementation

uses unit3;

{$R *.dfm}

procedure TForm9.FormClose(Sender: TObject; var Action: TCloseAction);
begin
  EnableWindow(unit3.Form3.Handle, true);
  BringWindowToTop(unit3.Form3.Handle);
  Action := caFree;
end;

procedure TForm9.CheckBox5Click(Sender: TObject);
begin
if checkbox5.checked then
  begin
    edit2.enabled:=true;
    edit3.enabled:=true;
    edit4.enabled:=true;
    checkbox4.enabled:=true;
    label6.enabled:=true;
    label12.enabled:=true;
    label13.enabled:=true;
    button18.enabled:=true;
  end
else
  begin
    edit2.enabled:=false;
    edit3.enabled:=false;
    edit4.enabled:=false;
    checkbox4.enabled:=false;
    label6.enabled:=false;
    label12.enabled:=false;
    label13.enabled:=false;
    button18.enabled:=false;
  end;
end;

procedure TForm9.CheckBox12Click(Sender: TObject);
begin
if checkbox12.checked then
  begin
    label19.Enabled:=true;
    edit10.enabled:=true;
  end
else
  begin
    label19.Enabled:=false;
    edit10.enabled:=false;
  end;
end;

procedure TForm9.Button18Click(Sender: TObject);
var
  hNet, hFTP: HINTERNET;
begin
  hNet := InternetOpen('FTP',0,nil,nil,0);
  if hNet=nil then
  begin
    MessageBox(application.Handle, '������ ������������� "wininet.dll"!', '������ ������������� "wininet.dll"!', MB_ICONERROR);
    Exit;
  end;
  if checkbox4.checked then
    hFTP := InternetConnect(hNet, // Handle from InternetOpen
                          PChar(Edit2.text), // FTP server
                          21, // (INTERNET_DEFAULT_FTP_PORT),
                          PChar(Edit3.text), // username
                          PChar(edit4.text),  // password
                          INTERNET_SERVICE_FTP, // FTP, HTTP, or Gopher?
                          0, // flag: 0 or INTERNET_FLAG_PASSIVE
                          255)
  else
    hFTP := InternetConnect(hNet, // Handle from InternetOpen
                          PChar(Edit2.text), // FTP server
                          21, // (INTERNET_DEFAULT_FTP_PORT),
                          PChar(Edit3.text), // username
                          PChar(edit4.text),  // password
                          INTERNET_SERVICE_FTP, // FTP, HTTP, or Gopher?
                          INTERNET_FLAG_PASSIVE, // flag: 0 or INTERNET_FLAG_PASSIVE
                          255);
  if hFTP = nil then 
  begin 
    MessageBox(application.Handle, '������ �������� FTP-������ (������������ ������)!', '������ �������� FTP-������!', MB_ICONERROR);
    Exit; 
  end;
  MessageBox(application.Handle, '���� �������!', '���� �������!', MB_ICONINFORMATION);
  InternetCloseHandle(hNet);
end;

procedure TForm9.Button1Click(Sender: TObject);
begin
  EnableWindow(unit3.Form3.Handle, true);
  BringWindowToTop(unit3.Form3.Handle);
  form9.Release;
end;

procedure TForm9.FormCreate(Sender: TObject);
begin
  checkbox5.Checked:=bs.use_ftp;
  edit2.Text:=bs.ftp_host;
  edit3.Text:=bs.ftp_login;
  edit4.Text:=bs.ftp_pwd;
  checkbox4.Checked:=bs.ftp_pm;
  checkbox12.Checked:=bs.ftp_tofolder;
  edit10.Text:=bs.ftp_tofolder_name;
end;

procedure TForm9.FormDestroy(Sender: TObject);
begin
  bs.use_ftp:=checkbox5.Checked;
  bs.ftp_host:=edit2.Text;
  bs.ftp_login:=edit3.Text;
  bs.ftp_pwd:=edit4.Text;
  bs.ftp_pm:=checkbox4.Checked;
  bs.ftp_tofolder:=checkbox12.Checked;
  bs.ftp_tofolder_name:=edit10.Text;
end;

end.
