unit GFX_About;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls, ExtCtrls, shellapi, sLabel, acPNG;

type

  TForm2 = class(TForm)
    Label1: TsLabel;
    Label2: TsLabel;
    Label5: TsLabel;
    Label6: TsLabel;
    Label3: TsLabel;
    Timer1: TTimer;
    Label8: TsLabel;
    Timer2: TTimer;
    Image1: TImage;
    procedure Timer2Timer(Sender: TObject);
    procedure Timer1Timer(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure FormClose(Sender: TObject; var Action: TCloseAction);
  private
    { Private declarations }
  public
    procedure init_shit;
  end;

  g_item = packed record
    color:tcolor;
    busy:boolean;
    //id:dword;
    x:dword;
    y:dword;
  end;

  g_obj = packed record
    items:array[0..31] of dword;// indexes
    count:dword;
    id:dword;
    busy:boolean;
  end;

  partletter = packed record
    x:byte;
    y:byte;
  end;

const
  FIELD_WIDTH       =  18;
  FIELD_HEIGHT      =  26;
  ID_SHIP           =  $00000001;
  ID_BULLET         =  $00000002;
  ID_GAMEOVER       =  $00000005;
  STATUS_NONE       =  $00000000;
  STATUS_ADDING     =  $00000001;
  STATUS_MOVING     =  $00000002;
  STATUS_GETTING    =  $00000003;

var
  Form2: TForm2;
  colors:array[0..11] of tcolor;
  obj_colors:array[0..4] of tcolor;
  items:array[0..4*FIELD_WIDTH*FIELD_HEIGHT-1] of g_item;
  objs:array[0..4*FIELD_WIDTH*FIELD_HEIGHT-1] of g_obj;
  ship_obj_index,monster_obj_index:dword;
  Buf:TBitmap;
  STATUS:DWORD;
  SHINDEX:DWORD;
  shs:array[0..7] of partletter;
  stts,sint,st3:integer;

implementation

{$R *.dfm}

uses
  unit3;

function RGBToColor(R, G, B: Byte): TColor;
begin
  Result := B shl 16 or G shl 8 or R;
end;

function GetR(const Color: TColor): Byte;
begin
  Result := Lo(Color);
end;

function GetG(const Color: TColor): Byte;
begin
  Result := Lo(Color shr 8);
end;

function GetB(const Color: TColor): Byte;
begin
  Result := Lo((Color shr 8) shr 8);
end;

function add_rect(x,y,color:dword):dword;
var
  i:integer;
begin
  result:=0;
  for i:=0 to length(items)-1 do
  begin
    if items[i].busy=false then
    begin
      {if color=dword(clblack) then
        items[i].color:=colors[random(length(colors))]
      else
        items[i].color:=color; }
      items[i].x:=x;
      items[i].y:=y;
      items[i].busy:=true;
      result:=i;
      break;
    end;
  end;
end;

function get_obj_pos(index:word):dword;
var
  i:integer;
  min:dword;
begin
  if STATUS<>STATUS_NONE then
  repeat
    Sleep(1);
  until STATUS=STATUS_NONE;
  STATUS:=STATUS_GETTING;
  min:=$FFFFFFFF;
  for i:=0 to objs[index].count-1 do
  begin
    if items[objs[index].items[i]].x<min then min:=items[objs[index].items[i]].x;
  end;
  result:=min;
  STATUS:=STATUS_NONE;
end;

function get_obj_index_by_coords(x,y:dword):dword;
var
  i,i2:integer;
begin
  result:=$FFFFFFFF;
  for i:=0 to length(objs)-1 do
  begin
    for i2:=0 to length(objs[i].items) do
    begin
      if (items[objs[i].items[i2]].x = x) and
         (items[objs[i].items[i2]].y = y) then
      begin
        result:=i;
        exit;
      end;
    end;
  end;
end;

procedure TForm2.FormClose(Sender: TObject; var Action: TCloseAction);
begin
  EnableWindow(unit3.Form3.Handle, true);
  BringWindowToTop(unit3.Form3.Handle);

  timer1.enabled:=false;
  buf.Free;
  Action := caFree;
end;

procedure DrawSomeGame;
var
  i:integer;
begin
  buf.Canvas.Brush.Color:=clWhite;
  buf.Canvas.FillRect(Rect(0,0,Buf.Width, Buf.Height));
  buf.Canvas.Rectangle(bounds(0,0,FIELD_WIDTH*10+1+2,FIELD_HEIGHT*10+1+2));
  // Draw items
  for i:=0 to length(items)-1 do
  begin
    if items[i].busy = True then
    begin
      items[i].color:=colors[random(length(colors))];
      buf.Canvas.Brush.Color:=items[i].color;
      //if items[i].color<>0 then
      //items[i].color:=items[i].color+1-1;
      buf.Canvas.Rectangle(rect({9}1+1+items[i].x*10,
                                   {9}1+1+items[i].y*10,
                                   {9}1+1+items[i].x*10+9,
                                   {9}1+1+items[i].y*10+9));
    end;
  end;
  form2.Canvas.Draw(8,8,buf);
end;

procedure TForm2.init_shit;
begin
  STATUS:=STATUS_NONE;
  // Create ship obj
  {ship_obj_index:=0;
  objs[0].busy:=true;
  clr:=clred;//obj_colors[random(length(obj_colors))];
  objs[0].items[objs[0].count]:=add_rect(06,28,clr);inc(objs[0].count);
  objs[0].items[objs[0].count]:=add_rect(06,29,clr);inc(objs[0].count);
  objs[0].items[objs[0].count]:=add_rect(07,29,clr);inc(objs[0].count);
  objs[0].items[objs[0].count]:=add_rect(08,28,clr);inc(objs[0].count);
  objs[0].items[objs[0].count]:=add_rect(08,29,clr);inc(objs[0].count);
  objs[0].items[objs[0].count]:=add_rect(09,29,clr);inc(objs[0].count);
  objs[0].items[objs[0].count]:=add_rect(10,28,clr);inc(objs[0].count);
  objs[0].items[objs[0].count]:=add_rect(10,29,clr);inc(objs[0].count);
  objs[0].id:=ID_SHIP;}

  timer1.Enabled:=true;
end;

procedure TForm2.FormCreate(Sender: TObject);
const
  delimiter='  ###  ';
begin
  label8.Caption:=delimiter+
                  'UFR Stealer v'+ufr_ver+delimiter+
                  'Code: vazonez'+delimiter+
                  'Special thanks to: logovaz, yMa, Flint_ta, Morgot, Coban2k && all members of VaZoNeZ.CoM'+delimiter+
                  'Contact: http://vazonez.com';

  form2.Visible:=false;

  {randomize;
  Form2.DoubleBuffered:=true;
  buf:=tbitmap.Create;
  buf.Width:=183;
  buf.Height:=263;

  Form2.Canvas.Pen.Width:=1;
  Form2.Canvas.Pen.Color:=clBlack;

  fillchar(objs,sizeof(objs),0);
  fillchar(items,sizeof(items),0);

  SHINDEX:=0;
  stts:=0;
  sint:=0;
  st3:=0;

  colors[00]:=RGB($48,$48,$48);
  colors[01]:=RGB($40,$40,$40);
  colors[02]:=RGB($38,$38,$38);
  colors[03]:=RGB($30,$30,$30);
  colors[04]:=RGB($28,$28,$28);
  colors[05]:=RGB($20,$20,$20);
  colors[06]:=RGB($58,$58,$58);
  colors[07]:=RGB($50,$50,$50);
 

  init_shit;}
end;

procedure TForm2.Timer1Timer(Sender: TObject);
const
  shs:array[0..359] of integer =
  (2,2,2,3,2,4,2,5,2,6,2,7,3,7,4,7,5,7,5,6,5,5,5,4,5,3,5,2,{U}
   10,2,9,2,8,2,7,2,7,3,7,4,7,5,8,5,9,5,10,5,7,6,7,7,{F}
   12,7,12,6,12,5,12,4,12,3,12,2,13,2,14,2,15,2,15,3,15,4,14,4,13,4,13,5,14,6,15,7,{R}
   3,11,4,11,5,11,6,11,7,11,8,11,9,11,10,11,11,11,12,11,13,11,14,11,
   14,12,13,12,12,12,11,12,10,12,9,12,8,12,7,12,6,12,5,12,4,12,3,12,
   5,13,5,14,5,15,5,16,5,17,5,18,5,19,5,20,5,21,
   6,13,6,14,6,15,6,16,6,17,6,18,6,19,6,20,6,21,
   8,13,8,14,8,15,8,16,8,17,8,18,8,19,8,20,8,21,
   9,13,9,14,9,15,9,16,9,17,9,18,9,19,9,20,9,21,
   11,13,11,14,11,15,11,16,11,17,11,18,11,19,11,20,11,21,
   12,13,12,14,12,15,12,16,12,17,12,18,12,19,12,20,12,21,
   14,22,13,22,12,22,11,22,10,22,9,22,8,22,7,22,6,22,5,22,4,22,3,22,
   3,23,4,23,5,23,6,23,7,23,8,23,9,23,10,23,11,23,12,23,13,23,14,23,
   -1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,
   -1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,
   -1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1);
var
  i2:integer;
begin
  if integer(SHINDEX) = length(shs) then stts:=1;
  if ((stts=1) and (sint>FIELD_HEIGHT)) then stts:=2;
  if stts=2 then
  begin
    inc(st3);
    if st3>30 then
    begin
      SHINDEX:=0;
      stts:=0;
      sint:=0;
      st3:=0;
      FillChar(items,sizeof(items),$00);
      FillChar(objs,sizeof(objs),$00);
    end;
  end;
  if stts=1 then
  begin
    for i2:=0 to FIELD_WIDTH-1 do
    add_rect(i2,sint,clblack);
    inc(sint);
  end;
  if stts=0 then
  begin
    add_rect(shs[SHINDEX],shs[SHINDEX+1],clblack);
    inc(SHINDEX,2);
  end;
  DrawSomeGame;
end;

procedure TForm2.Timer2Timer(Sender: TObject);
begin
  label8.caption := copy(label8.caption, 2, length(label8.caption)-1) + copy(label8.caption, 1, 1);
end;

end.
