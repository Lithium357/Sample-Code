"f:\Program Files\Borland\BDS\3.0\Bin\brcc32.exe" "gate.rc"
copy "f:\Program Files\Borland\BDS\3.0\Bin\gate.res" "gate.res"