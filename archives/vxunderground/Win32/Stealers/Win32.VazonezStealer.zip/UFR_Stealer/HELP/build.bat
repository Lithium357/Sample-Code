"f:\Program Files\Borland\BDS\3.0\Bin\brcc32.exe" "help.rc"
copy "f:\Program Files\Borland\BDS\3.0\Bin\help.res" "help.res"