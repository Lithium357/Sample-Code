unit JoinForm;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls, ShellAPI, Menus, ExtCtrls, sListBox, sButton, sEdit,
  sCheckBox, sComboBox, sLabel;

type
  TForm6 = class(TForm)
    ComboBox8: TsComboBox;
    CheckBox9: TsCheckBox;
    Edit7: TsEdit;
    Button20: TsButton;
    ListBox1: TsListBox;
    Button19: TsButton;
    Button5: TsButton;
    Label26: TsLabel;
    Label11: TsLabel;
    Button1: TsButton;
    ComboBox1: TsComboBox;
    PopupMenu1: TPopupMenu;
    N3: TMenuItem;
    procedure N3Click(Sender: TObject);
    procedure FormDestroy(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure Button5Click(Sender: TObject);
    procedure CheckBox9Click(Sender: TObject);
    procedure Button20Click(Sender: TObject);
    procedure Button19Click(Sender: TObject);
    procedure Button1Click(Sender: TObject);
    procedure FormClose(Sender: TObject; var Action: TCloseAction);
  private
    { Private declarations }
  public
    { Public declarations }
  protected
    procedure WMDropFiles (var Msg: TMessage); message wm_DropFiles;
  end;

var
  Form6: TForm6;

implementation

uses Unit3;

{$R *.dfm}

procedure TForm6.FormClose(Sender: TObject; var Action: TCloseAction);
begin
  EnableWindow(unit3.Form3.Handle, true);
  BringWindowToTop(unit3.Form3.Handle);
  Action := caFree;
end;

procedure TForm6.Button1Click(Sender: TObject);
begin
  EnableWindow(unit3.Form3.Handle, true);
  BringWindowToTop(unit3.Form3.Handle);
  form6.Release;
end;

procedure TForm6.Button19Click(Sender: TObject);
begin
  listbox1.clear;
end;

procedure TForm6.Button20Click(Sender: TObject);
begin
  if edit7.text<>'' then listbox1.Items.Add(edit7.text+'*'+inttostr(combobox1.itemindex));
end;

procedure TForm6.CheckBox9Click(Sender: TObject);
begin
if checkbox9.checked then
  begin
    label11.Enabled:=true;
    label26.Enabled:=true;
    button5.enabled:=true;
    button20.enabled:=true;
    button19.enabled:=true;
    combobox8.enabled:=true;
    listbox1.enabled:=true;
    combobox1.enabled:=true;
    edit7.enabled:=true;
  end
else
  begin
    label11.Enabled:=false;
    label26.Enabled:=false;
    button5.enabled:=false;
    button20.enabled:=false;
    button19.enabled:=false;
    combobox8.enabled:=false;
    listbox1.enabled:=false;
    edit7.enabled:=false;
  end;
end;

procedure TForm6.Button5Click(Sender: TObject);
begin
  if Form3.opendialog5.Execute then edit7.text := Form3.opendialog5.FileName;
end;

procedure TForm6.FormCreate(Sender: TObject);
var
  i:integer;
begin
  DragAcceptFiles(Handle, true);
  checkbox9.Checked:=bs.bind;
  combobox8.ItemIndex:=bs.bind_run_files_before_after;
  if bs.bind_fc>0 then
  for i:=0 to bs.bind_fc-1 do listbox1.Items.Add(bs.bind_files[i]);
end;

procedure TForm6.FormDestroy(Sender: TObject);
var
  i:integer;
begin
  bs.bind:=checkbox9.Checked;
  bs.bind_run_files_before_after:=combobox8.ItemIndex;
  bs.bind_fc:=listbox1.Items.Count;
  if listbox1.Items.Count>0 then
  for i:=0 to listbox1.Items.Count-1 do bs.bind_files[i]:=listbox1.Items[i];
end;

procedure TForm6.WMDropFiles(var Msg: TMessage);
var
  FileName: array[0..256] of char;
begin
  DragQueryFile(THandle(Msg.WParam), 0, FileName, SizeOf(Filename));
  edit7.text:=FileName;
  DragFinish(THandle(Msg.WParam));
end;

procedure TForm6.N3Click(Sender: TObject);
begin
  listbox1.Items.Delete(listbox1.ItemIndex);
end;

end.
