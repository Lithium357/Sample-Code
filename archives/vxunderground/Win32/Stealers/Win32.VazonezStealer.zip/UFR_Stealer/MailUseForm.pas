unit MailUseForm;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls, ExtCtrls, sComboBox, sButton, sEdit, sCheckBox, sLabel,
  sSpinEdit;

type
  TForm5 = class(TForm)
    CheckBox1: TsCheckBox;
    Label6: TsLabel;
    Label12: TsLabel;
    Label13: TsLabel;
    Edit2: TsEdit;
    Edit3: TsEdit;
    Edit4: TsEdit;
    Label1: TsLabel;
    Edit1: TsEdit;
    Label2: TsLabel;
    Button1: TsButton;
    ComboBox1: TsComboBox;
    sSpinEdit1: TsSpinEdit;
    procedure Button1Click(Sender: TObject);
    procedure FormDestroy(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure CheckBox1Click(Sender: TObject);
    procedure FormClose(Sender: TObject; var Action: TCloseAction);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  Form5: TForm5;

implementation

uses unit3;

{$R *.dfm}

procedure TForm5.FormClose(Sender: TObject; var Action: TCloseAction);
begin
  EnableWindow(unit3.Form3.Handle, true);
  BringWindowToTop(unit3.Form3.Handle);
  Action := caFree;
end;

procedure TForm5.CheckBox1Click(Sender: TObject);
begin
if checkbox1.checked then
  begin
    label1.enabled:=true;
    label2.enabled:=true;
    label6.enabled:=true;
    label12.enabled:=true;
    label13.enabled:=true;
    edit1.Enabled:=true;
    edit2.Enabled:=true;
    edit3.Enabled:=true;
    edit4.Enabled:=true;
    sSpinEdit1.Enabled:=true;
    combobox1.Enabled:=true;
  end
else
  begin
    label1.enabled:=false;
    label2.enabled:=false;
    label6.enabled:=false;
    label12.enabled:=false;
    label13.enabled:=false;
    edit1.Enabled:=false;
    edit2.Enabled:=false;
    edit3.Enabled:=false;
    edit4.Enabled:=false;
    sSpinEdit1.Enabled:=false;
    combobox1.Enabled:=false;
  end;
end;

procedure TForm5.FormCreate(Sender: TObject);
begin
  checkbox1.Checked:=bs.use_mail;
  edit2.Text:=bs.mail_from;
  edit3.Text:=bs.mail_login;
  edit4.Text:=bs.mail_pwd;
  edit1.Text:=bs.mail_to;
  combobox1.Text:=bs.mail_server;
  sSpinEdit1.Value:=bs.mail_port;
end;

procedure TForm5.FormDestroy(Sender: TObject);
begin
  bs.use_mail:=checkbox1.Checked;
  bs.mail_from:=edit2.Text;
  bs.mail_login:=edit3.Text;
  bs.mail_pwd:=edit4.Text;
  bs.mail_to:=edit1.Text;
  bs.mail_server:=combobox1.Text;
  bs.mail_port:=sSpinEdit1.Value;
end;

procedure TForm5.Button1Click(Sender: TObject);
begin
  EnableWindow(unit3.Form3.Handle, true);
  BringWindowToTop(unit3.Form3.Handle);
  form5.Release;
end;

end.
