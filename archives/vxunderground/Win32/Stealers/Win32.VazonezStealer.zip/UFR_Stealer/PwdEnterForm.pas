unit PwdEnterForm;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls, Parser, ExtCtrls, sButton, sEdit, sLabel;

type
  TForm15 = class(TForm)
    Label1: TsLabel;
    Edit1: TsEdit;
    Button1: TsButton;
    procedure FormClose(Sender: TObject; var Action: TCloseAction);
    procedure Button1Click(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  Form15: TForm15;

implementation

uses Unit3;

{$R *.dfm}

procedure TForm15.Button1Click(Sender: TObject);
var
  s:string;
begin
  s:=edit1.text;
  begin
    parser.pwd:=s;
    parser.IsEnteredPwd:=true;
    EnableWindow(unit3.Form3.Handle, true);
    BringWindowToTop(unit3.Form3.Handle);
    form15.Release;
  end;
end;

procedure TForm15.FormClose(Sender: TObject; var Action: TCloseAction);
begin
  EnableWindow(unit3.Form3.Handle, true);
  BringWindowToTop(unit3.Form3.Handle);
  Action := caFree;
end;

end.
