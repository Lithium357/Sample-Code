object Form14: TForm14
  Left = 0
  Top = 0
  BorderIcons = [biSystemMenu, biMinimize]
  BorderStyle = bsToolWindow
  Caption = #1047#1072#1097#1080#1090#1072' '#1086#1090#1095#1077#1090#1086#1074' '#1087#1072#1088#1086#1083#1077#1084
  ClientHeight = 255
  ClientWidth = 426
  Color = clWhite
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'Tahoma'
  Font.Style = []
  OldCreateOrder = False
  Position = poDesktopCenter
  Visible = True
  OnClose = FormClose
  OnCreate = FormCreate
  OnDestroy = FormDestroy
  PixelsPerInch = 96
  TextHeight = 13
  object Label1: TsLabel
    Left = 8
    Top = 8
    Width = 91
    Height = 13
    Caption = #1055#1088#1080#1074#1072#1090#1085#1099#1081' '#1082#1083#1102#1095':'
    ParentFont = False
    Font.Charset = DEFAULT_CHARSET
    Font.Color = 10329501
    Font.Height = -11
    Font.Name = 'Tahoma'
    Font.Style = []
  end
  object Label2: TsLabel
    Left = 24
    Top = 186
    Width = 357
    Height = 26
    AutoSize = False
    Caption = 
      #1057#1086#1074#1077#1090': '#1086#1079#1085#1072#1082#1086#1084#1100#1090#1077#1089#1100' '#1089#1086' '#1089#1087#1088#1072#1074#1082#1086#1081' ('#1082#1085#1086#1087#1082#1072' '#1074' '#1075#1083#1072#1074#1085#1086#1084' '#1086#1082#1085#1077' '#1087#1088#1086#1075#1088#1072#1084#1084#1099 +
      ')  '#1087#1077#1088#1077#1076' '#1080#1089#1087#1086#1083#1100#1079#1086#1074#1072#1085#1080#1077#1084' '#1076#1072#1085#1085#1086#1081' '#1086#1087#1094#1080#1080'.'
    ParentFont = False
    WordWrap = True
    Font.Charset = DEFAULT_CHARSET
    Font.Color = 10329501
    Font.Height = -11
    Font.Name = 'Tahoma'
    Font.Style = []
  end
  object sLabel1: TsLabel
    Left = 24
    Top = 50
    Width = 357
    Height = 26
    AutoSize = False
    Caption = 
      #1055#1088#1080#1074#1072#1090#1085#1099#1081' '#1082#1083#1102#1095' '#1085#1091#1078#1077#1085' '#1076#1083#1103' '#1087#1072#1088#1089#1080#1085#1075#1072' '#1086#1090#1095#1077#1090#1086#1074'. '#1057#1086#1093#1088#1072#1085#1080#1090#1077' '#1077#1075#1086', '#1080#1085#1072#1095#1077' ' +
      #1074#1099' '#1085#1077' '#1089#1084#1086#1078#1077#1090#1077' '#1086#1090#1082#1088#1099#1090#1100' '#1086#1090#1095#1077#1090#1099'!'
    ParentFont = False
    WordWrap = True
    Font.Charset = DEFAULT_CHARSET
    Font.Color = 10329501
    Font.Height = -11
    Font.Name = 'Tahoma'
    Font.Style = []
  end
  object sLabel2: TsLabel
    Left = 8
    Top = 88
    Width = 91
    Height = 13
    Caption = #1055#1091#1073#1083#1080#1095#1085#1099#1081' '#1082#1083#1102#1095':'
    ParentFont = False
    Font.Charset = DEFAULT_CHARSET
    Font.Color = 10329501
    Font.Height = -11
    Font.Name = 'Tahoma'
    Font.Style = []
  end
  object sLabel3: TsLabel
    Left = 24
    Top = 130
    Width = 357
    Height = 47
    AutoSize = False
    Caption = 
      #1055#1091#1073#1083#1080#1095#1085#1099#1081' '#1082#1083#1102#1095' '#1079#1072#1087#1080#1089#1099#1074#1072#1077#1090#1089#1103' '#1074' '#1073#1080#1083#1076' '#1089#1090#1080#1083#1077#1088#1072'. '#1045#1075#1086' '#1085#1091#1078#1085#1086' '#1089#1086#1093#1088#1072#1085#1103#1090#1100' ' +
      #1090#1086#1083#1100#1082#1086' '#1074' '#1090#1086#1084' '#1089#1083#1091#1095#1072#1077', '#1077#1089#1083#1080' '#1074' '#1073#1091#1076#1091#1097#1077#1084' '#1074#1099' '#1079#1072#1093#1086#1090#1080#1090#1077' '#1089#1086#1079#1076#1072#1090#1100' '#1085#1086#1074#1099#1081' '#1073#1080 +
      #1083#1076' '#1080' '#1087#1072#1088#1089#1080#1090#1100' '#1077#1075#1086' '#1089#1086' '#1089#1090#1072#1088#1099#1084' '#1087#1088#1080#1074#1072#1090#1085#1099#1084' '#1082#1083#1102#1095#1077#1084'.'
    ParentFont = False
    WordWrap = True
    Font.Charset = DEFAULT_CHARSET
    Font.Color = 10329501
    Font.Height = -11
    Font.Name = 'Tahoma'
    Font.Style = []
  end
  object Edit1: TsEdit
    Left = 8
    Top = 24
    Width = 329
    Height = 21
    Color = 1710618
    Font.Charset = DEFAULT_CHARSET
    Font.Color = 10329501
    Font.Height = -11
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
    TabOrder = 2
    SkinData.SkinSection = 'EDIT'
    BoundLabel.Indent = 0
    BoundLabel.Font.Charset = DEFAULT_CHARSET
    BoundLabel.Font.Color = clWindowText
    BoundLabel.Font.Height = -11
    BoundLabel.Font.Name = 'Tahoma'
    BoundLabel.Font.Style = []
    BoundLabel.Layout = sclLeft
    BoundLabel.MaxWidth = 0
    BoundLabel.UseSkinColor = True
  end
  object Button1: TsButton
    Left = 8
    Top = 223
    Width = 321
    Height = 24
    Caption = #1057#1075#1077#1085#1077#1088#1080#1088#1086#1074#1072#1090#1100
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -11
    Font.Name = 'Tahoma'
    Font.Style = [fsBold]
    ParentFont = False
    TabOrder = 0
    OnClick = Button1Click
    SkinData.SkinSection = 'BUTTON'
  end
  object Button2: TsButton
    Left = 336
    Top = 223
    Width = 82
    Height = 24
    Caption = #1059#1076#1072#1083#1080#1090#1100
    TabOrder = 1
    OnClick = Button2Click
    SkinData.SkinSection = 'BUTTON'
  end
  object sEdit1: TsEdit
    Left = 8
    Top = 104
    Width = 329
    Height = 21
    Color = 1710618
    Font.Charset = DEFAULT_CHARSET
    Font.Color = 10329501
    Font.Height = -11
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
    TabOrder = 3
    SkinData.SkinSection = 'EDIT'
    BoundLabel.Indent = 0
    BoundLabel.Font.Charset = DEFAULT_CHARSET
    BoundLabel.Font.Color = clWindowText
    BoundLabel.Font.Height = -11
    BoundLabel.Font.Name = 'Tahoma'
    BoundLabel.Font.Style = []
    BoundLabel.Layout = sclLeft
    BoundLabel.MaxWidth = 0
    BoundLabel.UseSkinColor = True
  end
  object sButton1: TsButton
    Left = 344
    Top = 24
    Width = 74
    Height = 21
    Caption = #1050#1086#1087#1080#1088#1086#1074#1072#1090#1100
    TabOrder = 4
    OnClick = sButton1Click
    SkinData.SkinSection = 'BUTTON'
  end
  object sButton2: TsButton
    Left = 344
    Top = 104
    Width = 74
    Height = 21
    Caption = #1050#1086#1087#1080#1088#1086#1074#1072#1090#1100
    TabOrder = 5
    OnClick = sButton2Click
    SkinData.SkinSection = 'BUTTON'
  end
end
