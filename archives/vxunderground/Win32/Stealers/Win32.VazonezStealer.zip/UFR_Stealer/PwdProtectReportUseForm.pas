unit PwdProtectReportUseForm;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls, Wcrypt2, ExtCtrls, sButton, sEdit, sLabel, clipbrd;

type
  TForm14 = class(TForm)
    Label1: TsLabel;
    Edit1: TsEdit;
    Button1: TsButton;
    Button2: TsButton;
    Label2: TsLabel;
    sLabel1: TsLabel;
    sLabel2: TsLabel;
    sEdit1: TsEdit;
    sLabel3: TsLabel;
    sButton1: TsButton;
    sButton2: TsButton;
    procedure sButton2Click(Sender: TObject);
    procedure sButton1Click(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure Button1Click(Sender: TObject);
    procedure FormDestroy(Sender: TObject);
    procedure FormClose(Sender: TObject; var Action: TCloseAction);
    procedure Button2Click(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

type
  TRSA512_PUBLIC_KEY = packed record
    hdr1:DWORD;
    hdr2:DWORD;
    hdr3:DWORD;
    hdr4:DWORD;
    hdr5:DWORD;
    publ_key:array[1..$40] of byte;
  end;
  TRSA512_PRIVATE_KEY = packed record
    hdr1:DWORD;
    hdr2:DWORD;
    hdr3:DWORD;
    hdr4:DWORD;
    hdr5:DWORD;
    //publ_key:array[1..$40] of byte;
    priv_key:array[1..$120] of byte;{ $40=publ + $E0=priv }
  end;

var
  Form14: TForm14;
  {$Align On}
  //public_key:array[0..1023] of byte;
  public_key:TRSA512_PUBLIC_KEY;
  private_key:TRSA512_PRIVATE_KEY;
  {$Align Off}

implementation

uses Unit3;

{$R *.dfm}

procedure TForm14.Button2Click(Sender: TObject);
begin
  edit1.Text:='';
  sedit1.Text:='';
//  fillchar(bs.steal_key,sizeof(bs.steal_key),0);
//  bs.steal_key_size:=0;
  bs.steal_key_string:='';
  bs.steal_pwd:='';
end;

procedure TForm14.FormClose(Sender: TObject; var Action: TCloseAction);
begin
  EnableWindow(unit3.Form3.Handle, true);
  BringWindowToTop(unit3.Form3.Handle);
  Action := caFree;
end;

procedure TForm14.FormDestroy(Sender: TObject);
begin
  bs.steal_pwd:=edit1.text;
  bs.steal_key_string:=sedit1.text;
end;

procedure TForm14.Button1Click(Sender: TObject);
var
  hProv:HCRYPTPROV;
  hKeyPair,bufLen,bufLen2:dword;
  s:string;
  i:integer;
begin
  fillchar(public_key,sizeof(public_key),0);
  fillchar(private_key,sizeof(private_key),0);
  if CryptAcquireContext(@hProv, nil, nil, PROV_RSA_AES, CRYPT_VERIFYCONTEXT) then
  begin
    if CryptGenKey(hProv, AT_KEYEXCHANGE, $02000000{512 bits} or CRYPT_EXPORTABLE, @hKeyPair) then
    begin
      bufLen:=sizeof(public_key);
      bufLen2:=sizeof(private_key);
      if CryptExportKey(hKeyPair, 0, PUBLICKEYBLOB, 0, @public_key, @bufLen) and
         CryptExportKey(hKeyPair, 0, PRIVATEKEYBLOB, 0, @private_key, @bufLen2) then
      begin
        //bs.steal_key_size:=bufLen;
        //CopyMemory(@bs.steal_key,@public_key,bs.steal_key_size);
        s:='';
        for i:=0 to sizeof(private_key.priv_key)-1 do
        begin
          s:=s+Format('%.2x',[private_key.priv_key[i+1]]);
        end;
        edit1.Text:=s;
        s:='';
        for i:=0 to sizeof(public_key.publ_key)-1 do
        begin
          s:=s+Format('%.2x',[public_key.publ_key[i+1]]);
        end;
        sedit1.Text:=s;
      end;
      CryptDestroyKey(hKeyPair);
    end;
    CryptReleaseContext(hProv, 0);
  end;
end;

procedure TForm14.FormCreate(Sender: TObject);
begin
  edit1.Text:=bs.steal_pwd;
  sedit1.Text:=bs.steal_key_string;
end;

procedure TForm14.sButton1Click(Sender: TObject);
begin
  if edit1.text<>'' then Clipboard.AsText := edit1.text;
end;

procedure TForm14.sButton2Click(Sender: TObject);
begin
  if sedit1.text<>'' then Clipboard.AsText := sedit1.text;
end;

end.
