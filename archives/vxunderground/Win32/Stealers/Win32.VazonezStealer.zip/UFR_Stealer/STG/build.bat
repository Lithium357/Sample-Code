@echo off
\masm32\bin\ml /nologo /c /coff /Cp trashgen.asm
coff2omf trashgen.obj
omf2d trashgen.obj tg.o
del *.obj
pause
