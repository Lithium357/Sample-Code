unit trashgen_lib;

interface
uses Windows;

function garbage: dword; stdcall;
procedure gen_garbage(buf:dword;len:dword;regs:dword);

implementation

{$L tg.o}

function garbage: dword; stdcall; external;

procedure gen_garbage(buf:dword;len:dword;regs:dword);
var
  v1,v2,v3:dword;
begin
  v1:=buf;
  v2:=len;
  v3:=regs;
  asm
    pushad
    mov edi, v1
    mov ecx, v2
    mov ebx, v3
    call garbage
    popad
  end;
end;

end.
