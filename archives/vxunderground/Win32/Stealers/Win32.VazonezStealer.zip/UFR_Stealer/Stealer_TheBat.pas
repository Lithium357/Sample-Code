unit Stealer_TheBat;

interface

uses
  Sysutils,Windows;

function TheBatDecrypt(const Password: String): String;

implementation

function TheBatDecrypt(const Password: String): String;
  const
    b64alphabet2: String = '+-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';

  function DecodeBaseTB(Value: String): String;
    function DecodeChunk(const Chunk: String): String;
    var
      W: LongWord;
      i, j: Integer;
    begin
      W := 0; Result := '';
      j := 3;
      for i := 1 to 4 do
        if Pos(Chunk[i], b64alphabet2) <> 0 then
          W := W + Byte((Pos(Chunk[i], b64alphabet2) - 1)) shl ((4 - i) * 6)
        else
          Dec(j);
      for i := 1 to j do
        Result := Result + Chr(W shr ((3 - i) * 8) and $ff);
    end;
  begin
    Result := '';
    if Length(Value) mod 4 <> 0 then Exit;
    while Length(Value) > 0 do begin
      Result := Result + DecodeChunk(Copy(Value, 0, 4));
      Delete(Value, 1, 4);
    end;
  end;
var
  S: String;
  i: Integer;
  Len: Integer;
begin
  Result := '';
  S := DecodeBaseTB(Password);          // First decryption stage
  if Length(S) < 4 then Exit;           // Empty password
  for i := 1 to 4 do
    S[i] := Chr($FF - Ord(S[i]));       // Decrypt pass length
  Len := PDWord(@S[1])^;
  Delete(S, 1, 4);
  for i := 1 to Length(S) do
    S[i] := Chr(Ord(S[i]) xor $5A);     // Second decryption stage
  Result := '';
  for i := Len downto 1 do              // Third decryption stage
    Result := Result + S[i];
end;

end.
