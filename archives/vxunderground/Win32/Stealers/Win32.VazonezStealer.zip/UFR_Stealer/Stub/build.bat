@echo off

if not exist rsrc.rc goto over1
\masm32\bin\rc /v rsrc.rc
\masm32\bin\cvtres /machine:ix86 rsrc.res
 :over1
 
if exist "stub.obj" del "stub.obj"
if exist "stub.exe" del "stub.exe"

\masm32\bin\ml /c /coff "stub.asm"
if errorlevel 1 goto errasm

if not exist rsrc.obj goto nores

\masm32\bin\Link /STACK:4194304 /SUBSYSTEM:WINDOWS /section:.text,RWE /section:.rsrc,RW "stub.obj" rsrc.res
 if errorlevel 1 goto errlink

dir "stub.*"
goto TheEnd

:nores
\masm32\bin\Link /STACK:4194304 /SUBSYSTEM:WINDOWS /section:.text,RWE /section:.rsrc,RW "stub.obj"
 if errorlevel 1 goto errlink
dir "stub.*"
goto TheEnd

:errlink
 echo _
echo Link error
goto TheEnd

:errasm
 echo _
echo Assembly Error
goto TheEnd

:TheEnd
 
del *.obj
del *.res

"c:\Program Files (x86)\CodeGear\RAD Studio\6.0\bin\brcc32.exe" "stub.rc"
copy "c:\Program Files (x86)\CodeGear\RAD Studio\6.0\bin\stub.res" "stub.res"

pause