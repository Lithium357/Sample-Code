crc32                     PROTO :DWORD, :DWORD

.code

crc32 proc uses ebx crcdata:DWORD, crclen:DWORD
      mov     edx, dword ptr [crcdata]
      mov     ecx, dword ptr [crclen]
      xor     eax, eax
      test    ecx, ecx
      je      @@4
      not     eax
@@1:  xor     al, [edx]
      inc     edx
      mov     bl, 8
@@2:  shr     eax, 1
      jnc     @@3
      xor     eax, 0EDB88320h
@@3:  dec     bl
      jnz     @@2
      dec     ecx
      jnz     @@1
      not     eax
@@4:  ret
crc32 endp
