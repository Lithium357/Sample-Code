SelfDelete proc
        
        SetFileAttributes, addr cmdl, FILE_ATTRIBUTE_NORMAL
        
        GetEnvironmentVariable, offset ComSpec, addr cmdpath, sizeof cmdpath
        lstrcpy, addr cmdprm, addr prm1
        lstrcat, addr cmdprm, addr cmdl
        lstrcat, addr cmdprm, addr prm2
        
        push    SW_HIDE
        push    0
        push    offset cmdprm
        push    offset cmdpath
        push    0
        push    0
        call    dword ptr [_ShellExecute]
        
        ret
SelfDelete endp
