unit VersionInfoEdit;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls, ExtCtrls, shellapi, sButton, sCheckBox, sEdit, sLabel,
  sBevel;

type
  TForm1 = class(TForm)
    Edit1: TsEdit;
    Label1: TsLabel;
    Edit2: TsEdit;
    Label2: TsLabel;
    Edit3: TsEdit;
    Label3: TsLabel;
    Edit4: TsEdit;
    Label4: TsLabel;
    Label5: TsLabel;
    Edit5: TsEdit;
    Label6: TsLabel;
    Edit6: TsEdit;
    Label7: TsLabel;
    Edit7: TsEdit;
    CheckBox18: TsCheckBox;
    Edit18: TsEdit;
    Button17: TsButton;
    Bevel23: TsBevel;
    CheckBox1: TsCheckBox;
    Button4: TsButton;
    Image1: TImage;
    Bevel4: TsBevel;
    Bevel7: TsBevel;
    Label8: TsLabel;
    Bevel1: TsBevel;
    CheckBox2: TsCheckBox;
    Button1: TsButton;
    procedure FormDestroy(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure CheckBox2Click(Sender: TObject);
    procedure Button1Click(Sender: TObject);
    procedure Button4Click(Sender: TObject);
    procedure CheckBox1Click(Sender: TObject);
    procedure Button17Click(Sender: TObject);
    procedure CheckBox18Click(Sender: TObject);
    procedure FormClose(Sender: TObject; var Action: TCloseAction);
  private
    { Private declarations }
  public
  protected
    procedure WMDropFiles (var Msg: TMessage); message wm_DropFiles;
  end;

var
  Form1: TForm1;

implementation

{$R *.dfm}

uses Unit3;

procedure TForm1.FormClose(Sender: TObject; var Action: TCloseAction);
begin
  EnableWindow(unit3.Form3.Handle, true);
  BringWindowToTop(unit3.Form3.Handle);
  Action := caFree;
end;

procedure TForm1.CheckBox18Click(Sender: TObject);
begin
if checkbox18.checked then
  begin
    edit18.Enabled:=true;
    button17.Enabled:=true;
  end
else
  begin
    edit18.Enabled:=false;
    button17.Enabled:=false;
  end;
end;

procedure TForm1.Button17Click(Sender: TObject);
begin
  if not Unit3.form3.opendialog4.Execute then exit;
  edit18.Text:=Unit3.form3.opendialog4.FileName;
end;

procedure TForm1.CheckBox1Click(Sender: TObject);
begin
if checkbox1.checked then
  begin
    image1.visible:=true;
    button4.Enabled:=true;
  end
else
  begin
    image1.visible:=false;
    button4.Enabled:=false;
  end;
end;

procedure TForm1.Button4Click(Sender: TObject);
begin
if Unit3.form3.opendialog1.Execute then
   image1.Picture.Icon.LoadFromFile(Unit3.form3.opendialog1.FileName);
end;

procedure TForm1.Button1Click(Sender: TObject);
begin
  EnableWindow(unit3.Form3.Handle, true);
  BringWindowToTop(unit3.Form3.Handle);
  form1.Release;
end;

procedure TForm1.CheckBox2Click(Sender: TObject);
begin
if checkbox2.checked then
  begin
    edit1.Enabled:=true;
    edit2.Enabled:=true;
    edit3.Enabled:=true;
    edit4.Enabled:=true;
    edit5.Enabled:=true;
    edit6.Enabled:=true;
    edit7.Enabled:=true;
    label1.Enabled:=true;
    label2.Enabled:=true;
    label3.Enabled:=true;
    label4.Enabled:=true;
    label5.Enabled:=true;
    label6.Enabled:=true;
    label7.Enabled:=true;
  end
else
  begin
    edit1.Enabled:=false;
    edit2.Enabled:=false;
    edit3.Enabled:=false;
    edit4.Enabled:=false;
    edit5.Enabled:=false;
    edit6.Enabled:=false;
    edit7.Enabled:=false;
    label1.Enabled:=false;
    label2.Enabled:=false;
    label3.Enabled:=false;
    label4.Enabled:=false;
    label5.Enabled:=false;
    label6.Enabled:=false;
    label7.Enabled:=false;
  end;
end;

procedure TForm1.FormCreate(Sender: TObject);
begin
  DragAcceptFiles(Handle, true);
  checkbox18.Checked:=bs.use_masking;
  edit18.Text:=bs.masking_file;
  checkbox1.Checked:=bs.change_icon;
  if bs.change_icon_file<>'' then
  image1.Picture.Icon.LoadFromFile(bs.change_icon_file);
  checkbox2.Checked:=bs.set_vi;
  edit1.Text:=bs.set_vi_strings[1];
  edit2.Text:=bs.set_vi_strings[2];
  edit3.Text:=bs.set_vi_strings[3];
  edit4.Text:=bs.set_vi_strings[4];
  edit5.Text:=bs.set_vi_strings[5];
  edit6.Text:=bs.set_vi_strings[6];
  edit7.Text:=bs.set_vi_strings[7];
end;

procedure TForm1.FormDestroy(Sender: TObject);
begin
  bs.use_masking:=checkbox18.Checked;
  bs.masking_file:=edit18.Text;
  bs.change_icon:=checkbox1.Checked;
  bs.change_icon_file:=Unit3.form3.opendialog1.FileName;
  bs.set_vi:=checkbox2.Checked;
  bs.set_vi_strings[1]:=edit1.Text;
  bs.set_vi_strings[2]:=edit2.Text;
  bs.set_vi_strings[3]:=edit3.Text;
  bs.set_vi_strings[4]:=edit4.Text;
  bs.set_vi_strings[5]:=edit5.Text;
  bs.set_vi_strings[6]:=edit6.Text;
  bs.set_vi_strings[7]:=edit7.Text;
end;

procedure TForm1.WMDropFiles(var Msg: TMessage);
var
  FileName: array[0..256] of char;
  p:tpoint;
begin
  DragQueryFile(THandle(Msg.WParam), 0, FileName, SizeOf(Filename));
  DragQueryPoint(THandle(Msg.WParam),p);
  if (p.x >= bevel23.Left) and (p.x <= bevel23.Left+bevel23.Width) and
     (p.y >= bevel23.top) and (p.y <= bevel23.top+bevel23.Height) then
     edit18.text:=FileName;
  if (p.x >= bevel7.Left) and (p.x <= bevel7.Left+bevel7.Width) and
     (p.y >= bevel7.top) and (p.y <= bevel7.top+bevel7.Height) then
     begin
       Unit3.form3.opendialog1.FileName:=FileName;
       image1.Picture.Icon.LoadFromFile(FileName);
     end;  
  DragFinish(THandle(Msg.WParam));
end;

end.
