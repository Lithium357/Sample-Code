"c:\Program Files (x86)\Borland\BDS\3.0\Bin\brcc32.exe" "upx.rc"
copy "c:\Program Files (x86)\Borland\BDS\3.0\Bin\upx.res" "upx.res"